# Goal: one faithful source tree, three byte-identical binaries

Reconstruct the shared C source tree the original developers most likely used,
and build `server.dll`, `Europa1400Gold_TL.exe` and `Europa1400Gold.exe` with
100% raw-file byte identity to their references. Both source fidelity and binary
identity are required. A matching binary assembled from fabricated source does
not complete this goal.

This is the durable objective for `goal-dd7dd2dd-8cde-4e14-a043-8674d4ec5631`.
If session goal state is lost, restore the objective from this file. Read
[AGENTS.md](AGENTS.md) for project rules and the relevant Rebrew skill before work.

## Priority and scope

1. Preserve and complete `server.dll`, including faithful reconstruction of
   discarded original source that affects link inputs and relocation reservations.
2. Reverse `Europa1400Gold_TL.exe` as the primary client workstream.
3. Validate `Europa1400Gold.exe` from the same source tree and verified related
   imports. Reverse unique Gold code when needed; do not reconstruct shared logic twice.

Keep one definition of shared game logic, with one managed identity per target.
Use target-specific code only where native evidence supports a difference.
Source placement and headers follow attested `__FILE__` paths, module conventions
and actual cross-TU use. Mark inferred names, layouts and organization explicitly.

## Completion criteria

All criteria must hold against current source, headers, compiler inputs and images:

- All three targets build reproducibly from the unified tree using their pinned
  toolchains. The raw linked files equal their references byte for byte, including
  headers, sections, imports, exports, resources and relocations. Postlink repairs
  cannot substitute for raw-link identity.
- Every reconstructed game function is EXACT in its object or verified as linked
  EXACT in the raw image. Library code/provider evidence is accounted separately.
  Every data byte and symbol placement is verified; unresolved owners stay explicit.
- The server passes `scripts/gate.sh`, including raw-file identity, linked EXACT,
  data/import placement and Wine load/export checks for `Init` and `Exit`.
  Its `.text` VirtualSize is `0x22846` and its import table matches all 100 entries.
- Both clients pass equivalent full-image checks against their own references.
  The current server gate alone does not establish client completion.
- Shared logic has no drifting duplicate bodies. Types, declarations, storage
  owners and native operands are reconciled across targets. No fabricated logs,
  placeholder calls, padding or fixups remain to manufacture agreement.
- All-target lint has zero errors and warnings, required checks pass, and the
  naming, native evidence and continuation documents are current.

Object RELOC, NEAR_MATCHING, PROVEN, bounded fixtures, coverage percentages and
historical green builds do not establish completion. Report file agreement,
accounted text, game reversing progress and stored data verification separately.

## Non-negotiable constraints

- C89 under MSVC6. No naked functions, `_emit` or inline assembly unless positive
  native evidence establishes original assembly at that site. A difficult match
  is insufficient evidence. Preserve reviewed assembly provenance where applicable.
- Run CL/LINK/LIB inside the configured Docker images: plain SP5 for the server,
  Processor Pack SP5 for both clients. Use the project's pinned environment;
  set `REBREW_DEBUG_INFO=OFF` for link checks. No host Wine/compiler fallback.
- Check library attribution before implementing a function. Reuse linked stock
  CRT and available library sources/providers; do not reimplement stock library
  code as game progress or patch third-party archives to force a match. Any
  evidenced original vendor changes must be pinned and reproducible.
- Preserve one storage owner per global and canonical subsystem declarations.
  Interior views, compiler literals, layout spans and imports are distinct facts.
  Never infer allocation ownership from an extern, address proximity or coverage row.
- Follow [naming_conventions.md](docs/naming_conventions.md). Attested spelling
  wins, including original errors. Use established module prefixes and record
  inferred names. Rename through `rebrew source rename`.
- Keep shared types in their owning headers; preserve byte-sensitive declaration
  order. Bind stable type IDs through `rebrew types bind`, separating C layout
  from evidenced allocation/stride extent. Resolve duplicate-symbol findings.
- Never hand-edit managed function, data, type or source-evidence stores. Use
  Rebrew CLI/locked APIs. Preserve unrelated changes and prior verified matches.
- Never weaken a gate, baseline, extent or binding policy to hide a regression.
  Do not restore invented logging calls or relocation reservations to recover bytes.

## Work loop

1. Read `rebrew todo --json` for the selected target and address-keyed findings
   before repeating experiments. Check existing CLI help/tools before writing helpers.
2. Check libraries, native bodies, callees and operands. Compare available
   decompiler seeds, including Kuna, against native evidence; then write real C.
3. Test/diff after source changes. Verify related imports against each destination
   before promotion. Use matching searches only after ordinary edits stall.
4. Reverify affected callers and all target contexts after shared-header, type,
   ownership or declaration changes. Known-binding checks remain enabled.
5. When matching measures disagree, compile an isolated raw native link and measure
   the complete image. Run `uv run --frozen scripts/gate.sh` before every commit. Client changes
   also require client-specific validation. Keep failed checks visible.
6. Read current coverage through `rebrew status` and the live coverage view.
   Use `rebrew coverage export` for an explicit offline snapshot; never maintain
   a second progress store. Record current evidence and concise next steps here.

Use the existing evidence homes: names in `docs/naming_conventions.md`; C shapes,
allocation and exhausted levers in their respective codegen documents; measurement
and process traps in `docs/measure-traps.md` and `docs/workflow-traps.md`; session
attempts and receipts in `docs/TODO.md`. Probes belong in ignored `.scratch/`.
Do not rerun exhausted probes without new evidence.

Fix Rebrew bugs in `/home/maci/Desktop/Projects/relumea/repos/rebrew` with a
reproducing regression test and a passing upstream suite before returning to
reversing. Record every missing capability immediately in that checkout's
`docs/IDEAS-GUILD.md` with the problem, proposed capability and replay evidence.
Keep binary-specific evidence in this project. Publishing and live sync require
explicit authorization; this file does not grant it.

## Current continuation — 2026-10-16

The full goal remains ACTIVE and incomplete. Goal69 repairs the shared
fcn_00451840 bounds contract in existing client_scene_transform.h to
int(float*,float*,float), replacing23 local declarations in23provider/caller
files. Byte-object vector views use explicit float pointers; no pointer is
transported through an integer at these repaired bound-test call sites.
Three forwarding providers now carry their actual float/pointer arguments:
TL402c00 /Gold402720 use float* third and float fourth parameters;405d70 uses
float range, matching existing20.0f/30.0f callers. No arithmetic, control flow,
flags, storage or layout changed. This is inferred C access-contract recovery,
not proof of original typedef or parameter spelling.

Before the sandbox changed, complete paired compilations preserved all64
contexts across31source/header files, including all five weak bodies: raw code,
external operands, compiler-local destinations and literals agree. Ten generated
$L names change in two switch contexts; their actual destinations do not. All
31current file hashes still match that proof. Independent source/native review
finds no blocking issue. Current metadata preserves all6067prior strong statuses
and every prior weak status. Scoped verification completed TL32passes/3oldweak;
Gold29context promotion remains pending. Its resumed verifier hit Docker denial
and asserted before writing any statuses. No new byte match is claimed.

Both native initializers are now named init_LoadObjektScene through the locked
identity writer, with no source/symbol/status/provider claim: TL510c90 is940
executable bytes +4NOPs; Gold50d7f0 is938 +6NOPs. The original diagnostic attests
the name. Complete paired native evidence covers32CFG blocks,80address sites,
36common calls and all12known direct callers' discarded EAX results. Gold adds
46e980 and signed-short loading coordinates. Hidden callers4e4230/4e2910 must
remain separate from the preceding165-byte matched entries. Universe/resource
pointer and loader/traversal callback contracts block faithful source adoption.

Current restrictions deny Docker socket access, keep .git/upstream read-only
and restrict network. Do not use host compiler/Wine or change the backend to
bypass them. Fresh Gold verification, server gate, commit and push have not been
completed for this working tree. The saved286720-byte server image still equals
the reference; it is the previous gate's image, not a fresh build. Lint is clean
for all targets and data has zero conflicts/duplicate definitions. Re-run Gold
scope verification and the complete server gate when access returns, then commit
and push these reviewed changes. Last pushed guild commit remains0fce67f5.
A separate project-config edit appeared after the compiled preservation run: it
removes MSVCRT/ZLIB cflags_presets and an empty SERVER crt_sources entry, among
other keys. Its writer is unknown; preserve it separately. Public config comparison
confirms changed preset fields, so current-configuration/library validation also
remains pending. The source repair patch excludes that unrelated config delta.
The existing upstream SDK-context feature gap has its Goal69 replay committed
locally as7b17d76b; make check/hooks pass, but push and its full test hook have
not run. Do not claim current remote state from cached origin/main.

Next integration work remains the shared838-byte cm_ExCreateGeb and148-byte
placement callback. Factory formal debt is closed by Goal68. Placement needs one
84-byte result view, correct existing Gold iterator/transform providers, and the
universe pointer contract repaired across its existing users. Iterator twins
already share a compatible callback ABI; the measured shared288-byte candidate
is not adopted without required raw-client organization baselines. Preserve
both current providers and explicit actual target selection in the meantime.
The universe audit expands to129direct files /241bindings through headers;
native %s formatting supports a char* record/name view, distinct from the
integer index. Prepare iterator/resource/owner-field transports before one
coordinated declaration cutover. A nine-binding CharacterCount control package
is planned only; it has no new source or compile claim.
Transform signature-only char*→existing typed Node view preserves254bytes in
both providers; a byte-field rewrite emits262 and is rejected. The60-file family
and its integer/list/vector transports are still open, so no transform patch or
new placement callback was adopted. Full reports are in.scratch/goal69.

TL remains1211no-source /1206802bytes and accounted1123675/2491370 (45.1%).
This checkpoint maps two native families at four target addresses and adds zero
matched game bytes. The second is inferred SaveBMP24 TL401ed0 /Gold401b90:
439bytes+9NOP each in unchanged448-byte spans,399fixed bytes/10pairedoperands.
The allocation label supports a role/name inference, not an independently
attested original identifier. No source,status,provider or extent is changed. Prior Goal68
adds151TL/146Gold; Goal67 adds454/client; Goal66 adds760/client. Keep library,
padding, mapping and cleanup separate from new game bytes. Do not restart
exhausted court/queue/office/camera/timer/runner or recent bounded families
without new evidence. Preserve OWN-before-OTHER query order, discarded server
inputs and the cutscene allocator-zero read at address8. Both clients' complete
raw-file/provider/data/storage proofs and broader source contracts remain open.

## History

[Archived checkpoints](docs/goal-history.md) preserve the previous goal file in
full. They are historical evidence, not current status or instructions. Keep this
file concise: replace the current continuation when it changes; write detailed
chronology to `docs/TODO.md` and evidence to its owning document.
