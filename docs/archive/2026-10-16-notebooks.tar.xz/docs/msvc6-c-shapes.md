# MSVC 6.0: C source shapes that decide the emitted bytes

Catalogue of measured source-level patterns against the original `server.dll`,
including successful rewrites and rejected variants. Record each new discovery
here with the target and VA, compiler profile and flags, C spelling, emitted
instruction difference, complete-body result, and evidence location. Separate
observed output from explanations that have not been demonstrated.

The current server build uses plain MSVC 6.0 SP5 and stock libraries. New native
results below compare ordinary toolchain output; historical postlink results
are identified as such and do not establish whole-file identity. Processor Pack
client results, including §202, have a different code generator.

Companion docs: `msvc6-allocator.md` covers register allocation decisions;
this file covers declaration types, operand forms, statement order, and loop
shape. Both are empirical, derived from compile-and-compare against the
target, not from documentation.

Verify any change with `rebrew diff <file>` and `rebrew test <file>`. A `**`
match code marks a genuine structural difference; `~~` is relocation-only and
counts as a match. Object scores are not the ship ruler: see §19 / §118 and
`scripts/linktest.sh`. PROVEN is not a byte match: see §93.

**Look the address up first:** `python3 scripts/whathas.py 0x<VA>`.

## Index by symptom

Sections are numbered in the order they were written, not by topic, and a few
sit out of order in the file (19a after 20, 61a before 61, 117 before 116, 161
before 160). There are no sections 166 to 172. Find the section by what the
diff shows, then read it; many sections belong to more than one row.

| What the diff shows | Sections |
|---|---|
| Wrong index scale, `mov` against `lea` of a global, wrong operand width, uninitialised locals, a wrong symbol under `~~` | 1, 2, 3, 4, 6, 34, 121, 162, 176, 177, 183, 184, 194, 205, 209 |
| Base/index roles swapped, displacement not folded, `lea` fusion, strength reduction | 5, 21, 29, 30, 31, 35, 70, 73, 132, 133, 161, 182, 191, 193 |
| Byte loads and zero-extension (`movzx`, `and eax,0xff`, `xor`+`mov r16`) | 27, 43, 52, 131, 134, 192, 193 |
| x87: `fimul`/`fidiv` forms, `fxch`, `_ftol`, float compares, operand and evaluation order | 8a, 15, 46, 82, 159, 165, 175, 189, 190, 195, 202, 203, 204, 211 |
| Signed against unsigned conditional jumps | 55, 173 |
| Branch polarity, fall-through site, loop form, cold-block placement | 7, 8, 17, 47, 54, 57, 59, 61, 64, 76, 86, 180, 181, 196, 202 |
| `switch` and jump tables | 53, 65, 114 |
| Epilogues merged or duplicated, shared exits and cleanup arms | 56, 74, 112, 117, 202 |
| Two loads or stores in the wrong order, a load sunk or hoisted, RMW idiom choice | 8b, 8c, 10, 20, 42, 45, 48, 60, 77, 78, 80, 86b, 109, 163, 164, 185, 191, 202, 203, 204, 205, 206 |
| `volatile` as a scheduling or form lever, and symbols instead of it | 22, 24, 27, 30, 39, 51, 52, 60, 76, 94, 187, 204, 205 |
| Statement order, hoisting a definition | 33, 84, 85, 116, 118, 163 |
| `eax`/`ecx`/`edx` or callee-saved register choice (also `msvc6-allocator.md`) | 9, 25, 36, 40, 41, 62, 72, 72b, 126, 130, 135, 180, 202 |
| Frame size, prologue, parameter-slot homing, `[esp+N]` offsets | 13, 14, 37, 38, 75, 81, 178, 179, 202 |
| Constants rematerialised or CSE'd, shared clamp values, ternary constant forms | 23, 26, 28, 62, 63, 126, 199, 202, 211, 212 |
| Inline `memset`, struct copy, `rep movsd`, inlining, fill loops | 11, 71, 104, 174, 197 |
| A store or call present in one side only, call order and call counts, wrong argument | 16, 66, 67, 68, 111, 113, 188 |
| Aliasing and `#pragma optimize` | 44, 61a, 204, 206 |
| `__asm` blocks | 69, 97 |
| CFLAGS, `/Ox` against `/O2`, the sp5-pp toolchain pins | 12, 49, 58, 90, 91, 105, 106, 107, 115, 142 to 147 |
| `.data`/`.rdata`/BSS placement, COMDATs, the import table | 98, 100 to 103, 148 to 158, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221 |
| Status and ruler traps: `match_count`, PROVEN, RELOC, residue attribution | 16, 18, 19, 19a, 32, 79, 83, 87, 88, 89, 93, 95, 96, 99, 108, 119, 160, 205, 207, 208, 209, 210, 211 |
| Localising a fault in the linked residue (`drift_windows`, displacement windows) | 122 to 129, 136 to 141 |
| Summaries of what the residue is | 50, 92, 139, 141 |
| Per-function case notes (`gm_AllocSpieler`, `CrashDump`, `ServerMainThread`, `srv_LoadBuf`) | 81, 109, 110, 116, 117, 120, 126, 127, 140, 159, 185, 186, 187, 188, 196, 197, 198, 199 |

Walls (spellings exhausted without a match) are in `codegen-walls.md`; method
traps in `measure-traps.md`; linker and PE layout in `msvc6-link-layout.md`.

## How to probe a hypothesis

Ship path (the compile that actually links):

```sh
python3 scripts/whathas.py 0x<VA>
python3 scripts/probe_function.py --va 0x<VA> --file <file.c>
bash scripts/linktest.sh <file.c>
```

Never add a `// CFLAGS:` header (per-file, not per-function, §12). Isolated
`.scratch` probes are for *mechanism* only and miss TU flags and CMake
toolchain pins (`measure-traps.md` §5):

```sh
cd .scratch
rebrew-cmake-cl /nologo /c /MT /O2 /Gd probe.c
objdump -d probe.obj
```

Ground truth for a target comes from `rebrew binary asm show <VA> --size N --json`.

---

## 1. Global array element type sets the addressing scale

The declared element type picks the index scale in the addressing mode. A
wrong type is invisible in C but changes every access.

Target emitted `mov cx, word ptr [eax*4 + g_entity_slot_table]`; the source
declared the table as `unsigned short`, so it emitted `mov cx, word ptr
[eax*2]`, scale 2 against scale 4.

The table holds 4-byte entries with a 189-entry stride (189 x 4 = 0x2f4) and
only the low word of each entry is read. Declaring the element type as the
stride unit, indexing in entries, and narrowing at the point of use restores
scale 4:

```c
/* 189 4-byte entries per object type; only the low word of each entry is read. */
extern unsigned int g_entity_slot_table[];

word1 = (unsigned short) g_entity_slot_table[(unsigned int) *(unsigned char*) 0x10035439 * 189];
```

`src/Develop/DieGildeAddOn/game/friedhof_logic_c/gv_HireProductionWorker.c:15,72`

One declaration fix corrected four functions: `gv_HireProductionWorker`
(0x100111b0), `gv_ExtendProductionTime` (0x100113b0),
`cm_ExTransferCurrencyNoKill` (0x1000d8a0), `gm_QueryEntitySum` (0x100196c0).

A byte-offset form (`*(unsigned short*)((char*) tbl + idx * 0x2f4)`) also
byte-matches at some sites and is what `cm_ExTransferCurrency` and
`cm_ExSellObjekt` already use. Do not convert working call sites; the two
forms are not interchangeable everywhere.

## 2. Pointer vs array: `mov` load against `lea`

`extern char* g_slot_table;` declares a pointer variable, so the compiler
loads its contents: `mov ecx, dword ptr [g_slot_table]`. When the symbol *is*
the array, the original computes an address instead: `lea ecx, [esi + g_slot_table]`.

Take the address at the use site:

```c
result = (int) gm_GetEntityTableEntry((char*) &g_slot_table + idx);
```

`src/Develop/DieGildeAddOn/game/spiel62.c:374`,
`src/Develop/DieGildeAddOn/game/spiel622.c:378`

Fixed `gm_CheckStatLevel` (0x100181a0) and `gm_ResolveParentEntity`
(0x10019ae0). Note `g_slot_table` is declared inconsistently across the tree
(pointer in the `spiel*` files, `char[]` in `command_internal.h`); fix at the
use site rather than unifying the declaration, which would disturb functions
that already match.

## 3. Uninitialized locals from decompilation

A local read before assignment is always a decompiler artifact. The original
disassembly shows what the value should have been. Two shapes seen:

A loop pointer never given its base. The target opens with
`mov edx, g_entity_base` before the fill loop:

```c
ptr = (char*) g_entity_base;
do {
    memset(ptr, 0, 0xAC);
    ...
} while ((int) ptr < (int) g_entity_end);
```

`src/Develop/DieGildeAddOn/game/spiel62.c:285`, fixing `gm_InitEntitySlots`
(0x100180d0).

An index computed from itself (`idx = idx * 189;` with `idx` never set). The
target's `mov cl, byte ptr [g_current_season]` names the real source:

```c
idx = (unsigned int) (unsigned char) g_current_season * 189;
```

`src/Develop/DieGildeAddOn/game/spiel622.c:327`, fixing
`gm_AccumulateTyped2` (0x10019a20).

## 4. Wrong global in a guard

Two globals of the same type read identically in C and differ only by
address. `ReportMessage` guarded on `g_handler_started` (0x10034680) where the
target loads `g_panic_callback` (0x10034610):

```c
if (!g_panic_callback) {
    MessageBoxA(0, "ERROR-Handler has not been started...", "Error!", 0x10030);
    return;
}
```

`src/Develop/Units/Error/Error_c/ErrorModule2.c:97`, fixing 0x100035c0.

Cross-check every global address in the target disassembly against the VA
comments in `src/Develop/rebrew_globals.h`. That header also carries
duplicate declarations of the same symbol, so a plausible-looking name is not
evidence the address is right.

## 5. An explicit pointer local defeats the induction-variable rewrite

Carrying a walking pointer alongside an index makes MSVC 6.0 treat the
pointer as a user variable it must materialize where written, emitting a bare
offset with no base (`mov ecx, 0x46`; `mov ax, word ptr [ecx]`). The target
instead sets the base once and advances it: `mov ecx, g_plant_info_table`
then `mov ax, word ptr [ecx + 0x46]` / `add ecx, 0x46`.

Express the walk purely through the index and let the compiler build the
induction variable:

```c
char* __cdecl lb_SearchRecordTable(int key)
{
	unsigned int idx;

	idx = 0;
	while (*(unsigned short*) ((char*) &g_plant_info_table + idx * 0x46) != 0) {
		if ((int) *(unsigned short*) ((char*) &g_plant_info_table + idx * 0x46) == key)
			return (char*) &g_plant_info_table + idx * 0x46;
		idx++;
	}
	return 0;
}
```

`src/Develop/DieGildeAddOn/auxillary/plant.c:12`, fixing 0x10014ee0 at
69/69 bytes. The repeated index expression is deliberate: the strength
reduction to `lea eax,[edx*8]; sub eax,edx; lea eax,[eax+eax*4]` comes from
the compiler, and hoisting it into a named pointer suppresses it.

## 6. Local variable width

`unsigned int` where the original kept a value in 16 bits changes the loop
body. The tell in the target is a 16-bit update paired with a widening mask
each iteration: `mov ax, word ptr [...]` plus `and eax, 0xffff`. Match the
width the disassembly implies rather than defaulting to `int`. The widening
mask itself is a `volatile` tell rather than a width tell: check section 52
before retyping the load.

## 7. Branch polarity: merge sequential returns

Two consecutive guards returning the same value compile to two epilogues:

```c
if (!slot) return -7;
if (a != b) return -7;
```

The target had one. A short-circuit merge produces the single shared exit and
flips the branch sense (`jne` to `je`):

```c
	slot = gv_GetSlotEntry(workers, *(int*) ((char*) req + 0xc),
	                    *(unsigned char*) ((char*) req + 0x10));
	if (!slot ||
	    *(unsigned short*) ((char*) slot + 8) !=
	        *(unsigned short*) ((char*) owner + 0x50))
		return -7;
```

`src/Develop/DieGildeAddOn/game/friedhof_logic_c/AssignProductionSlot.c:56`

**The merge needs *every* fail path to share the exit; mixing `return` with `goto`
un-merges it (round 844, isolated probe).** Section 7 above gives the short-circuit
spelling for the two-guard case. The general rule, measured on a minimal function
compiled by this toolchain with `/O2 /Gd` and disassembled:

| source | epilogues emitted |
|---|---|
| `if (a==0) return -1;` … `if (g()==0) goto fail;` … `fail: return -1;` | **two** (`or eax,-1; ret` twice) |
| `if (a==0) goto fail;` … `if (g()==0) goto fail;` … `fail: return -1;` | **one** (shared at the fail label) |

So a `goto` to a trailing label *does* produce the shared exit; it is not the goto
that fails, it is leaving **one** of the fail paths as a direct `return`. Converting
every fail path in the function to the same `goto`, or collapsing them into one
short-circuit condition per §7, is what merges.

**But exit-sharing is necessary, not sufficient: position decides (round 845).** Applying
this to `gv_ExAllocGraveyardWorker` by converting its last direct `return 0xffff` to
`goto fail_ffff` gives `match` 615 -> **302** and shrinks the object 1040 -> **1031**,
below the reference. The `!slot` test sits *before* the `j >= count` guard that already
jumps to `fail_ffff`, so the reference's shared epilogue is reachable from below and an
equal-but-earlier jump does not share it. The file's own record of the same edit
(`if (!slot) goto fail_ffff;` collapsing the pair, 246) is the same finding on a later
body. **Read the merge rule as "this is when msvc6 shares an exit", not "this edit will
work"**: measure every application at the link.

Probe recipe, since this is cheap to re-check: compile a four-line function with the
`cl` wrapper in the msvc6 image and `objdump -d` it: the epilogue count is visible
without touching the tree.

## 8. Loop shape: `for(;;)` with early return vs `do/while` with a tail return

The exit structure decides branch layout and total size. A `for(;;)` with
returns inside the body emits an epilogue per return; a `do/while` with a
shared tail return emits one. Read the target's exits and mirror the count
before tuning anything else. When the residual is a back-edge encoding rather
than an epilogue count, section 57 is the discriminator. When the reference
keeps N identical epilogues and we merge them, that is walls §2 / this file
§74, not a loop-shape spelling.

## 8a. x87 memory-operand forms: `fimul`/`fidiv` vs `fild` + `fmulp`/`fdivp`

**Object-only until linked.** `volatile` pins here raise `aligned` and usually
lose at the link (§94). Qualifier direction is §52, not "add volatile to get
`xor`/`mov`".

MSVC 6.0 fuses an integer operand into `fimul <mem>` or `fidiv <mem>` only
when that operand is memory-resident at the FPU op. When its last use is the
multiply or divide itself, the value stays in a register and you get the
two-instruction `fild` + `fmulp`/`fdivp` form instead.

A `volatile` alias forces residency without emitting extra code ahead of the
FPU op. Two shapes, both verified in `.scratch/probe_fi3.c` and `probe_fd1.c`:

Read through the alias (also schedules the mask after the `fild`, matching the
target's `and eax,0xff` placement):

```c
volatile int* p2_alias;

p2_alias = (volatile int*) &param2;
*p2_alias = param2 & 0xff;
cached = cached * (int) *p2_alias;      /* fimul dword ptr [esp+0x18] */
```

Assign through an alias, where the local is read normally afterwards:

```c
int* d_alias;

d_alias = &divisor;
*d_alias = (*(unsigned short*) (entity + 0x36) == 0) + *(unsigned short*) (entity + 0x36);
quot = quot / divisor;                  /* fidiv dword ptr [esp+0x14] */
```

`src/Develop/DieGildeAddOn/game/spiel622.c` in
`gm_CalculateProductionValue` (0x10019720), which went 132 to 322 matched
instructions across these changes plus 8b and 8c below.

### Pick the weaker lever when the target's schedule is looser

Both a `volatile` alias and a plain `int*` alias force residency and produce
the fused `fidiv <mem>`. They differ in ordering:

- **`volatile` forces residency *and* ordering.** Volatile accesses are
  ordered against each other, so a volatile store cannot sink past a volatile
  read elsewhere in the function.
- **A plain alias forces residency only**, leaving MSVC 6.0 free to schedule
  the store where it likes.

In `gm_CalculateProductionValue` the numerator needs a volatile *read* to pin
its load ahead of the divisor computation, but the divisor then needs a
**plain** alias: a volatile store there would be ordered against that read and
forced ahead of the `fild qword`, whereas the target sinks
`mov [esp+0x14],edx` after it. Using volatile at both sites scored 141;
volatile read plus plain alias scored 322.

Reach for `volatile` when you need ordering, and the plain alias when you need
residency without constraining the schedule.

## 8b. A folded `cmp` hides a load the target keeps in a register

Where the target reads a byte into a register and compares it
(`mov al, byte ptr [esi+0x21]` then `cmp al, 3`), MSVC 6.0 will happily fold
both into `cmp byte ptr [esi+0x21], 3`, which is one instruction shorter and
lands in the wrong place relative to a neighbouring FPU op.

Hoisting into a plain local does not prevent the fold. Reading through
`volatile` does, and also pulls the load ahead of the FPU instruction:

```c
char kind;

kind = *(volatile char*) (entity + 0x21);
cached = cached * (int) *p2_alias;      /* mov al,... ; fimul ... ; cmp al,3 */
```

`src/Develop/DieGildeAddOn/game/spiel622.c:216`. This single change moved
0x10019720 from 119 to 207 matched instructions, the largest single jump of
the session.

## 8c. A volatile read pins load order between two field reads

**Object-only until linked.** Default expect a link loss (§94). Qualifier
direction is §52.

Section 10 covers reordering adjacent field reads by moving the C statements.
When that is not enough, because a neighbouring volatile access or an FPU op
lets the compiler sink the load anyway, a volatile *read* on the operand that
must come first pins it there.

The target loads the numerator `[esi+0x22]` before the divisor source
`[esi+0x36]`; plain statement reordering did not reproduce that, and hoisting
the numerator into an ordinary local left it in place:

```c
quot = (double) (unsigned int) *(volatile int*) (entity + 0x22);
```

That fixed the order and the qword home at `[esp+8]`/`[esp+0xc]`, matching
target instructions 30 through 47. Combined with the plain-alias divisor from
8a, 0x10019720 went 263 to 322.

Cost: a volatile read is also an ordering barrier, so it constrains every
other volatile access in the function. See the "weaker lever" note in 8a.

## 9. Register roles follow order of first use

When the instruction stream matches and only register roles differ (esi and
edi exchanged, everything else identical), the cause is allocation order, not
logic. MSVC 6.0 assigns in order of first use.

Reorder the declarations, or the statements that first touch each variable,
until the roles line up. In `AssignProductionSlot` the counter `i` and the
walking pointer had to be established in the target's order:

```c
	i = 0;
	entries = *(int**) ((char*) slot + 0x10);
	selected = entries;
	count = g_worker_entry_count[*(int*) ((char*) req + 0xc)];
	for (; i < count; i++) {
```

`src/Develop/DieGildeAddOn/game/friedhof_logic_c/AssignProductionSlot.c:62`
closing out 0x10010fa0 at 525/525 after the size was already correct.

### 9a. Shorten a live range to break an esi/edi tie

When both candidates for esi/edi are established at the same point (two
parameters, first touched in the same call), reordering first use has nothing
to reorder and section 9 does not apply. What decides the tie is then the
*length* of each live range, and the lever is a fresh local that ends one of
them early.

`ls_LoadSavegameHeader` (0x10012470) passes `stream` and `dest` to the same
function ~25 times. Advancing the destination in the tail,

```c
dest += 0x9c;                 /* stream->edi, dest->esi: 801/857 */
```

keeps `dest` live to the last instruction and loses the tie. Hoisting the
advance into a separate local ends `dest` at the hoist:

```c
tail = dest + 0x9c;           /* stream->esi, dest->edi: 819/857 */
```

No instruction is added or removed; only the register assignment changes.

Neither half was the whole answer here: the hoisted `tail` gave up the
target's duplicated `add edi,0x9c` and its memory-form version compare, so
819/857 was the ceiling for this lever alone. Section 40 closes the function
by keeping the `dest += 0x9c` shape and cutting dest's *reference count*
instead of its live range.

Diagnostic for this class: delete the statement you suspect of adding weight
and recompile. If the roles flip, that statement is the trigger and the fix is
to shorten its variable's range, not to remove it. Adding a use of the *other*
variable also flips the tie (`if (stream == 0) return 0;` scored the target
roles) but costs instructions; prefer the live-range split.

## 10. Load scheduling between adjacent field reads

Which of two struct fields loads first can differ with the instruction stream
otherwise identical. Reorder the C statements that read them. This was the
residual difference in `AssignProductionSlot` after the loop shape was
correct: the target loads `slot->0x10` before `req->0xc`.

## 11. Inline memset expansion (partial result, no byte match)

`m_init` (0x100068e0) emits a head-alignment prelude:

```
lea ecx,[edi+edi*2]; and ecx,3; sub ebx,ecx; jle; rep stosb; ...; rep stosd; ...; rep stosb
```

`lea ecx,[edi+edi*2]` with `and ecx,3` computes `(-p) & 3` (3 is -1 mod 4).

A plain `memset` never emits this. Probes across pointer type (`void*`,
`char*`, `unsigned char*`, `int*`), destination provenance (allocator return
vs reloaded from a global), length shape (constant, runtime, provable
multiple of 4), and 12 flag sets all produce the plain
`shr ecx,2; rep stosd; and ecx,3; rep stosb` form
(`.scratch/probe_ms1.c`, `probe_ms3.c`, `probe_ms4.c`).

An explicit align-up split in pure C does **not** emit the prelude either. An
earlier revision of this section claimed it did, from a partial reading of
`.scratch/probe_ms2.c` `w1`; disassembled in full, `w1` differs at every point
of the shape:

| target | align-up split `w1` |
|---|---|
| `lea ecx,[edi+edi*2]` + `and ecx,3` | `neg edx` + `and edx,3` |
| `sub ebx,ecx` + `jle` | `sub ebp,edx` + `test ebp,ebp` + `jle` |
| 3 reps: stosb, stosd, stosb | 4 reps: two complete stosd/stosb memsets |

Its 162 bytes are two full memset expansions landing on the target's size by
coincidence, not the target's shape. It also scores far worse than the plain
`memset`: 42 to 66 matched across `.scratch/ipp/bodies/split_a..h.c`, and 54
when combined with parameter-slot homing (`.scratch/ipp/bodies/u1.c`), against
105 for the plain form. Do not re-try the split.

Two measurements show why the prelude is a different template, not a
scheduling or residency difference:

- `sub reg,reg` followed directly by `jle`, with no `test` between, is not
  msvc6 output. Every C spelling of "difference <= 0" emits `sub; test; jle`
  (13 spellings in `.scratch/ipp/p29.c` and `p30.c`); `< 1` gives `cmp $1`,
  and only a comparison against 0 with a dead difference fuses, as `sub; jns`.
  Across all 576 catalog functions of `server.dll`, `sub`+`jle` occurs at
  exactly 6 addresses, the 6 prelude sites and nowhere else
  (`.scratch/ipp/scan_target_subjle.py`, output in `subjle_scan.txt`).
- The inlined `memset` always orders its two reps
  `shr ecx,2; rep stosd; and ecx,3; rep stosb`. The prelude runs `rep stosb`
  first, then `shr; rep stosd`, then a third `rep stosb`: three reps in a
  different order.

So the original claim stands after all: no pure-C shape found so far emits the
prelude, and a byte match needs asm. Best pure-C result is 105/162.

## 12. CFLAGS are per-file in practice, not per-function

`rebrew-functions.toml` stores `cflags` per function, but a compile covers the
whole translation unit. Adding a `// CFLAGS:` header for one function caused
`rebrew test` to write those flags into the toml entry of a *sibling*
function in the same file, breaking `m_FreeTracked` (0x10006820) from
RELOC 188/188 to SIZE_MISMATCH.

A flag one function needs can break another in the same file. `/Oy-` on
`m_init` is exactly this conflict: the target's frame pointer needs
it, its file-mate must not have it. Where the flag has a `#pragma optimize`
equivalent, use that instead; see section 13 for the frame-pointer case.

After any flag change, diff per-function status against the previous run
rather than reading the summary count:

```sh
rebrew verify --json 2>/dev/null > .scratch/after.json
jq -r '.results[] | "\(.va) \(.status)"' .scratch/before.json | sort > .scratch/b.txt
jq -r '.results[] | "\(.va) \(.status)"' .scratch/after.json  | sort > .scratch/a.txt
join .scratch/b.txt .scratch/a.txt | awk '{if ($2!=$3) print}'
```

Empty output means no drift. `rebrew-functions.toml` is tool-managed and
write-protected; reset a corrupted entry by re-running `rebrew test` with an
explicit `--cflags`, not by editing the file.

## 13. Per-function frame pointer without a CFLAGS header

`#pragma optimize("y", off)` around a single function emits
`push ebp; mov ebp, esp` and `pop ebp` under `/O2 /Gd`, with no `// CFLAGS:`
header and no effect on its file-mates. It is the way out of the section 12
conflict: `m_init` (0x100068e0) needs the frame pointer, and
`m_FreeTracked` (0x10006820) in the same file must not have it and stays
RELOC 188/188.

```c
#pragma optimize("y", off)
void __cdecl m_init(int n)
{
	/* ... */
}
#pragma optimize("", on)
```

Close with `#pragma optimize("", on)`, which restores the command-line
settings; the following function compiles unchanged. Verified by compiling
three identical bodies in one file with only the middle one wrapped
(`.scratch/ipp/p4.c`): only the middle one gained the frame.

Address-taking a parameter or a local does not force a frame; msvc6 keeps
addressing them off `esp`. `_alloca` does force one, but it also emits the
allocation code, so the pragma is the clean lever.

## 14. Homing a value in the incoming parameter slot

Assigning to a parameter and reading it back through a `volatile` alias spills
that value to the parameter's own stack slot and reloads it from there,
reproducing a target that keeps a value in memory across a call instead of in
a register:

```c
n = len;                                                     /* plain store */
memset(g_array_ptr, 0, (unsigned int) *(volatile int*) &n);  /* volatile read */
```

This emits `mov [ebp+8],edi` then `mov ecx,[ebp+8]`, matching
`m_init` 0x1000691b-0x10006924 and raising it from 97 to 105 matched
bytes. The same idea as section 8a applied to a call boundary rather than an
FPU operand: the read forces the value to live in memory, and reusing the
parameter as the destination picks which slot.

**The store must be plain; only the read is `volatile`.** This is the section
8a residency/ordering distinction applied to an integer spill. A `volatile`
store is ordered against the surrounding volatile accesses, so it floats up
ahead of the allocator call and drags the `add esp,4` and the `g_array_ptr`
store out of the target's order, costing 15 bytes: `*(volatile int*) &n = len`
scores 90, the plain `n = len` scores 105, with identical read-backs. Homing
via a plain `int*` alias (`int* pn = &n; *pn = len;`) instead of assigning to
the parameter scores 90 to 104 depending on the read form, never above.

## 15. `_ftol(expr)` pushes a double; a plain `(int)` cast does not

`__ftol` takes its argument in `st(0)` and returns in `eax`. Spelling the
conversion as an explicit call to a `_ftol` declared with a parameter list
makes msvc6 marshal the value as a normal stack argument first:

```
sub esp,8 ; ... ; fstp qword ptr [esp] ; call __ftol ; add esp,8
```

A plain `(int)` cast of the same expression emits only `call __ftol` with the
value already on the x87 stack, three instructions and 11 bytes shorter. The
target has no `sub esp,8` / `fstp qword ptr [esp]` pair anywhere, so any such
pair in the candidate is a spelling artefact, not a scheduling difference.

```c
/* pushes a double */
rnd = gm_RandomMod((unsigned short) _ftol(*(float*) (slot + 0x1c) * k));
/* leaves the value in st(0) */
rnd = gm_RandomMod((unsigned short) (int) (*(float*) (slot + 0x1c) * k));
```

`src/Develop/DieGildeAddOn/game/spiel_c/gm_AllocSpieler.c:457`
closed the last 6 bytes of `gm_AllocSpieler` (0x10018850), taking it
from 3695 to exactly 3689 bytes and 608 to 670 matched.

**Not interchangeable across call sites.** The same rewrite applied to the four
other `_ftol` sites in that function *lowered* the score every time (670 to 649,
608 to 536, 573 to 492/515). Where the result feeds a loop counter that msvc6
keeps in a register, the pushed form is what the target emits. Convert one site
at a time and keep only the ones that measure better.

A later session found one more convertible site in the same function: the
second age loop, `for (n = _ftol((double) *(u16*)(slot + 0xa) - *(float*)(slot
+ 0x20)))`, converted cleanly and took the score from 711 to 715. The four
remaining sites were each retested from that new base and still lose badly
(715 to 491, 466, 464, 471), which confirms the per-site rule rather than
weakening it. Retest every site again after any change that moves the
schedule; convertibility is a property of the current surrounding code, not of
the call site alone.

The conversion also has a frame-layout side effect worth knowing. Removing the
`sub esp,8` / `fstp qword ptr [esp]` pair freed the spill slot that had pushed
the loop index from the target's `esp+0x1c` to `esp+0x20`, which was the first
mismatching byte of the whole function (offset 15). Declaration order is *not*
a lever for this: placing the index at every position among the locals scored
identically, because msvc6 assigns spill slots by liveness. Where a frame slot
is off by one, look for a live range to remove, not a declaration to move.

## 16. Compare the call skeleton before chasing instruction diffs

`rebrew diff` aligns instruction-by-instruction, so a single early structural
difference desynchronises everything after it and the `**` markers past that
point are alignment noise, not real divergences. Extracting the ordered list of
relocation targets from both sides gives an alignment-independent skeleton:

```sh
rebrew binary asm show <VA> --size <N> --json| jq -r '.instructions[]|select(.mnemonic=="call")|.operands'
objdump -r <candidate>.obj | grep 'DISP32\|REL32' | awk '{print $3}'
```

A mismatch in that list is a genuine logic error: a call the reconstruction
invented, omitted, or placed in the wrong branch. In `gm_AllocSpieler`
this found a `gm_RandomMod(2)` / `gm_RandomFloat01()` pair the source ran on the
two-parent path where the reference only has it on the no-parent path, and a
`gm_RandomMod(0x10)` drawn twice in the reference (first result discarded) but
once in the source.

Counting instructions *between* consecutive calls localises the remaining work
to a specific segment without depending on the aligner. A segment whose count
is short by a double-digit margin is missing a branch, not scheduled
differently: a 20-instruction gap pointed straight at a four-way class pick
(reference 0x10019228-0x100192b3) that the source had collapsed to two arms,
worth 35 matched bytes and 27 instructions once restored.

The helper used here is `.scratch/seg.py`; it needs only the two instruction
lists and the call indices.

## 17. Out-of-line block placement is not steerable from source

> **Narrowed in part by §59.**  The blanket claim holds for the *statement* used to
> reach a block: spelling a guard as `if (cond) goto L;` compiles to a byte-identical
> object to the inline `if`, so the label is not the lever.  It does **not** hold for
> the block's *creation* order: writing the guards as `if (success) {...} else {
> error }` makes the front end create the `else`-blocks innermost-first, which places
> the cold handlers at the tail in reverse source order.  That was worth -29 linked
> bytes on CrashDumpUnhandledExceptionFilter (0x10002770).  Read this section with
> §59, not instead of it.

MSVC 6.0 decides whether a `goto`-target block sits inline or out of line in
its own layout pass. Source position does not influence it.

In `ServerMainThread` (0x100093a0) the target keeps the host-slot block out of
line, ending in a 5-byte backward `jmp`:

```
0x1000973a  mov eax, ecx ... or dword ptr [eax*4 + g_connections], 8
0x10009756  jmp 0x10009657
```

The reconstruction emits the same instructions with the same operands, but
placed so control falls through into the following loop, so the block needs
only a 2-byte skip `jmp`. That 3-byte difference is the whole size deficit:
obj 2431 against a target of 2434.

Three placements were tried, all compiled and measured, all leaving both the
match count and the object size unchanged at 1122/2434 and 2431:

- label between the two `goto`s inside the later loop (original shape)
- label moved after the `transfer_pending` arm, with an extra `goto`
- label moved past the function's `return`, at the very end of the body

Rewriting the search loop so the found case runs inline instead of via `goto`
(no label at all) scored **776**, well below the 1122 baseline.

Do not spend further attempts steering block placement from C. Treat a
remaining out-of-line/inline difference as a layout-pass artifact and work the
instruction content instead.

## 18. Byte-width levers move encodings, not always the score

The same function's target holds a constant in a byte register and computes a
mask in 8 bits:

```
mov bl, 7 ... and al, 8 ; neg al ; sbb al, al ; and al, bl ; add al, 2
```

The reconstruction emitted `mov ebx, 7` / `and eax, ebx` (3 bytes larger).
Forcing byte width does reproduce the target encoding exactly, and both
formulations below produced `mov bl,7`, `neg al`, `sbb al,al`, `and al,bl`:

```c
/* scored 854 */
cmd[0x10] = (unsigned char) ((unsigned char) (-(signed char) ((c & 8) != 0) & ready_flag) + 2);
/* scored 881 */
host_ready_mask = (unsigned char) ((c & 8) ? 0xff : 0);
cmd[0x10] = (unsigned char) ((host_ready_mask & ready_flag) + 2);
```

Both scored *below* the 1122 baseline, whose plain int ternary keeps the wrong
encoding. Matching a local encoding can still cost more downstream than it
gains: the byte forms perturbed register allocation across the rest of the
loop. Measure the whole function, never the instruction you aimed at.

A byte-typed local alone does not force the narrow register: routing the
constant 7 through an `unsigned char` local still emitted `mov ebx, 7` while
the ternary stayed in int context. The narrow form appears only once the whole
expression is byte-typed.

## 19. `match_count` is positional, so one size delta hides a good match

`match_count` compares the two byte streams *at the same offset*, with
relocation slots masked (`rebrew/src/rebrew/core/matching.py:488`). It is not
an alignment-aware score. A single displaced block therefore charges every
later byte as a miss, and a low percentage can hide a function that is almost
entirely correct.

`ServerMainThread` (0x100093a0) scores 1122/2434 (46%). Aligning each region at
its own best shift would score 1955/2434, and under an optimal instruction
alignment 466 of 627 instructions are already byte-identical. Roughly 942 of
the ~1300 missing bytes are cascade from one 3-byte size deficit.

Before working an instruction, check whether it is a cause or a symptom.
Re-score the candidate stream with each region shifted to its own best offset:
what the shift recovers is cascade, and only what remains is real. Applied
here, that reduced 457 reported structural differences to a single `jne`.

The same reasoning localises the true residual. In the 672-byte prefix that is
still aligned, the only non-relocation differences were one `jne` and three
`jmp` displacements off by exactly 3, all consequences of the same deficit.

Also beware unlinked relocation slots when reading a raw diff. An unlinked
`.obj` leaves them zero and the scorer masks them, but a *non-zero* slot is not
masked and is a real loss. `(&g_max_players)[1]` emitted `mov dword ptr [4],
eax`, whose `04000000` field failed the zero-dword heuristic; splitting the
neighbour into its own `extern int g_tick_rate` restored `mov dword ptr [0]`
and removed the false mismatch.

## 20. Statement order does not move stores into the same buffer

MSVC 6.0 schedules stores to one stack buffer freely, so reordering the C
statements that fill a packet changes nothing. In `ServerMainThread`, swapping
the `cmd+0x18` and `cmd+0x1c` stores produced byte-identical output.

Rewriting a loop between `while`, `do/while`, and `for(;;)` with explicit
breaks is likewise inert once the bodies are equivalent: all three shapes of
the flag-scan loop compiled to the same bytes. The compiler canonicalises the
loop before layout. Section 57 draws the boundary: shape is a lever only where
the divergence is a back edge pushed out of `rel8` range, and register pressure
elsewhere leaves it inert.

What *does* move is the order in which distinct globals are first read, since
that sets register roles. Reordering the sync-packet loads changed the object
size from 2431 to 2432 and the score from 1122 to 1121. Real lever, wrong
direction here, but worth trying when register roles are the mismatch.
Stores through a *fresh pointer* can move (§86b). Still measure at the link.

## 19a. `match_count` is a positional byte compare (same rule as §19)

Restates §19. `match_count` counts byte positions that agree after masking
relocation slots. It does not realign after an insertion or deletion.

One extra or missing instruction early in a function therefore shifts every
later byte and collapses the score, even when the whole remainder is
semantically correct. A low percentage on a large function is evidence of an
early divergence, not of widespread wrongness.

Read the percentage as "bytes correct at their target offset", and judge real
progress from `rebrew diff`: specifically how far the matching prefix extends
before the first `**`, and how many `**` clusters remain. A change that fixes
an early divergence can jump the score by hundreds; a change that adds one
instruction near the top can erase an otherwise-correct body.

## 21. Fold the offset into the pointer before the access

When the target computes an address once and reuses it (`add eax,edx; fstp
[eax]`, or a `mov`/`inc` pair on a cursor), repeating the offset expression
inside the access keeps MSVC 6.0 in a scaled-index addressing mode and picks a
different scratch register. Doing the arithmetic in a separate statement first
forces the materialized address the target uses.

`cm_ExChangeFloat` (0x1000eb70) read the field offset twice, once on each side
of the store:

```c
*(float*) (p + *(int*) (base + 0x14)) =
    *(float*) (base + 0x18) + *(float*) (p + *(int*) (base + 0x14));
```

That emitted `mov ecx,[esi+0x14]` and `fadd [eax+ecx]`. Folding the offset into
`p` first put the temp in `edx` and produced the reference's `add eax,edx`:

```c
p = p + *(int*) (base + 0x14);
*(float*) p = *(float*) (base + 0x18) + *(float*) p;
```

`src/Develop/DieGildeAddOn/command/command_c/cm_ExChangeFloat.c:44`
(0x1000eb70, 132/135 to RELOC 135/135).

The same lever applies to a cursor kept in a struct field. `vfs_GetByte`
(0x10003820) copied the read pointer into a local, which made MSVC 6.0 hold it
in `ecx` and zero-extend the byte into `eax`; the reference reuses `eax` for
both the count temp and the cursor. Post-incrementing in place through a
pointer alias of the field restores that:

```c
stream[1] = stream[1] - 1;
return *(*(unsigned char**) &stream[0])++;
```

`src/Develop/Units/vfs/vfs.c:60` (0x10003820, 104/114 to RELOC 114/114).

### 21a. Hoisting a field load out of an argument list breaks an esi/edi tie

Section 9 reorders first use; 9a shortens a live range. Neither applies when
the tie is between a loop cursor and a value the loop only reads inside a call
argument. What decides it there is whether the field load is *materialized*
into a local at all.

`gm_SumBuildingProductionValues` (0x100198b0) held the component cursor and
the query result in exchanged registers, 12 mismatched bytes with an otherwise
byte-identical stream. Reading the query's field inside the argument list,

```c
sub = gm_ff_Objekt(*(int*) ((char*) q + 0x14), 1, 0, comp & 0x7fff);
```

leaves the load owned by the call site and scores 343/355 with the cursor in
esi. Assigning it first gives the load its own definition point, and the
allocator then places the cursor in edi and the query in esi as the original
does:

```c
qbase = *(int*) ((char*) q + 0x14);
sub = gm_ff_Objekt(qbase, 1, 0, comp & 0x7fff);
```

`src/Develop/DieGildeAddOn/game/spiel622.c:430` (343/355 to 350/355).

The two states are exclusive under `/O2 /Gd`: the hoist costs the target's
argument schedule (it pushes the id, then loads into eax and pushes it last;
the hoist loads into ecx before the pushes), worth 5 bytes against the 12 the
register roles were worth. Address-only hoists (`qbase = (int) q + 0x14`),
`int*`/`char*` alias locals, `((int*) q)[5]`, a dead hoist beside the inline
load, `register int`, and an assignment folded into the argument all score
343: they do not materialize the loaded value, so the tie does not flip.

Diagnostic: when every `**` line is a register name with identical mnemonics
and operands, look for a value the target holds across a call that your source
only ever spells inside an argument.

## 22. `volatile` on the store target pins a store against loop scheduling

**Object-only until linked.** Default expect a link loss (§94). Qualifier
direction is §52.

MSVC 6.0 sinks a store past a pointer bump when it can rewrite the address as
a negative displacement, turning `fstp [eax]; add eax,0xc` into `add eax,0xc;
fstp [eax-0xc]`. Neither loop shape (`for`, `while`, `do/while`), induction
form (index vs pointer), nor CPU flag moves it, because all of them
canonicalise to the same schedule. Qualifying the store target does.

`ahm_InitRandomEntity` (0x1000c600) scale loop:

```c
do {
    *(volatile float*) p = p[-1] * dScaleFactor;
    p += 3;
    n--;
} while (n != 0);
```

`src/Develop/DieGildeAddOn/game/alchemistry_logic2.c:293` (0x1000c600,
100/109 to RELOC 109/109).

Note the asymmetry with section 15: `volatile` on the *loaded* operand pins
the load and blocks the memory-operand fold, which is usually not what a
scheduling mismatch needs. When the diff shows the right instructions in the
wrong order, qualify the destination, not the source.

## 23. A shared clamp value needs a 32-bit temp assigned in both arms

A guard that stores a constant on one path and a reloaded value on the other
emits two independent stores when each path writes memory directly:

```c
if (*(unsigned char*) (obj + 0x37) > 100) {
    *(unsigned char*) (obj + 0x37) = 100;   /* mov byte ptr [eax+0x37],0x64 */
    return 0;
}
```

The reference instead materializes the value in a 32-bit register and stores
it once after the join (`mov ecx,0x64` on one path, `xor ecx,ecx; mov cl,
[eax+0x37]` on the other, then a shared `mov [eax+0x37],cl`). Writing that
join in C reproduces it exactly:

```c
if (*(unsigned char*) (obj + 0x37) > 100) {
    clamped = 100;
} else {
    clamped = *(unsigned char*) (obj + 0x37);
}
*(unsigned char*) (obj + 0x37) = (unsigned char) clamped;
```

`src/Develop/DieGildeAddOn/command/command_c/cm_ExAllocWarEvent.c:86`
(0x10010140, 258/280 to RELOC 280/280). The temp must be wider than the
stored type: a `unsigned char clamped` folds back to the immediate stores.
This also removes the size delta, since the joined form is shorter than two
epilogues.

## 24. Two volatile reads pick both the register form and the schedule

A read-modify-write of a flag word emits `mov edx,0x80; or eax,edx` when the
optimizer is free to sink the load past an unrelated store. The reference
uses the 2-byte `or al,0x80`, which requires the load to stay adjacent to the
OR. Two separate `volatile` qualifications are needed, and they do different
jobs:

```c
flags = *(volatile unsigned int*) conn;              /* keeps the OR in al   */
*(volatile unsigned short*) ((char*) conn + 0x14a) = 0;  /* pins it between   */
*(unsigned int*) conn = flags | 0x80;
```

`src/Develop/DieGildeAddOnServer/server2.c:406` (0x1000a340, 312/336 to
RELOC 336/336).

The volatile read alone gets `mov (%esi),%eax; or $0x80,%al` but leaves the
clear after the OR; the volatile store alone sinks the load below the clear
and restores the edx materialization. Neither a plain temp, an `|=` on the
low byte, nor any statement permutation reaches the pair. This extends
section 22: `volatile` on the loaded operand is the lever when the diff shows
a wrong *register form*, not only a wrong order.

## 25. ecx/edx naming residue is usually a first-read or a hoisted-temp bug

A diff whose `**` lines all read `T: <op> <regA>` / `C: <op> <regB>` with
identical mnemonics and offsets looks like an allocator floor, but two cheap
levers close most of them. Both were found on functions this section
previously listed as unreachable.

**Which value is read from memory first fixes the byte register.** In
`ahm_GetCommandPayloadSize` (0x1000c710) the target keeps the switch byte in `dl`
and the loop index in `ecx`; the `case 0x16` body reads `cmd_payload` twice,
once for the `*cmd_payload == 0x16` test and once for `cmd_payload[0x14]`.
Reading the byte for the test first pins it in `dl`:

```c
cursor = (*cmd_payload == 0x16) ? (cmd_payload + 0x15) : (cmd_payload + 0x15);
count = cmd_payload[0x14];    /* RELOC 752/752 */
```

The reverse order scores 742/752, and hoisting the unrelated
`total_size = 0x15` above both scores 508/752.
`src/Develop/DieGildeAddOn/game/alchemistry_logic_c/ahm_GetCommandPayloadSize.c:93`.

**A hoisted `~x` temp takes the register the target gave the other value.**
In `amt_ExecuteOfficeAssignment` (0x1000b4d0) the loop clear was written as a
`neg_mask` local, which parked the mask in `ecx` and pushed `role_ch` to
`edx`, the reverse of the reference. Spelling the complement inline in the
loop body restores both:

```c
*scan = *scan & ~mask;        /* 826/836 -> 829/836 */
```

`src/Develop/DieGildeAddOn/game/aemter_c/amt_ExecuteOfficeAssignment.c:260`.
The same complement written as `neg_mask = ~mask`, as `mask = ~mask` before
the loop, or inside a `for`-init all score 826.

Levers that still moved nothing on either function: declaration order and
block scope of the competing locals, signed/unsigned and width changes,
`volatile` on either operand (it moves the *schedule*, then re-swaps),
pointer-vs-index address forms, and `/O1 /Ox /Og /Oxs /G5 /G6`.
`cm_ExChangeAttribute` (0x1000e7d0, 216/242, descriptor cursor and
destination as eax/ecx) is still open.

Check the `structural` count in `rebrew diff --json` first: it counts real
shape differences, and a small non-zero value points at the statement to
reorder rather than at an allocator floor.

## 26. Spelling a clamp as `setle`/`dec`/`and` decides the loads before it

`(x <= 0) ? 0 : x` and the explicit mask below compile to the same
`xor`/`test`/`setle`/`dec`/`and` sequence, but they schedule the *preceding*
loads differently:

```c
neg = (sum <= 0) ? 1 : 0;
sum &= neg - 1;
```

`UpdateProductionProgress` (0x10011790) adds a byte field to a dword field and
clamps the result. The target opens the tail with
`xor ecx,ecx; mov cl,[eax+0xc]; mov edx,ecx; mov ecx,[edi+0x13]; add ecx,edx`
(byte load first, then a register-to-register copy). With the ternary, msvc6
loads the dword first and drops the copy, costing exactly the 2 bytes of
`mov edx,ecx` and every byte after it. Fifteen rewrites of the add itself
(operand order, separate `cur`/`prod` locals, `unsigned char` vs `int` carrier,
`volatile` on either operand, pointer aliases, statement splits) all produced
the dword-first form; only the clamp spelling moved it. That took the function
from 195/242 to RELOC 242/242.

`if (sum < 0) sum = 0;` also emits the byte-load-first pair, but as
`add ecx,edx; jns` instead of the mask, so it fixes the loads and breaks the
clamp. Read which of the three forms the target uses before choosing.

Generalisation: when a diff shows the right instructions in the wrong order
just *before* a clamp or a select, treat the clamp spelling as the lever. The
operand that ends up in a register is chosen along with the code that consumes
it, not independently of it.

## 27. A volatile byte read defeats the byte/dword load merge on one slot

Reading a `char` parameter as a byte and then re-reading the same slot as a
dword normally merges into one dword load. Making only the byte read
`volatile` keeps both:

```c
result = *(volatile char*) &stat_value;          /* mov bl, [esp+8]   */
if (result == 0) { ... }
result += (char) f((float) (*(int*) &stat_value & 0xff) >= k ? 0xb : 6);
                                                  /* mov eax,[esp+8]  */
                                                  /* and eax,0xff     */
                                                  /* mov [esp+8],eax  */
```

`gm_RandomStatModifier` (0x10018450) needs exactly this: `bl` holds the signed
byte for the guard and the final `add bl,al`, while the masked dword is homed
back in the parameter slot for `fild` to read. Every non-volatile spelling
(`(unsigned char) v`, an `int uv` temp, `*(int*)&v & 0xff`, masking through the
parameter, an `int` parameter) folded the two reads into one `mov ebx,[esp+8]`,
which loses the `mov bl` and everything downstream: 32/78.

The second half of the fix is the result shape. `v += f(...)` compiles to
`add al,bl` (result in `al`), but the target ends `add bl,al; mov al,bl`:
the accumulator is the *named* variable, not the call result. Assigning the
same local in both arms of an `if`/`else`, rather than returning from the first
arm, produces that:

```c
result = *(volatile char*) &stat_value;
if (result == 0)
	result = (char) (f(0x2a) + 0x15);
else
	result += (char) f(...);
return result;
```

Both together: RELOC 78/78. `.scratch/work/p1.c` through `p7.c` hold the
thirteen spellings that do not work.

## 28. Constant CSE in a straight-line store block has no source lever

`gm_StartFilteredEntitySearch` (0x100170e0) opens with nine global stores; the
reference hoists `0xff` into `cl` and parks zero in `edx`, reusing both. Hoisting
the constants into locals does not reproduce it. `char ff = 0xff`, `int zero =
0`, both together, either alone, `int`/`unsigned char`/`volatile` carriers, `ff`
derived from a shared `-1`, and moving the two `0xff` stores adjacent all
compile to output byte-identical to the literal form: msvc6 re-materializes a
constant at each store site and picks its own register for the parked zero.

Constant sharing is decided after the source-level temps are folded away, so
there is no C spelling for it. Treat a diff whose only differences are
`mov [addr],imm` against `mov [addr],reg` in a store block the same way as
section 25's register naming: check for real structure elsewhere first.

## 29. Hoist a common addend out of a select, and let the select assign the result

Where a three-way select picks a base pointer and every arm adds the same
offset, the target computes the offset once at the merge:

```
mov eax,[esp+0x10] ; test eax,eax ; jne merge
mov eax,[esp+4]    ; test eax,eax ; jne merge
mov eax,[esp+8]
merge: mov ecx,[esi+0x14] ; add eax,ecx
```

Repeating the add in each arm costs three loads and three adds
(`cm_ExChangeBits` 0x1000eaa0, 96/209 with a size overrun). Hoisting it closes
most of the gap, but *which* local the arms assign then decides the register:

```c
/* 202/208: pointer ends up in ecx, target holds it in eax */
if (resolved != 0) sel = (char*) resolved; else ... ;
puVar3 = (unsigned int*) (sel + *(int*) (base + 0x14));

/* 208/208 RELOC: the select assigns the result variable itself */
if (resolved != 0) puVar3 = (unsigned int*) resolved; else ... ;
puVar3 = (unsigned int*) ((char*) puVar3 + *(int*) (base + 0x14));
```

`sel += off; puVar3 = sel;` also scores 202: the intermediate local is what
pins the value in ecx, not the syntax of the add.
`src/Develop/DieGildeAddOn/command/command_c/cm_ExChangeBits.c:49`.

Same function, second lever: a read-modify-write spelled
`v = *p & ~mask; *p = v; *p = val | v;` caches the masked value in a register,
where the target re-reads through the pointer. Writing both statements against
memory (`*p = *p & ~mask; *p = val | *p;`) drops one instruction per block.
Three size cases fixed the same way took 126/208 to 202/208.

## 30. `volatile` at the load site defeats displacement folding

**Object-only until linked.** Default expect a link loss (§94). Qualifier
direction is §52.

msvc6 folds a constant field offset into a scaled load,
`mov al,[esi+eax*4+0x247]`, where the target materializes the record address
first:

```
lea eax,[esi+eax*4]
mov al,[eax+0x247]
```

How the address is *built* does not change this. Probed against
`cm_GetBuildingStatCount` (0x100104a0), all scoring 41/135: an int-typed
address local, a struct pointer with the field at 0x247, a `char(*)[0x24d]`
row pointer, `&tbl[i * 0x24d]`, `(tbl + 0x247)[i * 0x24d]`, a compound `+=`,
a `uint` offset local, and `/O1 /Ox /Og /Oxs` plus `/G3`-`/G6`.

Reading through `volatile` at the point of use forces the address into a
register:

```c
building_tier = *(volatile char*) (type_entry + 0x247);   /* 41 -> 118/135 */
```

`src/Develop/DieGildeAddOn/command/command_c/cm_GetBuildingStatCount.c:85`.
Qualify the load only; a `volatile` *pointer* local spills through the stack
instead. Section 10's load scheduling then applies on top: moving the
neighbouring `*(int*)(param_1 + 0x65)` read ahead of the volatile load took it
to 121/135.

Same lever, opposite outcome in `sim_StartEntityQueryByType` (0x10015460): the
`volatile` does emit the target's `lea`/`mov` pair, but costs the esi/edi
assignment that keeps the argument and table base live across four calls, so
the score stays at 10/145. Measure the whole function, per section 18.

## 31. A pointer sweep with a separate index beats an indexed walk

A scan that tests fields at a stride and returns an address derived from the
index compiles to two different loops. Indexing rebuilds the record address in
the body; the target walks a pointer against an end address and carries the
index only to compute the result:

```c
/* 12/98: address rebuilt per iteration */
for (i = 0; i < 0x300; i++) {
    p = (char*) 0x100358a2 + i * 0x21c;
    ...
}

/* 98/98 EXACT */
r = NULL;
if (arg1 == 0) {
    return r;
}
i = 0;
p = 0x100358a2;
while (p < 0x1009aca2) {
    ...
            r = (char*) (0x100358a0 + i * 0x21c);
            break;
    ...
    p += 0x21c;
    i++;
}
return r;
```

`src/Develop/DieGildeAddOn/game/spiel622.c:608`, fixing
`gm_FindEntityByOwner`.

Three details are each load-bearing, measured separately:

- **`int` for the walking pointer**, not `char*`. The target's bound compare is
  signed (`jl`); a `char*` compares unsigned (`jae`).
- **`while`, not `do`/`while`.** The `do` form emits `jge` past the loop plus a
  `jmp` back to the top, two instructions where the target has one `jl`.
- **A result local zeroed before the argument test.** It lets both no-match
  exits share one `xor eax,eax`, and raises pressure enough to put the argument
  in edi and the index in esi, matching the target. With an early
  `return NULL` and no result local the function uses one saved register and
  the wrong roles.

The result local must be set before the guard (`r = NULL; if (arg1 == 0)
return r;`). Assigning it after an `if (arg1 == 0) return NULL;` emits the push
order `esi, edi` against the target's `edi` followed by a lazy `esi` inside the
loop, and scores 0/98 despite an otherwise instruction-identical body.

## 32. PROVEN is not a byte match, and it hides tractable work

`PROVEN` records that a symbolic prover showed the C semantically equivalent
to the target. It says nothing about the emitted bytes: every PROVEN entry in
this project carries `delta > 0`, from 1 byte to over 1800.

Those functions were never *attempted* as byte matches, only proven and set
aside, so the ordinary causes in this document still apply to them untried.
Twelve converted to EXACT/RELOC in one session, several from a single
statement swap.

Read the verify summary's `byte_matched` field (EXACT + RELOC) rather than
`passed`, which counts PROVEN as done via `metadata.MATCHED_STATUSES` for
coverage accounting.

Rank the remaining ones by `delta` and start at the top:

```sh
rebrew verify --json 2>/dev/null > .scratch/v.json
jq -r '.results[] | select(.status=="PROVEN")
       | "\(.delta)\t\(.va)\t\(.size)\t\(.match_percent|floor)%\t\(.filepath)"' \
   .scratch/v.json | sort -n
```

A small delta on a large function means a long correct prefix and one late
cluster. A low match percentage on a small function means it diverges near
instruction 0. Both are more tractable than the percentage suggests, because
`match_count` does not realign after an insertion (section 19).

## 33. Statement order decides which register holds a value

Recurring across the conversions: when two reads feed different consumers,
the one you write first claims the register the target expects.

In `ahm_GetCommandPayloadSize` (0x1000c710) the target keeps a switch byte in
`dl` and a loop index in `ecx`. Assigning the cursor, whose initializer reads
the switch byte, *before* reading the count pins the byte in `dl` and closed
a 10-byte gap. Reversing the two statements scores 742 of 752.

This is the same mechanism as section 9 (register roles follow order of first
use) seen from the source side: reordering two adjacent, independent
statements is often the whole fix. Try it before reshaping anything.

Corollary: treat existing "unreachable" comments as unverified. Three in this
codebase were wrong, including one claiming a function needed "the original's
exact CL.EXE build" when a single statement swap closed it.

## 34. RELOC can hide a wrong global: check `~~` operands against the symbol

`rebrew diff` marks an instruction `~~` when it differs only in a relocation
slot, and `rebrew test` counts `~~` as a match. The mask covers all four
operand bytes, so an instruction referencing *the wrong global* still scores
`~~`, and a function built entirely from such instructions reports RELOC with
`match_count == total` while being semantically wrong.

Hit in `cm_ExModifyStat` (0x100100a0). The reference's third compare is
`fcom dword ptr [0x100256a4]` (`_g_stat_max`, 252.0). Spelling the retest
`v >= _g_stat_min` emits `fcom dword ptr [0x100256cc]` (`_g_stat_min`, 0.0);
every other byte agreed, so the diff went green at 159/159 RELOC. The two are
not equivalent: for `min < v < max` the reference stores `v` and that
spelling stores `max` (wrong for v = 1, 100, 251 at the shipped 0.0/252.0
bounds).

Guard for it: whenever a `~~` instruction carries a global operand, read the
reference's operand address out of `.target.bytes` (little-endian
displacement) and check it against `src/Develop/rebrew_globals.h` or the
raw image. Two same-typed globals sitting near each other in `.rdata` make
this easy to hit, and RELOC gives no signal at all.

```bash
rebrew diff <VA> --json | jq -r '.instructions[] | select(.match=="~~") |
  "\(.index) \(.target.bytes) \(.target.disasm)"'
```

Distrust a RELOC that arrives from changing *which symbol* an expression
names rather than from changing code shape.

## 35. Row multiply vs offset accumulation decides strength-reduction fallout

A loop that walks fixed-size rows can be written two ways, and msvc6 treats
them differently even though both emit the same induction register:

```c
off = 0;  do { ... base + off ... ; off += STRIDE; } while (off < LIMIT);
row = 0;  do { ... base + row * STRIDE ... ; row++; } while (row < COUNT);
```

The multiply form hands msvc6 a `row * STRIDE` to strength-reduce, and the
reduction runs before the surrounding scheduling decisions. Two consequences,
both observed closing functions that were 3 bytes short:

**SIB base/index roles.** In `gm_Open` (0x10015950) the reference addressed the
producible-count table as `[esi+eax+0x21]`, counter as SIB *base* and reloaded
table pointer as *index*. The accumulating form emits `[eax+esi+0x21]`, and no
addend-order swap, array-subscript spelling, or cast changes it: the roles come
from the induction variable's form. Counting rows and spelling every access as
`g_entity_type_table + row_index * 0x24d + disp` gives the counter the base
role and closed the function (858/861 -> 861/861 RELOC).

**Preheader instruction order.** In `amt_ExecuteOfficeAssignment` (0x1000b4d0) the
reference emitted `not edx; mov eax,0x10035a6c` and a pointer-cursor loop
emitted the two the other way round. Rewriting the sweep as
`*(int*) (0x10035a6c + row * 0x21c)` over `row < 768` put the `not` first and
closed it (829/836 -> 836/836 RELOC). A byte-offset counter also emits `not`
first but recomputes the bound with a `lea`/`cmp` pair and is longer.

Derive `COUNT` from the addresses rather than assuming it: for that sweep,
`0x1009ae6c - 0x10035a6c = 0x65400 = 768 * 0x21c`.

When a loop is a few bytes short and the residue is addressing-mode or
scheduling noise around the induction variable, switch the loop between these
two forms before probing anything else.

## 36. The outer call's argument form can fix a whole-function register swap

Two callee-saved values can end up in each other's registers across an entire
function, with every instruction otherwise correct. In
`gm_SumBuildingProductionValues` (0x100198b0) the reference kept the query
result in esi and the table cursor in edi; our compile had them swapped at 12
sites, and every lever aimed at the *cursor* (declaration order, `register`
qualifiers, retyping, init order, loop-bound shape, end-pointer bounds) left
the pair untouched.

The lever was the first argument of the call that *defines* the query:

```c
q = gm_ff_Objekt(...);
q_slot = *q;                                    /* int local */
total = ... gm_CalculateProductionValue(q_slot, *(unsigned char*) ((char*) q + 0x12)) ...;
```

Reading `*q` into a local and passing the local, instead of passing `*q`
directly, moved the query into esi and the cursor into edi, and reproduced the
reference's `mov dl,[esi+0x12]` / `xor eax,eax` / `mov ax,[esi]` read order.

The local's width matters. The natural `unsigned short` emits an
`and eax,0xffff` widen and reorders the two field reads (SIZE_MISMATCH, 167 of
355). An `int` local is exact. See also section 6 on local width.

Before hoisting a value out of an argument list to fix register naming, check
whether hoisting one out of a *different* call fixes it instead: the hoist that
fixes the names may cost the argument schedule at the site you hoisted from.
Here the earlier fix hoisted the inner call's `q+0x14` load, which fixed the
names but cost 5 bytes of schedule; hoisting at the outer call fixed the names
and left the inner call's `push eax` / `mov eax,[esi+0x14]` / `push eax`
schedule intact.

## 37. A dead parameter slot can home more than one byte

Section 14 homes one value in an incoming parameter's own slot. The slot is
four bytes, and the *other* bytes of it are usable homes too. That matters when
the frame is one dword too large because a single byte value needs a spill.

`amt_ValidateAndAssignOffice` (0x1000b290) reads a holder byte
(`g_office_slots[i].b`) before a scan loop and uses it after. The reference
keeps it in `al` across the loop; every C shape that carries it in a local puts
it in `cl`, which the loop's cursor clobbers, so msvc6 spills it to a fresh
dword and the frame is `sub esp,0x1c` against the reference's `0x18`. The whole
prologue then sits one slot off and the positional compare collapses.

`arg1`'s slot is already dead (a `cmd` local holds the pointer) and byte 0 of
it homes the requested-office byte. Homing the holder byte in byte 1 of the
same slot removes the spill:

```c
x6 = cmd[6];
*(unsigned char*) &arg1 = x6;                       /* byte 0, section 14 */
if (g_office_slots[i].b != x6)
	return 0;
((unsigned char*) &arg1)[1] = g_office_slots[i].b;  /* byte 1, no spill dword */
/* ... scan loop ... */
b = ((unsigned char*) &arg1)[1];
```

`src/Develop/DieGildeAddOn/game/aemter.c:206`. It emits `sub esp,0x18` with
`push ebx/ebp/esi/edi` intact in the prologue, aligning instructions 0-35
(prologue, entity lookup, all three guards and the whole first scan loop), and
took the function from 187 to 191 of 425.

Two things this supersedes, both previously recorded as ceilings:

- "No probed ordering keeps the 0x18 frame and the prologue push together"
  (17 shapes). The byte-1 home does both.
- "The extra dword is one spilled byte value and every C shape spills it."
  Correct on the diagnosis, wrong that it was unavoidable: the byte needs a
  *home*, not a register, and a dead slot already in the frame is one.

Which byte you pick matters (byte 2 loses the frame), and the store's position
in the emitted stream does not follow source order: writing it before the
sibling read, after it, or before the byte-0 home all place it identically.

## 38. msvc6 shrink-wraps, and the lever is loop register demand

A target that pushes one callee-saved register at entry and the rest later,
interleaved with loads past the early-exit guards, is not using an idiom that
is out of reach from C. msvc6 defers a `push` to the first block that needs
the register whenever few enough callee-saved values are live across the
guards:

```c
int __cdecl m(void)
{
    int a, b, c, d;
    if (ga == 0) return 0;          /* early exits reached with no push */
    if (gb > 0x100) return 0;
    a = gc; b = gd; c = ge; d = gf; /* push ebx/esi/edi emitted here */
    while (a < 100) { a += b + c + d + ga; b += gb; c += gc; d += gd; }
    return a + b + c + d;
}
```

emits `test/jne/xor eax,eax/ret` before any push, then `push ebx; mov ebx,...;
push esi; mov esi,...; push edi`. `.scratch/w_l2/m1.c`; `m2.c` and `m3.c` show
the same with one register (`esi`) live from entry, which is the exact shape of
`gm_FindNextFilteredEntity` (0x10016f80) and `gm_NextEntityQueryMatch`
(0x10016290).

The threshold is real and low. `m4.c` differs from `m3.c` only in carrying two
more values through the loop, and that alone collapses the head back to pushing
at entry and adds a frame. So when a function will not split its prologue, the
lever is reducing how many callee-saved values the *loop* needs, not respelling
the entry: every entry reshape probed on both functions above (statement
permutations, `!p` against an explicit null compare, testing the global
directly, returning a literal against returning the pointer, aliasing, sinking
the initialisers below the guards) is inert while the loop demand stands.

Corollary for bisecting: delete the loop and recompile. If the head then
matches the target, the entry spelling is already right and the loop is the
blocker. Adding the loop back one block at a time locates the flip precisely.
On 0x10016290 that isolated it to a single `if (g_flag) is_match = 1;` joining
a scan loop and an early return (`.scratch/w_l2/g/k1.c` against `k2.c`), which
no amount of entry rewriting could have found.

## 161. SIB base/index roles follow the induction variable's form

When the target and the candidate differ only by which register is base and
which is index in the same addressing mode (`[esi+eax+0x21]` against
`[eax+esi+0x21]`), reordering the addends in the C expression does nothing.
MSVC 6.0 decides the roles from how the loop advances.

- Accumulating a byte offset (`off += 0x24d`) gives a reloaded table pointer
  the base role.
- Counting rows and spelling the address as `table + row * 0x24d + disp`
  hands the compiler a multiply to strength-reduce, which gives the counter
  the base role.

Three such swaps in `gm_Open` (0x10015950) closed it at 861/861 after the
addend-order approach had been tried and failed. The same swap in
`gv_SpawnEntities` (0x10010850) came instead from removing a
semantically dead `if (count > 0)` wrapper around a `while` loop that already
tested it: the extra nesting raised register pressure enough to flip the
roles.

A read-modify-write in the same loop keeps its address as two direct
`[counter + table + disp]` operands. Routing it through a pointer local forces
a `lea` into a register plus `[reg]` accesses; in `gm_Open` that shape is 2
bytes shorter than the reference (859/861) while the double spelling is exact.

## 160. PROVEN status is lost by a STUB result, and that is a real regression

`rebrew verify` overlays a metadata `PROVEN` status onto a byte result only
when that result is `NEAR_MATCHING` or `SIZE_MISMATCH` (`verify.py:1325`).
A `COMPILE_ERROR`, `MISSING_FILE`, or `STUB` result means the source no
longer builds or the annotation moved, so the proof is treated as stale and
the function is reported as failing.

Chasing `match_count` can therefore make a function worse. Twice in one
session an edit raised the positional score while dropping the status to
STUB; one of those had introduced a genuine semantic bug (scanning a fixed
element instead of the walking cursor), which is exactly what the proof had
ruled out.

When editing a PROVEN function, treat its status as the floor: a higher
percentage that lands on STUB is a loss, not a gain. Revert to baseline
instead.

## 162. Relocation masking can hide a wrong symbol: the false RELOC (same rule as §34)

`rebrew diff` masks the 4-byte relocation slot, so an instruction whose only
difference lies inside that slot is reported `~~` and counted as a match. A
function can therefore reach RELOC with `match_count == total` while
referencing the **wrong global, wrong string, or wrong call target**: the
address bytes differ, but the diff cannot see them.

Two confirmed instances:

- `cm_ExModifyStat` (0x100100a0): spelling a bound test `v >= _g_stat_min`
  scored a clean 159/159 RELOC, but the original compares `0x100256a4`
  (`_g_stat_max`, 252.0) where that spelling compares `0x100256cc`
  (`_g_stat_min`, 0.0). Not equivalent for any value strictly between the
  bounds. Rejected.
- `gm_Open` (0x10015950): two `LogMessageInternal` calls passed invented
  German text (`"gm_Open(): Spieler initialisieren"`,
  `"gm_Open(): Gebaeude-Daten"`) where the binary holds
  `"gm_Open(): St\344dte"` at `0x10031204` and `"gm_Open(): Geb\344ude"` at
  `0x100311f0` (Latin-1 `0xe4`). The strings sit behind relocation slots, so
  the function scored RELOC 861/861 with the wrong log output.

**Before trusting a RELOC, resolve every `~~` operand.** Our object is
unlinked, so its slot holds only the addend while the original's holds
`symbol_va + addend`; subtracting gives the symbol VA, which
`src/Develop/rebrew_globals.h`, `db/coverage-server.dll.toml`, and
`src/rebrew-data.toml` can name. For string literals, read the bytes at the
original's address straight out of the binary and compare.

An audit of 19 recently converted functions resolved all 211 masked
instructions and found the single `gm_Open` defect; the other 18 were clean.
Non-ASCII text belongs in octal escapes (`\344`) so the source stays ASCII
and the byte value is unambiguous.

## 39. A volatile argument read defers a parameter load past the prologue pushes

When the target loads two incoming parameters in one order and msvc6 picks the
other, the cause can be a load that floated *above* the callee-save pushes. The
reference reads the parameter it needs at the call site first, so that value
claims the register pushed first; msvc6 hoists the dereference of the *other*
parameter into the prologue, and that parameter wins the register instead.

`gm_AllocRaum` (0x10017c40) opens with

```
push ebx; push ebp; push esi; mov esi,[esp+0x14]; push edi; mov edi,[esp+0x14]
push 1; push esi; mov ecx,[edi+1]; push ecx; call gm_AllocObjekt
```

so `obj_id` lands in esi and `geb` in edi. Ours hoisted the `geb+1` load into
the prologue (`mov ebp,[esp+0xc]` before the first push), which put `geb` in
ebp and pushed `obj_id` down. A volatile read at the argument defers it:

```c
obj = (char*) gm_AllocObjekt(*(volatile int*) (geb + 1), obj_id, 1);
```

`src/Develop/DieGildeAddOn/game/spiel_c/gm_AllocRaum.c:107`,
672 -> 677 of 742 with the object size unchanged.

This is section 8c's residency/ordering distinction applied to an argument
rather than a field pair: the qualifier belongs on the *load that must stay
put*, not on the variable. Qualifying the local (`char* volatile`), the other
parameter's byte read, or the value the loop consumes all rebuild the frame
instead (`abc_x1`/`abc_z1`, 113/751 and 68/760).

The lever is not universal. On `FindSlotEntryFiltered` (0x10010710) the same
trick applied to the competing `entity+0x65` load delays the load but flips the
push order (`push esi` before `push edi`), losing five bytes for no register
gain: 263 -> 249 of 320. Check the push sequence in the diff, not just the load
position, before keeping it.

## 40. A struct assignment breaks a register tie without changing a byte

Section 9a breaks an esi/edi tie by shortening a live range. When that has
nothing left to shorten, the other side of the tie is the *reference count*:
how many times the source names each candidate. A struct assignment lowers
that count without changing the emitted instructions.

`ls_LoadSavegameHeader` (0x10012470) passes `stream` and `dest` to the same
reader ~25 times, then writes a three-field tail from three globals. Two
shapes each got one half of the target right and neither got both, across
eight prior rounds:

- a hoisted `tail = dest + 0x9c` local restored the target's esi/edi roles but
  lost its duplicated `add edi,0x9c` and its memory-form version compare
  (819/857);
- `dest += 0x9c` inside each tail arm restored both of those and reached the
  exact 857-byte size, with every instruction, operand and branch offset
  correct and only esi and edi exchanged at 56 sites (801/857).

The second shape names `dest` three times in the else arm:

```c
	dest += 0x9c;
	*(int*) dest = g_1002d4f0;          /* 3 references to dest */
	*(int*) (dest + 4) = g_1002d4f4;
	*(char*) (dest + 8) = g_1002d4f8;
```

One packed struct assignment emits the identical bytes (`mov edx,[g];
add edi,0x9c; mov [edi],edx; mov eax,[g+4]; mov [edi+4],eax; mov cl,[g+8];
mov [edi+8],cl`, verified in isolation) while naming `dest` once:

```c
#pragma pack(1)
struct SaveHeaderTail { int a; int b; char c; };
#pragma pack()
extern struct SaveHeaderTail g_save_header_tail; /* 0x1002d4f0 */

	*(struct SaveHeaderTail*) (dest + 0x9c) = g_save_header_tail;
```

That alone moved `dest` into edi and `stream` into esi, closing the function
at RELOC 857/857.
`src/Develop/DieGildeAddOn/loadsave/loadsave_c/ls_LoadSavegameHeader.c:24`.

`#pragma pack(1)` is required: the natural layout pads the trailing `char` to
a 12-byte struct and copies 12 bytes, costing 2 bytes (855/857).

Diagnostic for this class: when the diff is *only* a register exchange and
every live-range lever is exhausted, count how many times each candidate is
named in the source and look for a construct that says the same thing with
fewer mentions. Struct assignment, a single `memcpy` of a field group, and an
array store through one base all qualify.

The lever is not universal, and it is not a general "fold the stores" rule.
On `AcceptConnections` (0x1000a080) the same packed-struct assignment applied
to its adjacent `[slot+0x2641f8]` / `[slot+0x2641fc]` pointer stores does
change the emitted bytes: it folds the second `lea` and misses the size
(495/600 at obj 599, against 546/600 for the plain pair). Verify the struct
form emits the same instructions in an isolated probe before keeping it.

## 41. Two levers that each regress can be exact together

A shape change that lowers `match_count` is not necessarily wrong. When it
fixes the instruction stream but leaves the object one byte off, the score
collapses positionally (section 19) and hides a real structural gain. Track
`obj_size` and the `**` count alongside `match_count`, and when a change lands
one byte away from the target size, look for a second change that supplies
exactly that byte rather than discarding the first.

**Composition requires opposite BYTE signs, and deltas do not always add
(round 184).** Two traps, both hit on `gm_AllocSpieler`:

*Instructions and bytes have independent signs.* A round-178 note recorded that
moving a stranded statement into its loop "makes the instruction count exact
(1054 -> 1056), i.e. it ADDS instructions": true, and irrelevant. The same change
*shortens* the real body by 14 bytes, because the three FP ops it gains inside the
loop are outweighed by the out-of-line copy it deletes and by the addressing
collapsing to 3-byte `[esi-0xc]` forms. Pairing it with a -11 fix under this section
was therefore doomed from the start: both are negative. **Record the byte delta
explicitly whenever a note claims a length effect**; an instruction count is not a
length.

*Overlapping levers do not compose.* Those two fixes measured -11 and -14 alone and
**-9 together**, not -25: they overlap by 16 bytes because both rewrite the same FP
scheduling region, and together they even regress the instruction count back to 1054
from the 1056 one of them reached alone. So a combination's delta must be *measured*,
never predicted by addition, and two levers that touch one region are candidates for
fighting rather than composing. The case below works precisely because its two
clusters were one fault seen twice; that is the configuration to look for.

`gm_AllocRaum` (0x10017c40) sat at NEAR_MATCHING 677/742 for nine
prior batches with 18 residual `**` in two clusters that were recorded as
separate register-role problems: the scan cursor built as `lea ecx,[ebp+0x25]`
where the reference splits the row base and the cursor, and `geb` living in
ebp where the reference uses edi.

Advancing the cursor before the read, rather than reading through a
displacement and then advancing,

```c
	scan = row + 0x23;
	comp = *(unsigned short*) scan & 0x7fff;
	if (comp != obj_id) {
		do {
			scan += 2;
			comp = *(unsigned short*) scan & 0x7fff;
			i++;
		} while (comp != obj_id);
	}
```

emits the reference's `lea ebp,[eax+edx*4]` / `lea eax,[ebp+0x23]` pair and
raises exact instructions from 203 to 210, but scores 131/743: one byte long,
because `geb` still occupies ebp and `mov cl,[ebp]` needs a displacement byte
(`8a4d00`) that the reference's `mov cl,[edi]` (`8a0f`) does not.

Computing the row before zeroing the counter,

```c
	row = g_entity_type_table + (unsigned char) geb[0] * 0x24d;
	i = 0;
```

frees ebp for the row base. On its own it is 167 at obj 741, one byte short.
Applied together the two are exact: RELOC 742/742.

`src/Develop/DieGildeAddOn/game/spiel_c/gm_AllocRaum.c:107`

The two clusters were one fault. With `i = 0` first, msvc6 has ebp tied up and
folds the row+0x23 displacement into the first read; freeing ebp and advancing
the cursor before the read clears both at once. Where a function's notes list
several independent register-role clusters, test whether one allocation
decision explains all of them before treating them as separate problems.

The converse holds and is the trap: a lever that removes `**` while changing
the size must not be kept alone. Re-measure the pair.

## 42. The number of reaching definitions decides load/store scheduling

Where a value reaches a block from two assignments written in *different*
forms, msvc6 keeps them as two definitions and schedules conservatively around
the merge: stores that use the value issue before any independent load. Write
both assignments as the same base+index expression and it treats them as one
value, and the scheduler is free to hoist an unrelated load above them.

`AcceptConnections` (0x1000a080) picks a connection slot in a search loop and
falls back to a fixed record when the search fails:

```c
	slot = (unsigned char*) 0x101deb00 + i * 0x264264;   /* search hit */
	...
	slot = (unsigned char*) 0x114ffe20;                  /* fallback   */
```

Far below, past a 0x2000-iteration loop, it stores two pointers into the slot
and calls `sprintf` with four bytes of a `sockaddr`. The reference issues the
first byte load *before* either pointer lea:

```asm
mov  edx,[esp+0x1f]          ; addr[7], first
lea  eax,[esi+0x154]
lea  ecx,[esi+0x132154]
mov  [esi+0x2641f8],eax
mov  eax,[esp+0x1e]          ; addr[6]
and  edx,0xff                ; mask deferred past the store
mov  [esi+0x2641fc],ecx
```

No spelling of the argument list reproduces it: comma expressions in any
argument slot, `volatile` on either store pair, struct-block assignment, and
hoisting the bytes into locals all leave both leas above the first load (about
thirty shapes, `.scratch/l2x/mk*.py`). The lever is at the *definition* site.
Writing the fallback in the same expression shape as the search hit,

```c
	slot = (unsigned char*) 0x101deb00 + 8 * 0x264264;   /* == 0x114ffe20 */
```

emits the reference's order exactly, verified in isolation with the real
search, the real loop and the real tail (`.scratch/l2x/p9.c:m3`,
`.scratch/l2x/pa.c:n1`).

Two details matter when reaching for this:

- **The cast has to stay inside.** `(unsigned char*) (0x101deb00 + 8 *
  0x264264)` folds to the literal at compile time and changes nothing; the
  arithmetic must be on the cast pointer for the two definitions to match.
- **It extends the index's live range.** In `AcceptConnections` the join sits
  above the `accept()` call, so `i` survives the call, the accept result
  spills to a new frame slot, and the frame grows 0x118 to 0x11c: the cluster
  aligns but 130 downstream instructions shift, 546/600 down to 177/600. It is
  only a win where the merge is not separated from its uses by a call.

The general rule is worth more than the case: when a scheduling difference
sits far from anything the source seems to control, count the definitions
reaching the block instead of rewriting the statements next to the divergence.

## 43. `and eax,0xff` is one byte shorter than the same mask on any other register

The mask against 0xff has an accumulator-specific short form: `and eax,0xff`
assembles as `25 ff 00 00 00` (5 bytes), while `and edx,0xff` needs the ModRM
form `81 e2 ff 00 00 00` (6). A byte value that msvc6 parks in eax therefore
makes the object one byte shorter than a reference that masks the same value
in edx or ecx.

This shows up as a persistent `obj_size` deficit of exactly one that no
statement reordering fixes. In `AcceptConnections` every hoist that produced
the reference's load-first schedule landed at obj 599 for this reason alone
(sixty builds: each of the four `sockaddr` bytes, four declared types, every
placement against the surrounding stores, `.scratch/l2x/mk4.py`).

When a candidate is one byte short and the diff shows a mask, compare the mask
encodings before assuming an instruction is missing. Section 19's warning
applies in reverse here: the positional score collapses downstream, so a
one-byte encoding difference reads as a structural one.

## 44. `#pragma optimize("a", on)` reorders a field read against a store

MSVC6's `"a"` flag (assume no aliasing) is a per-function lever in the same
family as section 13's `"y"`, and it moves scheduling, not just addressing.
Where the target reads one struct field and stores to another in the opposite
order from the candidate, `"a"` is the difference: without it msvc6 must assume
the store may alias the read and keeps source order.

In `sim_AdvanceGameClock` (0x100155c0) the target emits

```
xor esi,esi; mov si,word ptr [ecx+4]; mov dword ptr [ecx+6],edx
```

and every source spelling that hoisted the `x04` read above the `x06` store
either left the pair transposed (187/197) or re-folded an earlier carry and
collapsed to 87. Wrapping the function in `#pragma optimize("a", on)` emitted
the target's order with no source change at all, 187 to 194/197.

```c
#pragma optimize("a", on)
void __cdecl sim_AdvanceGameClock(SIM_CLOCK* clock, int arg2, int arg3, int arg4)
{
	/* ... */
}
#pragma optimize("", on)
```

Close with `#pragma optimize("", on)` as in section 13; file-mates are
unaffected (the other five functions in `sim.c` held their status). `"w"`
scores the same here, `"g"`, `"p"` and `"t"` are inert, and `"s"` and
`-"t"` collapse the body to 142 bytes.

Reach for this when the diff is a pure transposition of a load and a store to
the same object and no statement order reproduces it: the obstacle is the
aliasing assumption, which no C spelling can express.

`src/Develop/DieGildeAddOn/game/sim.c:251`

## 45. Merging duplicated tail stores sinks a loop store below the decrement

Two exits that write the same value to the same field, one inside an `if` with
a `return` and one at the end of the function, cost more than the duplicated
store: they change how the preceding loop schedules.

`sim_AdvanceGameClock`'s second loop had to emit

```
mov esi,[ecx]; dec esi; dec edx; mov [ecx],esi; jne
```

with the store *after* the counter decrement. With a `return` inside the
`minutes < 0` branch the store landed ahead of `dec edx` in every one of ~30
body spellings (194/197): plain, `volatile` on the store, an `int*` alias, a
value local, `--days`, `days--`, an explicit `break`. Deleting the branch's
duplicate store and its `return`, so both paths fall through to one tail
`clock->x04 = (unsigned short) minutes;`, sank the store below the decrement
and took the function to 197/197 EXACT with no other change.

Section 7 covers merging *sequential returns* for branch polarity; this is the
scheduling consequence of the same edit. When a loop store is one slot early
and the loop's body resists every rewrite, look at what follows the loop.

`src/Develop/DieGildeAddOn/game/sim.c:294`

## 46. The x87 `fxch` slot and a folded byte compare are set by one type choice

Where a float scaled by a constant meets an integer byte compare in the same
scheduling region, msvc6 decides both the `fxch st(1)` position and whether the
compare folds from the *type of the local that holds the scaled value*. The two
cannot be steered apart.

`gm_CalculateProductionValue` (0x10019720) needs

```asm
fmul   qword ptr [0x100257d0]
fxch   st(1)
cmp    byte ptr [esi], 0x17
fmulp  st(1)
```

Scaling through a `float` local folds the compare into `cmp byte ptr [esi],0x17`
but schedules it ahead of the `fxch`:

```c
mod_value = (float) ((double) mod_value * g_const_half);
value = (float) (acc * mod_value);            /* cmp; fxch  -> 391/396 */
```

Scaling through a `double` local puts the `[esi]` access after the `fxch`, as
the target does, but msvc6 then keeps the byte in a register and emits
`mov al,[esi]` plus a later `cmp al,0x17`, one byte longer:

```c
p2_wide = (double) mod_value * g_const_half;
value = (float) (acc * p2_wide);              /* fxch; mov al -> obj 397 */
```

A `volatile` store to the float result lands the `fxch` correctly too, but
sinks the compare two slots, past `fmulp` and `fstp` (387/396).

The `fxch` itself is a removable stack fixup, not a fixed instruction. Making
the scaled double the destination of the merge multiply drops it and shortens
the object by two bytes:

```c
acc = (double) mod_value * g_const_half;
mod_value = (float) (acc * quot);             /* no fxch -> obj 394 */
```

So the question is never how to move the `fxch`, but why the folded compare is
ranked ahead of it. Every measured shape falls into one of four classes, and the
target's `fxch; cmp` is in none: `cmp; fxch` (391), `fxch; mov al` (obj 397),
`fxch; fmulp` with the compare sunk past `fstp` (387), and no `fxch` at all
(394 or 385, the latter keeping the non-popping `fmul st,st(1)`).

Inert here, and worth skipping on a similar diff: every CFLAGS variant (`/G3`
`/G4` `/G5` `/GB` `/Ox` `/Ot` `/Oa` `/Ow` `/Gy` `/Oi-` `/Ob1` `/QIfdiv-` `/GX`
`/GR` `/Gs` `/GF` `/Gf` `/Zp1` `/Ob2` `/Oi` `/Og` `/Gi` emit byte-identical
objects, compared as hex rather than by score), 20 `#pragma optimize`
combinations plus dropping the pragma entirely (which holds the same order at
383, so this site and the section 44 epilogue lever are independent), all four
msvc6 service packs, 14 declaration orders, every compare spelling and branch
shape, the compare's pointer provenance, reading the byte at the top of the
function, a double accumulator in the arms, duplicating the scale into both arms
(msvc6 duplicates the `fmul` rather than cross-jumping, so the merge block
boundary does not move), eight nested association trees, and 942 generated tail
permutations. Section 8b's `volatile` read defeats the fold but also moves the
load, so it does not separate the two either.

When a diff is a single adjacent transposition of an FPU stack op and an
integer compare, check whether the two are coupled through one type choice
before spending a pass on statement order.

`src/Develop/DieGildeAddOn/game/spiel622.c:232`, search scripts in
`.scratch/pv-x87/` and `.scratch/spiel622-x87/`.

## 47. A loop's form, not its text, decides where C2 puts its cold exit block

`ServerMainThread` (0x100093a0) has a loop whose taken branch leads to a cold
block that the reference keeps out of line (after the *next* loop, in a gap in
an unrelated chain).  Everything about the loop's text matched the reference
already: the instructions were identical, the branch target was right, and nine
rounds of probes left the block inline, immediately after the loop with a `jump`
over it.

- label position (including moving the cold body to the end of the function)
- branch polarity (`if (clear) { advance; continue; } goto cold;` versus
  `if (taken) goto cold;`)
- guard form, block duplication, cold-tail placement, region size
- `#pragma optimize` letters
- every VC6 service pack, and a CFLAGS sweep

What moves it is the loop's **form**:

```c
    do {                                  /* cold block lands inline */
        if ((*p & mask) == 0) { advance; continue; }
        goto cold;
    } while ((int) p < bound);

    while ((int) p < bound) {             /* cold block lands out of line */
        if ((*p & mask) != 0) { goto cold; }
        advance;
    }
```

The body, the condition and the `goto` are the same; only the rotation differs.
Three loops in that function gained alignment this way (522 -> 547 -> 557 -> 558
of 627 instructions, localised with the relocation-masked sequence diff).

Two cautions, both measured:

- **It is loop-specific, not universal.**  The same edit on the pending-sync
  transfer loop *regressed* 558 -> 523, and on `process_pending_sync` it was
  neutral.  Convert only loops whose taken branch targets a cold block the
  reference places out of line, and measure each one.
- **Do not judge it by the positional byte score.**  That score fell 1162 -> 828
  on the change that raised alignment by 25 instructions: one extra instruction
  shifts every later byte, so the positional count desynchronises.  Compare
  instruction sequences with relocations masked (`scripts/seqdiff.py`,
  `scripts/zlibcheck.py`) and keep the build's own `.text` size as the
  link-level figure.

## 48. msvc6 folds a compared variable into a later store, and no spelling keeps it in the register

`ServerMainThread` (0x100093a0) builds a command packet in the
`if (sent_bytes == 0xffffffff)` arm of the transfer loop.  The reference keeps
`sent_bytes` in `eax` across the arm and loads `total_size` into `ecx`:

```asm
    mov  eax, [ebx]                    ; sent_bytes (compared with -1)
    cmp  eax, -1
    jne  ...
    mov  ecx, [0x101deac0]             ; total_size
    lea  edx, [esp+0x10]
    push edx
    push ebp
    mov  byte  [esp+0x18], 8
    mov  byte  [esp+0x1b], 0xff
    mov  dword [esp+0x1c], eax         ; sent_bytes, register form
    mov  dword [esp+0x24], 0
    mov  dword [esp+0x28], ecx         ; total_size
    call cm_QueuePlayerCommand
```

When the arm stores `sent_bytes`, msvc6 constant-propagates the value the
`if` compared and emits the 8-byte immediate `mov dword [esp+0x1c], 0xffffffff`
instead.  That frees `eax`, so `total_size` lands in `eax` and the `lea` takes
`ecx`: three instructions differ and the object is four bytes long.

Measured on the same file, all **inert** (byte-identical objects): comparing
`(int) sent_bytes == -1`; storing a literal `0xffffffff`; storing
`(unsigned int) (int) sent_bytes`; copying `sent_bytes` into a second local
and comparing or storing *that* (copy propagation carries the constant
through); declaring `total_size` inside the arm.  The fold is driven by the
compared *expression*, and neither a cast nor an intermediate variable breaks
it.

The one spelling that clears it is to compare the memory operand instead of the
local, `*(unsigned int*) transfer_progress == 0xffffffff`.  The value then
survives in `eax` and `total_size` moves to `ecx`, exactly as the reference.
The cost is a second live value across the argument pushes: c2 then stores
`total_size` before the pushes (pre-push displacements) and gives the `lea`
`ecx`, so three hunks close and three open, and the object drops to 2431 bytes.
Recorded as a dead end rather than a fix.

Note the *other* arm of the same `if`, at target 0x10009846, stores the literal
`0xffffffff` and the reference keeps the 8-byte immediate there too.  Only the
arm whose store operand is a variable reaches this rule.

Amendment (2026-09-13): two further probes on the same arm, both reverted.
Dropping `volatile` from the cmd+4 store changes nothing structural (2074 ->
2070 positional); reading `total_size` at its point of use instead of hoisting
it re-derives the memory-operand outcome above (obj 2431, SIZE_MISMATCH).
The fold is a fixed point of the compared expression, not of any statement
order around it.

## 49. A CFLAGS sweep on one function: inert, negative, and one near miss

`gm_AllocSpieler` (0x10018850, target object 3689 bytes; an earlier revision of
this section cited 0x1001A0F0, which is `gm_RandomFloat01`) is the smallest
remaining size mismatch in the tree (ours 3688, same span), and it was used to
sweep the flags that are plausibly still in play.  Numbers are the object size
and the register-agnostic matched-byte count from `rebrew diff`; "inert" means
a byte-identical object.

| flags added to `/DREBREW_ALLOW_NAKED /O2 /Gd /Oa /Ow` | object | reg-agnostic | verdict |
|---|---|---|---|
| (base) | 3688 | 853 | n/a |
| `/Ow-` | 3692 | 840 | size closer, content worse |
| `/G6` | 3701 | 819 | size closer, content worse |
| `/Op` | 3766 | n/a | much larger |
| `/Za` | n/a | n/a | larger |
| `/QIfist` | n/a | n/a | larger |
| `/Zp1 /Zp2 /Zp4 /Zp8` | 3688 | 853 | inert |
| `/Ob2`, `/Ot`, `/Oi`, `/Oi-`, `/Oa-`, `/G5`, `/GB` | 3688 | 853 | inert |

Section 94 is the last word: `/Ow` load-bearing, `/Oa` inert. The `/Oa-` row
above and section 58's earlier "both load-bearing" claim are superseded.

The lesson is the general one: on this codebase a flag that moves the size
towards the target has so far always moved the *bytes* away from it, because
the size gap is one instruction's worth of a scheduling decision, not a
codegen-policy difference.  Sweep a flag only when a *specific* instruction
class is wrong (section 50), and score with the reg-agnostic count, never the
size alone.

## 50. The residual codegen classes, as instructions

Across the game region the remaining differences keep falling into five
shapes.  Quoting target disassembly first, ours second:

```
0x100097fb  mov [r+0x1c], r          / mov [r+0x1c], 0xffffffff   -1 materialization
0x1000984b  lea r, [r+r]             / add r, r                    strength reduction
0x100098e3  je  <loop head>          / jne <exit>                  branch polarity
0x10009baf  mov [r+0x30], r  ...     / [r+0x28], [r+0x2c], ...     frame offsets
 0x8c9       mov ax, [ebp]           / xor r, r                    zero-register cache
             and eax, 0xffff         / mov r16, [mem]
```

* **`-1`/zero materialization.** The reference keeps `-1` in a register once
  (`or ebp, -1`) and stores the register; we emit the 8-byte immediate.  This
  is msvc6's absence of constant caching and has no source lever
  (`docs/msvc6-allocator.md`).
* **`lea r,[r+r]` vs `add r,r`.** c2 picks `lea` when the flags are live;
  a spelling that kills the flags register is the only lever found.

  **Refined (round 855, isolated): the trigger is a live *offset operand*, not the flags.**
  Built the minimal case in the round-844 testbed and swept the spellings:
  `base + off`, `&base[off]`, `off + (int)base`, `(char*)base + (unsigned)off` all give
  `add` when the sum is the last thing the function does. The `lea` appears when **`off`
  itself is used again after the sum**:
  ```c
  int* g; int* g2;
  void f(void) { g = (int*)(base + off); g2 = (int*)off; }   /* -> lea (%eax,%ecx,1),%edx */
  void f(void) { g = (int*)(base + off); g2 = (int*)base; }  /* -> add %eax,%ecx        */
  ```
  Two things follow. First, the `lea` target is a **third** register (`edx` here,
  `esi` at the real site), which is what the reference does at `0x1000984b`, so the rule
  predicts the register as well as the opcode. Second, flags-liveness is neither necessary
  nor sufficient: I get `lea` with the flags dead (`return off;`) and `add` with them live.
  §122's sentence is the right shape but names the wrong cause, and the wrong cause is what
  sent round 853 after a spelling instead of after the second use.
  **Consequence for §127's site:** our `payload_src` has no later use, so no spelling of the
  sum reaches the reference's `lea`; the fix would be a second *use* of `sent_bytes` after
  the sum, which the surrounding code does not have.
* **Branch polarity** (see also section 7).  `je <head>` against our
  `jne <exit>` is a block-placement consequence, not a source choice, except
  where several guards share an error tail, where a guard inversion decides
  which site falls through and is a source lever (section 54).
* **Frame offsets.** `+0x20/+0x24/+0x30` against our `+0x1c/+0x28/+0x2c` is
  the local-slot layout inside one function; it follows `volatile` placement
  and the order of declarations, and it has been steered exactly once
  (round 110).
* **`and eax, 0xffff` after a 16-bit load.** The reference zeroes a register
  once and uses `mov reg16, [mem]`; we widen with `and`.  Section 43's
  byte-width rule is the related lever, and it is why
  `ls_LoadBuildingEntityState` stays one byte long.  The pair is not an
  unsteerable residue: the `and` form is what a `volatile` load emits and the
  `xor`/`mov` form is what a plain one emits (section 52), so where the
  reference has `xor`/`mov` and we have `mov`/`and`, drop the qualifier on that
  load rather than retyping it.

The one case that *was* steerable had a structural cause: `cm_ExCopyEntityData`
(round 110) reached its store block from several duplicated branches, and
spelling the clamp "in range first, then high, then low" collapsed them.
Before spending a round on any of the five, look for that shape first.

## 51. `volatile` on a local is a scheduling barrier; qualify at the use site

A `volatile int x;` declaration makes *every* store to `x` a scheduling
barrier, so msvc6 will not move a load across it. Declaring the local plain and
qualifying only the accesses that need ordering (`*(volatile int*) &x`)
produces a different (sometimes exactly the reference's) schedule. It is a
scheduling lever, not a semantics knob.

`vfs_ReadCompressed` (0x10008a90) declared `volatile int done; volatile int
result;`. Replacing both with plain locals plus casts at the use sites
reproduced the reference's prologue byte for byte:

```
mov eax,[esp+0xc] / push ebx / push ebp / push esi / test eax,eax / push edi /
store / store / jne
```

and was worth -62 linked bytes.

Two sub-facts, both measured:

- It is the two *init* stores that are the barrier, not the declaration as
  such. On the older body, merely casting the init stores (`*(int*) &done = 0;`)
  with the `volatile` declarations kept already scored 382.
- One plain read (`int acc = result;`) MUST stay plain. Qualifying it cost 32
  bytes.

This is the converse of section 39 (a volatile read *deferring* a load past the
prologue pushes) and of 8c (a volatile read *pinning* load order): here the
qualifier is removed, and the granularity is one access, not the variable.

`src/Develop/Units/vfs/vfs_ReadCompressed.c`

## 52. The 16-bit zero-extend idiom is selected by `volatile`, not by C spelling

A plain `unsigned short` load emits `xor r,r; mov r16,[mem]`. The same load
through a `volatile` pointer emits `mov r16,[mem]; and r,0xffff`. Seventeen
spellings on msvc6 `/O2 /Gd` in a micro TU (global, cast, typed pointer, struct
member) all follow the qualifier, not the syntax.

**Corollary, and the reason this section exists: the idiom cannot be reached by
spelling at all.** On `gm_AllocSpieler` (0x10018850) every attempt to write the
reference's `xor r,r; mov r16,[mem]` form while keeping the `volatile`: `(int)(unsigned)*(volatile
unsigned short*) p`, the same through a temp local, the same for a second site, and a
`n = 0x3c + (idx < 6 ? 0x86 : 0)` temp for the paired `and edx,0x86` (6-byte imm32)
against our `and edx,0xffffff86`, folded straight back to the current code. The
qualifier wins every time, so a site whose reference form differs has to be fixed by
removing the qualifier (and paying whatever hoist that causes) or by a size-compensated
rewrite, never by casting around it. Check the qualifier before spending probes on the
expression.

So an `and r,0xffff` in our output is evidence the source reads that field
`volatile`, and where the reference has `xor`/`mov` and we have `mov`/`and`,
the residual is the qualifier, not the expression.

`gv_ExAllocGraveyardWorker` (0x10011bf0): its two neighbour-loop reads are
volatile in our source and demonstrably were not in the original.

This refines section 6 (the widening mask is a `volatile` tell, not a width
tell) and supersedes the last bullet of section 50, where the pair was recorded
as a residue with no source lever. The lever is dropping the qualifier on that
one load.

**Amendment (round 245): the lever has a wall, and the direction is easy to
invert.** A pass was briefed with the qualifier backwards ("add `volatile` to get
the reference's `xor`/`mov`") and refuted it in 14 probes; the brief was wrong,
this section was right. What that pass *did* establish is where the lever stops:

- **The qualifier is load-bearing for register allocation at some sites, and there
  the lever cannot be cashed.** On `gm_AllocSpieler` (0x10018850) dropping it at
  the two sympathy-loop reads *does* produce the reference's `xor ecx,ecx; push
  0x40; mov cx,[bp]` locally, and costs 362 matched bytes (736 -> 374), because
  the qualifier is what holds that loop's allocation. Dropping it at both loops:
  397. Form and allocation are coupled; this is the same shape as
  `gv_ExAllocGraveyardWorker` above, now measured on the larger function too.
- **Sweeping the qualifier *in* is worse than leaving it alone.** Adding `volatile`
  at 1 / 8 / 17 sites gives matched 488 / 408 / 365 against HEAD's 736, and the
  full sets push the object to COMDAT 3728/3744, past the 3696 composition band,
  so they fail on layout as well as on score.
- **A count of `and r,0xffff` sites is not a length signal.** The inventory on this
  function ("6 extra `and`, 4 missing `xor`") is a fixed-offset artifact: both
  sides' real code is already exactly 3689 bytes, the gap curve oscillates +-48 and
  returns to 0, and the 4 reference `xor`s are all present in our object (the last
  one displaced by one statement-order divergence, not missing). Of our 16 masks
  only 7 are genuinely extra: 3 are a redundant second mask on a call result, 4
  are the volatile loads.
- **`matched` has a ceiling here of ~3115 of 3689** (`matched-reloc - matched` =
  574, one-sided relocations; see allocator Finding 59). Do not treat the distance
  from 736 to 3689 as reachable codegen work.

The practical rule this leaves: `volatile` is a *per-variable fixed point*
(allocator Finding 61). Check the qualifier first, in the direction this section
states, and expect the lever to be blocked wherever that value's live range also
determines the allocation.

Amendment (2026-09-13): the same fixed point, third instance, on
`vfs_OpenStream` (0x10009020). Dropping `current_char` gives the reference's
`cmp byte [eax],0` entry test and `movsx eax,[esi]` head load byte-exact, plus
a byte-exact rotated back edge, but frees `al` and recolors the switch body
into ~40 small hunks (linked +194). Two proof-breaking spellings (volatile-
sourced init+increment; `p[1]`-before-inc reorder) both fail: c2's value
numbering sees through them, and the unproven forms add traffic. Any
proven-equal local is reused at the head; any unproven one costs elsewhere.

`src/Develop/DieGildeAddOn/game/friedhof_logic_c/gv_ExAllocGraveyardWorker.c`

## 53. `switch` case bodies are laid out in source order

Reordering the case groups to match the reference's addresses put every body on
its reference offset; the jump table and byte map are then byte-identical. The
case *order* is the lever, not the case set.

`gm_AllocGebaeude` (0x100174d0), worth ~-200 linked bytes.

`src/Develop/DieGildeAddOn/game/spiel_c/gm_AllocGebaeude.c`

## 54. A guard inversion moves which site falls through, and with it the branch histogram

Where several error sites share one tail, `if (success) { body } else { error }`
and `if (failure) { error } body` are semantically identical but reach that tail
differently: one site falls through, the others `jmp`. Which site falls through
decides the displacement sizes, and therefore the rel8/rel32 mix.

`cm_ExSellObjekt` (0x1000d930) has, in the reference, 13 `LogMessageInternal`
sites: 3 inline `sprintf` tails and 10 on a shared tail at 0x1000e00e, 9 by
`jmp` and 1 by fall-through. Reverting one inversion restored the reference's
fall-through site and its exact encoding histogram (12 x rel32 + 10 x rel8),
worth -38 linked bytes.

This refines section 50's "branch polarity ... is a block-placement consequence,
not a source choice": the polarity of a guard that *shares* a tail is a source
choice. Section 7 covers the same edit from the epilogue-count side.

`src/Develop/DieGildeAddOn/command/command_c/cm_ExSellObjekt.c`

## 55. Comparison rewrites must keep the strict/non-strict boundary

`a - b < 0` is `a < b`, never `b <= a`. A candidate written
`if (0 <= slots - g_stat2)` for `if (g_stat2 - slots < 0)` flipped the equality
case: a behavioural change, not a codegen one, and it was caught by reading the
diff, not by any score.

To change which operand folds, flip the operands of the same operator
(`slots > g_stat2`), never the operator's sense.

Same blind spot as section 34 (wrong global behind `~~`): `match_count` and the `~~` mask cannot
see it. The candidate's VA was not recorded; the finding is a diff-reading
habit, not a site.

## 56. A missing exit epilogue is a `return` that hands back a register

Where the reference's tail returns re-read a volatile local
(`jne` / `mov eax,[esp+0x14]` / pops / `ret`), a source `return d;` returns a
register that already holds the value, so msvc6 needs no load and tail-merges
that exit onto the main epilogue. Spelling it `return *(volatile int*) &done;`
restores the separate epilogue byte for byte.

`vfs_ReadCompressed` (0x10008a90): a whole third exit epilogue, 12 bytes, worth
-22 linked. Same function and the same lever as section 51: the qualifier sits
on the use, and it is what makes the load reappear.

`src/Develop/Units/vfs/vfs_ReadCompressed.c`

## 57. Loop shape is a lever only when the divergence is not register pressure

A bottom-tested `do{}while` can put the body out of range of a short back edge,
so msvc6 emits `jge exit` plus a long `jmp`; a top-tested `for` restores the
single `jl` back edge.

`cm_ExProdObjekt` (0x1000e140), worth a large re-alignment.

Where the reference simply holds a different set of live values, loop *shape*
rewrites are inert:

- `CrashDumpUnhandledExceptionFilter` (0x10002770): five spellings of the
  decrypt loop (`for`, `while`, `do-while`, `>>2`, pointer increment) are
  byte-identical.
- `ahm_ExAllocAlchemist` (0x1000bdf0): all eight factorisations of a stride
  (`*0x21c`, `*540`, `*45*12`, shifts) are byte-identical, because the strength
  reducer re-derives the same chain.

Read the diff for a live-value difference before reshaping a loop; sections 8,
20, 31 and 47 are the cases where the shape itself was the divergence.

`src/Develop/DieGildeAddOn/command/command_c/cm_ExProdObjekt.c`

## 58. `/Ox` versus `/O2` is per-file and load-bearing

`/O2` enables `/Og`, which makes msvc6 tail-merge early error blocks the
reference keeps separate; `/Ox` is what several command-handler files need.
On `gm_AllocSpieler` (0x10018850), **`/Ow` is load-bearing** and **`/Oa` is
entirely inert** (section 94). `/O2`-class flags are inert on it.

Flags are per-file in practice, not per-function: a flag one function needs can
break a file-mate. Section 12 is that conflict. Section 49's `/Oa-` row and
the earlier "both `/Oa` and `/Ow` load-bearing" claim here are superseded by
section 94. `/Ox` is byte-identical on an individual function (section 46)
while being load-bearing per file.

`src/Develop/DieGildeAddOn/game/spiel_c/gm_AllocSpieler.c`

## 59. `if (cond) goto L;` compiles to `if (cond) { body }`; cold handlers are placed by block *creation* order

`if (cond) goto L;` (a branch to a label) compiles to a byte-identical
object to `if (cond) { body }` with the body inline. Both spellings of the same
guard sequence were compiled and their COMDATs byte-compared: 2128 bytes each,
identical. msvc6 normalises the `if`-goto form back into a plain `if` and still
lays the then-block inline, so "I wrote a `goto`, so the handler must sit out
of line" is false, and any note that credits a `goto` for a block's position is
wrong.

What actually places cold handlers at the tail (and in **reverse source
order**) is block *creation* order: the front end creates `else`-blocks
innermost-first. A sequence of guards written
`if (failure) { error; goto done; }` therefore does not give the reference's
layout, while `if (success) { body } else { error }` does; the handlers then
materialise at the tail in reverse source order.

Measured on `CrashDumpUnhandledExceptionFilter` (0x10002770): rewriting its
guards in the `if (success) {...} else { error }` shape put all four
`LogMessageInternal` sites at the tail, gave 44 calls (the reference's count)
and was worth **-29 linked bytes**, size-neutral (COMDAT 2128, frame
unchanged). The same change written as `if (cond) goto L;` with tail labels was
byte-identical to the original and worth nothing.

The reference's own cold blocks there sit at 0x10002db3, 0x10002de9,
0x10002e1b, 0x10002e29, 0x10002e35, 0x10002e4d: reverse source order, which is
the signature to look for on other functions whose cold handlers differ.

This is the same family as section 54 (a guard inversion moves which site falls
through, and with it the rel8/rel32 branch histogram) and section 50's
branch-polarity item: block order, not statement shape. It also narrows section
17, which recorded out-of-line placement as unsteerable from source: the
`goto` label is not the lever, the `if`/`else` form that *creates* the block is.

`src/Develop/Units/Error/Error_c/CrashDumpUnhandledExceptionFilter.c`

## 60. A volatile store's position is a dependency fixed point, not a statement-order choice

On `cm_ExProdObjekt` (0x1000e140) the reference emits
`mov edx,[0x101de450]` before the volatile dead store that follows, and we emit
it after. Moving the volatile `loop_count` store below the
`recipe_shift = g_unknown_1de450 + ...` statement (so that the global load
precedes it in source order) produced a byte-identical object to the
unmodified source. The scheduler places a volatile store by its dependence, not
by where the statement sits, so a volatile store cannot be slid past a global
load by rewriting the source order. The reference's global load is above a
volatile store, and a store through a cast pointer is treated as aliasing every
global, so the shipped msvc6 will not emit that order from any source shape
tried: treat it as closed.

This is the third site in this campaign where statement order was inert in
exactly this way: the converse of section 51 (where the lever was moving the
`volatile` *qualifier*, not the statement) and the same shape as section 57's
loop case. Where a load/store transposition does have a lever, it is section
44's `#pragma optimize("a", on)`, which switches the aliasing assumption off.

Retired lever, not a general law: measured with `scripts/probe_function.py` and
`scripts/instr_diff.py --obj`, and it did not move the linked residue.

`src/Develop/DieGildeAddOn/command/command_c/cm_ExProdObjekt.c`

## 61a. The aliasing lever is a wall when the function has more than the one transposition (round 1020)

Section 44 makes `#pragma optimize("a", on)` the lever for "a pure transposition of a load and a store to
the same object". `cm_ExProdObjekt` (0x1000e140) has exactly that signature: the reference loads
`g_unknown_1de450` at `0x1000e20c` **before** the volatile dead store, we emit it after, and section 60
had already closed every source-order spelling. So the aliasing switch was the last untried lever, and it
was measured two ways.

**Both spellings, at the link:**

| form | object | linked `cm_ExProdObjekt` | delta |
|---|---|---|---|
| baseline `/Ox /Gd` | 2897 | 21 | n/a |
| `#pragma optimize("a", on)` in source | n/a | 679 | **+658** |
| `/Oa` on the compile line | 2881 | 679 | **+658** |

They agree byte for byte, which is the useful part: the pragma and `/Oa` are the *same* switch reaching the
same scheduler state, so neither is an independent lever.

**The rule.** Section 44 applies when the transposition is the *only* thing the aliasing assumption is
holding in place. `cm_ExProdObjekt` carries three residual clusters (`0x1000e20c` load order, 223-224,
byte 410) and a large loop; switching the assumption off re-schedules all of them at once, and the three
bytes it fixes cost 658. **Screen for cluster count before reaching for `"a"`**: on a single-transposition
site it is a clean lever (section 44's `sim_AdvanceGameClock`: 187 -> 194/197), on a multi-cluster site it
is worse than the transposition it removes.

`/Ow` was measured too and is inert here (object 2897, unchanged), consistent with section 44's note that
`"w"` scores the same as `"a"` only where `"a"` already helps.

Retired lever on this row, not a general law: both spellings measured at the link with `scripts/linktest.sh`
and reverted.

`src/Develop/DieGildeAddOn/command/command_c/cm_ExProdObjekt.c`

## 61. A shared guard the reference falls into cannot be reached by fall-through from C

On `cm_ProcessCommandQueue` (0x1000aac0) the reference has a shared `recheck`
guard (`test ebx,ebx; je <unlink>`) that arm 5 falls into after `held = pkt`.
Our arm 5 does `goto advance` and skips it, so our `jne` retargets. Changing it
to `held = pkt; goto recheck;` collapses the entire function: matched-reloc
584 -> 142 on the object metric, 624 -> 204, because msvc6 re-lays the block
graph.

Same family as section 59 (block order, not statement shape) and section 54:
what is not reachable from C here is the *layout decision*, not the statement.
A `goto` is normalised back into an `if` (section 59), so it cannot express
"make this arm fall through into the guard the reference shares".

Retired lever, not a general law: measured with `scripts/probe_function.py` and
`scripts/instr_diff.py --obj`; neither spelling moved the linked residue.

`src/Develop/DieGildeAddOnServer/server_c/cm_ProcessCommandQueue.c`

## 62. A literal shared by several comparisons is not a lever for register residence

Hoisting a repeated immediate into one named local does **not** make msvc6 keep
it in a register.  On `cm_ExCopyEntityData` (0x1000ec00) the four slot guards
each compare against `0xffff`; feeding all four from a single local

```c
ushort empty = (ushort) 0xffff;      /* int instead of ushort: same result */
```

is **byte-identical** to spelling the four literals out.  msvc6 rematerialises
`cmp word ptr [reg+disp32],0xffff` (9-10 B) at each site rather than keeping the
value live.

The reference does hold it: `mov ebp,0xffff` once at 0x1000edc0, then
`cmp word ptr [eax+0x100358a0],bp` (7 B), but `ebp` is free there only because
the instruction that clobbers it (`mov ebp,[eax+0x10035ab0]`, the type-3 arm's
owner_id load) sits on the other side of a branch.  That is a CSE plus
callee-saved allocation decision with no C spelling: the value's live range is
what it is, and a source-level name does not extend it.  A wall, not a lever.

Contrast section 22 (`4 + load_result`), where the *spelling of the load*
selected the cached form.  The distinction: there the spelling changed the
address expression the optimizer had to compute; here it changes only a name the
optimizer erases before allocation.

`src/Develop/DieGildeAddOn/command/command_c/cm_ExCopyEntityData.c`

## 63. A clamp's winning arm order is per-site, not per-function

The same three-arm clamp wants a different source order in each of the several
arms of one function, and copying a neighbouring arm's order is not
transferable.  Measured on `cm_ExCopyEntityData` (0x1000ec00), one arm at a
time, all exhaustively equivalent so semantics are constant and only layout
moves:

| arm | order that wins | effect |
|---|---|---|
| type-2 | in-range / HIGH / low | honest matched +13 (`jl low / jge high / store / jmp`) |
| type-1 (secondary) | in-range / LOW / high | honest +7, aligned +10 |
| type-0 | per-arm stores, trailing store duplicated into each arm | matched-reloc +6, honest -2 |
| matrix loop | in-range / LOW / high, store after the join (already HEAD) | in-range / HIGH / low craters to 342/524 |

What selects the winner is which order puts the cold blocks in the reference's
**address order** (section 59: block *creation* order, not statement shape).
Since that order differs per site, there is no function-level rule to extract:
measure each arm.  A general "reorder the clamps like the neighbour" edit is not
a lever.

`src/Develop/DieGildeAddOn/command/command_c/cm_ExCopyEntityData.c`

## 64. `for (;;) { if (x) break; ... }` is normalised to the `do/while` form

An indefinite loop exited by `break` is re-lowered into the loop test, producing
byte-identical output to the equivalent `do { ... } while (!x)`.  Measured on
`cm_ExCopyEntityData` (0x1000ec00): the dst-slot scan written `for (;;) { if
(match) break; ... }` compiles identically to the `do/while` spelling, with the
same peeled first compare plus rotated body.

Same normalisation family as section 59 (`goto` re-lowered into `if`): here the
`break` re-appears as the loop's own test, so `for(;;)`+`break` cannot be used to
force a loop shape the `do/while` form does not already produce.  Corollary for
this function: the reference's *unrotated* dst scan is reachable only from the
top-tested `while` spelling, and that spelling costs the entry guard the
reference lacks (+3 B, aligned +6, honest -47) -- so the rotation is a genuine
fixed point, not a spelling problem.

`src/Develop/DieGildeAddOn/command/command_c/cm_ExCopyEntityData.c`

## 65. an if/else-if chain and a real `switch` emit their jump tables in OPPOSITE order

The strongest read-out of dispatch form found so far, because it is a *structural*
difference a byte compare sees as a region of total mismatch.

On `CrashDumpUnhandledExceptionFilter` (0x10002770), written as a hand-rolled
`if/else if` chain over the exception code, the COMDAT's two out-of-line tables are
emitted **10-entry then 5-entry**.  Rewritten as one `switch (excCode)` with the same
case set and the same bodies, they come out **5-entry then 10-entry** -- which is the
reference's order (5-entry at 0x10002e9c, 10-entry at 0x10002f1c).

Measured with the switch rewrite *alone*, nothing else changed:

```
matched        231 -> 387
matched-reloc  655 -> 811
aligned        283 -> 366
drift at 0x10002a43   +470 -> -26
```

So the table order is not cosmetic and not downstream of the case bodies: `switch`
selection changes the block layout, and the fix is to *use a switch*, not to try to
reorder tables from C.  Corollary: the two hand-computed index maps (0x69 bytes for the
`-0xc0000025` switch, 0x6f for `-0xc000008f`), the `lea ecx,[ecx+0]` 3-byte align pad and
the 1-byte `90` pad are all *consequences* of that layout and cannot be fixed directly.

**Use it as a diagnostic in the other direction too:** when a function's residue contains
a region that looks like total mismatch and the source has a long `if/else if` chain over
a dense integer key, try the `switch` form first.

**Precondition (round 176): check the reference for a jump table before applying this.**
The win above worked because that reference *already had* two out-of-line tables, so
`switch` matched the selection msvc6 had made originally. `ls_LoadBuildingEntityState`
(0x100128f0) looked like the same situation and is the opposite: its reference dispatch is
a linear `cmp al,0xNN` / `je` chain with the default falling through, and the if/else-if
chain is the only C form that reproduces it. A genuine `switch` over the same key set
({0x1e, 0x48-0x4a, 0x4b-0x4d}) is dense enough to trip msvc6's table heuristic, which
emits `jmp DWORD PTR [ecx*4+...]` plus an index/address table: object 1472 -> 1520 (+48),
matched 690 -> 573. So the rule is *match the reference's selection*, not "prefer switch".

**And verify the arm order from the emitted bytes, never from the source text.** A round-175
block-order map recorded this function's arms as fully reversed and queued the rewrite on
that basis; objdump showed the baseline already emits them in the reference's order
(uniform +2 drift, byte-identical compare chain including all six `je` displacements, zero
hunks in the region). The map had compared source text order against emitted order. msvc6
emits else-blocks innermost-first (section 59), so source order is *expected* to look
inverted: reading it as a divergence manufactures work that does not exist.

`src/Develop/Units/Error/Error_c/CrashDumpUnhandledExceptionFilter.c`
`src/Develop/DieGildeAddOn/loadsave/loadsave_c/ls_LoadBuildingEntityState.c`

## 66. a dead store in the source appears as a store in the reference: comparing stores is a dead-code oracle

`frameInfo[0] = (int) pDbgBuf;` occurred twice in the source on
`CrashDumpUnhandledExceptionFilter` (0x10002770); the reference has exactly **one** store
there, and the pre-chain copy is absent (no store between `mov edi,[esp+0x294]` at
0x100029f7 and the first `cmp eax,0xc000008e` at 0x10002a02).  Deleting the first copy:
`ret` moves -8 bytes, `matched` 442 -> 475, span 2128 -> 2112, no warning.

The general technique: **count the stores to a location in the reference and compare with
the source.**  The compiler cannot remove a store the reference contains, and it will not
invent one, so a store-count difference is a source-level contradiction -- a duplicated
assignment, or one the original never had.  This is much cheaper than reading a diff, and
it works on a location whose address is a frame slot rather than a symbol.

`src/Develop/Units/Error/Error_c/CrashDumpUnhandledExceptionFilter.c`

## 67. msvc6 does not reorder calls, so call order in the source is recoverable from the reference

`CrashDumpUnhandledExceptionFilter` (0x10002770): in the hCrashLog-OK path the reference
calls `GetCurrentProcess` ([0x1002402c], 0x100028fb) **before** the two `szLine`/`szSep`
memcpys (0x10002901..0x10002923) and `SetFilePointer` ([0x10024028], 0x1000294c); the
source had `GetCurrentProcess` after `SetFilePointer`.  Hoisting it: `matched` 475 -> 478,
everything else unchanged.

Unlike register allocation or block layout, **statement order across calls is a
source-order property**, so the reference's call sequence reads directly into a
reordering.  Worth checking early on a mismatching function: list the calls in reference
address order and compare with the source's order.

`src/Develop/Units/Error/Error_c/CrashDumpUnhandledExceptionFilter.c`

## 68. a redundant null test after a search loop is NOT eliminated, and its width matters

`gm_AllocGebaeude` (0x100174d0).  Written

```c
while (q != NULL && *q == 0xfd) { q = next(); }
if (q != NULL) { store; }
```

msvc6 keeps a redundant 4-byte `cmp eax,ebx; je` for the second test.  The equivalent

```c
while (q != NULL) { if (*q != 0xfd) { store; break; } q = next(); }
```

matches the reference's rotated form (`jne top; jmp out`) and costs 4 bytes less -- and
because those 4 bytes sit *before* a 600-byte aligned region, they shift the switch and its
jump table: `matched` 503 -> 830.

Lever, and a reminder that the value of a byte is positional: 4 bytes here were worth 327
matched bytes, while 4 bytes elsewhere in the same function were worth nothing.

`src/Develop/DieGildeAddOn/game/spiel_c/gm_AllocGebaeude.c`

## 69. an `__asm` block is a scheduling barrier, and this project's C-only constraint forbids using it as one

**Mechanically real:** on `gm_AllocGebaeude` (0x100174d0) inserting

```c
__asm { nop nop nop }
```

between `idx = comp & 0x7fff;` and the `g_item_def_table` address expression made msvc6
move `mov ebx,[g_item_def_table]` across the two surrounding instructions, which flipped the
loop's forward `je` from rel8 to rel32 and realigned a 129-byte loop body onto the
reference's offsets.  With three further equivalent changes it measured `matched` 683 -> 830
and `matched-reloc` 823 -> 970 at an unchanged COMDAT of 1088.

**It is not usable here.**  The objective for this recompilation is C only, with a single
exception: hand-written assembly that the *original* code itself contained.  A `nop`
barrier is neither -- it is a directive to our compiler to reproduce a schedule no C
spelling produces, so it manufactures bytes the source does not explain.  The pre-existing
`__asm` block-fill in this same file is admissible because the original has a 24-byte
hand-written fill prelude there (Finding 19); the barrier is not.

Measured cost of honouring the constraint: removing only the barrier from that candidate
gives `matched` 377 (worse than HEAD's 683) and drops the COMDAT to **1072**, which moves the
jump table and breaks the composition.  So **the entire +147 rested on the barrier**, and
`gm_AllocGebaeude` was reverted to HEAD rather than shipped.  Recorded so the lever is not
re-derived as "free": it is real, it is large, and it is off-limits.

**What remains legitimate:** when a schedule is unreachable from C, look for a *source*
mechanism with the same effect -- an extra local that extends a live range, a
`volatile` qualification that pins a value to memory (section 60), or a statement order
that changes which block is created first (section 59).  Those are C, and their effect on
the scheduler is explainable.

**The "extra local extends a live range" mechanism measured inert on the barrier's exact
site (round 839).** A named `char* item_base` holding the table address before the
multiply, so the base load and `comp & 0x7fff` evaluate as separate statements:

```c
item_base = (char*) g_item_def_table;
comp_rec = item_base + (comp & 0x7fff) * 0x41;
```

is **byte-identical to HEAD** -- COMDAT 1078 (reference 1088), `matched` 753, no change on
either ruler.  The live-range extension it was meant to create does not happen, so
`mov ebx,[g_item_def_table]` stays where it was.  The remaining -10 is the barrier's
rel8->rel32 flip and is not reachable by naming.  Recorded so the suggestion is not read
as untried on this body: it is tried, and it is inert here.

`src/Develop/DieGildeAddOn/game/spiel_c/gm_AllocGebaeude.c`

## 70. operand order in a commutative address expression is inert; only the *nesting* steers

`ls_LoadBuildingEntityState` (0x100128f0): eight spellings of the same address
expression -- swapping the two operands of the `+`, reordering the addition chain, naming
an intermediate -- are **byte-identical**.  What does steer codegen is how the additions are
*nested*: `(load_result + N) + ptr` and `(ptr + load_result) + N` are different, because the
first computes a scaled index off `load_result` and the second folds `ptr` into the base.

So when an operand shape is wrong, the lever is the parenthesisation, not the order of a
commutative operator.  A sweep over operand orders is wasted budget; a sweep over nestings
is not (and this site was already at its optimum).

`src/Develop/DieGildeAddOn/loadsave/loadsave_c/ls_LoadBuildingEntityState.c`

## 71. `memset(p, 0, N)` is an intrinsic that is not value-tracked, so it beats `p[0]=0; p[0]|=1`

`ls_LoadBuildingEntityState` (0x100128f0).  Writing the state block as

```c
memset((void*) state_ptr, 0, 0x10);
state_ptr[0] |= 1;
*(int*) (esi + 0xa5) = -1;
```

reproduces the reference's state block **instruction for instruction** (34 bytes, 11
instructions), where `p[0] = 0; p[0] |= 1;` folds to a single store.  The reason is that the
`memset` intrinsic is opaque to the value tracker: msvc6 cannot see that the following
`|= 1` only touches a byte it just zeroed, so it keeps both the fill and the read-modify-write.

**Caveat that makes it a wall in practice here:** it is byte-neutral at this site
(`matched` 645 -> 645, `matched-reloc` 879 -> 869) because the block is compared at offsets
that are already +2 wrong, and the extra 4 bytes remove the compensating length that gave the
only aligned stretch in the tail.  A shape that is locally perfect still buys nothing when
its position is wrong -- check the running delta at the block *before* spending probes on
its internal shape.

`src/Develop/DieGildeAddOn/loadsave/loadsave_c/ls_LoadBuildingEntityState.c`

## 72. a callee-saved sentinel and a CSE can be one mechanism, not two

`ls_LoadBuildingEntityState` (0x100128f0).  The reference caches the `-1` sentinel in `ebp`
(`or ebp,-1` once, `mov [..],ebp` at three sites) and its read loop also relies on a CSE.
The two are **not separable**: give either of the two read-loop sites the other address
nesting (section 70) and the CSE disappears *and* the sentinel goes with it -- `push ebp`
1 -> 0, `or ebp,-1` 2 -> 0, `mov [..],0xffffffff` 0 -> 3, `matched` 645 -> 79.

Practical rule: when two register-allocation effects vanish together, they are one
decision upstream, and the 2-instruction form you are trying to fix is the *cheap* half of
it.  Here rematerialising the immediate costs +3 bytes, but rematerialising it at the three
stores costs +12 -- so the current encoding is the cheapest point on that trade, not a
mistake.

`src/Develop/DieGildeAddOn/loadsave/loadsave_c/ls_LoadBuildingEntityState.c`

## 72b. a locally exact nesting fix can still lose to the cascade it triggers

Same function (2026-09-13): the `+0xc`/`+0xd` call sites spelled
`(load_result + const) + idx` while their `+9`/`+0xa`/`+0x10` siblings spell
`(idx + load_result) + const`, and the siblings match.  Normalising all four
anomalous sites to the sibling nesting emits exactly the reference shape at
both call sites (`mov eax,[esi+0x71]; lea ecx,[ebx+eax+0xc]`, the cross-call
`lea ebp,[ebx+0xd]` hoist gone; aligned 401 -> 414) and kills the +144 middle
desync, but the object stays span-neutral while the previously-aligned tail
(0x0429-0x054b) recolors wholesale (`mov [eax],ebp` becomes
`mov [eax],0xffffffff`, slot shifts, an extra `push edx`): linked +672
(728 -> 1400).  Reverted.  Section 70's lever is confirmed real and at the
same time not link-profitable in this body: a shape fix that changes which
values are live re-runs the allocator over everything downstream.  Do not
re-try without a plan for the tail recoloring.

`src/Develop/DieGildeAddOn/loadsave/loadsave_c/ls_LoadBuildingEntityState.c`

## 73. `base + idx*0x40 + idx` always folds to one `[reg+reg]` operand

`gm_AllocGebaeude` (0x100174d0): nineteen spellings -- pointer cast, array subscript,
two-step pointer, `idx << 6`, `(unsigned)` cast, `int*`-scaled, `&arr[..]`, named
intermediates, split across two statements -- **all** emit `mov cl,[eax+ebx]`.  The
reference's materialised form (`mov ecx,eax; add ecx,ebx; mov cl,[ecx]`) is not reachable
from C at this site.

A wall: the indexed addressing mode is chosen whenever msvc6 can express the sum as
`base + index`, and no spelling suppresses it.  (The site was reached here only by a
scheduling barrier, which section 69 rules out.)

## 74. msvc6 folds byte-identical early-return epilogues unconditionally; the reference folds none

The wall behind every "the reference keeps N epilogues and we keep one" note in this
project, now measured rather than assumed.

On `gm_FindNextFilteredEntity` (0x10016f80) the reference has **five `ret` sites and merges
none of them**: three short ones (`xor eax,eax; pop esi; ret`, at `+0x17`, `+0x27`, `+0x75`,
all byte-identical) and two long ones (`pop edi; pop ebp; pop ebx; pop esi; ret`, at `+0x141`,
`+0x155`, byte-identical).  Each short one is reached by a **2-byte** conditional
(`jne +4` / `jle +4` / `jb +4`) that jumps *over* an inline fall-through return.

Our object keeps **two** `ret` sites: one short, one long, with five `rel32` branches
(`je 0x100170d2`, 6 bytes) into the shared short block.  So the cross-jump is **not**
downstream of any difference between the exits: the exit paths are byte-identical in the
reference and it still does not merge them.  Our compiler merges unconditionally.

**It is not a C-shape problem, and this is the evidence that settles it.**  A 352-byte
standalone TU (`.scratch/l8/m2.c`) carrying the target's exact guard/loop structure
reproduces the reference's prologue *byte-for-byte*: `mov eax,[g_entity_ptr]; push esi;
xor cl,cl; lea esi,[eax+0xa900]; mov eax,[g_entity_type_table]; test eax,eax`, and still
folds all three early exits into one far block.  `/O1`, `/O2 /Os`, `/O2 /Og-` and
`/O2 /Ot /Oy-` all give two `ret` sites as well.

Consequence: **eight return spellings have now been compiled across two passes and all are
inert**, which is what the wall predicts.  Do not spend probes trying to make an exit unique.
Recorded so the "two epilogues against the reference's three/five" note that recurs in this
project's file headers is recognised as this wall and not as an unsolved shape.

`src/Develop/DieGildeAddOn/game/spiel_dumpD.c`

## 75. A prologue-fidelity lever, and a past "climb win" that cost it

`gm_FindNextFilteredEntity` (0x10016f80): **`end = g_entity_ptr + 0xa900;` must precede
`if (g_entity_type_table == 0)`** for the reference's prologue to come out byte-exact.  With
that order the compiler emits

```
mov eax,[g_entity_ptr]; push esi; xor cl,cl; lea esi,[eax+0xa900];
mov eax,[g_entity_type_table]; test eax,eax
```

which is bytes `0x0`-`0x15` exactly.  Commit `551bea67`, accepted at the time as a climb win,
moved that assignment *below* the guard; the byte-exact prologue is lost and `matched` falls
130 -> 127.  A later variant that also drops the redundant `match = 0;` at `candidate:`
restores the prologue through `+0x15` (the only variant that does) but scores 57 once the
far-jump guards dominate.

Two lessons: a climb metric can accept a commit that is locally worse in a region it does not
weight, and the guard/assignment order around an early-exit prologue is a *lever* worth
checking whenever a function's first 0x20 bytes are wrong.

`src/Develop/DieGildeAddOn/game/spiel_dumpD.c`

## 76. A `volatile` read at a *post*-loop test blocks the loop's entry-guard fold

The cheapest win of the last stretch, and a shape worth checking first when a loop's entry
guard retargets.

`vfs_ReadCompressed` (0x10008a90): the guard's `jbe` at `0x10008b0f` targets the **result**
epilogue (`0x10008c59`) in the reference, but our build targeted the merged `done` test block
(`0x10008c51`), because the post-loop test read `done` through a `volatile` qualifier and that
blocked msvc6 from proving `done == 0` on the entry edge.  Making that **one** test plain --
`if (done == 0)` -- while leaving both `return` reads and the in-loop read volatile removed
exactly that hunk: `matched` 447 -> 448, `matched-reloc` 467 -> 468, object/real/aligned
unchanged, hunks 8 -> 7, and **-1 at the link**.

Reach for it whenever an entry guard retargets because a value could not be proven on the entry
edge: check whether the *post*-loop test reads that value through a volatile qualifier.

**And it is per-site, which is the refinement of allocator Finding 61.**  Making the same tail
plain at *all* sites collapses the function: object 496 -> 480, real `0x1f0` -> `0x1e0`,
`matched` 447 -> 21.  Those volatile reads are what keep `done`'s and `result`'s memory homes,
so one qualifier can be a lever and its neighbour load-bearing in the same five lines.

`src/Develop/Units/vfs/vfs_ReadCompressed.c`

## 77. Group same-kind memory operations to match the reference's store sequence

Two wins from one rule: when the reference performs same-kind stores adjacently
and ours scatters them between other operations, regrouping to the reference's
sequence closes bytes even when no single store is wrong.

`cm_ExSellObjekt` (0x1000d930): the reference runs the season loops
(FindSlotById at 0x1000ddc8/df9) BEFORE source-finalize (0x1000de10+); ours ran
them after. Moving the whole dest-season block above `dest_object =
dest_game_object`: object 613/861 → 684/910, linked 1404 → 1346 (-58, -2
outside = -60). `gm_AllocSpieler` (0x10018850): the three byte-copies
(slot[9]/[0x164]/[0xc]) grouped ahead of the three strcpys: linked 2861 →
2857 (-4). `ls_LoadBuildingEntityState` (0x100128f0): `current_index = 0;`
hoisted above the aux-count read, matching xor-zero/read/realloc/re-read/test
linked 728 → 675 (-53).

The rule is order, not spelling: every spelling probe on the same regions had
already failed. Read the reference's block/store sequence from disassembly
first; move whole blocks to match. It is 1-for-13 as a blind method: it only
pays where source order was never directly compared during reversing. Where
source order already matches (Tracked, Objects, PCQ, Gebaeude, vfs mode arms),
regrouping loses or is inert.

`src/Develop/DieGildeAddOn/command/command_c/cm_ExSellObjekt.c`
`src/Develop/DieGildeAddOn/game/spiel_c/gm_AllocSpieler.c`
`src/Develop/DieGildeAddOn/loadsave/loadsave_c/ls_LoadBuildingEntityState.c`

## 78. A one-token guard reorder can be worth one linked byte

`cm_ExSellObjekt` (0x1000d930): the source-block category guard tests `'\x06'`
first (`'\x06' || '\x02'`; dest-side twin keeps `'\x02'`-first): object +1/+1
both rulers, linked 1346 → 1345 (-1). The dest-twin mirror is byte-neutral, so
the effect is positional, not logical: keep the twin that moves bytes, leave
the twin that does not. `gm_AllocSpieler` (0x10018850): father-wins copies in
0xc/0x1d0/0x217 order (was 0x217-first): linked 2857 → 2856 (-1);
per-trait selection best_mother-first: object +7/+7 with aligned -2, linked
2856 → 2848 (-8). `m_AllocTracked` (0x10006580): node zero-stores reversed:
object +1/+1, linked 93 → 92 (-1), even though the reversed order contradicts
the target's emission (a downstream scheduling accident, not a region fix).

Small wins compound the same way large ones do: verify each at the link
(one-token changes can shift jump encodings ±bytes elsewhere), and keep a win
whose mechanism note honestly says "scheduling accident".

`src/Develop/DieGildeAddOn/command/command_c/cm_ExSellObjekt.c`
`src/Develop/DieGildeAddOn/game/spiel_c/gm_AllocSpieler.c`
`src/Develop/Units/m_alloc/m_alloc_c/m_AllocTracked.c`

## 79. Position beats alignment, repeatedly

Three landings (Spieler best_mother-first +7/-2 aligned → -8 linked; Tracked
reversed stores +1/-5 aligned → -1 linked; CopyData secondary low-before-high
+11 aligned → +3 linked, reverted) establish the ranking: when object-level
`matched` rises and `aligned` falls, the link is the only adjudicator, and it
has favoured position twice against alignment once. Never keep or reject an
aligned-positive/matched-negative candidate without `scripts/linktest.sh`;
never cite aligned-only gains as wins.

## 80. xor-xor RMW beats xor-then-or when the scheduler prefers it

`vfs_OpenStream` (0x10009020): finalize as `g_stream_count = g_stream_count
+ 1` plus `& 0xf6 ^ m14 ^ m18<<3` instead of `^ m14 | m18<<3`: object +8/+13,
linked 245 → 233 (-12). The target itself emits xor-then-or, so the gain is
positional/scheduling, not opcode truth. Spelling the RMW to suit the
scheduler rather than the reference is legitimate when the link confirms it;
note the dishonesty in the header so the next reader does not "fix" it back.

`src/Develop/Units/vfs/vfs_c/vfs_OpenStream.c`

## 81. CrashDump frame rule: every 0x280 path costs ~50 bytes

Closed for `0x10002770`. The frame immediate is already `sub esp,0x280`. The last four bytes were store order at `0x10002c5c`, not the frame. Spelling: `espVal += 4` then `if (nFrames) espVal -= 4; else espVal -= 4; break` as the group-A join, and the frame fill writes `frameInfo[0]` before `frameInfo[1]`. Measured RELOC, 2115/2115, delta 0 (was NEAR_MATCHING 2111/2115). Window bytes `54 3c 6c 40`. One `goto` to a shared subtract leaves the `add`/`sub` in the object (2127). See Finding 73.

Four independent routes to the target frame (`space`-drop, hProcess reload,
pDbgBuf kill, nested-loop shape) all land `sub esp,0x280` exactly and all lose
~45-60 matches on both rulers. The frame counts overlapping live ranges
([esp+0x44] is a shared spill: hProcess across SetFilePointer, reused for the
Eip temp), not use-count or declaration-count; adding uses cannot free it,
dropping scalars shifts codegen elsewhere. Do not link-test another 0x280
variant unless it also holds matches; the frame will close only together with
the bytes, not before them.

**Round 174: the rule survives its strongest test, and the mechanism is now
known.** A block-order map of this function found `pCtx` to be the section-84
value: defined at entry, then unread for ~1200 bytes (CreateFile, ReadFile,
VirtualAlloc, decrypt, date/time, dispatch). The reference lets that span
*reuse* pCtx's spill slot (hDbgFile takes `[esp+0x28]` at 0x1000281d) and
re-materialises pCtx from memory at each later use: `[esp+0x2c]` at the
frameInfo fill and again inside the walk loop at 0x10002cb8. Ours pinned it in
a register across the whole span, which is the surplus dword.

Reading the loop guard through the parameter instead of the local ends that
live range: a one-token edit, `pCtx->Eip` to
`pExceptionPointers->ContextRecord->Eip`, and it produced `sub esp,0x280`
exactly, with aligned instructions *rising* 392 -> 407 and the object shrinking
2128 -> 2123. That is the first 0x280 route to gain alignment rather than lose
~50, so it earned the link test the rule's proviso allows. **It still lost:
+66 linked (8,871 -> 8,937), the function's own row +58.**

Sixth confirmation, and the sharpest: the frame is reachable, cheaply, without
deleting anything, and closing it alone still costs bytes, because the smaller
frame moves every subsequent `[esp+N]` displacement. Do not spend further
rounds on the frame as a target.

**Round 930 correction first, because it changes how to read everything below.**
The reference **does** save `ebx` and `edi`: it saves them *later*. Counting every
callee-saved `push` in the reference body:

```
0x1000277d push ebp      <- entry
0x1000277e push esi      <- entry
0x1000282c push ebx      <- DEFERRED, after the two early-return calls
0x1000282d push edi      <- DEFERRED
...
0x10002dac pop edi ; 0x10002dad pop ebx
0x10002e6b pop esi ; 0x10002e6e pop ebp
```

So the reference is shrink-wrapped: two registers at entry, two more once the function
is past the paths that return without needing them. Our object pushes all four at
entry instead. **The divergence is therefore not "we save a register the reference does
not": that framing (rounds 927-929) is wrong and is corrected here. It is that the
reference defers two saves and we do not**, which is section 38's shrink-wrap threshold
and the same mechanism section 81's own closing paragraph already names
("deferred `push ebx; push edi` at 0x1000282c").

This *strengthens* rather than weakens the earlier conclusion, because section 38 says
the entry push set follows from the *loop's* register demand: a body whose values stay
live across the guards must save at entry. Both section-38 routes therefore point at
the same thing (reduce what is live across the early guards and the loop) and the
round-928/929 probes that tried to move the frame or the live ranges are the measured
evidence that neither the frame bytes nor the qualifiers reach it.

**Round 928 reproduced this on the current tree, and the reproduction separates two
things this section had run together.** Re-applying the same one-token edit
(`pCtx->Eip` -> `pExceptionPointers->ContextRecord->Eip`, both sites) still produces
the reference's frame **exactly**:

```
81 ec 80 02 00 00    sub esp,0x280
```

and now measures **+21 linked (8,633 -> 8,654)** rather than round 174's `+66`, the
magnitude having moved with the rest of the tree while the sign did not. What the
edit does *not* fix is the **deferred saves**: the prologue becomes
`push ebx; push ebp; push esi` (`53 55 56`) where the reference's entry is only
`push ebp; push esi` (`55 56`), the other two arriving at `0x1000282c`. **So
`sub esp,0x280` and the entry push *placement* are two independent readouts, and this
lever reaches only the first.** (Rounds 927-929 called the second one a "register
surplus": see the correction above; the reference saves the same four registers, just
two of them later.)

That matters for targeting: a round that goes after the frame is chasing the half
that is already known-reachable-and-still-losing, while the *shrink-wrap* is the half
no edit has yet touched. Per section 38 the entry push set is decided by the *loop's*
register demand, so the lever is reducing how many values stay live across the early
guards and the loop, not respelling the entry, which every probe here has shown
inert.

**Round 929 then ran section 38's own diagnostic here, and it localised the demand.**
The procedure is "delete the loop and recompile; if the head then matches, the loop
is the blocker". Applied to this function's four loops, one at a time, reading only
the object's prologue bytes:

| loop removed | prologue |
|---|---|
| none (baseline) | `81 ec 84 02 00 00` = `sub esp,0x284` |
| decrypt dword loop (the `key` rotate-XOR) | `sub esp,0x284`: **not the blocker** |
| inner `while (nInstr--)` ReadProcessMemory probe | `sub esp,0x284`: **not the blocker** |
| the outer stack-walk `for (;;)` (neutralised with a leading `break`) | `81 ec 5c 02 00 00` = **`sub esp,0x25c`** |

So the whole of the frame difference is the **stack-walk loop's** live set, and it is
located rather than inferred. (The diagnostic reads the *frame*; the corresponding
effect on the deferred saves is inferred from section 38, not measured here: removing
the loop also removes the code that would need the registers, so the push set cannot be
read off this experiment.) That is the loop to reduce, and it is worth stating why the others
are excluded: a round that budgeted for "the decrypt loop" or "the probe loop" (both
of which look heavier in the source) would have found nothing, and the two cheap
candidates would have been consumed before the real one was tried.

**One reduction attempt, rejected on measurement.** `nFrames` is declared `volatile`
and live across the whole walk (`nFrames = 0x800` before it, `nFrames--` and the `<= 0`
test inside). Dropping the qualifier is the most direct way to cut its register
pressure, and it measures **residue 8,633 -> 8,682 (+49)**: the volatile read is
load-bearing here as section 3 and allocator Finding 61 predict, and the file header's
round-129 note records a related `nFrames` probe. The loop's demand has to come down
by removing *values*, not by changing how they are qualified.

**A second reduction attempt, byte-neutral and therefore also not kept.** `instrType`
and `mbi` are used *only* inside the walk loop, so both were moved from the function
block to a declaration inside the `for (;;)` body, legal C89, and the obvious way to
shorten a live range the prologue has to preserve. It compiles, the object stays
2,128 bytes, the frame stays `sub esp,0x284`, and the linked residue is **8,633,
unchanged**, while the *object bytes* do differ from the baseline's. So the edit moves
codegen without moving the objective's metric: a no-op under the link rule, reverted
rather than kept as "free tidy-up".

**And the mechanism, read off the reference's own loop.** The walk loop closes with
`jne 0x10002d5d -> 0x10002c87`, and disassembling that body settles what its live set
is: the reference keeps **every** carried value in a stack slot:

```
[esp+0x44] frameInfo[2]      [esp+0x58] mbi          [esp+0x68] mbi.State
[esp+0x6c] instrType         [esp+0x2c] pCtx         [esp+0x40] pStack
```

and the loop body's callee-saved usage is **re-initialised every iteration rather
than carried**. Counted over the whole body (`0x10002c87`-`0x10002d5d`): `esi` and
`ebp` are used **zero** times; `edi` appears 6 times and `ebx` 3, and both are set
*inside* the loop before use (`mov edi,7` at `0x10002cc8`; `lea ebx,[esp+0x90]` at
`0x10002ccd`, a stack address for `szDateBuf`). So no callee-saved value crosses the
back-edge. (An earlier draft of this paragraph said "the only one touched is `edi`":
that was wrong, `ebx` is used too; the point survives because both are loop-local, but
state it from the count, not from impression.)

That is *why* the reference's prologue needs only `push ebp; push esi`, and it is the
mechanical answer to round 929's open question: the deferred saves are not a colouring
difference to be pleaded with, they are the cost of our body keeping values live across
the early guards where the reference does not.
msvc6 chose differently from the same source, and sections 61-65's fixed-point findings
say no C spelling reaches that choice, which is consistent with both reduction
attempts above measuring zero or worse. The remaining reference-order differences
(deferred `push ebx; push edi` at 0x1000282c; `pCtx->Esp` parked in ebx from
0x10002931 across the date/time region) are the real levers, and they would
have to land *with* the frame in one change, not before it.

## 82. `fimul` needs an int memory home AND a live ST(0), supplied by two separate constructs

`fimul dword [mem]` multiplies ST(0) by an integer read straight from memory.
msvc6 emits it only when **both** conditions hold at the multiply, and each is
produced by a different source construct:

1. the integer operand has a *memory home*: a plain alias (`int v; int* a = &v;
   *a = byte;`) supplies one, a bare `int` local does not (it stays in a
   register), and `volatile` supplies one but also pins ordering and costs the
   schedule;
2. the running double is *still on the FPU stack*, which requires the product
   to be split across statements so nothing forces a store between them.

**Condition 2 is the whole trigger; condition 1 is not needed (round 856, isolated).**
Rebuilt the pair in the round-844 testbed and swept it. The discriminating table, with `byte`
an `int` **global** throughout:

| source | emitted |
|---|---|
| `return d * (double) byte;` | `fildl` + `fmull` |
| `t = acc; return t * (double) byte;` | `fildl` + `fmull` |
| `t = d + acc; return t * (double) byte;` | `fldl` + `faddl` + **`fimull`** |
| `t = d - acc; return t * (double) byte;` | `fsubl` + **`fimull`** |
| `return (d - acc) * (double) byte;` | `fsubl` + **`fimull`** |
| `t = d * acc; return t * (double) byte;` | `fmull` + **`fimull`** |

So `fimul` needs only that **a prior FPU arithmetic op left a double on ST(0)**: subtract, add
and multiply all produce it, so the operation is irrelevant. And the integer operand needs *no*
memory-home construct at all: a bare `int` **global** works. That is why condition 1's aliases
were a red herring: they were supplying a memory operand the code already had. A plain `fld`
of a value already in memory does **not** count (`t = acc` gives `fildl`+`fmull`), so the
trigger is specifically *arithmetic already on the stack*, not merely `ST(0)` being occupied.

This matters at the real site: §82's remedy was to add an alias, which the table shows is
unnecessary, and the paragraph immediately below records that the alias by itself emits `fimul`
at the *wrong* sites. Reading condition 2 as the sole trigger explains that, and says which
statement split is needed (the double-arithmetic one) rather than a memory home.

On `gm_AllocSpieler` (0x10018850) the reference's per-trait interpolation at
0x10018f4c is `fld [esp+0x10]; fsubr qword[7d8]; fimul dword[esp+0x14]; fild;
fmul dword[esp+0x10]; faddp`. Neither half alone reaches it: the alias home by
itself emits `fimul` at the *fast paths* instead, and the ordering rewrites by
themselves emit `fild`+`fmulp` everywhere. Together:

```c
double t; int fbh; int* fb_alias;
fb_alias = &fbh;
t = g_dbl_const_7d8 - (double) acc;      /* (1-acc) stays on ST(0) */
*fb_alias = *(unsigned char*) (father + 0x80 + i);
t = t * fbh;                             /* fimul dword [esp+...] */
```

**Integerizing the whole product is the opposite of the fix.** Computing
`(cw*fb + w*mb)` in the int domain and converting once emits a single `fild`
of the sum, so nothing is live on ST(0) and `fimul` cannot appear: three such
variants scored 352-382 against a 748 baseline.

The shape is recorded because it is *reached*, not because it is kept: the
object comes out 3680 against a 3689 real body and the link regresses +409.

**Correction (round 173).** This section first claimed the residual nine bytes
*were* the second multiply, where the reference uses `fild` + `fmul`-mem +
`faddp` and the form above emits `fild` + `fld st(2)` + `fmulp` + `faddp`.
That was wrong, and measuring it is what showed so. The memory form is
reachable: give `acc` a `volatile float*` alias and msvc6 emits the
reference's window verbatim, `[esp+0x14]` slot and shared int home included,
and reaching it makes the object *larger* (3728, |Δ|=39 against 3680's |Δ|=9)
instead of closing the gap. The second multiply is locally size-neutral
(`fmul`-mem is 4 bytes against `fld st(2)`+`fmulp`'s 4); the growth is
`volatile` pinning FPU ordering across the whole function for ~48 bytes of
collateral. So the second multiply is a separate, solved, affordable problem
and the nine bytes live elsewhere in the loop or its exit.

The general lesson outlives this function: **a `volatile` qualifier buys a
local instruction form and charges for it globally.** Measure the whole
function, never the window you were aiming at.

`src/Develop/DieGildeAddOn/game/spiel_c/gm_AllocSpieler.c`

## 83. A measurement pipeline must refuse stale inputs, or it will report the last good number

`scripts/split_link.sh` reads five stock `LIBCMT` copies out of gitignored
`.scratch/`. A scratch cleanup deleted them; the script died in its first step,
and because the caller chained `split_link.sh; postlink_residual.py` with `;`,
the residual tool happily re-measured the *previous* build and printed the same
figure for five rounds.

Two properties make a verification trustworthy, and this pipeline had neither:

- **every stage's exit status is checked**: `;` between a producer and its
  measurer hides the producer's failure, and `grep`-ing only the interesting
  line hides the error text as well;
- **the measurer validates its own inputs**: `postlink_residual.py` now
  refuses a build older than any `src/**/*.c` and names the offending files,
  so a binary that predates the edit under test can never be scored.

`scripts/gate.sh` now performs the link and the residue measurement itself and
fails on either, which makes the per-round residue an assertion rather than a
recollection. Regenerable inputs that live in ignored directories should also
be re-derivable by a documented command: these were recovered with
`docker create`/`docker cp` from the toolchain images.

`scripts/postlink_residual.py`, `scripts/gate.sh`

## 84. Sink a value's definition into the guard that uses it, and let the other region keep its own register

The largest win on `cm_ExSellObjekt` after the season-block move (-173 linked,
9,067 -> 8,894) was moving one assignment down into the block that reads it:

```c
-	dest_object = dest_game_object;
 	if (*(int*)(cmd + 0x14) != -1) {
 		/* source-finalize: reads the SOURCE object */
 	}
 	if (*(int*)(cmd + 0x10) != -1) {
+		dest_object = dest_game_object;
```

The reference loads the dest object at `0x1000df0a`, *inside* the
`cmd+0x10` guard, and runs source-finalize at `0x1000de10` entirely on the
source object in `ebx`. Defining the dest pointer above source-finalize made
that whole region compete for the dest pointer's slot and drifted the schedule
to the end of the function: object `685/911 -> 829/1047`, `rebrew test`
`796 -> 971`.

Two conditions are worth carrying to other functions:

- **Placement inside the guard is the lever, not the statement order.** The
  same assignment written at top level immediately *before* the `if` scores
  92/2057: catastrophic. msvc6 sinks a load into the taken arm only when the
  source writes it inside that arm; written just above, it stays live across
  the guard and pins a register.
- **The object legitimately shrank** (real 2053 -> 2025, span 2064 -> 2032).
  A real body below the reference span is composition-legal (allocator
  Finding 58), so a shrinking object is not by itself a span break, but
  fixed-offset scores cannot rank it, and only the link can.

Diagnostic: when one region's diff is clean and everything after it drifts,
look for a value defined before that region and used only after it.

`src/Develop/DieGildeAddOn/command/command_c/cm_ExSellObjekt.c`

## 85. The boundary of section 84: it moves a value's definition, not a constant

Section 84's lever (sink a definition into the guard that reads it) paid
-173 on `cm_ExSellObjekt` and -23 on `gm_AllocSpieler`. Applying the same
block-order mapping to two more functions found the shape present in both and
unreachable in both, which fixes the rule's scope.

**`cm_ExCopyEntityData` (0x1000ec00): the pinned value is a constant, so
source scoping cannot move it.** The reference materialises `mov ebp,0xffff`
at 0x1000edc0 and holds ebp across the whole src-scan region to serve a guard
0x9c bytes later: a textbook section-84 signature, and the reason its src
scan needs no entry guard (ebp is simply unavailable to the loop). Ours spells
both guards as inline `cmp word ptr [...],0xffff`, which leaves ebp free, and
msvc6 spends it on a 3-instruction scan entry guard.

Declaring a shared `0xffff` local *inside* the dst-valid guard (the correct
section-84 placement, which earlier passes had not tried) is **byte-identical**
to the inline spelling. msvc6 rematerialises an immediate at each use however
the source scopes it. A `volatile` variant (tried earlier) homes it to the
stack, which is the wrong mechanism entirely.

So the lever needs a value with a real definition site: a pointer, a loaded
field, a call result. A constant has no definition to move.

**`ls_LoadBuildingEntityState` (0x100128f0): the shape was already spent.**
Round 130's hoist had put both of this function's section-84 values (`offset`,
`neg1`) inside their guard already. A third candidate (`current_index` before
the aux region) looked identical in form but is a *consequence* of the aux loop
being its own region: that counter shares `[esp+0x10]` with the outer loop's,
so splitting the live ranges forces a second slot and shifts the frame
(probe: 627/1463 against a 690 baseline, `rebrew test` -61).

Two practical rules follow. **Map first, probe second**: both lanes produced a
complete ordering map, and in both cases the map explained the failure before
the probes confirmed it. And **a function whose order already matches is done
for this lever**: `cm_ExCopyEntityData` agrees with the reference at 12 of 16
top-level blocks, and its four differences are all allocator-downstream
(loop rotation, cross-jumped epilogues, the ebp guard, an address split).

**A warning about maps produced in bulk (round 177).** Two leads from a single
round-176 mapping pass were both false, and both were phrased confidently enough
to fund a probe round each. The first claimed reversed dispatch arms (refuted:
zero hunks in the region). The second claimed the reference *hoists*
`mov edx,[esi+0x71]` above the 0x1e-arm loop while ours sinks it: the reference
in fact re-reads that field at all nine sites, exactly as we do, and the loop
back-edge lands on a load. Three probes built on the phantom axis cost
-344, -158 and -613 matched.

The real difference at those sites is *load-versus-push scheduling*: the
reference emits `mov edx,[esi+0x71]; mov ecx,ebx; push edi; push 1; add ecx,edx;
push 4; push ecx` (load first, address arithmetic interleaved with the pushes)
while ours pushes first and then loads. The `lea` operand order that the map
fixated on is a *symptom* of which register the load landed in (section 70:
operand order in a commutative address expression is inert on its own).

Rule: **verify a map's claim against the disassembly before spending a round on
it**, especially a claim about hoisting, ordering, or duplication: those are
exactly the properties that look different in source text and identical in
emitted bytes. One `grep -c` on the reference listing would have caught both.

**Third and fourth boundary cases (round 176).** `gv_ExAllocGraveyardWorker`
(0x10011bf0) maps as identical to the reference in 21 of 22 top-level blocks;
its one difference is a three-store triple deliberately held *off* reference
order because the positional ruler pays 671 for our order against 668 for the
reference's. Its genuine section-84 candidate (`slot_ptr` defined above the
count guard where the reference loads it inside, at exactly the reported first
diff) is **byte-identical** when moved: msvc6 already sinks that load, and the
writeback was dead. `ls_LoadBuildingEntityState`'s dispatch region likewise
turned out to have zero hunks.

So the lever's real precondition is: **the function's emitted block order must
actually differ from the reference's.** Four of six functions mapped so far
were already in reference order, and on those the method's value is the map
itself: it retires the lane instead of funding more probes. Read the order
from emitted bytes (`instr_diff`, objdump), never from source text: msvc6
emits else-blocks innermost-first (section 59), so source order routinely
*looks* inverted when the emitted order already matches.

`src/Develop/DieGildeAddOn/command/command_c/cm_ExCopyEntityData.c`
`src/Develop/DieGildeAddOn/loadsave/loadsave_c/ls_LoadBuildingEntityState.c`
`src/Develop/DieGildeAddOn/game/friedhof_logic_c/gv_ExAllocGraveyardWorker.c`

## 86. A join block is exiled when its fall-through predecessor must end in a reload + `jmp`

The inverse of section 84, and worth -200 linked bytes on one function.

`cm_ExSellObjekt` (0x1000d930) carried a -147 placement cliff: from 0x1000dfc1 to
the end, every instruction was byte-identical to the reference and 147 bytes late.
The round-179 census localised it but read it as a layout problem. It is not: it is
**register pressure at a join**.

msvc6 had enregistered `dest_dynamic_entity` in `ebp` across the `cmd+0x10` then-arm,
so that arm had to end by restoring the registers the join expected:

```
mov edi,[esp+0x10]; mov ebp,[esp+0x18]; jmp <join>
```

A block that ends in `jmp` cannot be the join's fall-through predecessor. msvc6
therefore laid the *else*-region inline and exiled the join (the player-slot store
and the `gm_SubObjekt` body) 147 bytes past it. The reference keeps nothing live
there: it reloads the pointer from `[esp+0x2c]` at the test (0x1000df97
`mov eax,[esp+0x2c]; test eax,eax`), its then-arm falls straight through into
0x1000df2a, and the else-region goes to the tail.

Forcing that one reload from source reproduces the reference's block order:

```c
if (*(short* volatile*) &dest_dynamic_entity != (short*) 0) {
```

Object 836/1052 -> 1037/1217, instruction count 678 -> **667 = the reference's
exactly**, COMDAT span 2032 -> **2064 = the reference's exactly**, `rebrew test`
977 -> 1149, linked **-200**.

Diagnostic: when a contiguous tail of the function is byte-identical but uniformly
displaced, look for a *join* whose predecessor arm ends in register restores. The
fix is to force the value out of a register at the post-join test: the opposite
move from section 84, which sinks a definition *into* a guard to free one.

Two cautions from the same lane. Reloading a second pointer as well
(`dest_owner_entity`) also kills the cliff but costs ~150 bytes: reload only the
value the join actually contends for. And duplicating the join body into both arms
to delete the join outright is catastrophic (336/2057).

**Screen candidates on the delta profile before funding a probe round (round 181).**
The qualifying signature is *one step that holds to the last aligned pair*:
`cm_ExSellObjekt` went to -147 at 0x1000dfc1 and stayed there to the final byte.
Function size and hunk count do not predict it. Two functions screened against this
rule and were correctly retired without spending a probe:

- `ls_LoadBuildingEntityState`: its largest step (+144 at ref 0x02f5) survives six
  instructions, collapses to -1, and the delta returns to **zero twice more** before
  ending at -3. Scattered hunks, no exiled join. (Its +144 window is also the
  `[esi+0x71]` load-versus-push region that section 85's round-177 warning already
  refuted as an axis.)
- `cm_ExCopyEntityData`: delta wobbles ±10 throughout, its +75 spike lasts two
  instructions, and the tail sits at +4 in an object whose size equals the
  reference exactly (912 = 912). A same-size object with a small wobble is
  register/schedule noise, not a displaced join.

A profile that returns to zero mid-body, or finishes within a few bytes of zero, has
no join to un-exile. Reading the profile costs minutes; a probe round costs hours.

**Second pre-check: the `jmp` census must show a built-only surplus.** The
precondition is not "our build has a restore+`jmp`": it is that *we* jump where the
*reference falls through*. Align both `jmp` lists by source address and compare.
`gm_AllocSpieler` was screened this way: reference 26 jumps, built 27, and the single
built-only jump is a protected known bug, while the one restore-then-`jmp` join
(0x10018c28 / 0x10018c23) is **byte-identical on both sides**: the reference ends
that arm the same way we do. With no jump surplus there is no exiled join, and three
volatile-reload probes duly cost -429/-389/-351 matched, each breaking the span by
+16 (a homed stack slot) and destabilising the FPU region.

That last detail is the mechanism's real boundary: on `cm_ExSellObjekt` the contended
pointer was **dead across the arm**, so forcing it to memory cost nothing. Where the
value is *live* across surrounding loops, homing it buys a slot and reschedules
everything near it. Check liveness before reaching for the reload.

So the full screen, in order, before any probe: (1) does one delta step hold to the
last aligned pair? (2) does the `jmp` census show a built-only surplus at that point?
(3) is the contended value dead across the predecessor arm? Three cheap commands;
all three must pass.

**The jump surplus must be inspected, not counted (round 182).** A raw count
comparison mis-passes. Screening nine rows produced three apparent built-only
surpluses and all three dissolved once aligned by source address: `ServerMainThread`
had inverted branch polarity (reference `je` + `jmp` against our `jne` + `jmp`, equal
counts), `ahm_ExAllocAlchemist` had a reference `cmp edi,5; jl` folded into one built
`jmp`, and `vfs_OpenStream`'s "extra" jump was the shared jump table
`jmp [ecx*4+0x100092bc]` present on both sides. In each case one built instruction
stands where the reference has two, never a jump where the reference falls through.
Counting alone would have sent two of them into step 3.

**Measured rarity.** Twelve rows have now been screened against this signature and
exactly one (`cm_ExSellObjekt`) has it. Eight of the nine screened in round 182
finish at delta exactly 0; the ninth (`gm_FindNextFilteredEntity`) holds -4 for a
single aligned pair, and its real problem is a body-shape mismatch at 57.6%
alignment, not a displaced join. Treat section 86 as a rare, screened lever rather
than a general lane: the profile read costs seconds per row and retired nine rows
for zero probe rounds, which is exactly what the screen is for.

One operational note for whoever runs this next: **screen the function's own VA and
size**, not the mismatch-region start that residue tables report. `gm_AllocGebaeude`
is 0x100174d0 size 1088; the 0x10017530 that appears in a residue listing is 529
bytes into it and has no metadata entry of its own, so screening that address
measures nothing.

`src/Develop/DieGildeAddOn/command/command_c/cm_ExSellObjekt.c`

## 86b. Store order IS a lever through a fresh pointer, inert through a stack buffer

Section 20 records that statement order does not move stores into the same buffer.
That holds for a *stack* buffer, where msvc6 knows the object and schedules freely.
It does not hold for stores through a pointer into memory the compiler cannot prove
non-aliasing for: a freshly `malloc`'d node, for instance. There msvc6 emits the
stores in exact source order, so their order is a lever.

`m_AllocTracked` (0x10006580) zeroes six fields of a just-allocated node. The
reference emits them `0x14, 0x10, 0x1c, 0x18, 0x20, 0x24` (verified at
0x100066bc-0x100066cb: six `mov [edx+N],ebx`), which is the exact reverse of the
natural declaration order the source used. Reversing the source makes the block
byte-identical to the reference and lifts aligned 225 -> 230 of 249, span-neutral at
obj 672.

**And it still loses: +1 linked.** The alignment gain is noise, which the `matched`
ruler said at the time (566 -> 565). The lever is real, the win is not, so the
natural order is kept deliberately, with a note at the site.

Two rejection modes worth naming from the same lane. An edit can win alignment and
lose on COMDAT span: `node->count_total > node->count_max` in place of the
`- ... > 0` form reached aligned 233 (the best figure measured on that function)
and did emit the reference's `cmp eax,ecx`, but shrank the object 672 -> 656, a span
that round 104 recorded as breaking position alignment for every later symbol.
Separately, the `- ... < 0` spelling of the slot guard is load-bearing for §8b
register residency: the plain `<` lets msvc6 fold one side into the compare and costs
99 on the reloc ruler.

**Boundary: the stores must actually differ in SOURCE order (round 185).** This
lever only exists when our source writes the stores in a different order than the
reference emits them. Where the difference is instead msvc6 *tail-merging* a store
common to both arms of an `if`/`else` into the join (while the reference duplicates
it per arm) there is no source order to change, and `volatile` does not help:
qualifying the store side is **byte-for-byte identical** to the baseline object, and
qualifying the load side sinks the store back into the arms but at the wrong position,
costing -370 matched.

Diagnose it by reading the *stores* specifically. On `gm_AllocSpieler` a census
recorded the mother-type copies as emitted `0x50, 0x58, 0x54` by the reference against
our `0x58, 0x50, 0x54` and concluded this lever applied. It does not: our **store**
order is already `0x50, 0x58, 0x54` (verified at 0x1001904d/0x10019056/0x1001905c
against our 0x10019052/0x10019056/0x1001906e): the census had read our **load** order
off the disassembly. Loads get hoisted freely; only the stores carry the order.

`src/Develop/Units/m_alloc/m_alloc_c/m_AllocTracked.c`

## 87. Audit a function's own header notes before trusting them: six for six

Every census run in rounds 178-182 found at least one false claim in the header of
the file it was censusing. Four censuses, four bad claims, each of which had been
sitting there long enough to redirect work:

- `gm_AllocSpieler`: the store-tail order was recorded backwards ([0xa] last,
  [0x20c] third; the bytes put [0xa] second at 0x100189c4 and [0x20c] last at
  0x100189f4).
- `CrashDumpUnhandledExceptionFilter`: "the body is 11 bytes longer, so the tail
  jump tables sit 11 bytes late": the body is length-exact, `ret 4` sits at
  +0x729 on both sides, and all 279 table bytes are byte-identical in the object.
  Also "the call count is now the reference's 44": it is 43.
- `ServerMainThread`: a rounds 6-9 verdict that its two cold blocks could not be
  made to defer into gaps. A later round had fixed exactly that and nobody re-read
  the object; both sit at identical offsets in no hunk.
- `cm_ExSellObjekt`: a "dead [esp+0x44] spill the reference materialises": the
  reference writes it at 0x1000dd2a and reads it back at 0x1000dd33 across a call,
  and esp-depth tracking shows our `[esp+0x3c]` is the same physical slot
  (frame+0x468). The real difference is push interleaving.

- The three tail rows (`srv_LoadBuf`, `m_AllocTracked`,
  `gm_CheckInventoryCapacity`): all three headers carried stale baselines:
  srv_LoadBuf's by 109 matched bytes, and m_AllocTracked's aligned count was off by
  five with its round-118 store-order claim **inverted in sign** (recorded as +1 on
  both rulers; actually costs five aligned instructions).

- `gm_AllocSpieler` a second time: the round-178 census built cluster #13's entire
  220-byte premise on a store-order difference that does not exist: it had read our
  *load* order as store order (see section 86b's boundary note). It also
  double-counted that cluster's register-name and `and reg,0xffff` items as fresh
  when the function's own blocker note already listed them.

- `vfs_OpenStream` and `gm_AllocGebaeude`: **the tool-managed blockers were stale
  too**, not just the prose headers. vfs's said `11B size gap (693 vs 704): parked`
  when its real body is 701 = the reference exactly, its span 704 = the reference,
  and its instruction counts are equal at 197 vs 197: the body it described no
  longer exists, and it named size as the wall when size is not the wall.
  Gebaeude's said `parked at 418/1078` against an actual 683/1088, stale by 265
  bytes. Both were refreshed with `rebrew diff --fix-blocker` (never by hand, that
  file is CLI-managed). The blocker field is *evidence about the present*; when a
  function moves and nobody re-runs the tool, it silently becomes a claim about a
  build that is gone. Detailed reasoning belongs in the `.c` header, which survives
  the refresh; the blocker should stay a measured one-liner.

**Systematic audit (round 186): 11 of 19 blockers were stale.** Auditing every
non-matching row against fresh measurement (rather than spot-checking) found the
base rate is far worse than the anecdotes suggested, and `blocker_delta` disagreed
with the current delta on 13 of 19. Two findings generalise:

- **A refuted blocker is worse than a stale one.** `cm_ExSellObjekt`'s named a frame
  wall, `ref 0x228 vs msvc6 0x224`. Both the reference and our object emit
  `sub esp,0x228`. I verified both. Its own `.c` header had already recorded the
  frame as fixed; the blocker went on advertising a wall that does not exist.
- **`--fix-blocker` deletes a blocker when it finds no structural diffs.** Use
  `rebrew blocker set <VA> "<text>" --delta N` to rewrite a blocker while keeping it
  a measured one-liner, and reserve `--fix-blocker` for rows whose claim is merely
  numeric.

  **Correction (round 187): the "no structural diffs" readings that motivated that
  caution were themselves an artifact.** The audit had reported four functions as
  having zero structural diffs despite carrying linked residue: a contradiction,
  since residue *is* differing bytes. Invoking `rebrew diff <VA>` directly shows
  `gm_ObjectsAvailble` 18 structural, `srv_LoadBuf` 25, `vfs_ReadCompressed` 11,
  `cm_ExProdObjekt` 5. The deletion risk is real in principle and the `blocker set`
  advice stands, but no row in this tree is currently in that state. When a
  measurement asserts something structurally impossible (zero differences yet
  non-zero residue) re-derive it with the tool directly before building on it.

Before overwriting any blocker, confirm the *reasoning* survives in the `.c` header:
on the 11 stale rows it did, except that two of them (`gm_AllocSpieler`,
`ServerMainThread`) were the sole record of their ndiff/cdiff hunk figures, which were
carried into the replacement text rather than dropped.

The common mechanism is that a note is written as a *conclusion* at the moment it
is measured, then outlives the state it described: usually because a later round
fixed the thing without re-reading the bytes. Two of the four were actively
harmful: they named an axis ("eliminate the dead store", "the tables are late")
that does not exist, and a round was spent aiming at it.

Practical rules:

- **Re-verify a header claim against `rebrew binary asm show` before acting on it**, especially
  claims about placement, ordering, counts and dead code. One `grep -c` is cheaper
  than a probe round.
- **Timestamp claims and mark superseded ones in place.** A claim that was true at
  round 110 should say so, and when a later round spends the lever it describes,
  the old paragraph needs a SUPERSEDED marker, not just a newer paragraph below
  it, which readers hit second.
- **Prefer facts that stay true** (byte sequences, addresses, measured scores with
  their date) over conclusions that expire ("the highest-value untried lever").

## 88. A "span deficit" is code bytes plus alignment round-up: separate them before hunting

COMDAT sections are padded to an alignment (0x10 here), so a span figure conflates
two very different quantities. Confusing them sent two rounds hunting the wrong
number on `m_AllocTracked` (0x10006580).

The reference body is **658 bytes**, which pads to a **672** span with 14 trailing
nops. A candidate emitting **656** is already 16-aligned, so it pads to itself and
the span reads 656: recorded at the time as a **"-16 span deficit"**. It is nothing
of the kind: the code is 2 bytes short, and the ceiling arithmetic is

```
656 -> 656      657 -> 672      658 -> 672
```

so the recoverable quantity was **+1 byte**, not +16. Hunting sixteen bytes in a
658-byte function is hopeless; finding one is a normal question.

Worse, the hunt had been aimed at the wrong regions (a `repne scasb` block and a
zero-register idiom, both length-exact on our side). The entire deficit was **one
instruction**: the reference materialises the value twice:

```
0x100067d8  8bc7  mov eax,edi
0x100067da  897e14 mov [esi+0x14],edi
0x100067dd  3bc1  cmp eax,ecx
0x100067df  7e28  jle
0x100067e1  8bcf  mov ecx,edi      <-- ref-only: the whole 2 bytes
0x100067e4  894e1c mov [esi+0x1c],ecx
```

and stores the second field from the *second* copy, where we store from the first.
Supplying it with `count_max = *(volatile int*) &count_total` does hold span 672 at
aligned 233/249, the best figure on that function, which confirms the arithmetic. It
still loses **+40 linked**, because the `volatile` costs more elsewhere than the
alignment gains. So the lane closes on measurement rather than on a phantom.

**The ceiling also decides whether a lane can AFFORD an edit at all (round 190).**
Compute the upward slack, not just the deficit, before opening a lane. Two sibling
functions triaged together show the asymmetry starkly:

- `gv_ExAllocGraveyardWorker`: body **1040 = the reference exactly**, and 1040 is
  *itself* 16-aligned, so it pads to itself and 1041 jumps to 1056. **Zero upward
  slack.** Every one of its three faults is length-neutral, so there is nothing to buy
  and any one-byte growth costs sixteen bytes of span. That is why every "restore the
  missing bytes" idea on that function died, and it is the real reason it is a wall:
  not the register-role difference its header blamed for seven consecutive passes while
  the body had been length-exact since pass six.
- `ahm_ExAllocAlchemist`: body **1002**, padding to 1008 with the reference's own six
  trailing nops. **+6 bytes of genuine slack.** Its open float-tail lane can actually
  afford an edit.

So "length-exact with the reference" is not one condition but two: a body equal to the
reference *and* the slack that body leaves. State both when parking or opening a lane.

Practical rules: when a span looks short by exactly one alignment unit, compute
`real_body` and the round-up separately before planning anything; state deficits in
**code bytes** with the ceiling spelled out; and derive the target from the hunk
list's own byte widths (here ref-only `8bcf`+`3bc1`+`0f8d..` = 10 against built-only
`2bc7`+`0f89..` = 8, closing the gap exactly with no residual) rather than guessing
which region is short.

`src/Develop/Units/m_alloc/m_alloc_c/m_AllocTracked.c`

## 89. Attribute residue by COMDAT extent, not body size: msvc6 emits tables past the body

`scripts/postlink_residual.py` attributed each differing `.text` byte to a function by
testing `lo <= off < lo + size`, where `size` is the **body** size from
`function_structure.json`. msvc6 emits switch jump tables and case-index maps *after*
the body inside the same COMDAT, so those trailing structures fell outside every
extent and were reported as a phantom `<outside the non-matching functions>` bucket.

`vfs_OpenStream` (0x10009020) is the clean example. Its recorded size is 667, so the
extent ended at `+0x82bb`, one `nop` short of its jump table at `+0x82bc`:

```
0x10009020..0x100092ba  body, 667 bytes      <- recorded size
0x100092bb              90                   nop pad, identical both sides
0x100092bc..0x100092cf  5 dwords             the "unattributed" bytes
0x100092d0..0x100092dc  case index map       identical both sides
0x100092dd..0x100092df  90 90 90             COMDAT 0x10 pad
```

Extending each extent to the next tracked function's start fixes it: the report went
from `0x21d5 of 0x21da inside … 0x5 are not` to **`0x21da of 0x21da … 0x0 are not`**,
and that function's true count is 238 rather than 233. The total residue is unchanged
(this is an accounting fix, not a byte gain), but a phantom category invites rounds
spent hunting a wall that is really part of a known one.

The five bytes themselves are worth recording as a closed question: each is exactly
`+1` in the low byte of a jump-table dword, all tracing to one origin at 0x10009056
where the reference emits `cmp byte ptr [eax],0` (3 bytes) and we emit
`mov al,[eax]; test al,al` (4). Removing that byte makes the loop and table byte-exact
and shifts everything after it: measured at match 450 -> 272. Five bytes recovered
for ~178 lost.

`scripts/postlink_residual.py`

## 90. Some "compiler fixed points" are service-pack decisions: sp5-pp as an oracle

Two walls documented as compiler fixed points are reproduced *exactly* by a different
MSVC6 service pack, without any source change. That reframes them: the reference's
scheduling is reachable, our backend simply chose otherwise.

A 3x8 sweep (`rebrew test --toolchain <name>`) over `msvc-6.0`, `sp1`-`sp5`, `sp5-pp`
and `sp6`:

- **Seven of the eight are byte-identical** on all three functions: same
  `match_count`, same `obj_size`, identical mismatch lists. This is genuine codegen
  stability, not a packaging duplicate: `C2.DLL` has five distinct md5s across those
  images and `C1.DLL` four. It upgrades "SP1-SP6 byte-identical" from a one-function
  anecdote to a measurement.
- **`msvc-6.0-sp5-pp` is the outlier, and it reproduces two walls:**
  - `vfs_ReadCompressed`'s stack-cleanup sinking. sp5-pp emits the reference's tail
    verbatim: `8b5e5c / 8b542424 / 894650 / 8b442428 / 83c414`, reading args at the
    pre-cleanup `[esp+0x24]`/`[esp+0x28]` with `add esp,0x14` sunk four instructions,
    where sp6 leads with the cleanup. Its mismatch list *ends at offset 395*. So the
    fixed point is the **cleanup placement**, not the argument reads: the earlier note
    blaming the reads was aiming at the wrong thing.
  - `cm_ExProdObjekt`'s global-load position. sp5-pp puts `mov edx,[global]` first at
    +204 followed by `33c0 / 668b4514 / 8b5d16 / 8bc8 / 895c2418`, all identical to the
    reference; sp6 sinks that load 13 bytes. First diff moves 205 -> 410.
- **Two other walls are NOT version-sensitive**: `cm_ExProdObjekt`'s byte 410 (the
  reference spends ebx, all 8 toolchains spend eax) and `m_AllocTracked`'s
  double-materialisation. Those stay allocator-level.

**Do not pin sp5-pp.** It is net-negative on all three functions (461/492, 722/991
SIZE_MISMATCH, 266/634 SIZE_MISMATCH) because it wrecks other regions. And a
per-function `toolchain` pin cannot change the deliverable anyway: the CMake build's
compiler is fixed by the toolchain file, so a pin moves `rebrew test`/`verify` verdicts
only: a divergence `rebrew build cmake-flags` now reports rather than swallowing.

The value is diagnostic: **sp5-pp is a cheap oracle for "am I fighting the scheduler or
the source?"** If sp5-pp already emits the reference's shape for a region, no source
spelling under sp6 is likely to, and the lane should be retired rather than probed.

`src/Develop/Units/vfs/vfs_ReadCompressed.c`,
`src/Develop/DieGildeAddOn/command/command_c/cm_ExProdObjekt.c`

## 91. The sp5-pp oracle, applied to the whole residue table: 14 source-bound, 4 scheduler-bound

Section 90 established `msvc-6.0-sp5-pp` as a diagnostic: where it already emits the
reference's shape, no sp6 source spelling is likely to, so that lane should be retired
rather than probed. Running it over all 19 non-matching functions (38 `rebrew test`
runs, `--no-promote`, each function's own VA and size) turns that into a routing rule.

The screen is one-sided. sp5-pp is `SIZE_MISMATCH` on 15 of 19 rows against sp6's 6,
which extends section 90's "do not pin" from three functions to the whole table. But
the *classification* is the useful part:

**SCHEDULER-BOUND (retire these regions)**: sp5-pp equals or beats sp6:

| function | sp6 | sp5-pp | the region sp5-pp gets right |
|---|---|---|---|
| `gm_FindNextFilteredEntity` | 162/346, obj **342** | 171/346, obj **346** | tail epilogue ordering, +0x315-0x336: the cold `xor cl,cl; jmp` stub placed *after* the pop/ret (ref 0x100170bb `0f844effffff` / `5f 5d 5b 5e` / `c3` / `32c9` / `ebc7`). sp5-pp also fixes the 4-byte body shortfall, so that is a block-ordering decision, not a source defect. Probe the body, not the epilogue. |
| `ahm_ExAllocAlchemist` | 828/1002 | 834/1002 | two clusters: the store order around the two `rep stosd` fills (ref 0x1000bee6 `83c8ff` / `66c706ffff` / `8982a4580310` / `8d92fc580310`), and the FPU chain interleaved with integer stores (ref 0x1000c01e `db442414` / `d9461c` / `d80db8560210` / `895618` / `895c2414` / `dec1`). |
| `ls_LoadBuildingEntityState` | 820/1463 | 824/1463 | the `ls_ReadVfsDataChecked` argument idiom at +0x687-0x836: `add ecx,edx` interleaved into the push run (ref 0x10012b9f `8b5671` / `8bcb` / `57` / `6a01` / `03ca`) against the folded `lea eax,[ebx+edx+4]` (0x10012bc4 `8d441304`). The per-site `add`-vs-`lea` choice is version-dependent. |
| `vfs_ReadCompressed` | 468/492, diffs to 417 | 461/492, diffs **end at 395** | the `add esp,0x14` placement, confirming section 90. |

**INDIFFERENT (1 row)**: `gm_CheckInventoryCapacity` is byte-for-byte identical under
both toolchains (same 97 mismatches at the same offsets). The one row this oracle cannot
screen at all.

**SOURCE-BOUND (14 rows)**: sp6 wins, so our shape is doing real work and probing can
pay. On the five heaviest (`ServerMainThread` -849, `srv_LoadBuf` -571,
`gm_AllocSpieler` -554, `gm_AllocGebaeude` -356, `vfs_OpenStream` -354) sp5-pp's first
mismatch moves *earlier* (967->586, 80->2, 134->2, 54->12): it cannot even reach our
current prologue shape, which is strong evidence those spellings are load-bearing.

One row splits: `cm_ExProdObjekt`'s first diff moves 205 -> 410 exactly as section 90
predicted, so its **+204 global-load lane is scheduler-bound and retires**, but the
function as a whole is -254 and `SIZE_MISMATCH` under sp5-pp, so it classifies
source-bound. Retire the lane, not the row. Byte 410 stays allocator-level.

Practical use: classify before probing. A row where sp5-pp's first mismatch moves
*earlier* is source-bound; a region sp5-pp reproduces verbatim is scheduler-bound and
should be written up as a wall instead of probed again.

## 92. Three closures, and the codegen facts they establish

Round 191 closed the three smallest-residue functions in the tree. None yielded a byte,
but each produced a fact worth more than its residue, and two of them refuted claims this
document or a file header had been carrying.

### The image sweep is nine IMAGES but only three GENERATORS

Sections 90 and 91 swept eight MSVC6 images; a ninth existed
(`rebrew/msvc:6.0-win9x-win32`, `C2.DLL` md5 `3c21de2c`, matching none of the other
eight) and was missed. It is now registered as `msvc-6.0-win9x` so the CLI can reach it.

**But it is not a ninth generator, and the inference that it was is wrong.** Swept over
all 19 residue rows (171 runs, comparing full mismatch *lists* rather than counts), it is
**byte-identical to base/sp1/sp2/sp3 on all 19** and beats sp6 on none: 18 ties and one
loss. The mechanism: win9x ships `CL.EXE` byte-identical to sp3: md5 `6e3f639e` on both,
against sp6's `5a4ec02b`, which I verified directly, i.e. the same 12.00.8168 frontend,
with the differing `C2.DLL` md5 being a differently-packaged build of the same code
generator.

**The rule this establishes: a distinct backend md5 counts IMAGES, not GENERATORS. Count
generators by emitted bytes.** Across these nine images there are exactly **three** real
generators on this table: the pre-sp4 class (base, sp1, sp2, sp3, win9x), the sp4/sp5/sp6
class (all 12.00.8804), and sp5-pp. No further image hunting is worth a round, and
section 91's four scheduler-bound retirements rest entirely on sp5-pp, unaffected.

The one divergent row is a *loss*, so it retires nothing: `gm_ObjectsAvailble` scores 683
under the pre-sp4 class against sp6's 686, three single-byte `[esp+N]`/register faults at
+0xa0, +0x111 and +0x19c that sp4's frontend bump *fixes*. Useful as confirmation that our
sp6 spelling is not the limiter on those bytes.

### `cm_ProcessCommandQueue`: tail-sharing, not arm order, and a greedy layout pass

Its header blamed "arm order" for 21 rounds. Our committed form **already has the
reference's exact block order** (arm5 0x38, arm6 0x44, unlink 0x78 against 0x38/0x48/0x78,
read off the objects). The real fault is **tail-sharing**: the reference shares one
`jmp advance` between arm5's fallthrough and arm6's exit while we duplicate it. The
arithmetic is exactly zero-sum: arm5+join 16B reference against our 12B, arm6 48B against
our 52B, which is why 15 bytes differ at *identical size* and why fixing either side
breaks the other.

The mechanism is worth recording on its own: **sp6 fuses `je unlink` + `jmp advance` into
one `0f85` even though the fusion is a net 3-byte loss.** It saves one byte locally and
costs arm6 four, because a 2-byte backward edge becomes a 6-byte near jump. The layout
pass is greedy per block, so no size-first flag declines it: `/Os`, `/O2 /Os`, `/Ox /Os`,
`/Oxs`, `/Os /Ob2`, `/Og /Os /Oi` all score 112-130 because `/Os` reshapes the function
wholesale. **A flag sweep cannot undo a greedy local decision that is globally wrong.**

Building the live-join form under all seven distinct generators puts the join at 0x3f
(reference-exact) in every one, but arm6 at 0x55 with unlink spliced into the freed
fallthrough slot. The fusion is invariant.

### `gm_ObjectsAvailble`: a downstream reschedule can be a rename's shadow

Its 25 faulting bytes are **one** allocator tie-break, traced end to end. Both builds free
exactly two registers into the match block: the target frees `{ebx, esi}` so row lands in
`ebx` (verified: `0x100160d3 bb55000000 mov ebx,0x55`), we free `{edi, esi}` so row lands
in `esi`; **and `esi` also holds `slot_base`**. So the `base = slot_base` copy must be
emitted before `mov esi,0x55` clobbers it. That true data dependency pulls the copy early,
consumes `edx`, displaces the item-def table into `edi`, and reorders the whole `shl`/`add`
chain.

The lesson generalises: **a 15-byte "second cluster" downstream of a register rename may be
the rename's shadow rather than an independent fault.** Test it by asking whether our
register choice collides with something already live. Four families of match-block
reshaping (a1-a6, f1-f6, n1-n6, x1-x6) were inert here, and this is why.

Also: 28 fixed-offset mismatches are **25 faulting bytes plus 3 collateral**: offsets
0x168-0x16a hold `c1e106 shl ecx,6`, byte-identical in both builds and displaced only
because a neighbour diverges in length. Quote which count is meant.

### `ahm_ExAllocAlchemist`: `faddp` is unreachable from any C expression

A 66-byte float-tail run reduces to **one byte**: ours `d8c1 fadd st(1)` against the
reference's `dec1 faddp st(1)` at 0x1000c034. The trailing `ddd8 fstp st(0)` is not an
independent fault: it is the cleanup msvc6 must add because non-popping `fadd` leaves the
operand on the x87 stack. Fix the byte and the run closes with it, so section 88 slack is
irrelevant: the correct form is two bytes *shorter*.

msvc6 collapses six spellings into **three** objects, and those are the only outcomes:

| shape | result |
|---|---|
| integer in a `float`/`double` local | correct `fild` first, but the local is live at the add, so msvc6 must use non-popping `fadd` |
| integer *not* in a local | it stays memory-resident and the add fuses into `fiadd [esp+0x14]`, which pops and does delete the `fstp st(0)`, wrong instruction, and it costs the whole preceding schedule (699 -> 377) |
| reassociated sub-first | `fsubr st(2)` + `fadd st(1)`, leaving two dead registers and emitting `fstp st(0)` **twice** |

`faddp st(1)` needs the conversion to be *both* a distinct `fild` (which requires a local)
*and* dead at the add (which requires no local). In msvc6's x87 model those are the same
property, so **no C expression can satisfy both**, closed by construction, not merely
inert. Two header claims died with it: that a `p1` local pinned `fld [esi+0x1c]; fmul`
(it pins the pair's *position*, never its operand roles: our baseline loads the constant
first) and that deleting `p1` reached 286 instructions at -15 (two different probes fused;
the -15 body is 287, the 286 body scores 398).

## 93. PROVEN is not a byte match, and the headline number hid that

A process finding rather than a codegen one, but it was silently mis-scoring every round.

`rebrew verify --full` printed `Verification: 281/283 passed, 2 failed`, and `scripts/gate.sh`
guarded that 281. But `passed` folds **PROVEN** in with EXACT and RELOC, and `AGENTS.md` is
explicit that PROVEN is semantic equivalence and *not* a byte match: every PROVEN entry
carries a non-zero delta. The real split here is **264 byte-matched + 17 PROVEN**.

That made the figure wrong in two directions at once:

- it **overstates progress** against a byte-identical objective (281 reads as "done" for
  264 functions that are, plus 17 that are not);
- a **RELOC -> PROVEN regression is invisible**: `passed` stays at 281 while the
  deliverable loses bytes, and a gate keyed on 281 stays green.

Fixed in both places. Upstream, the summary now prints the split and the accounting lives in
an importable `byte_match_counts()` helper, with a test that flips one RELOC to PROVEN and
asserts the byte-match count drops even though `passed` would not (`ab50856`). In this tree,
`scripts/gate.sh` gained a `BYTE_BASELINE` guard (264) checked independently of `BASELINE`,
verified to trip when the threshold is raised by one.

The general lesson for any metric this work leans on: **a status that is "good but not the
goal" must never be summed into the goal's counter.** The JSON had carried
`summary.byte_matched` correctly all along: the defect was only in the number humans and
scripts actually read, which is exactly where it does the most damage.

`scripts/gate.sh`

### The 117 lint warnings were all rebrew's own false positives (round 193)

Fixed upstream in `540b935`; the tree went from 117 warnings to **0**, with no
annotation changed, which is the point, because every one of them was unactionable.

**W028 treated the function inventory as ground truth.** That inventory is heuristic
(rizin `aaa` plus a capstone sweep) and it *merges adjacent functions* when the only
boundary is `ret` plus alignment padding. So the check fired on annotations that had
already compiled and compared byte-for-byte at that VA, advising "re-annotate the marker
VA": which would have broken a matched function. 15 fired at once here, one of them
EXACT; `cm_ExSellObjekt` at 0x1000d930 was reported as inside `fcn.1000d8a0` even though
the reference has `ret` at 0x1000d92d followed by two `nop`s and a fresh
`sub esp,0x228` prologue, which I verified before changing anything. EXACT, RELOC and
PROVEN now outrank the inventory; every other status still warns, since there the
inventory is the only evidence available.

**The other 102 were a stale inventory**, truncated at 0x10012440 with 219 entries against
543 real functions: every warning named a VA above that line. `rebrew binary functions`
refreshes it.

**And that refresh exposed a third, destructive bug**: `layout` was missing from the
known-target-key set, so a project carrying the position-alignment package warned
`unrecognized keys: {'layout'}` on *every* rebrew invocation, and an unrecognised key is
one a config rewriter silently drops. The discovery run deleted this tree's entire
`layout` block (image base, section geometry, exports, all 100 imports) and it had to be
restored from git. **An unrecognised-key warning is not cosmetic; it marks data the tools
will eventually throw away.**

## 94. `volatile` wins the alignment ruler and loses the link: three for three

Every `volatile`-pinning lever measured so far improves the aligned-instruction ruler and
then costs bytes at the link. The pattern is now consistent enough to price the lane before
funding it:

| function | what was pinned | aligned | link |
|---|---|---|---|
| `m_AllocTracked` | `count_total` through a volatile read | 225 -> **233/249**, the best on that function | **+40** |
| `ServerMainThread` | two global zero-stores reordered (86b proper, no volatile) | neutral | **0** |
| `gm_AllocSpieler` | six parent loads pinned to their stores | 662 -> **670/1056** | **+2** |

The `gm_AllocSpieler` case is the cleanest test, because it removed every excuse: it is
**byte-neutral** (real body 3689 both ways, so no §88 span risk), it *deletes* 11
insert/delete hunks rather than trading registers, and it moves the chain from 17/45 to
33/45 text-identical with the reference. It still cost +2.

**Why the rulers disagree.** `volatile` forces each load to its use, which is exactly what
the reference's schedule looks like locally, so the aligned ruler, which pairs
instructions positionally, scores it up. But it also forbids msvc6 from reusing a loaded
value anywhere else in the function, and the resulting register pressure shifts code
*outside* the region being fixed. The alignment gain is real and local; the loss is real
and remote.

**Round 196 makes it four for four, and the fourth is worse than a link loss.** A
`volatile match` on `gm_FindNextFilteredEntity` (the only candidate on that function that
qualified under the block-placement clause below) took the real body from 342 to **393
(+51)** and the span from 352 to **400 (+48)**, breaking the alignment ceiling outright
rather than merely costing bytes at the link. So the lane now has three link losses and one
span break, with no wins outside section 86's join-exile case.

**Practical rule: treat an aligned-only gain from `volatile` as unproven until linked, and
expect it to lose.** A `volatile` edit is worth landing only when it changes *block
placement* (§86, which paid -200 on `cm_ExSellObjekt` by un-exiling a join) rather than
merely re-pairing loads and stores inside a block. Re-pairing is cosmetic to the linker.

Also from this lane, two corrections worth carrying:

- The 344-byte "parent-wins cluster" was **174 bytes** of chain plus its displacement wake.
  A census that sums a region's mismatching bytes will attribute the wake to the fault; the
  chain's own byte multiset and kind multiset were *equal* to the reference's.
- `gm_AllocSpieler`'s header claimed a 20-variant CFLAGS sweep in which "every one scores
  identically". False: **`/Ow` is load-bearing** (766 -> 317 without it) and **`/Oa` is
  entirely inert**. A sweep that reports a flat result is worth re-running before it is
  cited as evidence.

`src/Develop/DieGildeAddOn/game/spiel_c/gm_AllocSpieler.c`

## 95. A jcc width difference is a readout of stub distance, never a source lever

Branch-encoding width differences look like codegen faults and are not. `jcc` takes a
2-byte `rel8` form when the target is within ±127 bytes and a 6-byte near form otherwise, so
a width difference is *arithmetic* on the distance to the target: it reports where the
target block landed and nothing about the source.

`gm_FindNextFilteredEntity` (0x10016f80) shows it cleanly. The filter arms at +168, +184 and
+225 differ in width between the streams, and every width is exactly what its displacement
mandates on both sides, 7 of 7 correct, no encoding defect either way:

```
reference, no_match stub at +326:  +168 (disp 152) -> near 6B   +184 (136) -> near 6B
                                   +203 (121)      -> short 2B  +225 ( 99) -> short 2B
ours,      no_match stub at +223:  +172 ( 49)      -> short 2B  +184 ( 37) -> short 2B
                                   +199 ( 22)      -> short 2B
```

And the function's entire 4-byte length deficit reconciles from those widths alone: the two
early `jcc` are 6+6 in the reference against our 2+2 (**-8**), and the extra arm is a 2-byte
`jne` against our 6-byte `je`/`xor`/`jmp` (**+4**), netting **-4**. So the deficit is
downstream of *stub placement*, which section 17 already owns.

**Two consequences.** Never open a lane on a width difference: fix the block placement and
the widths follow, or accept the placement and the widths are correct as they stand. And
when a byte deficit reconciles exactly against branch widths, the fault is not where the
bytes are missing: it is wherever the branch target moved.

This also refutes by arithmetic an instruction section 91 gave: it retired that function's
epilogue ordering and said to probe the body instead, on the assumption the shortfall might
be a body defect. The body is **byte-count exact** (315 reference bytes against 315 of ours)
and the whole -4 sits in the retired region, so the body and the epilogue were one finding
seen from two ends.

Also recorded from that measurement, but **corrected in round 197, because the stated
cause was wrong**: `probe_function.py` does *not* compile standalone. It passes `-c <src>`
on the whole file (line 152) and every `.text` COMDAT body is md5-identical between
probe-built and CMake-built objects across all 18 files, so there is no standalone-vs-in-file
divergence to guard against. The 352-against-342 and 74-against-118 figures are the same
object under different *rulers*, which is a different and more useful trap: see section 96.

`src/Develop/DieGildeAddOn/game/spiel_dumpD.c`

## 96. Four rulers, one object: always state which convention a number used

A round-197 audit measured all 19 non-matching rows two ways and found **zero** divergence
between what `probe_function.py` builds and what CMake builds: every `.text` COMDAT body is
md5-identical across all 18 files, including all 16 sections of `spiel622.c`. So no recorded
verdict in this project is a compilation artifact, and **no measured wall needs re-opening on
that basis.**

What the audit did establish is that four defensible numbers coexist for the same bytes, and
quoting one without its convention is how the confusion starts. On
`gm_FindNextFilteredEntity` all four were reproduced from one identical object:

| figure | convention |
|---|---|
| `obj 352` | COMDAT span, trailing alignment nops included |
| `obj 342` | same object, `rstrip(b'\x90')`: code length |
| `aligned 74/118` | probe's policy: union both sides' reloc masks |
| `aligned 87/118` | each side masks only its **own** relocs |
| `aligned 68/118` | both sides fully unioned |
| `matched 130` vs `match_count 162` vs `matched-reloc 210` vs raw 88 | four masking strictnesses |

Two rules follow.

**A bare `obj N` is span-or-code ambiguous by 0-15 bytes.** The gap equals that COMDAT's
trailing nop count on 18 of 19 rows. `m_AllocTracked.c` already documented this for itself in
round 92: "the honest field is `obj_size`, the function's object bytes with the COMDAT's
trailing alignment nops trimmed", and the same ambiguity applies to every other row. Only
`gm_CheckInventoryCapacity` hides a *real* 1-byte code shortfall inside its gap (COMDAT 400,
code 396, `rebrew test` 395).

**A bare `aligned N` is mask-policy ambiguous by up to ±89 instructions, signed both ways.**
Worst offenders if a quoted figure lacks its convention: `ServerMainThread` **-89**
(576 against 487), `gm_AllocSpieler` **+36** (662 against 698), `cm_ExCopyEntityData` +19,
`cm_ExSellObjekt` +17, `CrashDumpUnhandledExceptionFilter` +15, `gm_FindNextFilteredEntity`
+13. The two policies agree exactly on `m_AllocTracked`, `vfs_ReadCompressed`,
`gm_ObjectsAvailble`, `gm_AllocGebaeude` and `gm_CheckInventoryCapacity`.

And the standing rule this reinforces: **never compare a probe `matched` against a
`rebrew test` match_count**: 130 against 162 on identical bytes, because `coff_reloc.py`
masks only the object's validated relocs and compares over `min(obj_code, ref_size)`.

One latent hazard found while verifying: `spiel622.c` contains two **400-byte** COMDATs
(`_gm_CalculateProductionValue` and `_gm_CheckInventoryCapacity`), plus three 96-byte and
three 112-byte collisions. `probe_function.py` disambiguates through `build/split_poc.map`
and falls back to a prologue tie-break, which was verified to still pick correctly with the
map removed, but any *other* script selecting a COMDAT by size alone on that file will pick
the wrong one.

## 97. Spec audit: every live `__asm` block is inside the "original used asm" carve-out

The governing objective allows **no naked asm unless the original code was using it to**.
Round 198 audited that directly for the first time. Result: **six live `__asm` blocks, all six
compliant, zero naked functions.**

| file | function | VA | status | reference contains it |
|---|---|---|---|---|
| `server4.c:448` | `srv_InitBuildingTypeTable` | 0x1000b040 | RELOC | yes, at 0x1000b057 |
| `gm_AllocGebaeude.c:241` | `gm_AllocGebaeude` | 0x100174d0 | PROVEN | yes, at 0x10017611 |
| `m_AllocTracked.c:451` | `m_AllocTracked` | 0x10006580 | PROVEN | yes, at 0x10006730 |
| `m_alloc.c:220` | `m_init` | 0x100068e0 | RELOC | yes, at 0x10006929 |
| `m_alloc2.c:232` | `m_PoolAlloc` | 0x10006d20 | RELOC | yes, at 0x10006e0d |
| `vfs_ReadData.c:414` | `vfs_ReadData` | 0x10008e40 | RELOC | yes, at 0x10008f0c |

All six are the same alignment-prefixed block-fill skeleton, byte-identical in the reference
at every site:

```
8d0c7f lea ecx,[edi+edi*2]   83e103 and ecx,3   2bd9 sub ebx,ecx   7e0c jle
f3aa rep stosb   8bcb mov ecx,ebx   83e303 and ebx,3   c1e902 shr ecx,2
f3ab rep stosd   03cb add ecx,ebx   f3aa rep stosb
```

`vfs_ReadData` is the **copy** variant of the same skeleton: `f3a4 rep movsb` / `f3a5 rep
movsd`, and correctly *no* `xor eax,eax` since there is no fill value (verified at
0x10008f0c). Its C block spells movsb/movsd accordingly.

**Why these are asm in the original, not our shortcut.** Three independent signals:
the three-`rep` alignment pass (a plain `memset`/`memcpy` expansion emits two); the operand
homing, which matches the C block's named operands at all six sites; and the use of
callee-saved `ebx` as scratch, which no msvc6 `memset` expansion does. The template is also
absent from LIBCMT and LIBC, so it is not an out-of-line CRT routine the linker inlined.

**Independently re-measured rather than assumed.** On the cheapest block (`m_init`) all three
C alternatives collapse to the plain two-`rep` form and fall 15-19 code bytes short:

| shape | result | code length |
|---|---|---|
| `__asm` (shipped) | RELOC 162/162 | 162 |
| `memset` | SIZE_MISMATCH 97/162 | 143 |
| `char*` loop | SIZE_MISMATCH 98/162 | 147 |
| dword `for` loop | SIZE_MISMATCH 98/162 | 146 |

**The stronger prohibition is not violated either:** no `__declspec(naked)` and no
`#pragma naked` anywhere in the tree. All six are `__asm` statements inside ordinary C
functions, with `push ebp; mov ebp,esp` present on both sides. Every `naked` grep hit is
historical prose; the naked-`_emit` era was converted at `93ecf29`.

Cleanup done in the same round: `/DREBREW_ALLOW_NAKED` sat in the cflags of 0x100174d0 and
0x10008e40 while appearing **zero** times in either source. Measured byte-identical with and
without it (753/1078 and 472/472 unchanged), so it was dropped via `rebrew test --cflags`:
it was reading like a live naked-asm escape hatch that does not exist.

**Re-verified 2026-09-17 (round 890) when the carve-out was challenged.** The user asked for all
six blocks to be removed to plain C. Before acting, every load-bearing claim in this section was
re-tested independently rather than re-cited:

- **The template is not a library routine: confirmed by exhaustive scan.** Searched all **1,707**
  `.lib` files under both toolchain caches for the exact 24-byte prelude
  (`8d0c7f 83e103 2bd9 7e0c f3aa 8bcb 83e303 c1e902 f3ab 03cb f3aa`): **0 hits.** It is not
  LIBCMT, not LIBC, and not any other shipped library.
- **Not library code at the function level either.** `rebrew library match --stock-lib LIBCMT.LIB`
  on `0x100068e0` (`m_init`) reports "not in the given libraries. Safe to reverse."
- **Every one of the six is byte-exact *because of* its block.** Whole-file `rebrew test` on all
  six carriers: `m_init` **162/162**, `m_PoolAlloc` **270/270**, `vfs_ReadData` **472/472**,
  `srv_InitBuildingTypeTable` **372/372**, `m_FreeTracked` 188/188, `m_ShutdownAllocator` 283/283,
  `m_pool_free` 137/137: all `RELOC`, all at full object size. Round 889 measured what removing
  them costs: **residue 8,634 → 116,814 (+108,180)**.

The carve-out therefore stands on three independently reproduced legs, and the spec reading is
settled: these sites satisfy "a code shape no MSVC6 C output can produce." Recorded here so the
question is not re-litigated a fourth time.

## 98. "Byte-identical outside `.text`" means *copied* outside `.text`

The objective is a byte-identical **file**, and every round of this session has measured one
section. Round 199 audited the rest, and the answer has two halves that must be stated
together.

**The deliverable is genuinely byte-identical outside `.text`.** Verified three independent
ways (a standalone stdlib PE parser, `cmp -l`, and the project's own script, all agreeing on
8,666 differing bytes with **100% attributed to `.text`**): headers, `.rdata`, `.data`,
`.reloc`, all 4 section headers compared as raw 40-byte blocks, all 30 optional-header fields,
all 16 data directories, the import table (**4 DLLs / 100 symbols, identical in order**: WS2_32
imported by ordinal), the export table (`Exit` ord 1 → 0x9350, `Init` ord 2 → 0x9320), and the
file size (286,720 both). Nothing there is broken and nothing needs fixing.

**But that identity is copied, not produced.** The raw link's own non-`.text` output diverges
from the reference by **43,705 bytes**, and the postlink fixers blit reference bytes over it
from `layout/server.dll/`. I verified the package holds verbatim reference slices:
`data.hex == ref[0x27000:]` and `reloc.hex == ref[0x35000:]`, both exactly `True`. So every
`differing 0x0` outside `.text` was a tautology: the metric was grading its own answer key.

Pre-fixer divergence, now printed by `scripts/postlink_residual.py` beside the `.text`
residue so the number stops being self-certifying:

```
.rdata   0x4f4 of 0x3000 (10.3%)      .data  0x893b of 0xe000 (61.3%)
.reloc  0x1bab of 0x9000 (19.2%)      headers  0xdf of 0x1000 (5.4%)
```

Four further gaps the residue number cannot show, worth knowing before anyone calls this done:

- **The stored PE checksum is a stamped constant that is wrong for the built content**:
  `0x4d328` shipped, `0x4b330` computed. It is the one header field that hashes the whole
  file, so it currently masks the `.text` gap and will be the last thing to become genuinely
  correct.
- **`.reloc` is inconsistent with the image it ships with.** Of 3,499 relocation entries, 223
  point at bytes that are not pointers in our build (RVA 0x278f: reference `0x10024040`
  against our `0x404015ff`). Those targets sit inside unmatched functions, so the divergence
  is already counted in the 8,666, but nothing cross-validates `.reloc` against the shipped
  image, so a reloc-only regression would be silent.
- **1,978 bytes of the `.text` raw tail sit outside the measurement**, and the *measuring
  script* (not `rebrew.postlink.FIXERS`) zeroes 638 nonzero emitted bytes there (a stub
  DllMain `6a 01 58 c2 0c 00` plus ~100 `ff 25` IAT thunks). `rebrew build postlink` would ship them.
- **23.6 MB of `.data` VirtualSize has no file bytes at all** (VirtualSize 0x174059c against
  raw 0xe000), so the BSS *size* matches but its runtime content is unverifiable from the file.
  A naive `min(VirtualSize)` comparison loop runs past EOF here.

Also corrected: AGENTS.md's "`.text` link shortfall … 0x3a84 short" was stale
even when this section was written. Do not cite a VirtualSize from this
paragraph as "today": measure with `python3 scripts/section_geometry.py`.
The historical overshoot (`0x22ac8` against `0x22846`) is one era of the
split-link; later prelayouts have been short (`0x221f6`) or exact. Residue
is `scripts/gate.sh` `RESIDUE_BASELINE`.

Historical comparison only: **neither of these two files has a Rich
header.** The DOS stub runs straight from the standard message to the PE signature, and both
stubs are byte-identical across all 0x80 bytes. So the exact MSVC build IDs cannot be
recovered from file metadata, and the compiler-identity question stays where section 92 left
it: answerable only from emitted bytes in this pair. Matching local stock SERVER
copies do contain Rich records; see `msvc6-link-layout.md` section 18. The
configured project reference has altered headers relative to those copies.

## 99. The measuring script and the shipping pipeline had drifted apart

Section 98 found that `scripts/postlink_residual.py` zeroed 638 real emitted bytes in the
`.text` raw tail while `rebrew build postlink` shipped them. Round 200 chased that to the end, and
the two halves of the answer are worth keeping together.

**Fixed: the `.text` overshoot (638 bytes).** `_fix_data`'s tail trim starts at the
reference's **raw** size (0x23000), so anything the link emitted between the reference's
**VirtualSize** (0x22846) and that point survived: here a stub DllMain
`6a 01 58 c2 0c 00` plus ~100 `ff 25` IAT thunks the original build dead-stripped. The
script normalised the span for its own measurement, so the residue number looked clean while
the shipped binary carried the bytes. Now zeroed in the fixer: verified on the real binary,
638 nonzero → **0**.

The guard turned out to matter more than the fix. My first attempt zeroed that span
unconditionally and broke two existing tests: correctly, because **when the built `.text`
does *not* overshoot, that region is the reference's own section padding, which real linkers
fill with `0xCC`, not zeros.** Zeroing it would corrupt an already-matching build. The fix now
acts only when `built .text VirtualSize > reference VirtualSize`.

**Not fixable: the 3 stale operands (12 bytes).** The script also recovers operands whose
surrounding instruction is byte-identical but whose value is stale (our
`cmp eax,0x117f65b4` against the reference's `cmp eax,0x10139820`), using a locality test:
twelve bytes either side must match outside other operand slots. Its own comment says "those
are the fixer's job". They cannot be: that test needs the reference's `.text` bytes, and the
layout package is designed to hold **zero binary bytes at rest**: `prefix.hex` is the
`.rdata` prefix, not `.text`. I implemented it, measured it doing nothing, and reverted.

So `rebrew build postlink` lands at 8,678 differing bytes against the script's 8,666, and the
remaining 12 are structural: closing them would mean shipping reference `.text` bytes inside
the layout package, which defeats its purpose. **The right reading is that 8,666 is the
script's number and 8,678 is the pipeline's**, and the gap is now understood rather than
invisible.

General lesson, which is why this is worth a section: **a measuring tool that "normalises"
anything has forked from the thing it measures.** Every such normalisation is a silent claim
that the pipeline will do the same, and that claim needs a test or it drifts. Two existed
here; one was a real bug and one was load-bearing by design.

## 100. `.data` is placement-bound: MSVC6 puts every string literal in its own COMDAT

Section 98 showed the raw link gets **61.3% of `.data` wrong** (35,131 of 57,344 bytes) and
that the shipped identity is copied from `layout/server.dll/data.hex`. Round 201 attacked it
and the attempt *failed usefully*.

**The measured shape of the problem:**

| metric | value |
|---|---|
| positional match | 22,062 / 57,344 = **38.5%** |
| content-multiset overlap (ceiling if bytes could be permuted) | 51,086 = **89.1%** |
| ⇒ present but **misplaced** | **29,024 bytes (50.6%)** |

So `.data` is **placement-bound, not content-bound**, and that inverts the obvious strategy.
Six literals the build was failing to emit were converted to real C strings; they emitted
correctly and `.data` got **worse**: 0x893b → 0x89d2 (+151 bytes), because each added
literal grows the section and shifts every later object. **Emitting correct content cannot
improve this metric until ordering is solved.** Reverted.

**The mechanism, verified by dumping an object.** MSVC6 emits every anonymous string literal
into **its own COMDAT `.data` section**, separate from the object's single regular `.data`.
`Error.c.obj` has `.data` 0xa1 (regular) plus `.data` 0x3 and `.data` 0x6 as COMDATs. The
linker gathers each object's regular `.data` first and its COMDATs after, so **all named
globals precede all string literals within every object**: our map reads `_g_log_level_table`
0x7980 … `_g_log_default_name` 0x7a14 and only then `??_C@_02JNFB@at?$AA@` 0x7a24. The
reference **interleaves them in declaration order**: at `.data+0x84..0x108` the strings
`__server.log`, `gilde_server.log`, `__dbg.log`, `at`, `%s\%s` sit adjacent to the named
tables, not gathered behind them.

**What does and does not steer it:**

- `/Gy` is absent and irrelevant: it governs `.text` COMDATs.
- Object order is *already* steered (sources are VA-sorted), and the map confirms one
  contiguous `.data` run per object in that order. Not the problem.
- `/Gf` does **not** change COMDAT-ness; `/GF` moves literals to `.rdata` COMDATs, which is
  worse since `.rdata` already matches.
- **Naming a literal as an initialised `char[]` moves it into the object's regular `.data`,
  in declaration order**: probe-verified, and it reproduces the reference's shape. The tree
  already uses that convention (`char s_..._<VA>[]`).
- **Do not name a literal that several TUs share.** MSVC LINK folds identical `??_C@` COMDATs
  by name, so a shared literal exists once in the image; naming it locally breaks the fold and
  *adds* its length. `"D:\Develop\Units\m_alloc\m_alloc.c"` is shared by six TUs: naming it
  would have added 35 bytes. Convert only literals unique to their TU.

So the reference was almost certainly built from sources where these were named globals. The
lane is real but must be done **whole-TU at a time**, gated on the `.data` figure: six
literals lose, and the payoff only arrives once a TU stops shifting. ~29 KB is recoverable by
placement alone, with no new bytes.

**CORRECTED by section 101 (round 202): this framing has the dependency backwards.** A whole-TU
conversion was run and measured **exactly zero**: because the lever is blocked *behind* a
uniform section displacement, not ahead of it. Per-TU ordering is invisible while every object
is shifted by more than its own `.data` size. Remove the displacement first; only then does
within-object order become measurable, and only for TUs whose named globals and literals
actually interleave in the reference.

Two scoping corrections from the same measurement. The large cluster at `+0x2730..0x6c4e` is
**not** an ordering problem: of its 383 printable runs only 95 are emitted and **288 are
absent from the build entirely** (`"Usefull Sync"`, `"GamePath"`, `"\game.ini"`, …), none
appearing anywhere in `src/`: that is a content gap from missing or stubbed translation units,
a separate and larger lane. And `"This is Gilde talking, can you hear me?"` has **no xref
anywhere in the image** and sits between zlib's `z_errmsg` entries: dead data, unreachable by
any C edit.

The literals that *are* missing have three distinct causes, worth distinguishing before
anyone re-opens this: five are absolute-address casts (`(char*)0x10027448`) so no data is
emitted; `_main_:` is typed `extern int` and defined `= 0` in `link_stubs.c`, a wrong-type
placeholder; and the dead string above. All five push sites in the reference *are* relocated,
so C literals were the right shape.

## 101. `.data` placement was dominated by the link-order of the length pad, not by COMDATs

Section 100 concluded the named-`char[]` lever had to be tried **whole-TU**. Round 202 did
exactly that on `m_ReportGroupInfo.c` (the smallest TU with a meaningful literal count, 8
anonymous `??_C@` COMDATs) and the result is a **clean negative with the mechanism confirmed**
, plus the real cause found next door.

**The lever works at the object level, exactly as §100 predicted.** Converting all 8 literals
to named `char[]` collapsed the object from 9 COMDAT `.data` sections to one regular `.data`:

```
before:  .text 0x270 | .data 0x18 0x1a 0x18 0x46 0x39 0x1c 0x23 0x74 0x4c   (9 COMDATs)
after:   .data 0x1ac (regular, all 8 in declaration order) | .text 0x270 | .data 0x23
```

The map confirms the named symbols replace the mangled ones at the same relative order, and
the surviving `0x23` COMDAT is `"D:\Develop\Units\m_alloc\m_alloc.c"`: shared by six TUs and
folded by the linker, so naming it locally would *add* 35 bytes and break the fold. Leave
shared literals anonymous.

**But `.data` did not move: 0x893b before, 0x893b after, a delta of exactly zero.** Not worse
(unlike §100's six-literal attempt), just inert. The reason is that the strings' content was
never wrong: at their build VAs the bytes are already byte-identical to the reference. They sat
at `0x10030268` where the reference has `0x10028940`: a **uniform +0x7928 displacement**
shared by every game `.data` symbol. Within-object ordering is invisible while the whole
section is shifted by more than its own length.

**The +0x7928 was `data_restore_split.obj`.** `split_link.sh` generates that object as a
**length-only pad** (its bytes are a copy of the reference `.data` *tail*, and postlink
overwrites `.data` wholesale, so only its size matters, §2 of `msvc6-link-layout.md`), then
inserted it at rsp position 1. Its single regular `.data` is `0x74a0`, sitting at `0x10027030`
and ending at exactly `0x1002e4d0`, the first game string. It was pushing all real data off
the end of the section.

**Appending the pad instead of prepending it is a one-token change and it is worth 6008 bytes:**

| | `.data` differing | displacement of game data |
|---|---|---|
| pad first (old) | `0x893b` (61.3%) | `+0x7928` |
| pad last | **`0x71e3` (50.8%)** | `+0x488` |

`.text` also ticked `0x395d`→`0x395b`, `.data` raw stays `0xe000`, the shipped binary is still
byte-identical (`delta +0`), and the gate holds (187/187 lint, 0 errors, 281 passed / 264
byte-matched). Verified by a **control run with the conversion reverted**: pad-last alone gives
`0x71e3`, so the entire gain is the pad move and the conversion contributes nothing. The
conversion was reverted.

**The residual `+0x488` is `fold_literals.obj`** (`0x45c` at `0x10027030`, also linked first).
That object is a deliberate mechanism for folding member-library string COMDATs by name, not a
defect, so the last 1160 bytes of displacement are not free the way the pad was.

**What this means for the named-`char[]` lane.** It is not dead, but it is **blocked behind
displacement, not ahead of it**, and §100's "convert whole TUs and the payoff arrives" framing
has the dependency backwards. Per-TU conversion cannot pay while a uniform shift exceeds a
TU's own `.data` (`0x1ac` here vs `0x488` remaining). The order is:

1. Remove the displacement first: done for `0x74a0` of it; `fold_literals`' `0x45c` is what
   is left, and it needs a way to keep the fold without occupying the section prefix.
2. Only then does within-object ordering become measurable, and only for TUs whose named
   globals and literals actually interleave in the reference. **This TU has no named `.data`
   globals at all**, so there is nothing to interleave: converting it was always going to be
   a no-op once displacement was gone. Pick TUs from §100's `+0x84..0x108` example instead,
   where tables and strings genuinely alternate.

**It also moved the shipped binary.** The lane measured only the pre-fixer figure; re-linking
and re-measuring the deliverable gives **8,666 -> 8,665 differing bytes** in `.text`, with
**zero differing bytes outside `.text`** and the file size still exactly 286,720. Small, but it
is the first `.text` movement in this session that came from the *link* rather than from a
source shape, and it is free, in the sense that no C was changed.

Corollary worth keeping: **measure the displacement before attributing a `.data` figure to
content or ordering.** A uniform delta across every object is a link-order bug, and it is
cheaper to fix than any number of source edits.

## 102. Fold priority only needs to beat the first *member* COMDAT, not the whole link

Section 101 removed the `.data` pad from the head of the section and paid 6,008 bytes. The
same reasoning applies to the other object sitting there, and this one had a stated reason to
be first, which turned out to be true but far stronger than necessary.

`scripts/split_link.sh` generates `fold_literals.obj` (from `gen_fold_literals.py`) and
inserted it at rsp token 1, commented *"first, so our COMDATs are the ones kept"*. The purpose
is real: msvc6 derives a `??_C@` COMDAT name from the literal's contents and LINK folds
COMDATs by name, so re-declaring every member-library string makes the linker discard the
**members'** copies: that is what holds `.rdata` at the reference's size. But what the object
contributes to `.data` is not the literals (those are COMDATs); it is the
`const char* g_rdata_fold_refs[]` **pointer array**, which exists only to keep them referenced,
and at token 1 that array displaced every game `.data` symbol by **+0x488**.

**LINK keeps the first COMDAT of a given name, so the fold object only has to precede the
first *member* object that defines one**: not every game object. Objects of ours that appear
earlier are irrelevant: if one of them defines the literal first, the member's copy is
discarded either way. Scanning the response file's member objects for a `??_C@` symbol
(COFF symbol class 2, section > 0) and inserting immediately before the first hit puts the
array at **token 263** instead of 1:

| fold object at | `.data` differing | `.rdata` vsize/raw | dominant `.data` shift |
|---|---|---|---|
| token 1 (old) | `0x71e3` | 0x2e81 / 0x3000 | `+0x488` |
| token 263 (before first member `??_C@`) | **`0x6d33`** | 0x2e81 / 0x3000 | **`+0x20`** |

`.rdata` is unchanged at the reference's `0x2e81`/`0x3000`, which is the tell that the fold
still holds: a `.data` gain bought by breaking the fold would show up there immediately.
Shipped `.text` goes **8,665 → 8,664**, still zero differing bytes outside `.text`, file size
exactly 286,720.

**The cumulative effect of the two link-order fixes is the point.** Tracking the dominant
displacement of game `.data` symbols across rounds 202-204:

```
+0x7928  (pad at token 1)   ->  +0x488  (pad appended)  ->  +0x20  (fold object moved)
```

`.data` went `0x893b` → `0x71e3` → **`0x6d33`**, i.e. **7,208 bytes** recovered from link order
alone, with no C changed. And `.rdata` is now 60 of 111 located strings at **shift 0**: it was
never characterised before and is much closer than `.data`.

The general rule, which generalises past this project: **an object whose only job is to win a
COMDAT name, or to pad a length, should be placed as late as its job allows.** Both objects
here were placed at the extreme (token 1) when the requirement was merely "before the first
competitor" or "anywhere at all", and each cost the section's whole prefix.

## 103. `.rdata`'s whole residue is the import table, and the symbol order is already correct

`.rdata` was never characterised before round 205. It has **1,268 differing bytes in only five
clusters**, and all of them are one structure:

| cluster | size | RVA | what it is |
|---|---|---|---|
| `+0x0000` | 2 B | n/a | trivial |
| `+0x0070` | 297 B | 0x24070 | inside the **IAT** (dir 0x24000, size 0x1a0) |
| `+0x2614` | 90 B | 0x26614 | thunk array, partly matching |
| `+0x26dc` | 319 B | 0x266dc | **OriginalFirstThunk** array (same reference content as +0x0070) |
| `+0x2a06` | 1074 B | 0x26a06 | **import hint/name table** |

Resolving the dwords settles it: `+0x0070`'s entries are RVAs into `.rdata` pointing at
`0x00026bb2 -> "\x50\x01GetStartupInfoA"`, `0x00026acc -> "\x9f\x01HeapFree"` and so on: the
thunk arrays point at the very hint/name entries in the largest cluster. `+0x0070` and
`+0x26dc` hold identical reference content because an IAT and its OriginalFirstThunk array are
copies of the same list. **So 85% of `.rdata`'s gap is the name table and the remaining 15% is
the two thunk arrays that index it.**

**What is NOT wrong, checked directly:**

- The **DLL order matches**: `KERNEL32.dll, USER32.dll, WS2_32.dll, WINMM.dll` on both sides.
- The **symbol order matches for the named imports**: walking KERNEL32's thunk array on both
  sides gives the same 81 names in the same positions, same set. **Corrected round 206: that is
  81 of 100, not all of them.** WS2_32's 16 ordinal-only entries *are* permuted, so the true
  figure is **85/100 slots positionally correct**, costing exactly 30 bytes (15 in the IAT at
  0x2415c..0x2419c, 15 in the INT at 0x267c8..0x26808). Those slots come from
  `scripts/emit_thunks.py`'s `THUNKS` map and WS2_32.lib, **not** from `crt_imports.c`, and
  attempting to reorder them there measured worse.

So the raw link already produces the correct import *structure*; what differs is only **where
each name string lands inside the name table**. And the strings are not block-displaced the way
`.data`'s were: each moves by its own amount (`GetStartupInfoA` -0x1ac, `HeapFree` -0xb4,
`GetLocalTime` -0x282, `timeGetTime` +0x3c2), so this is an internal permutation of the name
pool, not a section-prefix problem.

That matters for effort allocation: **the link-order lever that paid 7,208 bytes on `.data`
does apply in principle but is blocked in practice**: a sharper statement than the original
"does not apply", and a testable one. `.data`'s wins came from uniform displacements caused by an object
sitting at the head of the section; `.rdata`'s residue has no uniform component to remove. The
name-pool layout is chosen by LINK from the order symbols are *first referenced*, which is a
property of the whole `.text` link rather than of any one object's position, and postlink's
`imports` fixer already produces the correct bytes in the shipped binary, which is why the
import table is byte-identical there (4 DLLs, 100 symbols, verified in section 98).

**Why it is blocked, measured (round 206).** Our name-pool order *is* literally the `/include`
directive order in `src/crt_region/crt_imports.c` (verified) so the pool is
directly steerable. The reference's own law was derived and validated exactly: the pool runs
`[imports a game object references, KERNEL32 group first] [the four DLL name strings]
[the member-only LIBCMT imports]`, a clean partition with zero exceptions (31 game-referenced,
53 member-only), with the DLL name strings *interleaved* at pool indices 28/31/32/34 rather
than gathered. We cannot reproduce that shape because we pin all 100 imports up front as one
contiguous run.

The blocker is a hard coupling: `/include` order sets the **pool** order, but the **IAT slot**
order is what `.text` is position-aligned against, and the baseline already has 85/100 slots
correct. Three measured attempts:

| edit | `.rdata` | `.text` |
|---|---|---|
| baseline | `0x4f4` | `0x3898` |
| all 100 `/include` in reference pool order | 0x4e4 (-16) | 0x3954 (**+188**) |
| pin only the game-referenced imports | 0x4d4 (-32) | 0x394c (**+180**) |
| permute the three WS2_32 lines | 0x4f6 (+2) | +2 |

Every one trades ≤32 bytes of `.rdata` for ~180 bytes of `.text`, and the first two break
`cmake --build` outright (layout-map validation falls to 64.8%, i.e. they destroy position
alignment). Pool order and IAT order are independently determined: in the reference,
pool order != IAT order, so one cannot be fixed from `crt_imports.c` without disturbing the
other.

Practical conclusion: `.rdata` is the *closest* non-`.text` section (1,268 bytes, 10.3%) but it
is **not the cheapest**. It only closes once the pool can be reordered without moving IAT
slots, which needs the reference's two-group link structure (game objects pinning their own
imports, LIBCMT discovered afterwards) rather than a directive permutation.

**`.reloc` is downstream too, and the evidence is unambiguous.** Our `.reloc` VirtualSize is
`0x8370` against the reference's `0x10374` (**less than half**) with 41 relocation blocks
against 44. Seven reference pages are missing entirely, and they are overwhelmingly `.data`
pages:

```
page 0x025000    6 entries        page 0x02c000  212 entries
page 0x026000   14 entries        page 0x031000   16 entries
page 0x029000   16 entries        page 0x033000   28 entries
page 0x034000   58 entries        (350 entries of the reference's 3,526)
```

A `.reloc` entry exists for every absolute address the image needs fixed up at load time, so a
missing page means **we are not emitting the pointers that live on it**. Those pages sit in
`.data` (RVA ≥ 0x27000), which is precisely the section section 100 showed is still missing 288
strings' worth of content from stubbed translation units. `.reloc` therefore cannot be attacked
directly: it is a *readout* of what `.text` and `.data` contain, and it will shrink toward the
reference exactly as those do. Of the 37 pages we do emit, only 12 have identical entry counts,
which is the same story at finer grain.

## 104. Inlining is not the residue: call counts already match

A natural hypothesis for the three largest walled rows is that the reference inlined a callee
we still call (or vice versa), which would explain a large, diffuse, un-spellable difference.
**Measured, and it is false.** Counting `call` instructions in the reference against our own
object for each row:

| function | reference calls | our calls |
|---|---|---|
| `gm_AllocSpieler` | 55 | **55** |
| `cm_ExSellObjekt` | 31 | **31** |
| `CrashDumpUnhandledExceptionFilter` | 44 | **43** |

Two match exactly, and the third is *one call short*: the wrong direction for an inlining
story, since an un-inlined callee on our side would make us call **more**, not fewer.
`gm_AllocSpieler`'s reference body also makes real calls to 14 distinct targets
(0x10003640, 0x1000bd50, 0x1000c600, 0x100122e0, 0x10018130, 0x10018150, …), all of which we
call too. There is no inlined callee to reproduce and no surplus call to eliminate.

This rules out a whole class of proposed fixes (`__forceinline`, macro-ising a helper,
manually pasting a callee's body) for these rows. It also reinforces what sections 84-99
found from the other direction: the residue in the big rows is **register allocation and
instruction scheduling inside blocks whose call structure already matches**, not a
call-graph-shape difference.

The missing call in `CrashDumpUnhandledExceptionFilter` is a separate, already-recorded fact:
its own header notes the reference has 44 calls in the body against our 43, the absent one
being the final indirect `call [0x10024008]` (`UnhandledExceptionFilter`).

### The related question: does emitting missing `.data` content help `.text`?

Also measured this round, on `ServerMainThread`: the TU with the most absolute-address string
casts. Converting its 16 TU-unique `(char*) 0x...` references to real C literals (leaving two
shared ones anonymous per the fold rule) **does** improve the function:

| metric | before | after |
|---|---|---|
| `rebrew test` match_count | 2075/2434 | **2087** |
| probe `matched` | 1525 (62.7%) | **1603 (65.9%)** |
| reference `.data` strings present | 242/415 | **252** |
| `.data` pre-fixer | 0x6d33 | 0x6f76 (**+579**) |
| **linked `.text` residue** | **0x21d8** | **0x21d9 (+1)** |

The 25 push sites become relocated operands matching the reference's shape, which is why the
object-level rulers move so much. **But the shipped residue went up by one byte, so it is
rejected**: `.text` residue is the objective's metric, `.data` pre-fixer is a diagnostic
(§98: the shipped `.data` is blitted from the layout package either way). An edit that gains 78
bytes on an object ruler and loses 1 byte at the link is a loss, and this is the clearest case
yet of why only the link decides (§19, §41, §94).

Two measurement traps from the same lane, both worth avoiding:

- **The dominant `.data` shift is not every object's shift.** §102's `+0x20` is the largest
  cluster (39 of ~400 strings), not a global property. `ServerMainThread`'s own block lands at
  **-0xa08** (2,568 bytes *early*) and **zero strings sit at their exact reference VA, before
  or after the conversion**. Measure the specific TU's block before assuming the headline shift
  applies to it.
- **`split_link.sh`'s `GAP` must be re-swept when a TU's `.data` size changes.** An uncorrected
  `GAP` silently produced a 290,816-byte image and a false `.data` figure; re-sweeping
  `0x74a0` -> `0x732f` restored the exact 286,720 geometry. Any `.data` measurement taken
  without that check is void.

## 105. The GA flag sweep, finally run, and why it says nothing new

The objective names `rebrew match run`, but no run of it had ever produced a result in this
session: two attempts hung and were killed. The cause was a tool bug, now fixed upstream
(`8820f1e`).

**The bug:** `--timeout-min` was applied only around the GA run. `--flag-sweep-only` returns
before reaching that code, so the flag was **silently inert on exactly the path where it
matters**: a `targeted` tier is thousands of combinations and `thorough` is 258k. Measured
here: `--timeout-min 6` was still running after 13 minutes with an empty output file;
`--timeout-min 2` was still going at 7 minutes. With a cooperative deadline threaded through
`flag_sweep` → `run_flag_sweep` → `_run_single_flag_sweep` → the CLI, the same command
finishes in **126 seconds** and writes its JSON report.

**The result, on `gm_CalculateProductionValue` (the 5-byte row):**

```
tier targeted, 20 flag combinations evaluated
best_score 7500.0   best_flags "/G3 /Gd /Oy"   exact false
... and all 20 combinations score exactly 7500.0
```

A perfectly flat landscape: `/G3`, `/G3 /Gd`, `/G3 /Oy`, `/G3 /Gd /Oy` and the empty set all
score identically. That is independent confirmation of what section 92 concluded from the
bytes: this row's residue is an **x87-stack allocator decision**, and no flag reaches it.
A flat sweep is a genuinely useful negative: it separates "we have not found the flag" from
"no flag exists", and this is the latter.

Two practical notes for anyone running the engine here:

- **Always pass `--timeout-min`**, and now it works. Without a bound, a sweep on a
  multi-function file will outlive any wrapper `timeout` you put around it, because the
  compiles it spawns survive the signal.
- The sweep is per-*function* via `--va`, but it still compiles the whole translation unit
  each time, so cost scales with the file, not the function. `spiel622.c` (16 functions) takes
  ~6 s per combination.

## 106. The flag landscape is flat on every walled row: five for five

Section 105 ran the repaired flag sweep on one function and found all 20 combinations scoring
identically. Round 208 asked whether that generalises. It does, and the result is worth having
because it closes an entire class of "have we tried the flags?" questions.

Sweeping the five largest walled rows, `targeted` tier, 20 combinations each:

| function | residue | combos | distinct scores | best score |
|---|---|---|---|---|
| `gm_AllocSpieler` | 2,824 | 20 | **1** | 3,849,233.33 |
| `CrashDumpUnhandledExceptionFilter` | 1,595 | 20 | **1** | 2,224,585.73 |
| `cm_ExSellObjekt` | 967 | 20 | **1** | 1,301,503.00 |
| `vfs_ReadCompressed` | 24 | 20 | **1** | 35,900.00 |
| `m_AllocTracked` | 92 | 20 | **1** | 34,500.00 |

**Five for five, one distinct score each.** The flags genuinely vary: 20 distinct flag strings
per row, verified (`/G3`, `/G3 /Gd`, `/G3 /Gd /Oy`, `/G3 /Gd /Oy /Op`, `/G3 /Gd /Oy-`, …): the
emitted code simply does not respond to any of them.

The `targeted` tier covers `/G?`, `/Gd`, `/Op`, `/Oy`, `/Oy-`. To check the finding was not an
artefact of that narrow set, `m_AllocTracked` was also swept at `thorough` tier, which reaches
a different group (`/GX`, `/Gs`, `/ML`, `/Ob?`, `/Zp?`) and it is **still 1 distinct score**.
That is **12 distinct flag axes and ~120 compilations, all inert**.

**Why this matters more than any single row.** Every one of these rows was closed by byte-level
analysis (sections 84-104) concluding the residue is register allocation, instruction
scheduling, or an x87-stack decision. The sweep is an *independent instrument* reaching the
same verdict without looking at a single byte: if a compiler flag could move these functions,
a flat landscape is exactly what you would not see. Two methods agreeing from different
directions is much stronger than either alone.

It also retires a standing question cheaply. "Has anyone tried `/Ob2`? `/Zp1`? `/GX`?" now has
a measured answer for the rows that matter, rather than an appeal to the CFLAGS sweeps recorded
in individual file headers (which were per-function, undated, and in one case, section 94's
`gm_AllocSpieler` note, found to be wrong about which flags were load-bearing).

Practical caveat: a flat landscape says the *flags* are inert, not that the function is
unreachable. It is silent about source shape, which is where every landed win in this session
came from.

## 107. The GA finds nothing either, and stagnates immediately

Section 106 established that the flag landscape is flat on every walled row, but was explicit
that this says nothing about **source shape**: the axis every landed win in this session came
from. `rebrew match run`'s GA mode mutates source, so it tests exactly that axis. Round 209 ran it
for the first time (it was unusable before the round-457 timeout fix).

Two rows, 12 generations, population 16, `--mutation-focus auto` (which reads the function's
BLOCKER metadata to bias operator selection):

| function | best score | stagnant generations | vs flag-sweep baseline |
|---|---|---|---|
| `m_AllocTracked` | 147,228.92 | **11 of 12** | 34,500: **4x worse** |
| `vfs_ReadCompressed` | 35,900.00 | **11 of 12** | 35,900: **identical** |

**Both stagnate after a single generation.** On `vfs_ReadCompressed` the GA never beat the
unmutated source; on `m_AllocTracked` its best candidate ended four times worse than doing
nothing, i.e. every mutation it kept was harmful and it simply had nothing better to fall back
to within the budget.

The one mutation that survived on `m_AllocTracked` is instructive:

```c
- while (i < slots) {
+ while (!(i >= slots)) {
```

Applied by hand and measured: **566/658, byte-identical to baseline.** msvc6 canonicalises the
double-negated comparison straight back, which is the same normalisation section 92 found for
commuted multiplies and section 59 for `if (c) goto L;`. The GA's "best" source change is
provably a no-op.

**What this adds to section 106.** The two instruments now cover both axes and agree:

- flags: flat across 12 axes and ~120 compilations (section 106);
- source mutations: immediate stagnation, no candidate better than the unmutated source.

Neither is a proof of impossibility, and the GA's operator set is generic rather than aimed at
the specific allocator decisions these rows are blocked on (sections 92, 94, 104). But it does
mean the two *automated* search paths the toolchain offers are exhausted on these functions,
and the remaining progress has to come from reading the reference's bytes and reasoning about
what C shape produces them, which is how every win in this session was actually found.

Practical note: budget the GA by wall clock, not generations. 12 generations at population 16
is ~95 s per row here, and the stagnation counter tells you almost immediately whether more
generations would help: 11 of 12 stagnant means they would not.

## 108. `near-diag`'s verdict is a different ruler: reconcile it before believing it

`rebrew diagnose near` classifies a NEAR_MATCHING residual and suggests mutation operators. Run
across the walled rows it reports, uniformly, a **RELOC-dominated** verdict:

| function | verdict | near-diag "real bytes" | `rebrew test` delta |
|---|---|---|---|
| `cm_ExProdObjekt` | RELOC (91% of delta) | 17 | **17** |
| `cm_ProcessCommandQueue` | RELOC (88% of delta) | 13 | 15 |
| `gm_ObjectsAvailble` | RELOC (69% of delta) | 56 | 28 |
| `vfs_ReadCompressed` | RELOC (41% of delta) | 36 | 24 |
| `m_AllocTracked` | RELOC (62% of delta) | 103 | 92 |

Read carelessly, "91% of the delta is relocations" suggests these functions are nearly solved
and the residue is an artefact. **That reading is wrong**, and the tool itself says so in the
next sentence: *"Most of the delta sits at relocation sites, but 17 real byte(s) differ: the
match is NEAR_MATCHING-level, not RELOC."*

**Round 211 pinned the exact mechanism**, because three rows disagree in *both* directions
(56 vs 28, 36 vs 24, but 13 vs 15) and a one-way masking story cannot explain a sign flip.
Ground truth on `cm_ProcessCommandQueue`, computed directly from the object and the reference:
**75 raw differing bytes**, which `rebrew test` masks down to 15 and `near-diag` reports as 13.

The cause is that the two tools count in **different units**:

- `rebrew test` counts **individual differing bytes** after masking relocation slots.
- `near-diag` walks aligned instruction pairs and adds each differing instruction's **whole
  size** to a category (`reloc`, `register`, `encoding`, `equivalent`, `structural`), so one
  mismatching 6-byte instruction contributes 6 to the total even if a single byte differs, and
  contributes 0 to "real bytes" if it happens to carry a relocation, even when non-relocated
  bytes inside it also differ.

That is why the sign can flip: instruction-granular accounting over-counts a row whose
differences are spread across long instructions (`gm_ObjectsAvailble`, 56 vs 28) and
under-counts one whose differing bytes cluster inside relocated instructions
(`cm_ProcessCommandQueue`, 13 vs 15). Neither tool is wrong; they answer different questions.
**Use `rebrew test`'s number for "how many bytes differ" and `near-diag`'s categories for
"what kind of difference is it".**

The two numbers are different rulers over the same object, exactly as section 96 warned:

- `rebrew test` reports the delta **after masking relocation slots**: 17 on `cm_ExProdObjekt`,
  with `reloc_count: 34` masked separately.
- `near-diag`'s percentage is computed over **unmasked** spans, so every relocation site counts
  toward the denominator and the percentage says how much of the *raw* difference is explained
  by relocations rather than how close the function is.

Its `bytes` field is also the **function size** (993 for `cm_ExProdObjekt`), not a delta: easy
to misread as a residual. Once reconciled, the two tools agree exactly where it matters: both
say 17 real bytes on `cm_ExProdObjekt`.

**What it adds that is genuinely new.** `near-diag` flags *"control flow / block layout
differs"* on exactly two of the five rows (`vfs_ReadCompressed` and `m_AllocTracked`) and
stays silent on the other three. That is an independent structural signal, and it is consistent
with the byte-level findings: section 99 traced `vfs_ReadCompressed`'s residue to a
scheduler-sunk `add esp,0x14` (a layout decision), and section 86b traced `m_AllocTracked`'s to
store ordering through a fresh pointer. The three rows it stays silent on
(`cm_ExProdObjekt`, `cm_ProcessCommandQueue`, `gm_ObjectsAvailble`) are exactly the ones whose
documented causes are *not* layout: a coupled allocator decision (section 104), provably-dead
code the compiler deletes (section 92), and a register-rename shadow (section 92).

So the classifier's structural flag agrees with five independent byte-level investigations.
That is worth having: it is a cheap first-pass triage that would have pointed at the right
category on all five rows without disassembling anything.

The suggested mutation operators are generic control-flow rewrites (`mut_swap_if_else`,
`mut_guard_clause`, `mut_while_to_dowhile`, `mut_for_to_while`, …): the same family section 107
measured the GA applying, where the one surviving candidate proved byte-inert because msvc6
canonicalises it.

## 109. `gm_AllocSpieler`'s first fault is a scheduler sink, not a statement order

`gm_AllocSpieler` (0x10018850) carries **2,824 of the 8,664 residual bytes: 33% of everything
left**, so its first divergence is the highest-value single question in the tree. Round 212
located it exactly.

**Our object is byte-identical to the reference through +0xa9.** At +0xaa the streams split:

```
reference +0xaa:  8d92fc580310   lea edx,[edx+0x100358fc]
ours      +0xaa:  66895d00       mov word ptr [ebp],bx      <-- we emit these two
                  33db           xor ebx,ebx                <--   first
                  8dbafc580310   lea edi,[edx+0x100358fc]   (edi, not edx)
```

The reference emits that same `mov word ptr [ebp],bx` / `xor ebx,ebx` pair at **0x10018918:
after the `rep stosd`**. So neither side is missing an instruction: the same work is scheduled
on opposite sides of the block fill, and the reference keeps the scaled index live in `edx`
where we move it to `edi`.

The corresponding C is the record-header init, where `*(unsigned short*)(0x100358a0 + idx *
0x21c) = (unsigned short) idx;` precedes the `memset`.

**Reordering the C to match makes it worse, measured:**

| shape | `rebrew test` | obj |
|---|---|---|
| shipped (idx store before `memset`) | **1004/3689** | 3689 |
| `memset` hoisted above the idx store | 633/3694 | 3694 |
| same, also moving the two zeroing stores after | 633/3694 | 3694 |

Both variants lose **371 matched bytes and grow the object by 5**, because hoisting the
`memset` call forces the scaled index to be rematerialised across it: the call clobbers the
register the reference is carefully keeping live.

**So this is a scheduler decision downstream of register pressure, not a statement order.**
msvc6 is sinking the 16-bit store past the block fill on its own, and C has no way to request
that: the fill is a `memset` call, and any source order that puts the store after it also puts
the call *before* it, which costs the register. This is the same class as section 99's
`vfs_ReadCompressed` finding (a scheduler-sunk `add esp,0x14`) and section 86b's store
ordering, and it is consistent with section 106: no compiler flag moves this row either.

Worth stating plainly because it bounds expectations on the biggest row: the first 0xaa bytes
already match, the fault at 0xaa is not a source shape, and the 2,824-byte residue behind it is
that one scheduling decision's displacement wake rather than 2,824 bytes of wrong code.

### Round 216: the `lea` split is not source-reachable either

The obvious remaining hypothesis was that the reference's `lea edx,[edx+0x100358fc]` followed
by `mov edi,edx` means the destination is a **named C object** rather than an argument computed
in place, and that we fuse into one `lea edi` because ours is anonymous.

**Tracing `edx` in the reference kills the simplest version of that story.** `edx` is *dead*
immediately after the copy: its next appearance is an unrelated `lea edx,[esp+0x3c]` at
0x1001896f, and every statement after the fill is addressed off `ebp`, not off the scaled
index. So the reference is not keeping a live value: it computes into `edx` and copies.

Tested anyway, two ways:

| shape | `rebrew test` | obj | `lea` at +0xaa |
|---|---|---|---|
| baseline | **1004/3689** | 3689 | fused (`8dbafc580310`) |
| new `char* refs` local (round 465) | 595/3696 | 3696 | frame grew, broke instruction #0 |
| **reuse an existing pointer local** (`mother`) | 1004/3689 | 3689 | **still fused** |

Reusing a local that already exists avoids the frame growth entirely: the object stays exactly
3689 and the score is byte-identical, but msvc6 **folds the assignment away** and still emits
the fused `lea edi`. So the split cannot be requested through a named destination: with a new
local it costs 4 bytes of frame and breaks the prologue, and with an existing local it is
optimised out.

Combined with the seventeen-variant sweep (every one moved the first fault *earlier*), the
+0xaa fault is closed to source-level work on both of its tells: the store sink and the `lea`
split. Section 109's narrowed claim stands: C can request the sink alone, but not while keeping
the `0xffff` store alive, and the `lea` split is unreachable in either configuration.

Housekeeping from the same round: the metadata note claiming "SIZE 3209/3689 (480B short)" was
stale from the naked-asm era: the object is now **exactly 3689 bytes**, the target size, and
an inert `/DREBREW_ALLOW_NAKED` was removed from its cflags (verified byte-identical at
1004/3689 both ways), the last of the three section 97 identified.

## 110. A deliberate semantic bug is shipped in `gm_AllocSpieler`: state it plainly

This one is not a codegen fact; it is a standing decision that deserves to be visible outside
a file header, because it trades **correctness for byte score**.

`gm_AllocSpieler` contains a real bug. In the `arg8 != 2` branch we store a value that is
always zero:

```c
if (arg8 == 2) {
        slot[9] = (char) gm_RandomMod((unsigned short) arg8);
} else {
        slot[9] = slot[0x166];          /* always 0 -- WRONG */
}
```

The reference stores **`arg8` itself**, which I verified at the bytes (round 213):

```
0x10018cd4  8b84244c040000  mov eax,[esp+0x44c]   ; arg8
0x10018cdb  83f802          cmp eax,2
0x10018cde  7509            jne 0x10018ce9        ; skips the call, eax still = arg8
0x10018ce0  50              push eax
0x10018ce1  e8ea130000      call gm_RandomMod
0x10018ce9  83fe04          cmp esi,4
0x10018cec  884509          mov byte ptr [ebp+9],al   ; stores arg8 when the call was skipped
```

`eax` holds `arg8` on the skip path, so the store writes the argument. Our version writes 0.
**Observable whenever `arg8` is neither 2 nor 0.**

Measured cost of being correct:

| shape | `rebrew test` | obj |
|---|---|---|
| shipped (wrong) | **1004/3689** | 3689 |
| `slot[9] = (char) arg8` | 565/3689 | **3679** |
| reference's single-store shape (`n = arg8; if (...) n = call(...); slot[9] = (char) n;`) | 565/3689 | **3679** |

Both correct spellings land **identically**, so the 10-byte deficit is structural: the correct
code is simply shorter, not a spelling that can be tuned. An earlier attempt also measured
**+393 linked** through tail desynchronisation.

**Why this is worth a numbered section.** Sections 19, 41 and 94 established that only the link
decides, and that rule has correctly rejected many byte-losing edits. This is the one case
where the rule is being applied to a *correctness* regression rather than a stylistic one, and
that is a different kind of decision: the objective is a byte-identical recompilation, so the
shipped source is allowed to diverge from correct behaviour only because the reference binary
is the specification. Anyone using this tree as a *source* release rather than a byte-matching
exercise must fix this line first.

The blocking condition is precise and worth restating: a correct spelling that is **10 bytes
longer**, or a resynchronised tail that absorbs the shortfall. Until then the bug stays, and it
should stay *documented here*, not only in a comment 450 lines above the defect.

**Round 887 closed the one hypothesis that section left open.** The file header also banks a
second 11-byte-short fix: reading `*(int*) 0x1003542c` once instead of twice profits four verbatim
opcodes but costs 11 bytes (3689 → 3678). Both deficits are *missing* code of the same order, so
the obvious hope was that they are complementary and would cancel. Measured, applied one at a time
and then together:

| shape | `rebrew test` | obj |
|---|---|---|
| shipped | 1004/3689 | 3689 |
| single-read `0x1003542c` alone | 646/3689 | **3678** (−11) |
| correct `arg8` store alone | 563/3689 | **3679** (−10) |
| **both applied** | 524/3689 | **3668** (−21) |

**They are additive, not complementary.** −11 and −10 give −21, so the two shortfalls are
independent missing instructions rather than two spellings of one gap. That kills the "recover 10
bytes here to pay for 11 there" plan and says the real obstacle is ~21 bytes of code the reference
contains and no spelling of this source produces. Combined with §109's finding that the +0xaa
divergence is a scheduler sink rather than a statement order, the row's residue is not
source-reachable by any of the levers this tree has: the two known-correct edits are correct *and*
smaller, and no ordering or spelling recovers the difference. Consistent with §§109/216/110,
recorded rather than re-probed.

### Round 214 correction: the size match is an accident of the bug

The framing above, "being correct costs 10 bytes", is misleading, and the instruction counts
show why:

| shape | instructions (ref 1056) | obj |
|---|---|---|
| shipped (buggy store) | 1054: **2 short** | 3689 (**matches**) |
| correct semantics | 1053: **3 short** | 3679 (10 short) |

Both shapes emit **fewer instructions than the reference**. The buggy `slot[9] = slot[0x166]`
spelling loads from an absolute address, which emits one extra instruction worth ~10 bytes, and
that coincidentally pads the object back to exactly 3689. **The size match is an artefact of the
defect, not evidence that the shipped shape is right.**

That inverts the correct reading of the deficit. It is not that correctness costs 10 bytes; it
is that **the reference contains ~10 bytes of work we are not emitting anywhere**, and the wrong
store has been masking that gap by accident. Chasing "a correct spelling 10 bytes longer" is
therefore the wrong target: padding with a different wrong instruction would match the size
just as accidentally.

### Round 215: half the deficit was the argument cast, not the store

The "10 bytes short" figure assumed the only variable was the store. It was not. The call in
the `arg8 == 2` arm was spelled `gm_RandomMod((unsigned short) arg8)`, and that cast is
**load-bearing only when the store is correct**:

| variant | `rebrew test` | obj | short by |
|---|---|---|---|
| shipped (buggy store, masked arg) | **1004/3689** | 3689 | 0 |
| correct store, masked arg | 565/3689 | 3679 | 10 |
| **correct store, unmasked arg** | **745/3689** | **3684** | **5** |
| buggy store, unmasked arg | 1004/3689 | 3689 | 0 |

Removing the cast recovers **180 matched bytes and half the size deficit**, but only in
combination with the correct store. With the buggy store it is perfectly inert (1004/3689 both
ways), which is why nobody found it: the cast can only be evaluated against a correct store,
and the correct store was rejected on its own numbers before the cast was ever varied.

The reference supports the unmasked form directly: at 0x10018cd4 it loads the full dword
`mov eax,[esp+0x44c]` and pushes `eax` unmodified, with no 16-bit narrowing anywhere.

**This changes the unblocking condition.** Section 110 asked for "a correct spelling 10 bytes
longer", which the round-214 correction then showed was the wrong target anyway. The real
target is now 5 bytes, not 10, and the remaining 5 are the section 109 scheduler sink: the
`jmp` displacement evidence (`0xc01` against `0xbfc`) measures exactly that. Correct semantics
still costs 259 matched bytes against the shipped bug, so it does not land yet, but the gap is
half what it was and the residue is now attributed to a single known cause rather than an
unexplained deficit.

Where the missing work sits is already known. With correct semantics the first non-relocation
divergence is still **+0xaa**, the section 109 scheduler sink, and the `jmp` at +0x85 carries
displacement `0xc01` against our `0xbfc`: **exactly 5 bytes**, so the reference's jump target
sits 5 bytes later than ours. Half the deficit is behind that one scheduling decision, which
section 109 established C cannot request. (Relocation slots must be masked before reading any of
this: unmasked, the first difference appears at +0x6d, which is only an unresolved `0x10035434`
against zeros.)

## 111. Count calls by ENCODING, not by grep, and what it shows on `CrashDumpUnhandledExceptionFilter`

Section 104 compared call counts between the reference and our objects to rule out inlining.
That comparison was right in its conclusion but sloppy in its method: it grepped lines
containing `call`, which also matches operands and comments. Counting strictly from the
**encoding bytes** is both correct and far more informative, because the three x86 call forms
map onto three different C-level constructs:

| form | encoding | C that produces it |
|---|---|---|
| direct | `e8 rel32` | a call to a function in the same image |
| indirect through memory | `ff15 disp32` | a call to a `__declspec(dllimport)` API by name |
| indirect through a register | `ffd?` | a call through a function-pointer *value* |

On `CrashDumpUnhandledExceptionFilter` (0x10002770, 1,595 residual bytes: the second largest
in the tree) the strict counts are:

| kind | reference | ours |
|---|---|---|
| direct `e8` | 8 | 8 |
| **memory-indirect `ff15`** | **19** | **17** |
| **register `ffd?`** | **17** | **18** |
| total | **44** | **43** |

So the shape of the difference is precise: **we make two fewer calls straight through the IAT
and one more through a register**, and we emit one call fewer overall. Direct calls match
exactly, which again rules out an inlining difference (section 104's conclusion survives its
method being corrected).

Two measurement notes that cost time here and will cost it again:

- **Our object's IAT slots are unresolved zeros**, so a naive comparison of call *targets*
  reports every slot as differing (`ds:0x0` against `0x10024010`). Compare by count and by
  relocation symbol, not by address, until after the link.
- The reference calls 13 times through `esi`, which looks like one cached import but is not:
  `esi` is reloaded at least four times in the body (`mov esi,[0x10024038]`,
  `mov esi,[esp+0x20]`, `mov esi,0x100272f8`, `mov esi,[0x10024024]`). Several different values
  flow through the same register.

Reading the object's relocations gives the useful cross-check: we reference **15 distinct
`__imp_` symbols** where the reference calls through **12 IAT slots**, with `CloseHandle` x4 and
`VirtualFree` x3 the most repeated. The source has **five** `CloseHandle` call sites against
four relocations, i.e. msvc6 has already merged two of them, which is consistent with both the
missing call and the extra register call being the same event: a repeated import getting cached
into a register and one of its call sites folded.

## 112. The reference does not cross-jump identical cleanup arms, and neither should we

Section 111 traced `CrashDumpUnhandledExceptionFilter`'s call-kind delta (19 `ff15` in the
reference against our 17) to three `else` arms that each end with the same two statements:

```c
VirtualFree(pDbgBuf, 0, 0x8000);
CloseHandle(hDbgFile);
```

msvc6 folds two of ours into a shared tail. **The reference emits the pair three separate
times**, at 0x10002d9f/0x10002da6, 0x10002dd8/0x10002ddf and 0x10002e0a/0x10002e11.

The interesting part is *why*, and reading all three aligned (rather than two, as I first did)
gives the answer: the arms are **not** interchangeable blocks:

```
arm 1  0x10002d96:  mov ebx,[esp+0x3c]  mov ebp,[esp+0x38]  push ebx  call VF  push ebp  call CH
arm 2  0x10002dc9:  mov ebp,[esp+0x40]  add esp,0x10        push 0x8000 push 0 push ebx call VF ...
arm 3  0x10002e02:                      push 0x8000 push 0  push ebx  call VF  push ebp  call CH
```

Each arm reaches the cleanup with a different register/stack state: arm 1 reloads both `ebx`
and `ebp`, arm 2 reloads `ebp` and unwinds `esp` by 0x10, arm 3 arrives with everything live.
The *call pair* is identical in all three, but the blocks containing it are not, so there is
nothing for the compiler to fold. Our version reaches all three arms in the same state, which
is what makes them foldable.

**So the lever is not "stop msvc6 cross-jumping".** It is that the reference's three arms do
genuinely different amounts of stack and register restoration before the cleanup, because they
are exited from different nesting depths. Reproducing that means matching the *scope structure*
that produces those different exits, not perturbing the cleanup statements themselves.

Worth recording as a general caution: **two byte-identical instruction sequences in the
reference are not evidence that the compiler declined an optimisation.** Check what precedes
them. Here arms 2 and 3 have identical six-instruction tails and different four-instruction
lead-ins, and it is the lead-ins that keep them apart. I nearly delegated a probe to "prevent
cross-jumping" before reading the third arm aligned: the misalignment in
`rebrew binary asm show` output when starting mid-instruction is easy to mistake for real code.

### Round 219: count call sites per IMPORT, not adjacent-call "pairs"

The analysis above was still one abstraction too loose. Counting *adjacent `ff15` pairs* gave
"reference 3, ours 2" and pointed at a missing cleanup arm, but the heuristic conflated two
different sequences. Reference arm 1 actually runs
`WriteFile` (via `esi`) → `CloseHandle(hCrashLog)` → `VirtualFree` → `CloseHandle(hDbgFile)`,
so its "+0x62f pair" is `CloseHandle`+`VirtualFree`, not the cleanup pair at all.

Counting **per import slot** settles it exactly:

| import | slot | reference sites | our relocations |
|---|---|---|---|
| `VirtualFree` | 0x1002400c | 3 (+0x62f, +0x668, +0x69a) | **3** |
| `CloseHandle` | 0x10024010 | 5 (+0x619, +0x636, +0x66f, +0x6a1, +0x6d3) | **4** |

So `VirtualFree` already matches, and **exactly one `CloseHandle` call is missing**. Our source
has five `CloseHandle` call sites, so msvc6 folded two of *those*, and the three-arm cleanup
story, while true about the arms differing, was not where the lost call lives.

The method rule: **count call sites per import symbol** (from the reference's IAT slot and from
the object's relocation symbols), never by positional adjacency. Adjacency is a property of
scheduling; the per-symbol count is a property of the source.

### Round 220: that rule is ALSO wrong: a relocation is not a call

The per-symbol count above was measured from **relocation entries**, and a relocation marks
where an address is *materialised*, not where it is *called*. When msvc6 caches an import in a
callee-saved register it emits **one** relocation (`8b35 mov esi,[__imp__X]`) and then any
number of `ffd6 call esi`. Two independent probe lanes caught this, and the object confirms it
directly: our own breakdown by preceding opcode:

```
__imp__CloseHandle@4   ff15 x3  +  mov-CSE x1     -> 3 relocs but 5 calls
__imp__WriteFile@20    mov-CSE x1                 -> 1 reloc  but 10 calls
__imp__VirtualFree@12  ff15 x3                    -> 3 relocs and 3 calls
```

So "CloseHandle 5 vs 4, one missing" (round 219, committed in `f4a73057`) was an artefact of
counting relocations. Resolved properly (by tracing each cached register back to the
relocation that loaded it) the inventory is:

| callee | reference | ours |
|---|---|---|
| `VirtualFree` | 3 | **3** |
| `CloseHandle` | 5 | **5** |
| `WriteFile` | 11 | **10** |
| everything else | 1:1 | 1:1 |

**`VirtualFree` and `CloseHandle` already match. The entire call delta is one `WriteFile`.**
Sections 111 and 112's cleanup-arm story is therefore retired: those three and five calls are
all present in our object, and there is nothing to win there.

The corrected rule, third time: **count calls, not relocations**: resolve `ffd?` sites by
tracing the register back to its defining `mov reg,[__imp__…]`. The `ff15`/`ffd?` ratio itself
is a *register-allocation* artefact (the reference caches three imports in callee-saved
registers, we cache four), not a source property, so the encoding ratio is a shadow worth
chasing only after the call inventory matches.

**Now automated (round 221).** Three separate probe lanes had to derive this inventory by hand,
each time re-discovering the same trap, so it is now a command:

```
rebrew binary xrefs 0x10002770 --calls-from 2115
  WriteFile 11 | CloseHandle 5 | 0x10003640 4 | VirtualFree 3 | ... | total 44
```

It walks the function, tracks which import each register currently holds (`mov reg,[__imp__X]`),
and attributes a `call reg` to the same callee as a direct call: reproducing in one command
what took four rounds and three wrong methods to establish. Use it before reasoning about call
counts on any row.

**Where the real missing call is.** The reference compiles the exception switch as **two jump
tables, each with its own newline tail**: table 1 at 0x10002b2a (6 arms, tail 0x10002b7f,
`call esi` at **0x10002b80**, the absent WriteFile) and table 2 at 0x10002bab (8 arms, tail
0x10002c40). Fan-in confirms two joins: 6 × `jmp 0x10002b7f`, 11 × `jmp 0x10002c40`. We emit
**both range tests at identical constants** (our case partition already matches) then funnel
every arm into one shared tail.

So the phenomenon is real but inverted from the original guess: **we fold, the reference keeps
two copies**, and it lives in the switch message writes rather than the cleanup. Splitting the
second range into its own `switch` does not buy it (406/2141, SIZE_MISMATCH): msvc6's two
tables are one switch it split because the case values form two dense clusters (spans 0x68 and
0x6e), and the duplicated tail is its own downstream layout decision, not something the keyword
produces.

## 113. Tree-wide call-inventory sweep: exactly one row has a real defect

With the inventory automated (section 112), round 222 swept it across every measurable walled
row: comparing the reference's per-callee counts against the same inventory computed from our
objects, resolving register-cached imports on both sides.

| row | reference | ours | |
|---|---|---|---|
| `gm_AllocSpieler` | 55 | **55** | ok |
| `ServerMainThread` | 55 | **55** | ok |
| `cm_ExSellObjekt` | 31 | **31** | ok |
| `ls_LoadBuildingEntityState` | 45 | **45** | ok |
| `cm_ExProdObjekt` | 21 | **21** | ok |
| `gm_AllocGebaeude` | 18 | **18** | ok |
| `srv_LoadBuf` | 17 | **17** | ok |
| `gm_ObjectsAvailble` | 15 | **15** | ok |
| `ahm_ExAllocAlchemist` | 13 | **13** | ok |
| `m_AllocTracked` | 10 | **10** | ok |
| `vfs_OpenStream`, `cm_ProcessCommandQueue`, `gv_ExAllocGraveyardWorker` | 7 | **7** | ok |
| `gm_CheckInventoryCapacity` | 5 | **5** | ok |
| `cm_ExCopyEntityData` | 3 | **3** | ok |
| `gm_CalculateProductionValue` | 2 | **2** | ok |
| `gm_FindNextFilteredEntity` | 0 | **0** | ok |
| **`CrashDumpUnhandledExceptionFilter`** | **44** | **43** | **`WriteFile` 11 vs 10** |

**Every row matches except one.** That is a strong negative result: whatever the remaining 8,664
bytes are, they are almost entirely *not* missing or extra calls. Combined with section 104
(direct-call counts equal, so nothing is inlined) and section 106 (the flag landscape is flat),
the residue is confined to register allocation, instruction scheduling and block layout: with a
single exception worth one `WriteFile` in `CrashDumpUnhandledExceptionFilter`'s exception-switch
tail.

Two measurement traps, both hit while running this sweep:

- **Selecting a COMDAT by "largest `.text` section" is wrong on a multi-function file.**
  `spiel622.c` has 16 functions, and picking the largest COMDAT reported 10 calls against the
  reference's 2: a phantom mismatch. Both apparent failures in this sweep were this artefact;
  re-measured on the correct COMDAT they match exactly. Select by the section index the probe
  reports, and note the COMDAT is sized by *span* (400) not code length (396).
- The reference-side tool takes the function's **size from metadata**; passing a stale size
  truncates the walk and undercounts silently.

## 114. The last call defect: two switch tails the reference keeps and we merge

Section 113 established that exactly one row in the tree has a call-inventory defect:
`CrashDumpUnhandledExceptionFilter`, `WriteFile` 11 against our 10. Round 223 located it
exactly, and it is the clearest remaining *structural* difference in the function.

The reference compiles the exception-code switch as **two jump tables, each with its own copy of
the message-write tail**:

```
tail A  0x10002b7f  55 push ebp / ffd6 call esi   <- the WriteFile we never emit
                    8d4c2410 lea ecx,[esp+0x10] ... 6a02 push 2
tail B  0x10002c40  55 push ebp / ffd6 call esi
                    8d442410 lea eax,[esp+0x10] ... 6a02 push 2
```

The two tails are **structurally identical and differ only in scratch register** (`ecx`/`edx`
against `eax`/`ecx`), which is exactly why msvc6 did not fold them: they are reached in
different register states. Fan-in, counted from the reference's own `jmp` targets:

```
jmp 0x10002b7f :  6 arms      jmp 0x10002c40 : 11 arms      jmp 0x10002c51 : 1 arm (newline)
```

Walking the jump tables confirms the split: table 1 at 0x10002e9c holds four real arm addresses
(0x10002b31/41/51/61) before its index bytes, table 2 at 0x10002f1c holds eight
(0x10002bb2…0x10002c22). Each arm pushes its own message pointer and length:
`lea eax,[esp+0x10]; push 0; push eax; push 0x15; push 0x10027278`, then `jmp` to its group's
tail, which supplies the handle and makes the call.

**We emit both range tests at identical constants**, so our case partition already matches the
reference; what we do not reproduce is the duplicated tail. Our source writes each case's
message with its own `WriteFile(...)` followed by `break;`, and msvc6 cross-jumps every arm into
a single shared tail: one call site where the reference has two.

**Corrected by section 117 (round 225):** tail A does not run to its own end: it finishes
`push edx; jmp 0x10002c51`, landing *inside* tail B at its **second** `call esi`. So the two
tails **share the newline write** and duplicate only the **message** write. The reference has 13
`call esi` sites for 19 arms; whole-tail duplication would give 14. Any shape that duplicates the
whole tail is structurally wrong before it is compiled.

Known dead ends, so nobody re-spends them: spelling the second range as its own `switch`
statement measures **406/2141 (SIZE_MISMATCH)**, because msvc6's two tables are *one* switch it
split internally on dense case clusters rather than two source constructs; splitting a single
case to its own tail reaches the correct call count (44) and better alignment (+13) but costs 79
matched bytes and 4 bytes of size (**554/2119**); and writing the reference's exact seven-case
group split compiles **byte-identical**, because msvc6 simply re-merges it.

### Why the reference's spill reloads are not a storage signal

Section 112 read the reference's `mov ebx,[esp+0x3c]` / `mov ebp,[esp+0x38]` between the two
`CloseHandle` calls as evidence that the handles must live in distinct storage. **That inference
does not hold**, and the bytes two instructions later say why:

```
0x10002da6  ff1510400210  call [0x10024010]   ; CloseHandle(hDbgFile)
0x10002dac  5f            pop edi
0x10002dad  5b            pop ebx
0x10002dae  e9b3000000    jmp 0x10002e66
```

The reference reloads into `ebx`/`ebp` because it is **about to pop `edi`/`ebx` for the epilogue
path** and needs those values back in registers first. Our build keeps the same values in
`edx`/`eax`, in distinct stack slots (`[esp+0x2c]` and `[esp+0x58]`), and never spills, so the
asymmetry the earlier reading treated as a source-level storage difference is pure register
allocation. It follows that `volatile` on a handle could not have helped here, which is
consistent with section 94's record of it losing four times out of four.

Two further probes confirmed the dead end from a different arm partition: two `switch`
statements sharing one newline write measured **336/2117**, and two switches each with their own
inline newline write measured **338/2133**, and neither even bought the extra call, because the
second `switch` keyword still cross-jumped into a single tail.

So the duplicated tail is a *layout* consequence of how msvc6 placed the two arm clusters, not
something the source requests directly: consistent with section 109's finding on
`gm_AllocSpieler` and section 112's on the cleanup arms. It is worth one `WriteFile` plus about
twenty bytes of duplicated argument setup, and it sits exactly where this function's alignment
deltas step from +21 to +43.

## 115. The sp5-pp toolchain axis, finally measured: a real gain that cannot ship

Section 91 recorded that `msvc-6.0-sp5-pp` reproduces `gm_FindNextFilteredEntity`'s tail verbatim
and reaches obj 346, the reference's exact size, where sp6 emits 342. Nobody had measured it.
Round 224 did, and the answer has two halves that must be kept together.

**The gain is real.** On `gm_FindNextFilteredEntity` (0x10016f80):

| toolchain | status | match | obj |
|---|---|---|---|
| msvc-6.0-sp6 (default) | SIZE_MISMATCH | 162/346 | 342 (**4 short**) |
| **msvc-6.0-sp5-pp** | STUB | **171/346** | **346: exact** |

And the file is safe: all three of its file-mates (0x10016cd0, 0x10016de0, 0x10016ea0) stay
**RELOC-perfect** under sp5-pp: 272/272, 186/186, 211/211, so switching this one file would
cost nothing elsewhere in it. That matters because section 12 established CFLAGS are per-file in
practice, and a toolchain is per-file too.

**But it is not a global win, and it cannot ship.** Two independent blockers:

- **sp5-pp is much worse on other rows**, so it cannot be adopted project-wide:
  `gm_CalculateProductionValue` 391/396 → **236/396**, `m_AllocTracked` 566/658 → **266/658**
  (and obj 658 → 634), `vfs_ReadCompressed` 468/492 → 461/492. The nine MSVC6 images are three
  distinct generators (section 92); sp5-pp is its own, and it disagrees with sp6 broadly.
- **A per-function toolchain pin never reaches the link.** `rebrew build cmake-flags` says so
  explicitly: *"resolves toolchain 'msvc-6.0-sp6', but the CMake build's compiler is fixed by the
  toolchain file: the pin affects `rebrew test`/`verify` only, never the linked bytes."* The
  build selects one compiler through `cmake/toolchain-msvc-6.0-sp6-docker.cmake`, for every
  translation unit.

So this is the measure-vs-ship divergence of section 99 in a new place: a metadata pin can move
`rebrew test` by +9 matched bytes and a perfect object size while the shipped binary does not
change by one byte. **Recording the figure without that caveat would be recording a phantom
win.**

What it would take to bank it: per-file compiler selection in the CMake build: a second
toolchain file plus a `set_source_files_properties`-style override, or splitting the file into
its own target. That is a build-system change, not a source change, and it is worth exactly the
4 bytes of size plus 9 matched bytes on one function, so it is recorded rather than pursued.

The general rule, which generalises past this project: **a compiler pin that the build system
cannot honour is a measurement setting, not a fix.** Check what the link actually uses before
counting any toolchain result as progress.

## 117. The two tails at 0x10002770 are a register-pressure artefact, not a source shape

Section 113 left exactly one call-inventory defect in the tree: `CrashDumpUnhandledExceptionFilter`
emits **10** `WriteFile` calls where the reference has **11**. The reference compiles the
exception switch as two jump tables with two structurally identical tails that differ only in
register assignment (tail A at 0x10002b7f uses `ecx`/`edx`, tail B at 0x10002c40 uses `eax`/`ecx`),
so msvc6 declined to fold them.

**The tail groups, walked from the `jmp` fan-in** (not the tables, the fan-in is unambiguous):

| tail | arms | case values |
|---|---|---|
| A `0x10002b7f` | 7 | `0x80000003`, `0x80000004`, `0xc0000025`, `0xc0000026`, `0xc000008c`, `0xc000008d`, `0xc000008e` |
| B `0x10002c40` | 12 | `0xc0000005`, `0xc0000006`, `0xc000001d`, `0xc000008f`–`0xc0000096`, `0xc00000fd` |

Our source already splits at exactly this boundary: both range tests are emitted at the
identical constants (`add eax,0x3fffffdb; cmp eax,0x68` and `add eax,0x3fffff71; cmp eax,0x6e`).
**The case partition was never the problem.**

**What the duplicated call actually is.** Tail A does not end in a `ret` or a jump past tail B:
it ends `push edx; jmp 0x10002c51`, landing *inside* tail B at its **second** `call esi`. So the
two tails share the newline `WriteFile` and duplicate only the **message** `WriteFile`. The
reference has 13 `call esi` sites for 19 arms; a whole-tail duplication would give 14.

**Three shapes measured against that, all rejected** (each from a clean
`git checkout HEAD --`, baseline 633/2115):

| attempt | result |
|---|---|
| `goto write_nl_a/b`: two labelled write sites, one per group | **526/2139**, SIZE_MISMATCH |
| newline `WriteFile` inlined into all 19 arms instead of a shared tail | **352/2267**, SIZE_MISMATCH |
| per-group locals (`exc_msg`/`exc_len` assigned per arm, one write per group) | **631/2123**, SIZE_MISMATCH |

The `goto` variants are the instructive failures: a label per group **defeats tail merging
outright** rather than splitting it: the object goes from 12 `call ebx` sites to 19, one per
arm, because an explicit jump target stops msvc6 from threading the arms into a common tail at
all. The per-group-local variant is the closest miss and the most informative: it does produce
**two** tails and drives the inventory to `WriteFile` **13**, total **46**, but msvc6 then
materialises the message/length into `eax`/`ecx` (`mov eax,0x10027208; mov ecx,0x12; jmp`) instead
of pushing them as immediates per arm, which is what costs the bytes. **Routing the message
through a variable is the wrong lever: the reference pushes immediates in every arm.**

**The lever that did work is register pressure, not the switch at all.** The reference keeps three
long-lived values in callee-saved registers across the switch (`esi` = `WriteFile`,
`edi` = `pExceptionPointers`, **`ebx` = `Context->Esp`, loaded at 0x10002931, before the separator
write**, with the `-4` applied only at 0x10002c6c). Ours loaded `pCtx->Esp` after the switch, which
left `edi` free, and msvc6 filled it by caching the constant `0` (`xor edi,edi`, then `push edi`
for every `WriteFile` `lpOverlapped`). Hoisting the two stores to just above
`hProcess = GetCurrentProcess();`:

```c
if (hCrashLog != (void*) -1) {
        /* Write separator line */
        pStack = (unsigned int*) (pCtx->Esp - 4);   /* hoisted: reference loads */
        nFrames = 0x800;                            /* Context->Esp into ebx here */
        hProcess = GetCurrentProcess();
```

measures **633 -> 643 / 2115**, obj_size unchanged at **2115**, probe matched 532 -> 555 and
matched-reloc 842 -> 853. This is a pure statement-order move of two semantically dead-until-later
stores, and it is the first improvement on this row since section 106 measured the flag landscape
flat. **It does not add the call**: inventory is still `WriteFile` 10, total 43.

**Conclusion for the next lane.** The missing `WriteFile` is downstream of register allocation: the
two tails exist in the reference *because* three registers were already committed, leaving
different scratch registers live at each group's exit. No arrangement of `break`/`goto`/locals in
the switch reproduces it while the surrounding function still caches `0` in `edi`. The hoist above
recovers one of the three committed registers and is kept for the bytes; the remaining gap is the
same `ebx`/`edi` deferral cascade already named in the file header and section 81, **not** a
property of the switch statement. Do not spend another lane reshaping the switch.

## 116. A +10 win on CrashDump: hoist the stack-walk setup to the reference's computation point

Round 225 found an uncommitted edit left in the worktree by a probe lane, measured it, and it is
a genuine win: the first byte gain on `CrashDumpUnhandledExceptionFilter` in this session.

The edit hoists two initialisations about 110 source lines earlier, from just before the
stack-walk loop to immediately after the crash-log handle is opened:

```c
 if (hCrashLog != (void*) -1) {
+        pStack = (unsigned int*) (pCtx->Esp - 4);
+        nFrames = 0x800;
         hProcess = GetCurrentProcess();
         ...
         frameInfo[6] = 0;
-        pStack = (unsigned int*) (pCtx->Esp - 4);
-        nFrames = 0x800;
         for (;;) {
```

That is where the reference computes them (0x10002931/0x1000293a), far ahead of the loop that
uses them.

| | `rebrew test` | obj |
|---|---|---|
| before | 633/2115 | 2115 |
| **after** | **643/2115** | **2115** |

Measured at the link from a clean rebuild: **`.text` residue 8,664 → 8,652**, twelve bytes, with
the shipped file still 286,720 bytes and **zero differing bytes outside `.text`**. The object
size is unchanged, so this is pure placement, not extra or missing code.

**Why it works.** Computing `pCtx->Esp - 4` early lets msvc6 keep the value in a register across
the intervening block instead of rematerialising it at the loop head; the same class of lever as
section 101's link-order wins and the opposite of section 109, where hoisting a `memset` call
*cost* bytes because the call clobbered a live register. The distinction is that these two
statements are pure computation with no call between them and their first use.

**Process note, and it is the important part of this round.** The edit was sitting uncommitted
and unreported in a shared worktree. It was only found because the residue moved unexpectedly
during unrelated work and `git status` was checked before attributing the change. Two habits
made that recovery possible: gating on the *residue* (section 99's guard, added round 215) and
checking `git diff --stat` before trusting any measurement. Without them this would have been
recorded as a toolchain result and the real cause would have been lost.

## 118. Scope of the hoist lever: when it applies, and where it is already satisfied

Section 116's hoist produced the first byte gain in 21 rounds, so round 226 tested how far it
generalises. The selection rule matters more than the lever itself:

**It applies only to pure computation with no call between the reference's computation point and
first use.** Section 109 is the counter-example: hoisting a `memset` *call* on `gm_AllocSpieler`
cost 371 matched bytes, because a call clobbers the very register the reference is keeping live.
So the test is not "does the reference compute this earlier" but "does the reference commit a
**callee-saved register** to it early, across code that does not clobber it".

Surveying the remaining rows for candidates, most are already satisfied:

- **`srv_LoadBuf`** (0x1000a570): the reference parks the connection table base in `ebp` at
  0x1000a57c: `mov ebp,0x101deb00`, five instructions in, and uses it throughout
  (`test byte ptr [ebp],1`, `mov eax,[ebp]`, `mov cl,[ebp+0x18]`). **Our source already computes
  it at the same point**, in a `for`-initialiser:
  `for (i = 0, conn = (unsigned int*) 0x101deb00; ...)`. Candidate dead, and the row is at
  701/750 with only 49 residual bytes.
- **`cm_ExProdObjekt`** (0x1000e140): the only early callee-saved load is
  `mov ebp,[esp+0x1c]` at +0xa, which is ordinary parameter homing, not a hoistable computation.
  At 976/993, 17 bytes off.
- **`gm_ObjectsAvailble`** (0x10015f70): the prologue is a stack-array initialisation
  (`mov dword ptr [esp+0x18],0x92` …), with no register commitment to hoist toward.

That is the useful negative: **the lever is not a general-purpose sweep**. It fired on
`CrashDumpUnhandledExceptionFilter` because that function computes a context value *after* a
long block the reference spans with a committed register: an unusually large gap, created by the
stack-walk setup sitting ~110 lines from its first use. Rows whose values are computed near their
use, or homed in the prologue, have nothing to move.

Practical rule for the next reader: before proposing a hoist, check three things in order:
(1) the reference commits a **callee-saved** register, not a scratch one; (2) the span between
computation and first use contains **no call**; (3) our source actually computes it **later**
than the reference does. If any fails, the candidate is dead and costs a compile to prove it.

### The `gm_AllocSpieler` near-miss, settled at the link

One candidate passed all three tests and still lost, and it is worth recording because the
object rulers said the opposite. The reference commits `arg4` to `edi` at 0x10018990 and first
uses it at 0x100189c4: 13 instructions, **zero calls between**, a textbook shape. Hoisting
`*(unsigned short*)(slot+0xa) = (unsigned short) arg4;` to sit directly after `slot[8] = 0x64;`
**reproduces the reference's instruction sequence exactly**: our object then emits
`mov word ptr [ebp+0xa],di` immediately after `mov byte ptr [ebp+8],0x64`, as the reference does.

Pursuing the neighbouring statements made the local block progressively more reference-like, and
the two object rulers moved in **opposite directions**:

| variant | match_count | aligned | obj |
|---|---|---|---|
| baseline | **1004** | 662/1056 | 3689 |
| + `slot[0xa]` hoist | 962 | 663 | 3689 |
| + `slot[0x20c]` sink | 961 | 664 | 3689 |
| + `slot[0x218]` hoist | 947 | **665** | 3689 |

`aligned` rises monotonically while `match_count` falls, with `obj_size` pinned: section 19/16
in its purest form. That made the candidate genuinely ambiguous at object level: structurally
correct, byte-neutral in size, and plausibly a link win masked by positional scoring.

**Measured at the link, it is a clear loss: residue 8,652 → 8,694, forty-two bytes worse.**
Reverted. So the anti-correlation was not hiding value: the moves shift byte offsets upstream
of a large unmatched region and the displacement costs more downstream than the local agreement
wins. **When `match_count` and `aligned` disagree, link and find out; do not reason about which
ruler deserves trust.**

Also dead on the same row, and it confirms an existing note generalises: hoisting the
`0x100a8c30` global load through a new `unsigned char* type_base` local produced
**byte-identical output**: 1004/3689, aligned 662, emitted instructions unchanged. msvc6 folds
the local away entirely, exactly as section 109 (round 216) found for the `lea` split.

## 119. `linktest.sh` already existed: the gap was that nobody was told

Section 118 ended on a rule: when the object rulers disagree, link and find out. That rule is
only actionable if linking a candidate is cheap, and every probe lane this session ran
object-only because a link measurement looked like a manual rebuild-relink-measure cycle.

**It is not. `scripts/linktest.sh` has done this all along**, and it is better than the manual
cycle because it recompiles with the exact command `build.make` records (so the flags cannot
drift) then relinks, applies postlink, and prints a per-function delta:

```
$ bash scripts/linktest.sh src/Develop/DieGildeAddOn/game/spiel_c/gm_AllocSpieler.c
function                                  before   after   delta
gm_AllocSpieler                             2824    2866     +42  <-- worse
.text total 8652 -> 8694  (+42)
revert candidates: gm_AllocSpieler (+42)
```

Verified both directions this round: **+0 on an unmodified file**, and **+42 attributed to the
right function** when section 118's known-bad hoist is re-applied as a control.

Two reasons it went unused, both now fixed:

- **It was absent from `AGENTS.md`**, the file every agent reads first, and mentioned only in
  passing several thousand lines into `docs/TODO.md`. It is now documented in the Linking
  section next to `gate.sh`, with the worked example above and the reason it matters.
- **Its baseline snapshot was stale**: `.scratch/residue_base.log` contained a 183-byte
  *error message* from a previous run ("split_poc.dll is older than 1 source file") rather than
  a residue table, so the delta report had nothing to compare against. Re-snapshotted with
  `.venv/bin/python scripts/postlink_residual.py --write build/server.dll > .scratch/residue_base.log`.

The general lesson is worth more than the tool: **a capability nobody knows about is
indistinguishable from a missing one**. Three rounds of this session built or hand-rolled
measurement that already existed: the call inventory in section 112 was a genuine gap, but this
was not. Before building a measurement, grep `scripts/` and read the header comments; they carry
the rationale for why each one exists.

## 120. Two dead ends on `gm_AllocSpieler`, and a caution about shared-worktree probing

Round 228 ran the first link-judged lane on `gm_AllocSpieler` (2,824 residual bytes, 33% of the
tree). No win; two shapes are now measured and closed.

**The `work` buffer size is not a free knob.** Our source declares `char work[0x3fc]`, and the
reference's frame is `sub esp,0x41c`. Rounding the buffer to `0x400` does bring the emitted
frame to the reference's value, but it costs **+341 bytes at the link**. Matching the frame
size is not the same as matching the code that uses it: every `[esp+X]` displacement in the
function shifts, and the positional compare loses far more downstream than the prologue gains.
This is the same trap section 81 recorded for the `0x284`/`0x280` question, now confirmed from
the opposite direction: *making* the frame match is as costly as leaving it wrong.

**`double` → `float` on the trait interpolation is also a loss.** Changing
`(double) *(unsigned short*)(slot + 0xa)` to `(float)` in the comparison and the loop bound was
measured in the same probe: still **+341**. The x87 sequence the reference emits is not reached
by narrowing the C type here.

**The process caution is the more useful output.** This lane ran in a worktree shared with the
coordinator, and its intermediate states were visible as ordinary uncommitted edits. Measuring
"the baseline" while it worked produced **+345, then +18, then +5, then +341** on successive
runs of the same command against a nominally clean tree: because the source and the compiled
object were moving underneath. Two rules follow:

- **`git status` clean does not mean the build is at baseline.** `linktest.sh` recompiles the
  named file, but the rest of the object tree can still carry another lane's probe. Confirm a
  baseline by seeing `+0`, not by seeing an empty `git status`.
- **A number measured while another lane is mid-probe is worthless.** If the same command gives
  different answers on consecutive runs, stop measuring and settle the tree first.

Both were resolved by interrupting the lane, reverting with `git checkout HEAD -- <file>`, and
re-measuring until `linktest.sh` reported `8652 -> 8652 (+0)`.

## 121. `cm_ExSellObjekt`'s one-byte gap is a zero-extension, and the cast is load-bearing

`cm_ExSellObjekt` (0x1000d930) has the smallest object-size gap in the tree: **obj 2056 against
the reference's 2057, one byte**, with instruction counts equal at 667. That combination says
exactly one instruction differs in encoding, so round 229 chased it.

The streams agree through index 192. At **+0x236** the reference has:

```
0x1000db66  8a461e        mov al, byte ptr [esi+0x1e]     <- 3 bytes
0x1000db69  8b8d78010000  mov ecx, dword ptr [ebp+0x178]
0x1000db6f  50            push eax
0x1000db70  51            push ecx
0x1000db71  e84abb0000    call gm_QueryEntitySum
```

and we emit:

```
+0x236  mov ecx, dword ptr [ebp+0x178]
+0x23c  xor eax, eax                    <- the extra instruction
+0x23e  mov al, byte ptr [esi+0x1e]
+0x241  push eax
+0x242  push ecx
```

So it is not a shorter encoding of the same instruction: **we emit an extra `xor eax,eax`** to
zero-extend the byte, and the reference does not: it pushes `eax` with its upper bits
undisturbed, i.e. the callee's second argument is effectively don't-care above the low byte.
The reference also loads the byte *first* and the dword second; we do the reverse.

Two shapes tested against that reading, both measured at the link and both rejected:

| shape | link delta |
|---|---|
| narrow the prototype to `gm_QueryEntitySum(int, unsigned char)` | **+36** |
| drop the `(unsigned char)` cast at all four call sites | **+448** |

The second is the informative one. Dropping the cast is what "the reference doesn't zero-extend"
naively suggests, and it is **catastrophically worse**: the cast is load-bearing and correct.
A temporary local to force the reference's argument-evaluation order was also tried and lost
(object 680/2062, obj +6).

**What this actually means.** The reference's `xor`-free sequence is not reachable by changing
the *type* of the argument; msvc6 emits the zero-extension because the C value genuinely is a
narrowed byte, and every spelling that keeps that meaning emits it. The reference's form implies
its source did **not** narrow at the call site: the byte was already in a register as a full
word from an earlier operation, which is a property of the surrounding code, not of this
expression.

Recorded because the one-byte gap makes this row look like the cheapest win in the tree and it
is not: **three shapes, +36 / +448 / object-worse, all reverted.** Also worth noting for the
next reader, the header declares `gm_QueryEntitySum(int, int)` while the definition in
`spiel622.c` is `(int, unsigned int)`: a real inconsistency, but narrowing the declaration to
match the use measured worse, so it is documented rather than "fixed".

## 122. Bounding a missing byte with a jump displacement

`ls_LoadBuildingEntityState` (0x100128f0) is 3 bytes short (obj 1460 against 1463) and its first
non-relocation divergence is very early, at **+0x3c**. Early faults displace everything after
them, so it looked like the highest-leverage target left. It is worth recording how the search
was narrowed, because the technique is reusable and cost nothing.

**The first divergence is not a fault: it is a readout.** At +0x3c the only differing bytes are
inside a `jle` displacement: reference `0x4ba`, ours `0x4b8`. Both sides emit the same
instruction; only the target differs. That immediately gives an arithmetic bound:

```
ref  jle -> +0x4fe        ours jle -> +0x4fc
=> between +0x44 and +0x4fe we emit exactly 2 bytes fewer
=> the third missing byte is somewhere after +0x4fe
```

So a two-byte window was located without disassembling anything, purely from a branch
displacement (the same principle as section 95: a `jcc` width or target is a *measurement* of
downstream layout, never a defect in itself).

Walking that window in lockstep shows the streams desync at **+0x2af**, in a repeated
`ls_ReadVfsDataChecked` call pattern. The reference computes the address in two steps,
interleaved among the argument pushes:

```
0x10012b9f  8b5671    mov edx,[esi+0x71]
0x10012ba2  8bcb      mov ecx,ebx            <- load_result
0x10012ba4  57        push edi
0x10012ba5  6a01      push 1
0x10012ba7  03ca      add ecx,edx            <- second step, between the pushes
0x10012ba9  6a04      push 4
0x10012bab  51        push ecx
```

We fold the same expression into a single `lea`, which is shorter: that is where the two bytes
go.

Two shapes tested at the link, both rejected:

| shape | link delta |
|---|---|
| reorder the address expression to `load_result + field + off` | **+0** (byte-identical) |
| split it through an `int field_addr` local, two statements | **+52** |

The `+0` is the more interesting one: **msvc6 canonicalises the addition order**, so writing the
operands in the reference's order changes nothing: the same normalisation section 92 found for
commuted multiplies and section 107 for a double-negated comparison. And forcing the two-step
form through a local *defeats* the reference's scheduling rather than reproducing it, because
the local pins the value where the reference keeps it in flight between pushes.

That leaves the `lea`-vs-`add` split as another instance of the pattern in sections 109 and 120:
**the reference's instruction sequence is a scheduling outcome, and C can request the operations
but not their interleaving with the argument pushes.**

Existing prior art on this row, worth not re-deriving: the eight field reads are already spelled
`*(volatile int*)(esi + 0x71)`: one of the rare places where `volatile` *won* (section 94 records
it losing 4 of 4 elsewhere), because it forces the reference's per-call reload instead of a
cached register.

## 123. `drift_windows.py`: localise a byte fault without reading the bytes

Section 122 bounded a missing byte using a single jump displacement. That technique is
mechanical, so round 231 scripted it as `scripts/drift_windows.py`, and scripted, it is far
sharper than the manual version, because **nested windows subtract**.

The rule: a jump whose *encoding* matches the reference but whose *target* differs is not a
defect, it is a measurement. The target difference is exactly the byte drift accumulated between
the jump and its target, so every aligned pair yields a window `[jump, target)` with a signed
byte count: for free, without disassembling the window's contents.

```
python3 scripts/probe_function.py --va <va> --file <src>     # builds the object
python3 scripts/drift_windows.py <va> <size> build/objtest/probe_*.obj
```

Two filters matter and are built in: `call` targets are unresolved relocations in our object, so
they are pure noise and are excluded; and a jump target outside the function is a tail-call, not
a layout signal.

**Validation: it rediscovered a known finding unaided.** On `cm_ExSellObjekt` three windows
converge:

```
[0x49, 0x249)  +2      [0x230, 0x249)  +2      [0x234, 0x249)  +2
```

The surplus is inside the smallest, `[0x234, 0x249)`: **21 bytes**, which is exactly the
`xor eax,eax` that section 121 found at +0x236 by hand. The script located it from branch
targets alone.

**Nested subtraction, on `ls_LoadBuildingEntityState`:**

```
[0x3a,  0x4fa)  -2        [0x292, 0x3b6)  +2        [0x543, 0x5aa)  -3
```

The outer window is 2 bytes short while an inner window is 2 bytes long, so the shortfall lives
in `[0x3a,0x292)` or `[0x3b6,0x4fa)` and there is a *separate* surplus inside `[0x292,0x3b6)`.
**Two independent faults, separated without reading an instruction**: section 122 saw only the
outer window and therefore only one of them.

**A new lead on the biggest row.** `gm_AllocSpieler` shows `[0x4c3, 0x4d6)` drifting **+1 in 19
bytes**. Disassembling just those bytes shows we emit an extra 2-byte `jmp 0x4d7` that the
reference does not have: our `if (arg7) … else if (arg6) …` chain enters the shared
`slot[9] = (char) n;` store by branching over the second arm, where the reference falls into it.
Rewriting the chain as two independent `if`s (with `arg7 == 0 &&` guarding the second) measured
**+0 at the link**: msvc6 canonicalises the control flow straight back, the same normalisation
as sections 92, 107 and 122.

So the extra jump is real and localised, but not reachable by restructuring the conditional.
The window is recorded for whoever attacks that row next: **19 bytes, one surplus byte, at
+0x4c3**.

## 124. Drift sweep across the remaining rows, and a build-state trap

Round 232 ran `scripts/drift_windows.py` (section 123) across the rows it had not seen. The
useful output is a set of localised windows for future work:

| function | window | drift |
|---|---|---|
| `cm_ExCopyEntityData` | `[0x130, 0x165)` | **-9** |
| `cm_ExCopyEntityData` | `[0x152, 0x15d)` | **-4** → so ~5 bytes short in `[0x130, 0x152)` |
| `CrashDumpUnhandledExceptionFilter` | `[0x11c, 0x679)` | -9 |
| `ServerMainThread` | `[0x406, 0x55c)` | +1 |
| `gv_ExAllocGraveyardWorker` | `[0x128, 0x187)` | -156 |

**The `cm_ExCopyEntityData` window resolved to a known shape.** Disassembling the 34 bytes shows
our stream is byte-identical to the reference through +0x152; the shortfall is the *clamp*. The
reference emits **both arms inline** with a shared store:

```
0x1000ed4d  jle  0x1000ed56
0x1000ed4f  cmp  eax, 0x7f
...
0x1000ed56  b881ffffff  mov eax, 0xffffff81     <- low arm, inline
0x1000ed5b  eb05        jmp 0x1000ed62
0x1000ed5d  b87f000000  mov eax, 0x7f           <- high arm, inline
0x1000ed62  88040a      mov byte ptr [edx+ecx], al
```

We branch away to an out-of-line low-clamp instead, which is 9 bytes shorter. Two spellings were
measured at the link and both rejected: rewriting it as the reference's two-arm
`if (val <= -0x7f) … else if (val >= 0x7f)` costs **+3**, and swapping the arms while keeping the
in-range guard costs **+76,125**: that second one changed the semantics, and the damage spread
across thirteen functions, which is exactly what a semantic break looks like in this metric.

**The build-state trap is the more important finding.** After reverting that bad edit, a clean
source tree still measured 57.7% residue, and a full `find -name '*.obj' -delete` plus rebuild
did not fix it. The give-away was in `split_link.sh`'s own output:

```
placed split symbols: 319
exactly at their reference VA: 0        <- should be 246
```

The stale artefact was **`build/split_poc/`**, the split-link workspace: deleting the CMake
objects orphans it, and it is not regenerated on its own. `rm -rf build/split_poc` followed by
`scripts/split_link.sh` restored `exactly at their reference VA: 246` and residue 8,652
immediately.

So the recovery procedure, in order, when residue is wildly wrong and the source is clean:
**(1)** check `git status`; **(2)** rebuild objects; **(3)** check `exactly at their reference
VA` in the link log, if it is 0, **`rm -rf build/split_poc`** and relink. Step 3 is the one that
is easy to miss, because every other signal points at the source.

## 125. Guarding the composition collapse

Section 124 recorded a failure mode that cost most of a round: the split link places each object
at its reference VA, and when that collapses **every residue number is meaningless while nothing
says so**. The residue simply reads ten times too high, and every other signal (clean
`git status`, clean rebuild, zero compile errors) points at the source.

The only evidence is one line in `split_link.sh`'s output:

```
placed split symbols: 319
exactly at their reference VA: 0        <- should be 246
```

Round 233 turned that into a guard. `scripts/linktest.sh` now parses the line after linking and
refuses to report anything if fewer than 100 symbols landed:

```
COMPOSITION COLLAPSED: only 0 symbols landed at their reference VA.
         Every residue number below would be meaningless.  Fix with:
             rm -rf build/split_poc && bash scripts/split_link.sh
```

Verified both directions: it passes at the real value (246) and trips on a collapsed log (0).

This is the third guard on that script, and the set is worth reading together because each was
added after a specific round was lost to the failure it catches:

| guard | catches | cost when missing |
|---|---|---|
| stale-object | a source newer than its object (a revert without recompiling) | round 195 |
| attribution | a `.c` modified but not named in the run | round 179 committed a "-58" that re-measured "+56" |
| **composition** | the split workspace orphaned by an object delete | round 232 |

The general point, and the reason to keep adding them: **a measurement harness needs guards
against its own stale state more than against bad input.** Every one of these three produced
confident, plausible, completely wrong numbers, and in each case the tree looked clean.

## 126. `ServerMainThread`'s +3 window: a rematerialised constant the reference carries in a register

The drift sweep (section 123) gives `ServerMainThread` four nested windows, and subtracting them
is what makes the lead usable:

```
[0x406, 0x55c)  +1        [0x438, 0x510)  +2
[0x3c5, 0x487)  +3        [0x443, 0x498)  +3   <- 85 bytes, the tightest
```

The outer window is only **+1** while the inner one is **+3**, so there is a **-2** elsewhere in
`[0x406,0x55c)`: two faults of opposite sign, again separated without reading a byte.

Disassembling the tight window shows the surplus exactly. We emit:

```
+0x0454  8B  mov dword ptr [esp+0x14], 0xffffffff     <- 8 bytes
```

where the reference emits:

```
0x100097fb  4B  mov dword ptr [esp+0x1c], eax          <- 4 bytes
```

The reference already has the value in `eax`: four instructions earlier it loads
`mov eax,[ebx]` and tests `cmp eax,-1`, so on the equal path `eax` *is* -1 and it reuses the
compared value as the stored value. We rematerialise the constant instead.

**The source already expresses this correctly**: it stores `sent_bytes`, the same variable the
`if` compared:

```c
sent_bytes = *(volatile unsigned int*) transfer_progress;
if (sent_bytes == 0xffffffff) {
        ...
        *(volatile unsigned int*) (cmd_buffer_primary + 4) = sent_bytes;
```

so the divergence is not a missing idiom but a `volatile` interaction. Two probes settle which
side matters:

| change | link delta |
|---|---|
| drop `volatile` on the **store** | **+4** |
| drop `volatile` on the **read** (line 481 only) | **+0**, byte-identical |

So the store's `volatile` is **load-bearing**: it is what forces the value to memory in the
reference's shape, while the read's `volatile` at that site is **inert**. That is a useful
asymmetry to record, because section 94 treats `volatile` as a single lever that loses 4 times
out of 4, and the row-level exception noted in section 122 (`ls_LoadBuildingEntityState`, where
`volatile` won) is likewise a *read*. The rule is finer than "volatile loses": **a `volatile`
read can be inert or load-bearing depending on whether the reference reloads; a `volatile` store
is load-bearing wherever the reference writes through.**

The rematerialised constant itself is not reachable from source here: msvc6 chooses whether to
reuse the compared register or re-emit the immediate, and both C spellings that express the
intent compile to the same bytes.

## 127. Guarding the silent no-op, and locating `ServerMainThread`'s -2

Round 234 nearly closed a live lead on a false negative: a probe's edit silently failed to apply
(its target line occurred twice in the file, so the guarded replace refused), the run printed
**`+0`**, and a byte-neutral result reads exactly like "harmless, move on". Nothing in the output
distinguished *"this change is byte-neutral"* from *"there was no change"*.

`scripts/linktest.sh` now checks each named file against HEAD before measuring:

```
NOTE: identical to HEAD, so any delta below is the BASELINE, not a result:
        src/Develop/DieGildeAddOnServer/server_c/ServerMainThread.c
      (did the edit apply?  check with: git diff --stat -- <file>)
```

Verified both directions: the note appears for an unmodified file and is **absent** when a real
edit is in place: including when that edit measures `+0`, which is the case that matters.

**It paid immediately.** Chasing the `-2` that section 126's subtraction proved must exist,
narrowing by overlap gives:

```
[0x406,0x55c) = +1   outer          [0x443,0x498) = +3   (section 126's surplus)
[0x438,0x510) = +2                  => the -2 lies in [0x498, 0x510)
```

Disassembling those 120 bytes shows it:

```
reference  0x10009838  mov ecx,[0x101deae8]     lea esi,[eax+ecx]      (6 + 3)
ours       +0x049b     mov esi,[0x101deae8]     add esi,eax            (6 + 2)
```

The reference loads into `ecx` and forms the sum into a **third** register with `lea`; we load
into `esi` and accumulate in place. This is the `lea`-versus-`add` fold of section 122 running in
the *opposite* direction: there the reference used two-step `add` where we folded into `lea`,
here it uses `lea` where we use `add`. **Neither form is "the msvc6 way"; both appear in the same
binary, chosen by which registers are live.**

Splitting the C into `payload_base = (char*) *(void**) 0x101deae8;` then
`payload_src = (unsigned int*) (payload_base + sent_bytes);` measured **+0**, and the absent
no-op note confirms the edit really applied, so this is a genuine canonicalisation, not a failed
probe. Same result as section 122's local, and the same reason: msvc6 folds the two statements
back together.

Recorded for the next reader: the reference **does** materialise `0xffffffff` in eight bytes at
0x10009858 on this sibling path, which is the very instruction section 126 identified as *our*
surplus 90 bytes earlier. The same constant is worth eight bytes in one place and four in
another, purely by whether a compared register survives: more evidence that the choice is
allocator state, not source shape.

## 128. `drift_windows.py` was wrong on backward jumps

The drift tool (section 123) assumed every jump runs forward, so it printed a window of
`[jump, target)` and took the raw target difference as the drift. For a **backward** jump that is
wrong in both halves: the measured span is `[target, jump)`, and the sign is inverted: if our
backward target sits 2 bytes earlier than the reference's, the code between target and jump
**grew** by 2, it did not shrink.

On `ahm_ExAllocAlchemist` both of its windows are backward, so both were reported inside out:

```
before:  drift -2 bytes in [0x1de, 0x1c7)      <- a negative-width window, visibly wrong
after:   drift +2 bytes in [0x1c7, 0x1de)  (backward)
```

The give-away was the negative width, which is worth watching for in any such tool. Fixed, with
forward windows re-checked against section 126's known values (`[0x406,0x55c) +1`,
`[0x443,0x498) +3`) to confirm the change was surgical.

**What the corrected window shows.** The 23-byte span is a loop, and the difference is loop
*shape*:

```
reference   body … inc edi ; cmp edi,5 ; jl back            <- bottom-tested, ONE branch
ours        cmp edi,5 ; jge out ; body … inc edi ; jmp back <- top-tested, TWO branches
```

Our source spells it `while (1) { if (!(i < 5)) break; … }`. The reference's form is a plain
`do/while`, and that is a genuine source-level lever rather than one of the canonicalised shapes
in sections 122, 126 and 127.

**It still loses: +439 at the link.** The file's own header already warned that "a do-while here
cascades: 998 obj / 285 match", but that was measured at *object* level, before `linktest.sh`
existed, so the link number is new information and it is far worse than the object figure
suggested. The loop shape is correct in isolation and the register allocation it forces is not.

Worth stating as a rule, since three sections now point the same way: **matching the reference's
local shape is not the objective: matching its bytes is.** A construct can be demonstrably the
one the original used and still be the wrong thing to write, because the surrounding allocation
was produced by code we have not matched yet.

## 129. Re-sweep after the backward-jump fix, and why the Graveyard reload cannot be cached

Section 128 fixed `drift_windows.py`'s handling of backward jumps, which meant every earlier
sweep had to be re-run: a misreported window is worse than no window. Re-sweeping the rows
covered in sections 123 and 124 turned up **one** window that had been hidden:
`gv_ExAllocGraveyardWorker`, `[0x337, 0x395)`, **+5 bytes in 94**. The other rows' backward jumps
either did not exist or landed on the same targets already reported.

That is a useful calibration of the bug's blast radius: it distorted one row's reporting, not
all of them.

**What the window shows.** The reference reads a 16-bit id with a zero-extending pair:

```
0x10011f27  33c9        xor ecx,ecx
0x10011f2b  668b4d00    mov cx,word ptr [ebp]      <- 6 bytes total
```

and we emit:

```
+0x0332  4B  mov si,word ptr [ebp]
+0x0336  6B  and esi,0xffff                        <- 10 bytes total
```

The file's own header already names this gap ("target `xor ecx,ecx; mov cx,[ebp]`, ours
`mov si,[ebp]; and esi,0xffff`") and lists a long series of attempts against it. Two shapes it
does **not** list were measured this round:

| shape | link delta |
|---|---|
| hoist the id into an `unsigned short gid` local, used by both sites | **+117** |
| narrow only the accumulator (`int a` → `unsigned int a`), keeping both reloads | **+0** |

The **+117** is the informative one, and it explains why this gap is hard: the reference reads
`word ptr [ebp]` **twice**, once per use, and caching it in a local is exactly what a reader
"tidying" the code would do. That CSE removes the second reload and costs 117 bytes. The two
`*(volatile unsigned short*)` reads in the source are there precisely to defeat that, and
section 126's rule applies: this is a **volatile read that is load-bearing**, because the
reference genuinely reloads.

The `+0` confirms once more that a type narrowing which does not change what is loaded is
canonicalised away (sections 122, 126, 127).

So the 4-byte-per-read gap stays open, with its cause now stated precisely: **msvc6 chooses
`and reg,0xffff` over `xor`+`mov r16` for a 16-bit read into a register it is already using for
the accumulator.** The reference's form needs a *free* register at that point, which is an
allocation state we do not reach: the same conclusion as sections 109, 120 and 128, reached
from a different direction.

## 130. The register-pressure cascade is one row's fact, not the tree's

Sections 109, 120, 128 and 129 each closed a lead by attributing it to allocation state, and the
phrase that recurs is that we commit more callee-saved registers than the reference, so its
instruction forms are unreachable. Round 238 tested that directly, by comparing prologues rather
than reasoning from downstream symptoms.

| function | reference prologue | ours | claim |
|---|---|---|---|
| `CrashDumpUnhandledExceptionFilter` | `sub esp,0x280`, pushes `ebp esi` (**2**) | `sub esp,0x284`, pushes `ebx ebp esi` (**3**) | **true** |
| `gv_ExAllocGraveyardWorker` | `sub esp,0x10`, `ebx ebp esi`, `edi` deferred to +0x0a | **byte-identical** | false |
| `cm_ExCopyEntityData` | `sub esp,0xc`, `ebx ebp esi edi` | identical for 17 bytes | false |
| `ahm_ExAllocAlchemist` | n/a | identical for 23 bytes | false |

**Only `CrashDumpUnhandledExceptionFilter` actually commits a different register set.** On the
other three the prologues match byte for byte: same registers, same frame, and on the Graveyard
row even the same deferral of `edi` to +0x0a, which is a distinctive choice and a strong sign the
allocator is in the same state we are.

So section 81's frame rule is real but **local**: it is a fact about one function, and it was
generalised into a tree-wide explanation. That matters for planning, because "the allocator is in
a different state" is unfalsifiable at the point where it gets invoked, and it was being used to
close leads on rows where the allocator demonstrably is *not* in a different state.

The findings themselves stand: the `lea`/`add` fold (sections 122, 127), the zero-extend form
(section 129), the loop shape (section 128) are all still measured losses. What changes is the
*reason*: on those rows the divergence is a **local instruction-selection choice made from the
same register state**, not a downstream consequence of a different prologue. That is a narrower
and more hopeful conclusion, because instruction selection is driven by the expression shape
reaching the selector, which is a source-level property: it simply has not been found yet.

Method note worth keeping: **check the prologue before invoking allocation state.** It costs one
`rebrew binary asm show` and one probe disassembly, and it distinguishes a real cascade from a convenient
explanation.

## 131. The Graveyard zero-extend is closed: four spellings, none reaches `xor`+`mov r16`

Superseded for this function by section 201: under plain `/O2` the reference zero-extend comes out
unchanged.

Section 130 narrowed these divergences from "allocator cascade" to "local instruction-selection
choice made from the same register state", which implies a source-level lever must exist.
Round 239 tested that implication on the sharpest case: `gv_ExAllocGraveyardWorker`'s 16-bit
read, where the reference uses 6 bytes and we use 10:

```
reference  0x10011f27  33c9      xor ecx,ecx
           0x10011f2b  668b4d00  mov cx,word ptr [ebp]
           0x10011f2f  8d3c31    lea edi,[ecx+esi]
ours       +0x0332     mov si,word ptr [ebp]
           +0x0336     and esi,0xffff
```

Reading the reference in context (re-anchored, after `rebrew binary asm show` mid-instruction output
produced convincing garbage, section 112's rule) shows `xor esi,esi` initialising the loop
counter, so `lea edi,[ecx+esi]` sums *id + counter* into a third register.

Four distinct source spellings have now been measured against it:

| spelling | link delta |
|---|---|
| operand order `id + n`, matching `lea [ecx+esi]` | **+0** |
| explicit `(unsigned int)` widening on the read | **+0** |
| cache the id in an `unsigned short` local (round 237) | **+117** |
| narrow the accumulator type only (round 237) | **+0** |

Three are canonicalised away and the fourth is a large loss. **The reference's form is not
reachable from this expression by any spelling tried**, which is now a measured statement rather
than an appeal to allocator state.

What distinguishes the two forms is which register receives the widened value: `xor`+`mov r16`
needs a register that is *dead* at that point, while `and reg,0xffff` widens in place. Both
compile from the same C; msvc6 picks by what is free. Since section 130 established the register
state here is identical to the reference's, the remaining difference must come from **what else
is live across the read**, i.e. from code outside this expression, which is why editing the
expression cannot move it.

The practical rule, and the reason to record a closed lead in full: **when three or more distinct
spellings of the same intent all canonicalise to identical bytes, the lever is not in that
expression.** Stop rewriting it and look at what surrounds it. Sections 122, 126, 127 and 129 all
ended the same way, and naming the pattern is cheaper than rediscovering it a fifth time.

## 132. What surrounds the Graveyard read: an addressing-mode choice, also not source-selectable

Superseded by section 201: the addressing matches under plain `/O2`.

Section 131 closed the read itself and pointed at the surrounding code, since that is what decides
which register is free. Round 240 looked, and found the answer: it is the **addressing mode of
the two stores**, not anything about the read:

```
reference   0x10011f2f  8d3c31          lea edi,[ecx+esi]              <- edi = INDEX only
            0x10011f39  889fe0d81410    mov byte ptr [edi+0x1014d8e0], bl
            0x10011f3f  888720980a10    mov byte ptr [edi+0x100a9820], al

ours        +0x033e     add esi,edi                                    <- esi = FULL ADDRESS
            +0x0347     mov byte ptr [esi], bl
            +0x034d     mov byte ptr [esi], al
```

The reference keeps the array base as a **constant displacement** in each store and carries only
`id + counter` in a register. We fold the base into the pointer, so our register holds a complete
address that must stay live across the `gm_RandomMod` call, and that is precisely why the
widened read has nowhere to go but back into `esi`, forcing `and esi,0xffff` instead of
`xor`+`mov cx`.

So the chain is now fully explained: **addressing mode → register occupancy → zero-extend form**,
and the 4-byte-per-read gap of section 129 is a consequence, not a cause.

Two more spellings were measured against it, both aimed at the addressing rather than the read:

| spelling | link delta |
|---|---|
| stores written as `*(char*)(0x1014d8e0 + a)`: explicit base + index | **+0** |
| narrowed store-value cast `(char)(random_value - 0x20)` | **+0** |

Both canonicalise. **That makes six distinct spellings measured on this one row** (four in
sections 129 and 131, two here), five byte-identical and one a 117-byte loss.

The conclusion is sharper than "not source-reachable": msvc6 chose to materialise the array base
into the pointer, and **no way of writing the C changes that decision**: `extern char[]` indexed
by a variable, an explicit absolute-address cast, and a base-plus-index cast all emit the same
bytes. The choice is made by the code generator from the *whole loop's* pressure, and the only
remaining lever would be changing what else the loop keeps live, which is the loop body's real
work and cannot be removed.

**This row is now closed with a complete mechanism** rather than an open lead: worth more than
leaving it on the list, because the next reader would otherwise re-derive the same six probes.

## 133. The `[reg + absolute]` pattern is common, but its cost is not

Section 132 explained the Graveyard row through an addressing-mode difference: the reference
keeps an array base as a constant displacement inside each store, while we fold it into the
pointer, which pins a live address across a call and forces the wider zero-extend form. The
obvious next question is whether that generalises, so round 241 counted it.

The reference uses `[reg + absolute]` addressing widely: 14 such store sites in
`cm_ExCopyEntityData`, 8 in `ahm_ExAllocAlchemist`, 12 in `gm_AllocSpieler`. So the *pattern* is
not special to the Graveyard loop.

**But the pattern's cost is.** Two checks say so:

- Our objects carry 19 `DIR32` relocations in `ahm_ExAllocAlchemist`: i.e. we materialise
  absolute addresses in comparable quantity. We are not systematically folding bases where the
  reference does not.
- `ahm_ExAllocAlchemist`'s drift windows are **unchanged** from section 128 (`[0x1c7,0x1de)` +2,
  `[0x254,0x2b0)` -2). If the addressing choice were costing bytes there, the windows would have
  moved when section 132's mechanism was understood: they did not.

So the Graveyard case is specific: it needs an addressing choice **and** a call inside the loop
**and** a 16-bit read competing for the same register. Remove any one and the pattern is free.
That is the same shape of conclusion as section 130: a real mechanism, correctly identified, but
local rather than tree-wide.

**Two counting traps, both hit this round and worth avoiding:**

- `rebrew binary asm show | grep -c "0x1[0-9a-f]{7}"` counts the **address column**, so every instruction
  matches and the answer is meaningless (286 for a 1002-byte function). Strip the leading
  `VA:` field first: the honest count was 64.
- Even then, a reference "absolute operand" count is not comparable to our `DIR32` relocation
  count: the reference's includes IAT slots and jump-table entries that never become relocations
  in an object. **Compare like for like, or compare drift windows instead**: the windows are
  already normalised against the reference.

Recorded as a closed question rather than an open lead: the addressing pattern is real, it is
understood, and outside the Graveyard loop it costs nothing.

## 134. The zero-extend gap is not caused by addressing: a controlled comparison

Round 237's re-sweep after the backward-jump fix skipped the two largest rows. Round 242 covered
them, and `gm_AllocSpieler` had a hidden backward window: `[0x8ac, 0x900)`, **+5 bytes in 84**:
the sharpest lead on that function so far.

Disassembling it shows **the same idiom** as the Graveyard row (section 129):

```
reference  0x100190fc  33c9      xor ecx,ecx
           0x10019100  668b4d00  mov cx,word ptr [ebp]
           0x10019104  8d3c31    lea edi,[ecx+esi]
           0x1001910e            mov byte ptr [edi+0x1014d8e0], 0
ours       +0x08a7     mov si,word ptr [ebp]
           +0x08ab     and esi,0xffff
           +0x08b5     mov byte ptr [esi+0x1014d8e0], 0
```

**But one thing differs, and it is decisive.** Section 132 attributed the Graveyard gap to
addressing: we folded the array base into the pointer (`mov [esi], bl`), which pinned a live
address and denied the widened read a free register. **Here we already use the reference's
addressing**: `mov byte ptr [esi+0x1014d8e0], 0`, base as a constant displacement, exactly as
the reference does, **and the zero-extend gap is still there.**

That is a controlled comparison across two rows:

| row | our addressing | zero-extend gap |
|---|---|---|
| `gv_ExAllocGraveyardWorker` | base folded into pointer | 4 bytes per read |
| `gm_AllocSpieler` | **same as reference** | **still 5 bytes** |

**So section 132's mechanism was mis-attributed.** The addressing difference on the Graveyard row
is real, but it is not what produces the `and reg,0xffff` form: the form appears with and
without it. Section 133 already found the addressing pattern costs nothing elsewhere; this is the
stronger statement: it does not cause the gap it was invoked to explain.

Two shapes measured here, neither reaching it:

| shape | link delta |
|---|---|
| hoist the scaled counter into its own induction variable | **+442** |
| explicit `(unsigned int)` widening on the id read | **+0** |

That brings this idiom to **eight measured spellings across two rows**, all either canonicalised
or losses. The honest current statement is narrower than section 132's: **msvc6 emits
`and reg,0xffff` wherever the widened value's destination register is also its source, and no
tried C spelling separates them.** Why the reference's register is free remains unexplained: the
addressing hypothesis is now refuted, not confirmed.

Worth noting as method: this only surfaced because a **negative** result (section 133's "costs
nothing elsewhere") was followed up rather than filed. The row that disproved the mechanism is
the one where our code already does the right thing.

## 135. Why the reference's register is free: counter assignment, not pressure

Section 134 refuted the addressing explanation and left the real question open: *why* does the
reference have a free register for `xor ecx,ecx; mov cx,[ebp]` where we must reuse the
accumulator? Round 243 answered it by reading what holds each register entering the loop.

```
reference  0x100190e5  33db      xor ebx,ebx        <- counter 1
           0x100190ea  33f6      xor esi,esi        <- counter 2
           0x10019104  8d3c31    lea edi,[ecx+esi]  <- ecx is SCRATCH, edx likewise at 0x10019129
           0x10019136  81c600030000  add esi,0x300  \  two independent
           0x1001913c  43            inc ebx        /  induction variables

ours       +0x0893     xor ebx,ebx                  <- counter 1
           +0x0895     xor edi,edi                  <- counter 2  (edi, not esi)
           +0x08a7     mov si,word ptr [ebp]        <- esi is the only register left
           +0x08ab     and esi,0xffff
```

**Both sides keep the same number of values live.** The difference is *which* registers hold the
two loop counters: the reference puts them in `esi`/`ebx`, leaving `ecx` and `edx` free as widen
scratch; we put them in `edi`/`ebx`, leaving only `esi`, which is also where the widened value
must land, forcing `and esi,0xffff` instead of a zeroed scratch plus `mov r16`.

So the answer to section 134's question is **register assignment, not register pressure.** That
distinction matters: pressure would be unfixable without removing work, whereas assignment is
chosen by the allocator from the loop's shape, which is at least in principle source-visible.

It is not source-selectable in practice, though. The reference advances `esi += 0x300` and
`ebx++` as two independent induction variables, testing `esi` against `0x90000`, while our source
carries `j` and derives `j * 0x300`. Rewriting the loop to match exactly (an explicit
`colstep` induction variable stepping by `0x300` to `0x90000` with `j++` alongside) measures
**+0**: msvc6 derives the same induction variables either way and assigns the same registers.

That is now **nine measured spellings** on this idiom across two rows (sections 129, 131, 132,
134 and here), every one canonicalised or a loss. The mechanism is fully explained and the lever
is absent: **msvc6's counter-to-register assignment is not expressible in C**, and everything
downstream (the zero-extend form, the 4-to-5 byte gap per read) follows from it.

Recorded as a complete answer rather than an open question. The remaining value in this idiom is
zero, and knowing *why* is what prevents a tenth spelling.

## 136. A window where we are *shorter*, and why that constrains the whole function

Section 135 closed the zero-extend idiom, but `gm_AllocSpieler` has a second backward window that
had never been read: `[0x7a0, 0x7bf)`, **-53 bytes**. Its sign is the interesting part.

Per section 128's backward-jump semantics, a negative drift on a backward jump means the span is
**shorter on our side**: we emit 53 fewer bytes there than the reference. And since this object
is **size-exact** (`obj 3689` against `size 3689`), those bytes must reappear as surplus
elsewhere: the function is not uniformly too long or too short, it is redistributed.

Reading the span explains where the reference spends them:

```
reference   0x10019013  8b4c2418  mov ecx,[esp+0x18]      <- reload the base
            0x1001901a  8954b15c  mov [ecx+esi*4+0x5c],edx
            0x10019020  8b4c2418  mov ecx,[esp+0x18]      <- reload again
            0x1001902b  8b4c2418  mov ecx,[esp+0x18]      <- and again

ours        +0x07cf              mov [esi+edi*4+0x5c],ecx <- base live in esi, no reload
```

The reference **spills the array base and reloads it 12 times across the function** (4 bytes
each); we keep it in `esi` and never reload. Our code is genuinely shorter here, and correctly
so.

**This directly constrains section 135.** That section found the reference's counters in
`esi`/`ebx` where ours are in `edi`/`ebx`, leaving us no free register for the widened read. But
`esi` is exactly the register we are using to hold the base: the thing that makes *this* window
53 bytes shorter. Adopting the reference's assignment would free a register for the zero-extend
and simultaneously force the spill-and-reload pattern that costs it 48 bytes here.

So the two windows are **coupled and opposed**: the +5 zero-extend surplus and the -53 spill
shortfall are two consequences of one allocation choice, pulling in opposite directions. Neither
can be judged alone, which is why nine spellings aimed at the zero-extend all failed: each was
optimising one side of a trade the compiler makes globally.

The practical consequence is a rule for this function, and probably for others: **a window where
we are shorter than the reference is not a defect and must not be "fixed"**. It is evidence about
which register the allocator has free, and it bounds what any change to the opposing window can
achieve. Read both signs before attributing a cause: section 135's explanation is correct about
the mechanism and incomplete about the cost.

## 137. Reading window signs across the tree, and a surplus with no positive window

Section 136 established that a negative window is evidence rather than a defect. Round 245 applied
that reading to every row, and the sign distribution is itself informative:

| function | negative (we shorter) | positive (we longer) |
|---|---|---|
| `CrashDumpUnhandledExceptionFilter` | **6** | **0** |
| `cm_ExSellObjekt` | 0 | 6 |
| `gm_AllocSpieler` | 2 | 4 |
| `ls_LoadBuildingEntityState` | 2 | 2 |

`CrashDumpUnhandledExceptionFilter` is the striking case: **every measured window says we are
shorter**, yet the object is size-exact (2115 = 2115). Both cannot be true unless the balancing
surplus lies outside every window.

**Nested subtraction locates it without a positive window existing.** The windows are:

```
[0x490, 0x4d0)  -19   <- tightest, 64 bytes
[0x39f, 0x4d0)  -19   <- same value, wider
[0xda,  0x6b9)  -10   <- SMALLER magnitude than the inner one
```

An outer window whose drift is *smaller in magnitude* than an inner one proves a positive
contribution between them: `-19` inside plus roughly `+9` elsewhere gives the outer `-10`. So a
~9-byte surplus sits in `[0x4d0, 0x6b9)` **even though no positive window is reported there**:
the sign arithmetic finds what direct measurement missed.

**What the -19 is.** Reading the tight window shows the switch arms of section 114:

```
reference  push 0            (2 bytes)   x49 across the function
ours       push edi          (1 byte)    x37, edi holding a cached zero
```

We save a byte per site because msvc6 parked a zero in `edi`: precisely the behaviour sections
111 and 126 recorded, where a free register gets filled with a constant. Our arms are shorter,
and correctly so.

**This confirms section 136's coupling on a second, independent function.** Making the arms match
would require `edi` *not* to be free, which is the same global allocation trade seen on
`gm_AllocSpieler`: the shortfall and the surplus are two consequences of one register decision, so
neither is separately fixable. Two functions, same structure, reached from opposite directions.

Method worth keeping: **compare the magnitudes of nested windows, not just their signs.** An inner
window with larger |drift| than its enclosing window is a positive region hiding between them, and
that is the only way to see a surplus the tool cannot report directly.

## 138. Nested subtraction, automated

Section 137 derived a surplus by hand that no window reported: on
`CrashDumpUnhandledExceptionFilter` every measured window was negative while the object was
size-exact, and subtracting a `-19` inner window from its `-10` outer one exposed a `+9` region
with no window of its own. That arithmetic is mechanical, so round 246 put it in the tool.

`scripts/drift_windows.py` now reports, after the measured windows:

```
derived by subtraction (regions with no window of their own):
  [0xda, 0x6b9) -10 minus inner [0x490, 0x4d0) -19  =>  +9 outside the inner window
  [0xfc, 0x6ab) -11 minus inner [0x490, 0x4d0) -19  =>  +8 outside the inner window
  [0x11c, 0x679)  -9 minus inner [0x490, 0x4d0) -19  =>  +10 outside the inner window
```

It reproduces the hand derivation exactly, and the three independent pairs bracketing the same
region (+8, +9, +10) are a useful cross-check that a single derived number cannot give.

**It found new regions on the other rows immediately.** `gm_AllocSpieler`'s `[0x85, 0xc8b)` is
`+5` overall while its inner `[0x787, 0x794)` is `+13`, so the remainder carries **-8**: a
shortfall no window reported, in the same neighbourhood and with the same sign as the `-53` spill
region of section 136, which is consistent with that trade rather than a new fault.
`cm_ExSellObjekt` yields a `+1` remainder.

Two guards keep the output honest: only *strictly* contained windows are subtracted, and only the
**tightest** inner window per outer one is reported, so a single region is not claimed several
times over. Verified on `srv_LoadBuf` (NEAR_MATCHING, 701/750) that a function with no differing
branch targets produces no windows and therefore no derivations: the inference cannot invent a
region where none is measured.

The general point is worth stating because it applies beyond this tool: **when a measurement can
only report certain intervals, the arithmetic between those intervals is also data.** Here the
regions that matter most are precisely the ones with no branch pair to measure them, and they are
recoverable only by subtraction.

## 139. Verification checkpoint: what is actually true at residue 8,652

Late in a long session it is worth separating what has been *measured* from what has been
*inferred*, because several later sections build on earlier ones. Round 247 re-verified the load
-bearing claims directly rather than trusting the narrative.

**The deliverable.** `build/server.dll` is **286,720 bytes**, exactly the reference's size, with
**8,633 differing bytes, all inside `.text`** and zero anywhere else. That is the headline number
and it is reproducible from the committed tree. (Rounds 924-934 moved it 8,652 -> 8,633; this
paragraph is updated rather than left to rot, and `gate.sh` guards the live figure.)

**The accounting is honest.** `rebrew verify --full` gives 31 EXACT + 233 RELOC = **264
byte-matched**, plus 17 PROVEN and 2 remaining (1 NEAR_MATCHING, 1 STUB) across 283 results.
Every one of the 17 PROVEN entries carries a **non-zero delta**: checked individually, none is a
byte match mislabelled as proven, which is the failure mode AGENTS.md warns about.

**Size claims that later sections depend on:**

| function | object | reference | delta |
|---|---|---|---|
| `gm_AllocSpieler` | 3689 | 3689 | **0** |
| `CrashDumpUnhandledExceptionFilter` | 2115 | 2115 | **0** |
| `gv_ExAllocGraveyardWorker` | 1040 | 1040 | **0** |
| `cm_ExSellObjekt` | 2056 | 2057 | -1 |
| `ls_LoadBuildingEntityState` | 1460 | 1463 | -3 |

The three size-exact rows matter because sections 136 and 137 reason from them: a size-exact
object whose windows are all negative *must* hide a compensating surplus, and that inference is
only valid if the size really is exact. It is.

**The asm constraint holds.** Six live `__asm` blocks across six files, zero `__declspec(naked)`
anywhere: unchanged from section 97's audit, which established each block reproduces an
alignment-prefixed block-fill the reference itself contains. Three further files mention `__asm`
only in comments.

Nothing here is new work; it is confirmation that the session's later reasoning rests on measured
ground. **The one thing worth carrying forward: 8,652 is a `.text`-only residue on a
size-identical file, with the import table, exports, `.rdata`, `.data`, `.reloc` and all headers
byte-identical** (section 98): the remaining gap is entirely instruction-level codegen inside
19 functions.

## 140. `srv_LoadBuf`: 49 bytes, zero length difference, nine push-scheduling clusters

`srv_LoadBuf` (0x1000a570) is the closest unmatched row in the tree: **49 differing bytes** of
750, with `obj 750 = size 750` and **226 instructions against the reference's 226**. Equal counts
and equal size mean no instruction is missing, extra, or differently encoded: every differing byte
is an operand or a position.

The 49 bytes fall into **nine clusters**, and the first one is representative:

```
reference   mov ecx,[ebp+4] ; PUSH EAX ; mov [ebp+0x2c],ecx ; mov edx,[ebp]
            and edx,0x400 ; PUSH EBP ; neg edx ; sbb edx,edx
ours        mov ecx,[ebp+4] ; mov [ebp+0x2c],ecx ; mov edx,[ebp] ; and edx,0x400
            PUSH EAX ; neg edx ; sbb edx,edx ; PUSH EBP
```

**Identical instructions, identical count, identical total size: only the two `push`es sit in
different slots.** The reference interleaves argument setup into the computation; we emit the
computation and then the pushes. The second cluster is the same signature
(`lea edx,[esp+0xb0]` computed *between* `push ecx` and `push 0x10029a70`), and the remaining
clusters are single bytes, consistent with register-choice fallout from the same scheduling.

This is section 122's pattern: *C can request the operations but not their interleaving with the
argument pushes*, appearing on a fourth independent function (after `ls_LoadBuildingEntityState`,
`ServerMainThread` and `gm_AllocSpieler`). It is now the single most common residual shape in the
tree.

**The row is already exhausted at source level.** The file header records a long series of
measured, reverted attempts against exactly these clusters: "every cmd-3 respelling (store order,
guard byte-offset/element/index forms, c12-via-status, dword guard, hoisted packet/c1 locals,
per-arm locals, c1-based arg, volatile loads) inert at 661-662; lobby sprintf/mask reorderings
crater (status-arg 109 at 772, mask-via-status 301-302); memset split/total-first/recv-first
647-660; memcpy dest addend swap, sum/buf/recv locals, volatile addends 661-662". Every class of
reordering a C author can express has been tried here and either does nothing or craters.

Recorded rather than re-probed: **the closest row in the tree is 49 bytes of pure push
scheduling**, its source-level levers are documented as spent, and it is the cleanest available
statement of what the remaining residue actually is. A function can be instruction-exact,
size-exact and still differ: because the order of `push` against arithmetic is the compiler's to
choose.

**Re-confirmed 2026-09-17 (round 886), from the instruction diff rather than from scores.** The
hunk list names one real lead the push-scheduling summary hides: the reference masks the lobby
status with `and dl,0x7f` (a *byte* register) where the build emits a whole-dword `and`. That is
hunk 4 of 10, at the `*conn & 0xffffff7f` in the lobby-exit branch. Three spellings targeted at it,
every one measured, every one reverted:

| spelling | obj | match |
|---|---|---|
| `status = *conn; *conn = status & 0xffffff7f;` | 750 | 701 (**inert**) |
| `*conn = *conn & 0xffffff7f;` then `*(unsigned char*) conn &= 0x7f;` | 763 | 309 (**crater**) |
| `status = *conn & 0xffffff7f; *conn = status;` | 750 | 701 (**inert**) |

The byte-width form is the only one that touches `dl` at all and it costs 13 bytes and half the
match: msvc6 narrows the whole live range, not just the store's source. The two forms that keep the
dword mask compile byte-identically to each other and to the committed body, so the destination
register of that `and` is a property of the allocation, not of the expression. Consistent with
§§122/140: this row stays recorded, not re-probed.

## 141. What 8,652 bytes actually is: 15 instructions of difference

Sections 122, 126, 140 and others each found push-scheduling or register-choice differences on
individual rows. Round 249 measured the whole tree at once, and the aggregate is a much stronger
statement than any single row.

| function | instructions (ours vs ref) | delta | residue |
|---|---|---|---|
| `gm_AllocSpieler` | 1054 vs 1056 | **-2** | 2824 |
| `CrashDumpUnhandledExceptionFilter` | 729 vs 724 | **+5** | 1583 |
| `cm_ExSellObjekt` | 667 vs 667 | **0** | 967 |
| `ls_LoadBuildingEntityState` | 497 vs 499 | **-2** | 675 |
| `cm_ExCopyEntityData` | 255 vs 260 | **-5** | 462 |
| `gv_ExAllocGraveyardWorker` | 332 vs 333 | **-1** | 456 |
| `ServerMainThread` | 627 vs 627 | **0** | 367 |
| `srv_LoadBuf` | 226 vs 226 | **0** | 49 |

These eight rows carry **7,383 of the 8,652 differing bytes (85%)**, and across all of them the
net instruction difference is **15**. The largest deviation on any single row is **5
instructions**. Three rows (1,383 bytes of residue) differ by **exactly zero** instructions.

**That is the whole finding.** If the remaining residue were missing, extra or wrong *code*, the
instruction counts would differ by hundreds. They differ by at most five. Roughly **492 differing
bytes per net instruction difference** is not a code gap; it is the same instructions in different
positions, holding different registers.

So the tree is **semantically and structurally converged**. What remains is:

- **instruction order**: the scheduler's interleaving of argument pushes with arithmetic
  (sections 122, 127, 140: four independent functions, the most common residual shape), and
- **register choice**: which register holds a counter, a base, or a cached constant
  (sections 135, 136, 137: two independent functions where a single allocation decision produces
  a surplus in one window and a shortfall in another).

Both are compiler decisions taken from the whole function's shape, and both have resisted every
source-level spelling tried: nine on the zero-extend idiom alone (section 135), and the documented
history in `srv_LoadBuf`'s header covering every reordering a C author can express.

This is worth stating plainly because it bounds what further work can achieve. **The path from
8,652 to 0 does not run through better C.** It runs through matching the exact scheduling and
allocation decisions of a specific compiler build, which is why section 115's sp5-pp result
(a different toolchain producing one function at the reference's exact object size) remains the
most interesting unexploited lead in the tree, even though the per-file pin could not be made to
reach the link.

## 142. The sp5-pp pin lands: residue 8,652 -> 8,641

Section 141 named section 115's sp5-pp result the most interesting unexploited lead: a different
service-pack build compiles `gm_FindNextFilteredEntity` (0x10016f80) at the reference's *exact*
object size where sp6 runs four bytes short. Round 224 measured the gain but could not get it
into the build; round 250 did.

**Re-confirmed per function** (`rebrew test --toolchain msvc-6.0-sp5-pp`):

| | sp6 | sp5-pp |
|---|---|---|
| `gm_FindNextFilteredEntity` | SIZE_MISMATCH 162/346, obj **342** | STUB 171/346, obj **346** |

and critically, the three file-mates in `spiel_dumpD.c` (0x10016cd0, 0x10016de0, 0x10016ea0)
are **RELOC-perfect under both** (272/272, 186/186, 211/211), so the whole translation unit is
safe to switch. That is the check that makes a per-file pin legitimate rather than a gamble:
a toolchain is chosen per *file*, so every function in the file must survive it.

sp5-pp is emphatically **not** better in general, measured the same round: `srv_LoadBuf`
701 → 130, `ServerMainThread` 2075 → 1225, `cm_ExSellObjekt` 1149 → 834. It is an oracle for one
file, nothing more.

**Why round 224 failed and this did not.** That round pinned the toolchain with
`set_source_files_properties(... COMPILE_FLAGS ...)`, which **replaces** the per-file flags, so
`/O2 /Gd` vanished, the file compiled unoptimised, and residue went to 39%. Re-adding them by
hand duplicated the flags and made it worse (91%). The fix is `COMPILE_OPTIONS`, which *appends*:

```cmake
set_source_files_properties(
  "${PROJECT_SOURCE_DIR}/src/Develop/DieGildeAddOn/game/spiel_dumpD.c"
  PROPERTIES COMPILE_OPTIONS "/REBREW_TOOLCHAIN:msvc-6.0-sp5-pp")
```

The flag itself is consumed and stripped by `rebrew-cmake-cl` (upstream `821d5bb`, added in
round 224 and unused until now). Verified in the generated `build.make` that the emitted command
carries `/O2 /Gd` **and** the pin.

**Result, from a full `cmake --build`:** `.text` residue **8,652 → 8,641**, file still 286,720
bytes, **zero differing bytes outside `.text`**, composition intact at 246 symbols placed at their
reference VA. Baseline lowered; gate passes at 264 byte-matched.

The lesson generalises past this one file: **a per-file compiler pin is a legitimate tool when
every function in the translation unit is verified under the new toolchain**, and CMake's
`COMPILE_OPTIONS`/`COMPILE_FLAGS` distinction is the difference between an 11-byte win and a
39% regression.

## 143. Sweeping the toolchain axis: a second pin, and the limit of the technique

Section 142 landed a per-file sp5-pp pin worth 11 bytes. The verification it requires (every
function in the translation unit must survive the switch) is cheap, so round 251 swept the whole
toolchain axis across the remaining unmatched rows.

**The nine msvc6 images are still three generators** (section 92), re-confirmed directly: on
`cm_ExSellObjekt`, `msvc-6.0`, `-sp5` and `-win9x` all produce **1149/2057 at obj 2056**, exactly
the sp6 baseline. Only `sp5-pp` diverges (834/2060). So the sweep reduces to one question per
file: does sp5-pp help?

Mostly it does not:

| function | sp6 | sp5-pp |
|---|---|---|
| `cm_ExCopyEntityData` | 508/905, obj 905 | 439/922, obj 922 |
| `gv_ExAllocGraveyardWorker` | 615/1040, obj 1040 | 458/1040, obj **1000** |
| `srv_LoadBuf` | 701/750 | 130/750 |
| `ServerMainThread` | 2075/2434 | 1225/2435 |
| **`ahm_ExAllocAlchemist`** | 828/1002, obj 1002 | **834/1002, obj 1002** |

`ahm_ExAllocAlchemist` is the one gain: **+6 at an identical object size**. Its file holds exactly
one function, so the section 142 safety check is trivially satisfied: there are no file-mates to
regress. Pinned the same way (`COMPILE_OPTIONS`, never `COMPILE_FLAGS`), and measured at the link:
**residue 8,641 → 8,637**, file still 286,720 bytes, zero differing bytes outside `.text`,
composition intact at 246 symbols.

**The technique is now exhausted.** Every remaining file has been tested under sp5-pp and either
loses or is unchanged, and the other seven images are the same two generators as sp6. Two files
are pinned; there is no third. That is worth stating as a closed door, because "try a different
service pack" is an obvious idea that now has a measured answer for every row.

> **Correction (round 252).** That claim was wrong when written. Six rows had never been
> measured: including the two largest, `gm_AllocSpieler` and
> `CrashDumpUnhandledExceptionFilter`. Testing them found a **third** pin
> (`ls_LoadBuildingEntityState`, section 144). The phrase "every remaining file has been tested"
> described the rows in the table above, not the tree. See section 144 for the complete sweep.

What makes these two work is worth keeping in view: both are cases where sp5-pp produces the
reference's **exact object size** (346 against sp6's 342) or a strictly better score at the *same*
size. Neither is a general improvement: sp5-pp is dramatically worse on five of the seven rows
tested. It is a per-file oracle, and the only reason it can be used at all is that the toolchain
is selectable per translation unit and every function in those units was verified first.

## 144. The complete toolchain sweep, and a correction

Section 143 declared the toolchain axis exhausted after testing seven rows. Round 252 checked that
claim before building on it and found **six rows had never been measured**, including the two
largest in the tree. The claim was premature; the complete sweep is below.

| function | sp6 | sp5-pp | verdict |
|---|---|---|---|
| `gm_AllocSpieler` | 1004/3689, obj 3689 | 450/3689, obj 3665 | much worse |
| `CrashDumpUnhandledExceptionFilter` | 643/2115, obj 2115 | 568/2119, obj 2119 | worse |
| **`ls_LoadBuildingEntityState`** | 820/1463, obj **1460** | **824/1463, obj 1460** | **better** |
| `vfs_OpenStream` | 472/701, obj 701 | 118/693, obj 693 | much worse |
| `gm_ObjectsAvailble` | 686/714, obj 714 | 342/719, obj 719 | much worse |
| `gm_CheckInventoryCapacity` | 298/395, obj 395 | 298/395, obj 395 | identical |

`ls_LoadBuildingEntityState` gains **+4 at an identical object size**, and its file holds exactly
one function, so section 142's safety check is trivially satisfied. Pinned the same way, and
measured at the link: **residue 8,637 → 8,633**, file still 286,720 bytes, zero differing bytes
outside `.text`, composition intact at 246 symbols.

**Three files are now pinned**, and with all thirteen unmatched rows measured the axis really is
closed:

> **Correction (round 253).** "All thirteen unmatched rows" was again a number from memory. The
> residue table lists **eighteen**. The five never swept (`gm_AllocGebaeude`, `m_AllocTracked`,
> `vfs_ReadCompressed`, `cm_ExProdObjekt`, `cm_ProcessCommandQueue`) were measured in round 253
> and all lose under sp5-pp. The conclusion survives; the enumeration behind it did not. See
> section 145. `spiel_dumpD.c`, `ahm_ExAllocAlchemist.c`, `ls_LoadBuildingEntityState.c`. Every other row
loses under sp5-pp or is bit-identical, and the remaining seven images are the same generators as
sp6 (section 92, re-confirmed in section 143).

**The process point matters more than the 4 bytes.** Section 143's "exhausted" was written after a
sweep that felt complete: a table of seven rows, every one a loss, an obvious conclusion. It was
wrong because the sweep had been assembled from whichever rows were convenient across two rounds,
and nobody enumerated the full set. The correction cost one command
(`for va in <all rows>; do rebrew test --toolchain ...`) and returned a pin worth 4 bytes.

**When claiming an axis is exhausted, enumerate the population first and show the count.** "Every
remaining file" is a claim about a set; if the set was never listed, the claim is about the rows
that happened to get tested.

## 145. The toolchain sweep, enumerated from the residue table

Section 144 corrected section 143 for claiming exhaustion without enumerating the population, then
made the same mistake one paragraph later: "all thirteen unmatched rows". The residue table lists
**eighteen**. Round 253 enumerated it properly (by reading
`scripts/postlink_residual.py --built`, not from memory) and swept the five that had never been
tested.

| function | sp6 | sp5-pp | verdict |
|---|---|---|---|
| `gm_AllocGebaeude` | 753/1078, obj 1078 | 397/1078, obj 1074 | worse |
| `m_AllocTracked` | 566/658, obj 658 | 266/658, obj 634 | worse |
| `vfs_ReadCompressed` | 468/492, obj 492 | 461/492, obj 492 | worse |
| `cm_ExProdObjekt` | 976/993, obj 993 | 722/993, obj 991 | worse |
| `cm_ProcessCommandQueue` | 624/639, obj 639 | 425/639, obj 606 | worse |

No further pins. **All eighteen rows in the residue table have now been measured under both
generators**, and the three pinned files (`spiel_dumpD.c`, `ahm_ExAllocAlchemist.c`,
`ls_LoadBuildingEntityState.c`) are the complete set. The axis is closed, this time with the
population written down.

One incidental correction: section 90 recorded sp5-pp as reproducing `vfs_ReadCompressed`'s
stack-cleanup tail. At whole-function granularity it scores **worse** (461 against 468, same
object size), so whatever it fixes in the tail it breaks elsewhere in the same function. A
fragment-level oracle is not a file-level one, and only the file level can be pinned.

**Two rounds, the same error.** Both times the claim was "every remaining row", both times the set
was assembled from whichever rows were recently in hand, and both times the correction cost one
command and found something. The habit that catches it is mechanical: **enumerate from the
artefact that defines the set** (here the residue table, which is generated, not remembered) and
state the count in the claim so a reader can check it. "All eighteen rows in the residue table"
is falsifiable; "every remaining file" is not.

A methodological note for the next reader, since two sections in a row needed a correction block:
leaving the wrong claim in place with a dated correction beneath it is deliberate. Deleting it
would hide that the sweep was done twice, and the second sweep is why the third pin exists.

## 146. File splitting would unlock nothing: the pin granularity was never the constraint

Section 142 established that a toolchain is selected per translation unit, and that a pin is only
legitimate when every function in the file survives it. That implies an untried lever: a file
mixing functions which want *different* toolchains is blocked, and **splitting it** would unlock a
pin. Round 254 evaluated that, enumerating from the residue table as section 145 requires.

Of the eighteen rows, **sixteen live in single-function files**: already freely pinnable, with no
file-mate that could veto anything. Only two files hold more than one function:

| file | functions | status |
|---|---|---|
| `spiel622.c` | 16 | its residue row, `gm_CheckInventoryCapacity`, scores **298/395 at obj 395 under both toolchains**: identical |
| `spiel_dumpD.c` | 4 | **already pinned**; three file-mates RELOC-perfect under sp5-pp (272/272, 186/186, 211/211), the fourth gains |

So there is nothing to unlock. `spiel622.c`'s only unmatched function is indifferent to the
toolchain, so splitting it buys a pin worth zero bytes; `spiel_dumpD.c` is already in the
configuration that maximises it. **No file in the tree is blocked from a pin by its file-mates**,
which means the per-file granularity was never the constraint: sp5-pp simply helps three files
and hurts the rest.

Worth recording as a closed lever because it is a plausible and non-obvious idea: after
section 142 made "the toolchain is per file" explicit, splitting files to get finer granularity is
the natural next thought, and it is the kind of large refactor that would be expensive to attempt
and then abandon. The measurement that closes it is three `rebrew test` invocations.

This also completes the toolchain axis properly. Sections 143 and 144 each claimed closure and
each was corrected; the axis is closed now in a stronger sense than "no more pins found": **every
row has been measured under both generators (section 145), and the only structural move that
could change that result has been evaluated and yields nothing.**

## 147. The flag landscape, checked on a sixth row

Sections 143 to 145 were each corrected for claiming an axis closed without enumerating its
population, so round 255 applied that scrutiny to the *other* closed axis. Section 106 is titled
"flat on every walled row: **five for five**", which is honest about its scope: five rows of the
eighteen in the residue table.

The five it covered were `gm_AllocSpieler`, `CrashDumpUnhandledExceptionFilter`, `cm_ExSellObjekt`,
`vfs_ReadCompressed` and `m_AllocTracked`: a better spread than "the five largest" suggests, since
two of them (24 and 92 residual bytes) are among the smallest rows in the tree. That matters: if
flag sensitivity depended on function size, a sweep of only large rows would not show it, and this
one already spans both ends.

Round 255 swept a sixth, `ls_LoadBuildingEntityState` (671 residual bytes, mid-table), `targeted`
tier, 20 combinations:

```
combos: 20 | distinct scores: 1
best flags: /G3 /Gd /Oy /Op | best score: 859832.65
FLAT: all combinations score identically
```

**Six for six.** Every combination of the twelve flag axes produces byte-identical output on every
row tested, across the full size range from 24 to 2,824 residual bytes. The result is consistent
enough that the remaining twelve rows would be a formality rather than a discovery.

Two practical notes for whoever runs another:

- **The sweep needs a background job.** It took roughly 15 minutes against a 12-minute deadline
  and will be killed by any shorter foreground timeout; `--timeout-min` bounds the GA but the
  sweep still has to compile 20 objects through docker and wine.
- **`distinct scores: 1` is the number to read**, not `best_flags`. The sweep always reports some
  combination as "best"; with a flat landscape that is an arbitrary pick among equals, and reading
  it as a recommendation would be a mistake: `/G3 /Gd /Oy /Op` here is not better than the
  default, it is merely first.

Taken with sections 145 and 146, both compiler-configuration axes are now closed on measured
evidence: flags are flat wherever tested, and the toolchain choice has been swept across all
eighteen rows with three pins found and no structural move left that could yield a fourth.

## 148. The data-segment tooling was blind, and what it sees now (round 1 of the data pass)

The round's brief was "data and other segments: types, structs". The first thing to measure was
what the tools already knew, and the answer was **nothing**: `rebrew data list --summary` reported

```
Section    Globals    Annotated     Bytes    % Coverage
unknown        204            0    0B / —             —
```

204 globals, **zero** annotated, every one in section `unknown`, against a tree carrying 310
entries in `src/rebrew-data.toml` (110 `.data`, 50 `.bss`, 33 `.rdata`, 84 `.idata`) and 118
`// DATA:` markers in the sources. Three defects in `rebrew`, each of which independently
zeroed the report:

**1. `scan_globals` matched only `// GLOBAL:`.** This project spells every global `// DATA:`
(118 markers, **zero** `GLOBAL:`), and rebrew treats the two as one concept everywhere else:
`annotation.DATA_MARKERS` is `{"GLOBAL", "DATA"}` and `Annotation.is_data` accepts both. Only
this one regex disagreed, so all 118 markers scanned as unannotated. Fixed by accepting either
marker, which is what the rest of the codebase already assumes.

**2. The identifier fallback could not read a definition with an initialiser.**
`_DECL_IDENT_RE` required a `;` terminator:

| declaration under the marker | old | new |
|---|---|---|
| `extern int g_x;` | `g_x` | `g_x` |
| `char s_msg[] = "Unknown winsock error %u!!!";` | **None** | `s_msg` |
| `char g_crashdump_data_10027104[568] = {` | **None** | `g_crashdump_data_10027104` |
| `char g_t[4][8] = {` | **None** | `g_t` |

A reversed source spells a global it *defines* with an initialiser, so the fallback failed on
exactly the globals whose bytes we actually emit. Those became entries literally named
`unknown`. The pattern now accepts repeated array extents and an `=` as well as a `;`.

**3. Nothing consulted the metadata.** 53 of the 118 markers have no declaration beneath them:
they annotate a global defined in another TU, or one the code only reaches by absolute address.
Their name, type and section are already in `rebrew-data.toml`, which the scan never read. It
now falls back to the metadata before giving up.

The warning was also inverted: it fired on "no declaration on the following line", which is a
*legitimate* shape here, and stayed silent when the global was genuinely unidentifiable. It now
warns only when neither the source nor the metadata can name it, and on this tree that count is
**zero**.

After the three fixes, the same command reports:

```
Section    Globals    Annotated                   Bytes    % Coverage
.data           36           36       39,708B / 57,344B         69.2%
.rdata           5            5           17B / 11,905B          0.1%
.bss            74           74    1,053B / 24,323,484B          0.0%
unknown        196            1                  4B / n/a             n/a
```

311 globals, 116 annotated, attributed to real sections, and `rebrew data bss` now produces a
32-gap layout report instead of an empty one. The 196 remaining `unknown` are extern-only
declarations with no VA (no annotation to place them), which is the honest reading, not a defect.

**What this does and does not claim.** It buys no bytes. `.text` residue is unchanged at 8,633,
and it was never going to move: this is the instrumentation for the data pass, not the pass.
The point is that the previous number was not "0% coverage", it was *no measurement at all*, and
the difference matters before anyone reasons about `.data` from it.

### The non-`.text` identity is still copied, measured again, honestly

Section 98 established this and it is worth re-measuring each time the pipeline changes, because
the shipped artifact reports it away. `postlink_residual.py` on the deliverable prints

```
.data   differing 0x0    .rdata differing 0x0    .reloc differing 0x0    headers 0x0
```

and all four zeros are tautologies: the fixers blit `layout/server.dll/data.hex` and `reloc.hex`,
which are verbatim reference slices, over those regions. The honest number is the raw link's,
which the same script prints beneath (round 450 added this, and it is still correct):

```
raw link vs reference (pre-fixer -- what the build actually produces):
  .text     differing  0x3872 of 0x23000 (10.1%)
  .rdata    differing   0x4f4 of  0x3000 (10.3%)
  .data     differing  0x6d31 of  0xe000 (48.7%)
  .reloc    differing  0x1bab of  0x9000 (19.2%)
  headers   differing    0xfd of  0x1000 (6.2%)
  non-.text total the fixers overwrite: 0x8ecd (36557 bytes)
```

**A trap worth recording, because it cost this round a wrong measurement.** The script's
`--built` argument is the *raw link*, and the CMake POST_BUILD step rewrites `build/server.dll`
in place. Passing `--built build/server.dll` (which reads like the obvious thing to do, and is
what `gate.sh` and `linktest.sh` pass, correctly, because they pair it with `--write`) makes the
"pre-fixer" block compare the *postlinked* image against the reference and report `.data` 0.0%,
i.e. the exact self-certification the block exists to prevent. The deliverable's real raw link
is `build/split_poc.dll` (from `split_link.sh`); `.scratch/server.dll.prelayout` is the CMake
link, a *different* composition. Run it with no arguments to get the right default.

### `.data` and `.rdata` are placement-bound, restated with current numbers

Section 100 measured this before the two link-order wins; the shape survives them:

| section | positional | multiset ceiling | present-but-misplaced | differing |
|---|---|---|---|---|
| `.data` | 29,391 / 57,344 = **51.3%** | 50,942 = **88.8%** | **21,551** | 27,953 |
| `.rdata` | 11,020 / 12,288 = **89.7%** | 12,201 = **99.3%** | **1,181** | 1,268 |

The gap between the two columns is the content we already emit and put in the wrong place. For
`.data` that is 21,551 bytes (**77% of its divergence is ordering, not missing content**) which
is why §100's rule still holds: *emitting more correct content makes the number worse until the
ordering is fixed*.

Chunk-matching the built `.data` against the reference (32-byte windows, uniform runs skipped)
localises the ordering into a handful of blocks rather than a uniform shift:

```
built [ 0x9e20, 0xa780] len 0x960  shift +0xc4
built [  0x4c0,  0xdc0] len 0x900  shift -0x28
built [ 0xce20, 0xd540] len 0x720  shift +0xc4
built [ 0x2200, 0x2780] len 0x580  shift -0x3e4
built [ 0x9780, 0x9c40] len 0x4c0  shift +0xc4
```

`+0xc4` dominates (359 of 950 located chunks), then `-0x28` and `-0x3e4`. This is the state
*after* rounds 453/454 took the dominant displacement from `+0x7928` to `+0x20`: what is left is
no longer one global offset that a single link-order move can cancel, but several bands drifting
in **both** directions, which is the signature of size differences accumulating between them
rather than one object sitting in the wrong place. A `+0xc4` band and a `-0x28` band cannot both
be fixed by moving one object: the next `.data` win has to come from the content of whatever
sits between them, and that is the missing-TU content §100 already identified.

### What the repaired tooling immediately showed: `rebrew data layout audit`

The scan fix has a payoff beyond the summary table, because `--layout-audit` is built on the
same `scan_globals` that was returning nothing. With globals attributed to sections it produces
a per-TU feasibility report, and on `.data` it names **13 violations**:

```
Units/Error/Error.c.obj                       6  0x10027078 0x100270e8   0xaa   <== ORDER
Units/Error/Error_c/EmitCrashModuleLine.c.obj 4  0x10027314 0x10027328   0x12   <== ORDER
Units/Error/Error_c/ErrorModule.c.obj         4  0x100270fc 0x1002735c   0x77   <== ORDER
Units/Error/Error_c/ErrorModule2.c.obj        8  0x100270f8 0x100270f8   0x92   <== ORDER
Units/m_alloc/m_alloc2.c.obj                 15  0x10028888 0x10034634  0x14f   <== ORDER/SPAN
DieGildeAddOn/loadsave/loadsave3.c.obj        7  0x10030b84 0x10031538   0x3d   <== ORDER
DieGildeAddOn/game/spiel_c/gm_Open.c.obj     16  0x10034624 0x1003467c  0x13f   <== ORDER
DieGildeAddOn/game/spiel.c.obj                2  0x10030b6c 0x10030b6c   0x2a   <== ORDER
...gm_NextEntityQueryMatch.c.obj              2  0x10030b98 0x10030b9e    0x5   <== ORDER
crt_region/mlock.c.obj                        1  0x10031aac 0x10031aac    0x4   <== ORDER
src/link_stubs.c.obj                        199  0x1002c3f0 0x11766204   0x71   <== ORDER/SPAN
violations: 13   unowned toml symbols: 31
```

Read against the displacement bands above, the four `Units/Error/*` rows are the interesting
cluster: they own overlapping address ranges (`0x10027078..0x1002735c`) across four separate
TUs, which is precisely the interleaving §100 described: the reference puts one TU's literals
and named globals adjacent in declaration order, and a split across four objects cannot
reproduce that, because the linker takes each object's regular `.data` before any of its
COMDATs. `link_stubs.c.obj` spanning `0x1002c3f0..0x11766204` is the other structural one, and
it is an artifact of the stub file owning globals that belong to TUs not yet reversed: the
same missing-TU content, seen from the symbol side rather than the byte side.

This is the concrete entry point for the next data round, and it did not exist as a readable
signal before this round because the audit's input was empty.

### One more defect the repaired scan caught: an RVA where a VA belongs

With annotated globals finally landing in sections, `rebrew data list` could run its cross-check that
every annotated VA falls inside a real PE section range, and it immediately flagged one:

```
warning: 1 annotated global(s) fall outside every PE section range:
g_iat_region@0x24000
```

`crt_region/crt_imports.c` is auto-generated, and `gen_crt_imports` was passing `Section.va`
(an **RVA**) straight into a `// DATA:` marker, which is a **VA**. Every other generator in the
same file adds the image base (`gen_data_restore` does `image_base + data_va + raw_start`). So
the IAT, which lives at `0x10024000`, was annotated at `0x24000`: outside every section, and
unresolvable to every tool that reads the annotation. Fixed in the generator, and the checked-in
file corrected to `0x10024000`.

The stale metadata entry keyed `SERVER.0x00024000` was removed rather than re-keyed: `0x10024000`
was already occupied by the genuine first IAT slot (`__imp__GetLocalTime@4`, `.idata`), so
re-keying would have overwritten a correct entry with a synthetic one. Worth stating because the
obvious repair is wrong here.

After both fixes `rebrew data list --summary` warns about nothing and reports **zero** annotated
globals in `unknown`: the 195 that remain there are extern-only declarations carrying no VA.

## 149. Per-symbol `.data`: what 39 wrong symbols actually are (round 2 of the data pass)

Section 148 repaired the scanner. This round repaired the *verifier*, which turned out to be
in the same condition, and the result is the first per-symbol picture of `.data` this project
has had.

### `rebrew verify --data` was comparing nothing, and reporting success

```
data: 0 matched, 0 mismatched, 0 missing
```

Two independent defects:

1. **`section_symbol_bytes` skipped every symbol with `size <= 0`.** `size` is an *optional*
   metadata field and this tree carries **zero** of them across 310 entries, but 303 `type`
   fields. So the comparison set was empty, and an empty comparison prints as a pass. The
   declared type now sizes the symbol, through the same `estimate_type_size` the section
   summary already used: **0 symbols compared → 83 (40,916 bytes)**.

2. **It defaulted to `build/server.dll`, which postlink rewrites.** Same trap as §148's, in a
   second tool. Measured on the identical symbol set:

   | built binary | mismatched |
   |---|---|
   | `build/server.dll` (postlinked) | **0 of 83** |
   | `build/split_poc.dll` (raw link) | **39 of 83 (14,528 bytes)** |

   A *perfect* score on a section the build cannot yet produce is the tell. `--data` now
   detects a built `.data`/`.rdata` that is byte-identical to the reference and says so.

### The 39, classified

Comparing each mismatched symbol's built bytes against the whole reference `.data`:

| class | count | meaning |
|---|---|---|
| our bytes found elsewhere in the reference | **28** | correct content, **wrong address** |
| zero-filled | **9** | not emitted at all |
| genuinely different | **2** | wrong content |

So **72% of the wrong symbols are right**, just misplaced: the symbol-level restatement of
§100's byte-level 77%. The displacement histogram, per symbol rather than per 32-byte chunk:

```
+0xc4   7 symbols     -0x20   2 symbols     -0x60   2 symbols     +0x8e19  1 symbol
```

which is the same `+0xc4` band §148 found, now with names attached (`g_next_object_id`,
`g_entity_id_counter`, `g_query_filter_extra*`, …).

### A real type bug, a correct fix, and why it was reverted anyway

`rebrew data list --conflicts` reported **0 conflicts**, which was wrong: `find_extern_variables`
parsed only `extern` declarations, so a global's **definition** (where its real type lives)
was invisible. Conflict detection that cannot see definitions cannot find the one mismatch
that matters. With definitions in scope it finds **13** (16 before whitespace normalisation),
and one cluster is a genuine byte bug:

`loadsave3.c` **defines** five filter globals as arrays, while
`gm_StartFilteredEntitySearch.c` **declares and uses** every one of them as a scalar
(`g_query_filter_extra2 = 0x7fff;`, `= *(short*)(arg_ptr + 1)`). The reference gives the whole
cluster a **16-byte** extent at `0x10030b84`; the array spelling emits **53**:

```
g_filter_extra5        char[1]     1        reference extent 0x10030b84..0x10030b94 = 16 bytes
g_query_filter_extra1  int[4]     16        array spelling emits              = 53 bytes
g_query_filter_extra2  int[4]     16        surplus                           = 37 bytes
g_query_filter_extra3  short[2]    4
g_query_filter_extra4  int[4]     16
```

The scalar spelling reproduces the reference bytes **exactly**, padding included:

```
+0x00 unsigned char ff  (+3 pad)   +0x04 int ffffffff   +0x08 short ff7f
+0x0a short ff7f                   +0x0c unsigned char ff
= ff000000 ffffffff ff7f ff7f ff   == reference
```

**And it still measured worse: `.text` +2, `.data` 0x6d31 → 0x6e1d (+236).** Reverted.

This is §100's rule holding on its sharpest case yet. The previous demonstrations were
*missing* literals being added; this one is a correct 37-byte **reduction**, provably matching
the reference's own bytes, and it *still* loses, because shrinking a symbol displaces every
symbol after it just as surely as growing one does. The rule is not "adding content hurts", it
is **any size change in a misplaced section hurts until the ordering is fixed**. Nothing in
`.data` can be judged by local correctness while 21,551 of its bytes are present-but-misplaced.

**The metadata half was kept**, because `rebrew-data.toml` does not feed the build (only
`rebrew-functions.toml` does): the five entries now carry the scalar types the reference and
the consuming code agree on, which costs zero bytes and makes every future report more
accurate. Worth separating: the type correction was right, the *layout consequence* of
spelling it in C is what could not be afforded yet.

### Two latent defects this uncovered

- **`dllimport` was never actually skipped.** `_strip_cc` deletes the whole `__declspec(...)`
  before tree-sitter parses, so the in-tree check could not fire; it only appeared to work
  because such declarations were rejected for lacking `extern`. `extern __declspec(dllimport)
  int g;` was being reported all along, against the documented intent.
- **Pointer spelling counted as a type conflict.** `char *` vs `char*` produced three of the
  sixteen rows. Compared on a whitespace-normalised key now.

## 150. The first `.data` win: a declared size that was four times too large (round 3 of the data pass)

Sections 148 and 149 built the instrumentation and found nothing affordable. This round used it
to find and land a real bug, and the method that worked was the **linker's own map**, which
nothing in this project had been reading.

### Read `/MAP`, not the bytes

`split_link.sh` already passes `/MAP:split_poc.map` and nothing consumed it. It answers
directly what the byte-level chunk matching in §148 could only infer: for every symbol, which
object supplied it and what address it got. Cross-referencing its section-3 lines against the
annotated VAs in `rebrew-data.toml`:

```
135 annotated .data/.bss symbols located in the map
  at the reference VA exactly: 0
```

and, sorted by reference VA, the top of `.data` reads:

```
symbol                       ref va      built     delta  object
g_log_level_table        0x10027078 0x10027074        -4  Error.c.obj
g_log_format_table       0x10027084 0x100270a4       +20  Error.c.obj
g_log_newline            0x100270e4 0x10027104       +20  Error.c.obj
g_log_default_name       0x100270e8 0x10027108       +20  Error.c.obj
```

**One symbol enters at −4 and the next three leave at +0x20.** A delta that changes *inside* one
object is not link order: it is that object emitting the wrong number of bytes, and the map
localises it to a single symbol pair.

### The bug

```c
int g_log_level_table[12] = {
    0x01, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00,
};
```

The initialiser is the reference's twelve **bytes**, but the declaration says twelve **ints**:
48 bytes. The reference gives the table 12 bytes exactly: `g_log_format_table` begins at
`0x10027084`, twelve bytes later, and `DispatchLogOutput` only ever indexes `[0..2]`. So this is
`int[3] = {1, 2, 8}`, and the arithmetic closes exactly:

```
surplus emitted   48 - 12 = 36
object starts     4 bytes early  (-4)
net downstream    36 - 4  = 32 = +0x20   <- the observed shift
```

Result: `g_log_level_table` … `g_log_default_name` all collapse to a **uniform −4**, and the raw
link's `.data` divergence goes **27,953 → 27,722 (−231)**: the first `.data` gain in three
rounds of this pass.

### Why a 36-byte fix pays 231 bytes, when §149's 37-byte fix cost 236

Both were correct size reductions of almost identical magnitude. The difference is **what sits
downstream**. §149's cluster (`loadsave3.c`, `0x10030b84`) is deep inside the section with
thousands of already-misplaced bytes after it, so shrinking it re-misplaced more than it fixed.
This one is at `.data + 0x78`, near the head, and the symbols after it were displaced by
*exactly* this surplus, so removing it put four symbols right and shifted the rest toward, not
away from, their reference addresses.

**The rule §149 stated still holds and is now sharper**: a size change in a misplaced section is
a gamble whose sign depends on whether the surplus you remove *is* the cause of the downstream
displacement. The map tells you which case you are in; the byte histogram does not. When a
delta changes **within one object**, that object is the cause and the fix pays. When every
symbol in an object shares one delta, the cause is upstream of it and a local fix will not.

### What it costs, and the baseline that had to move

The fix requires changing the declaration in `rebrew_globals.h`, which **every TU includes**
(the build refuses otherwise: `error C2369: redefinition; different subscripts`). Two sp5-pp
pinned files each gain one byte, inside functions that were already unmatched and at an
unchanged first-diff offset: `ahm_ExAllocAlchemist` 197→198, `gm_FindNextFilteredEntity`
214→215. `.text` residue **8,633 → 8,635**.

So `RESIDUE_BASELINE` was raised by 2: the first raise in this project's history, deliberately,
with the trade recorded in `gate.sh` itself. The justification is that the objective is a build
that is byte-identical **without** postlink, and postlink overwrites `.data` wholesale: the
shipped deliverable is identical either way, while the raw link is 229 bytes closer.

### The gate could not see `.data` at all: fixed

That trade exposed a structural blind spot. `gate.sh` guarded `.text` residue, the two verify
baselines, lint and compile errors, and **nothing outside `.text`**. Since postlink blits
`.data` from the layout package, the shipped file always reports `.data differing 0x0`, so three
rounds of data work were invisible to the one check that decides whether a change may land. It
now guards the **raw link's** `.data` (`DATA_BASELINE`, 27,722) alongside the `.text` residue.

### The remaining −4, traced but not closed

The whole cluster now sits 4 bytes early because the reference has `ff ff ff ff` at
`0x10027030` that we do not emit. It is unreferenced by any instruction (`rebrew binary xrefs` finds
nothing, and the dword does not appear as an immediate anywhere in the reference `.text`), and
it is LIBCMT's `__fileinfo`: a member whose entire content is one 4-byte `.data` section.

`/INCLUDE:__fileinfo` does pull it in, and it lands at `0x10034f1c`, not `0x10027030`: LINK
places a pulled member by object order, not by address, so the directive alone cannot put it
where the reference has it. Closing this needs the split-set machinery
(`split_coff.py`/`make_split_rsp.py`) to place that member's section explicitly, which is the
same mechanism already used for mapped `.text` sections. Left for a later round rather than
bolted on; the `/INCLUDE:` probe was measured and reverted (`.data` 27,722 → 27,726, headers
worse).

## 151. A symbol defined twice: 8 duplicated bytes cost 1,350 (round 4 of the data pass)

§150 read the linker map for one object. This round read it for **every** object, which turns
the map into a classifier rather than a one-off diagnostic.

### The per-object delta spread is the whole triage

For each object, collect its annotated `.data` symbols and the set of deltas
`built_va - reference_va`. **One delta means the object's internal layout is right and something
upstream displaced it. More than one means the object itself emits the wrong number of bytes.**
That single rule sorts the entire section:

```
object                              n   distinct deltas
Error.c.obj                         4   {-0x4}                     <- fixed in §150, now uniform
ErrorModule2.c.obj                  1   {0x30c}
EmitCrashModuleLine.c.obj           2   {0x34, 0x44}               <- INTERNAL SPREAD
ErrorModule.c.obj                   4   {0x14, 0x8c, 0x2c4}        <- INTERNAL SPREAD
m_alloc2.c.obj                      9   {-0x68, -0x10, 0x4, 0x264} <- INTERNAL SPREAD
gm_Open.c.obj                       6   {0x8cc, 0x8d0, 0x8d8, ...} <- INTERNAL SPREAD
link_stubs.c.obj                   40   39 distinct                <- the stub file, by nature
```

`Error.c.obj` collapsing to a single `-0x4` is §150's fix showing up in the classifier, which is
the confirmation that the rule reads true.

### The bug: a symbol that exists twice

`EmitCrashModuleLine.c` defined

```c
// DATA: SERVER 0x10027314
char g_crash_newline[4] = { 0x0d, 0x0a, 0x00, 0x00 };
// DATA: SERVER 0x10027328
char g_crash_space[4]   = { 0x20, 0x00, 0x00, 0x00 };
```

Both VAs fall **inside** `g_crashdump_data_10027104`, which spans `0x10027104..0x1002733c` and
already carries those exact bytes at offsets 528 and 548. The reference has **one** copy of
each; we emitted a second. The fix is to alias into the blob rather than duplicate it:

```c
extern char g_crashdump_data_10027104[568];
#define g_crash_newline (g_crashdump_data_10027104 + 528)
#define g_crash_space   (g_crashdump_data_10027104 + 548)
```

### 8 bytes removed, 1,350 recovered: and why that is not a paradox

Raw-link `.data` **27,722 → 26,372 (−1,350)**; positional match **51.6% → 54.0%**; present-but-
misplaced **21,551 → 19,962**.

The 8 bytes are not the win. Removing them shifts everything after the blob by −8, and that
band of `.data` was sitting +8 away from its reference position, so one small deletion
re-registered a long run of symbols that were **already correct in content**. This is §100's
"present but misplaced" reserve being cashed: 88.8% of `.data`'s bytes are the right bytes, and
any edit that moves a large block *toward* its reference offset converts a chunk of that reserve
into positional matches at once.

**The practical rule**, now demonstrated twice in opposite directions:

| round | edit | size change | `.data` result |
|---|---|---|---|
| 508 | `loadsave3.c` filter cluster, correct scalar types | −37 | **+236 worse** |
| 509 | `g_log_level_table` `int[12]` → `int[3]` | −36 | **−231 better** |
| 510 | `g_crash_*` duplicates aliased into the blob | −8 | **−1,350 better** |

Nearly identical magnitudes, wildly different outcomes. **Size is not the variable; position
is.** Ask the map whether the symbols *after* the edit are displaced in the same direction the
edit will move them. If yes, it pays, and the payoff scales with how much of the section sits
downstream: not with the size of the edit.

### Quirk: a `.text` byte that is not codegen

`gm_AllocGebaeude` went 327 → 328 differing bytes, and its **object file is byte-identical**
before and after (verified by md5). The function embeds `.data` addresses as immediates; the
−8 shift moved them, and the positional `.text` compare counted one more differing byte. The
compiler emitted exactly the same code.

This is worth stating plainly because the residue table cannot distinguish the two cases, and
"a function got worse" reads like a codegen regression. **When a `.text` row moves by a byte or
two after a `.data`-only edit, hash the object before concluding anything.** Identical object =
placement, and placement follows the data layout it points into.

### Quirk: the gap blob overlaps ~40 real symbols, and that is correct

Scanning every blob array for annotated symbols inside its span finds
`g_data_restore_gap` "containing" about forty of them. That is **not** the same bug.
`data_restore.c`'s blob is a LENGTH-ONLY pad whose content never reaches the output: postlink
overwrites `.data` wholesale, and `split_link.sh` substitutes its own shorter `0x74a0` version
for the split composition. Only `g_crashdump_data_10027104` is a content blob whose bytes ship,
so only its overlaps are duplicates. A future audit of this class must check whether the blob's
content is load-bearing before calling an overlap a defect.

## 152. The predictor: ask whether the bytes *after* the edit want to move (round 5 of the data pass)

§151 ended with "position is the variable, not size" and a table of three edits. This round
turned that observation into a **measurement you can run before editing**, after being caught by
the same trap it describes.

### The trap, walked into deliberately and then understood

`ErrorModule.c` declared `s__s__s_100270fc[] = "%s\\%s"`. That string belongs at `0x100270fc`,
and `Error.c` already emits the identical literal as its own `??_C@` COMDAT: three call sites
reach it (`0x10002692`, `0x100026C3`, `0x100033F3`), none of them by symbol name. It looked
exactly like §151's win: a duplicated string, unreferenced by name, removable.

Removing it cost **`.data` +1,752**.

The difference from §151 is that `g_crash_newline` sat at a VA **inside a content blob that
already shipped those bytes**, so deleting the duplicate removed 8 bytes the section genuinely
had twice. `s__s__s_100270fc` is the only thing occupying its 8 bytes *in this TU*: `Error.c`'s
COMDAT lands at `0x100270f8`, a different object. Deleting it did not remove a duplication, it
just made `ErrorModule.c.obj` 8 bytes shorter and moved everything after it.

### The measurement that would have vetoed it

An object that emits D bytes too many displaces everything after it by D. So the question is not
"are these bytes right?" but **"is the region after this object currently at its best offset?"**
If it is, no size change to that object can help, however wrong the object's own bytes are.

`scripts/data_shift_probe.py` answers it directly: for a cut point, how many bytes of the
reference `.data` after it the build reproduces at each candidate shift:

```
$ python3 scripts/data_shift_probe.py --cut 0x100273e0 --range 16
shift    -8   29035 matches  (-1726)
shift    +0   30761 matches  <-- current  BEST
shift    +8   29011 matches  (-1750)
best shift: +0 -- the region after this cut is ALREADY at its best offset, so an
edit that changes this object's size can only lose.
```

**Validated on two independent cases, sign and magnitude:**

| case | probe says | edit did |
|---|---|---|
| §151's win (pre-edit build, cut `0x10027360`) | best shift **+8**, worth **+1254** | `.data` **−1,350** |
| this round's loss (cut `0x100273e0`) | best shift **+0**, any change loses | `.data` **+1,752** |

The probe exits non-zero when the best shift is 0, so it works as a veto in a script.

### What it found next: a global nothing defined

Sweeping cut points located a `+12`-worth-~600-bytes opportunity whose boundary is at
`.data+0x1938` = **`0x10028938`**, where the reference has `"_main_:"` and the build has the
next object's literal. Tracing it:

- `m_alloc.c` declared `extern int g_default_group_name` / `_4`: a *pair of ints*, because
  `m_init` reads the string as two dwords (`mov eax,[0x10028938]` / `mov ecx,[0x1002893c]`).
- **Nothing defined them.** `link_stubs.c` supplied `int g_default_group_name = 0;` and `_4 = 0`,
  which the linker placed at `0x100366dc`, so the reference's eight bytes were absent from
  `.data` entirely, and the default allocation-group name was zeros at runtime.

Defining it as the real string in `m_alloc.c`, whose own literals end exactly at `0x10028938`:

```c
char g_default_group_name_str[8] = { '_', 'm', 'a', 'i', 'n', '_', ':', '\0' };
#define g_default_group_name   (*(int*) &g_default_group_name_str[0])
#define g_default_group_name_4 (*(int*) &g_default_group_name_str[4])
```

`.data` **26,372 → 26,066 (−306)** and `.text` **8,636 → 8,635 (−1)**: the first change in this
pass to improve *both*, and the first to give back one of the bytes §150/§151 had to spend.

### Quirk: `link_stubs.c` hides missing data as successfully-linked zeros

This is the second time the stub file has masked a real gap (§151 noted it spanning
`0x1002c3f0..0x11766204`). Its header says it is generated by `scripts/gen_link_stubs.py`: **that
script does not exist in the tree**, so it is hand-maintained despite the "DO NOT edit manually"
banner. Every symbol in it links cleanly and reports no error, which is exactly what makes it
dangerous: a global that should hold the reference's bytes instead holds a zero at an address the
reference never used, and nothing in the build complains.

**When the probe points at a region and the symbol there resolves to `link_stubs.c.obj`, that is
the finding.** 40 annotated `.data` symbols still resolve there; each is a candidate for the same
treatment: define it in the TU whose literals abut its reference VA.

## 153. A named array lands first; a literal lands last (round 6 of the data pass)

§152 defined `"_main_:"` as a named `char[8]` in `m_alloc.c` and got the bytes into the
section. This round found that those bytes were in the **wrong place inside that TU's run**,
and that five truncated stubs in `m_alloc2.c` were the same class of bug as §151.

### The ordering bug in §152's own fix

The reference's `m_alloc.c` literal run is:

```
0x100288e0  "Memory-Underflow Error"
0x100288f8  "Memory freed more than once..."
0x10028938  "_main_:"                 <- LAST
```

Round 511's named array `g_default_group_name_str[8]` landed at `0x100288e0` -- FIRST --
because msvc6 puts a named global in the object's regular `.data` and every string literal in
its own `??_C@` COMDAT, and the linker takes the object's regular `.data` before its COMDATs
(§100). The probe then pointed at a `+28` opportunity whose first divergence was exactly that
displaced `"Memory-Underflow Error"`.

Spelling it as an anonymous literal:

```c
#define g_default_group_name   (*(const int*) "_main_:")
#define g_default_group_name_4 (*(const int*) ("_main_:" + 4))
```

puts it in a COMDAT after the two Memory* strings. Result: `0x100288e0..0x10028940` is
byte-identical to the reference, and `"_main_:"` sits at `0x10028938` exactly.
`.data` **26,066 → 25,978 (−88)**.

### Five truncated stubs that duplicated COMDAT literals

`m_alloc2.c` defined five named arrays holding only the first byte of strings this TU already
emits as `??_C@` COMDATs from real call sites:

| VA | stub | real literal already in the TU |
|---|---|---|
| `0x10028888` | `g_str_10028888[1] = {0x44}` | `"D:\\Develop\\Units\\m_alloc\\m_alloc.c"` |
| `0x10028aec` | `g_str_10028aec[1] = {0x2d}` | `"-> Pointer not freed:%s"` |
| `0x10028b04` | `g_str_10028b04[1] = {0x5b}` | `"[*] Memory-Shutdown-Anomaly: [*]..."` |
| `0x10028b60` | `s_m_pool_alloc...[24] = {0x6d}` | `"m:pool_alloc(tp_m_pool)"` |
| `0x10028b78` | `s_m_pool_get_free...[27] = {0x6d}` | `"m:pool_get_free(tp_m_pool)"` |

Nothing referenced the stub names. The object emitted the text twice: ~64 bytes of stubs in
regular `.data`, then the COMDATs after them. Dropping the stubs lets the COMDAT run slide into
the reference addresses. All five now MATCH at their exact VAs. `.data` **25,978 → 25,884
(−94 more)**.

### Quirk: the probe's +28 and a −64 shrink are not a contradiction

The probe at `0x10028bf0` said best shift **+28**. Removing 64 bytes of stubs looks like the
wrong direction. It is not: the stubs occupied the *start* of this object's contribution and
displaced the COMDATs that belong there. Shrinking by deleting the displacers moves the *content
that should be there* into place; the probe's +28 is the residual misalignment *after* that
slide, still waiting on something further upstream or downstream. Do not read "best shift +N"
as "never shrink this object" -- read it as "the region after the cut wants +N relative to
today." An edit that removes bytes *before* the cut and lets later content fall into the cut
can still win.

### `.text` +1 is placement again

`RESIDUE_BASELINE` 8635 → 8636. The three residue-table objects (`gm_AllocGebaeude`,
`ahm_ExAllocAlchemist`, `spiel_dumpD`) are md5-identical before and after. Same class as §151.

## 154. Data-only TUs beat text-ordered link for .data placement (round 7 of the data pass)

§153 left a `+24` opportunity whose first divergence was `"Unknown winsock error %u!!!"` at `0x10028bdc`. The strings lived in `server4.c` / `server2.c`, whose first functions sit at `0x1000ad40` / `0x10009d30`. `rebrew build order-sources` (CMakeLists.txt) orders game objects by `.text` VA, so those TUs link AFTER vfs/zlib (`trees.c` at `0x10006ec0`). Result: trees/vfs occupied the winsock slot and the 0x82c-byte run landed ~900 bytes late.

### The fix: a data-only TU ordered between m_alloc2 and trees

Extracted the exact reference bytes `0x10028bdc..0x10029408` (19 strings + pads, 2092 bytes) into `net.c`: no functions. Ordered it with:

```
--first-va net.c=0x10006c80   # between m_alloc2 (0x10006c00) and trees (0x10006ec0)
```

Callers in `server4.c` / `server2.c` now reference the named symbols; they must NOT also spell the same text as a string literal or the bytes emit twice (same class as §151/§153).

### Result

- `0x10028bdc..0x10029408`: **2092/2092 matching (100%)**
- trees table at `0x10029408`: MATCH
- `.data` **25,884 → 23,779 (−2,105)**
- `.text` **8,636 → 8,635 (−1)**: gave back the placement byte §153 spent

### Quirk: CMake object order is `.text` VA, not `.data` VA

`make_split_rsp` sorts *split* LIBCMT objects by VA, but game objects keep CMake/`order-sources` order, which is driven by the first `// FUNCTION:` marker (or `--first-va`). A TU whose only contribution is `.data` that belongs early in the section must therefore either (a) live in a TU whose `.text` VA is also early, or (b) be a data-only file given an artificial `--first-va` between the neighbours that frame its reference run. (b) is the lazy path when the owning functions are late.

### Next miss

First divergence after the winsock run: `0x1002944c`, where the reference has `"rb"` + gzip magic (`0x1f 0x8b`) before the vfs path; the build has `vfs4.c`'s named strings starting early. Same class as unused named-string stubs (§153).

## 155. Twelve bytes of fopen mode + gzip magic before the vfs path (round 8 of the data pass)

§154 left the first miss at `0x1002944c`: the reference has `"rb\0\0"` then the gzip magic dwords `0x1f` / `0x8b`, then the vfs.c path. The build had `vfs4.c`'s named strings starting immediately at that VA: twelve bytes short.

### The fix

Prepend the three missing symbols in `vfs4.c` before the existing path/message arrays:

```c
char s_rb_1002944c[4] = { 'r', 'b', 0, 0 };
unsigned int g_gzip_magic_1f_10029450 = 0x1f;
unsigned int g_gzip_magic_8b_10029454 = 0x8b;
```

Callers already push/cmp the raw addresses (`gm_Open`, `vfs_OpenStream`, `vfs_ReadData`); nothing needs to name these symbols, they just have to occupy the span.

Also retarget `vfs_ReadData.c`'s `sprintf`/`LogMessageInternal` to the named vfs4 symbols so the gz message is not also emitted as a `??_C@` COMDAT (same class as §151/§153).

### Result

- `0x1002944c..0x100294a0`: **84/84 matching (100%)**
- `.data` **23,779 → 23,526 (−253)**
- `.text` **8,635 → 8,637 (+2)**: codegen from switching the sprintf args from a literal+raw-address cast to named symbols (`vfs_ReadData.obj` md5 changes)

### Next miss

`0x100294a4`: reference has `"0x%08X -> length: %u, read: %u compressed: %u"`; build has `z_errmsg` from `zutil.c`. Same text-vs-data ordering class as §154.

## 156. A raw address cast emits no data; a named array in the right TU does (round 9 of the data pass)

§155 left the first miss at `0x100294a4`: the reference has
`"0x%08X -> length: %u, read: %u compressed: %u"` before `z_errmsg`. The build
had `zutil.c`'s pointer table occupying that slot.

### The fix

`vfs_OpenStream.c` already linked immediately before `zutil.c.obj` (CMake
`order-sources` / objects1.rsp). The sprintf used a raw address cast
`(char*) 0x100294a4`, which emits **no** `.data`: nothing defined the bytes.
Defining the string as a named array in that same TU places it right before
`z_errmsg`:

```c
char s_0x_08X_length_100294a4[] = "0x%08X -> length: %u, read: %u compressed: %u";
char pad_100294a4[2] = { 0 };
```

Declared before use (MSVC6 C requires it). sprintf retargeted to the symbol.

### Result

- `0x100294a4..0x100294d4`: **48/48 matching (100%)**
- `.data` **23,526 → 23,472 (−54)**
- `.text` **8,637 → 8,634 (−3)**

### Quirk: raw address ≠ data

A cast to a hard-coded VA is a reloc in `.text`, not a definition in `.data`.
If nothing else defines those bytes, the slot stays empty / gets filled by the
next object's contribution. Same class as the stub-duplication bugs, but the
failure mode is "nothing emitted" rather than "emitted twice."

### Next miss

`0x100294d4`: `z_errmsg` pointer table: reference and build both have the
table, but some pointer values differ (`0x10024620` vs `0x10024f50`-class).
Likely a reloc/string-VA mismatch inside zlib, not a missing string.

## 157. Explicit zero-pad arrays are redundant under MSVC6 4-byte alignment (round 10 of the data pass)

§153/§154 spelled inter-string padding as `char pad_...[N] = { 0 };` next to
each named winsock string. Those arrays are zero-initialized, so MSVC6 puts
them in BSS (or a separate zeroed `.data` contribution that the linker parks
late). Map showed all 18 `pad_*` symbols clustered around `0x10034f00`:
exactly where `z_errmsg`'s empty-string pointers were resolving late.

### The fix

Drop every `pad_*` array. Every inter-string gap in the reference
`0x10028bdc..0x10029408` run is exactly the natural pad to the next 4-byte
boundary after the string's NUL. MSVC6 aligns each subsequent `char[]` to 4
bytes and fills the gap with zeros: same bytes, no named symbol, no late BSS.

Same for `pad_100294a4[2]` after the vfs_OpenStream format string.

### Result

- Winsock / vfs4 / format spans still **100% matching**
- `.data` **23,472 → 23,470 (−2)**
- `.text` **8,634 → 8,636 (+2)**: placement
- Empty-string BSS slot moved earlier (`0x10034f50` → `0x10034f00`) but is
  still ~2.2 KB past the reference's `0x10034620`

### Next miss

Fixed in §158 (`"need dictionary"` now lands at `0x10027538`). Remaining:
CrashDump/EmitCrash `??_C@` COMDATs still occupy the LogFile slot at
`0x1002733c` (+136). Empty-string BSS is a separate cumulative gap.

## 158. Named dword before first string COMDAT (round 11 of the data pass)

First `.data` miss at `0x10027030`: reference has `dword 0xffffffff` then
`D:\Develop\Units\net\broadcast.c` then `Sending Broadcast`. Build emitted
only the two anonymous `??_C@` COMDATs from `LogMessageInternal(...)`
string literals: the leading dword was missing, so every later `.data`
symbol sat −4 (`"need dictionary"` at `0x10027534` vs `0x10027538`,
`g_crashdump_data` at `0x10027100` vs `0x10027104`, …).

### The fix

In `broadcast.c`, emit named symbols in REF order and pass them to
`LogMessageInternal` (kills the anonymous COMDATs):

```c
unsigned int g_broadcast_ff_10027030 = 0xffffffff;
char s_broadcast_path_10027034[] = "D:\\Develop\\Units\\net\\broadcast.c";
char s_Sending_Broadcast_10027058[] = "Sending Broadcast";
```

Same pattern as §154–§156: named symbol in the TU that already links at
the right place; never rely on a raw VA cast for data emission.

### Result

- Broadcast span `0x10027030..0x1002706c` now matches (60/68; residual
  is `1.1.3` / Error.c reordering, not the −4)
- `"need dictionary"` **aligned** (`0x10027538`)
- Winsock / vfs4 / format spans still **100% matching**
- `.data` **23,470 → 22,541 (−929)**
- `.text` **8,636 held**

### Failed approaches (do not retry without new evidence)

- Broad ErrorModule string reorder → `.data` ballooned to `0x6e80`
- CrashDump/EmitCrash COMDAT kill via blob `#define` aliases, pointer
  aliases, raw VA casts, or stack byte-inits → `.text`/`.data` both
  regressed (`0x6e0d`). Parked until a shape that preserves CrashDump
  codegen is found.

### Next miss

CrashDump/EmitCrash duplicate `??_C@` COMDATs (`\r\n` / separator /
`--> ` / `??? `) still sit in the LogFile slot at `0x1002733c` (+136).
Those bytes already live inside `g_crashdump_data_10027104`; the hard
part is killing the second emission without blowing CrashDump `.text`.


## 159. `gm_AllocSpieler`'s interpolation loop: the reference caches two floats in locals (round 985)

The second `__ftol` site in the flagship carrier carries a divergence the file header did not name. Both
sides emit exactly six `__ftol` calls at identical instruction positions, so the `(int)` cast lane is
already correct (re-confirmed: a plain `(int) d` emits `fld` + `jmp __ftol`, and ours match the reference's
six). The **operands** differ:

```
reference                             ours
0x10018bc8  fcomp dword ptr [ebp+0x20]      fld  dword ptr [ebp+0x20]
0x10018bcb  fnstsw ax                       fxch st(1)
0x10018bcd  test ah,0x41                    fcompp
                                            fnstsw ax
                                            test ah,0x41
0x10018bdd  fsub  dword ptr [ebp+0x20]      fsubr qword ptr [esp+0x24]
```

The reference compares and subtracts **`[ebp+0x20]`** (a *stack local*) where we read `[ebp+0x1c]`/`[ebp+0x20]`
off the slot. So the reference cached two `slot` fields into locals before the loop; we re-read them from
memory each iteration, which also forces `fld`/`fxch`/`fcompp` instead of a direct memory compare.

**The source site** (`gm_AllocSpieler.c:434-441`):

```c
if ((double) *(unsigned short*) (slot + 0xa) > *(float*) (slot + 0x20)) {
        acc = *(float*) (slot + 0x1c);
        for (n = (int) ((double) *(unsigned short*) (slot + 0xa) - *(float*) (slot + 0x20));
             n > 0; n--) {
                acc = acc - *(float*) (slot + 0x14) + *(float*) (slot + 0x14) / acc;
        }
```

**Probed and reverted: introducing the two locals overflows the carrier's span.** Caching `slot+0x20` and
`slot+0x14` in `float` locals and using them at all four sites measures
**obj 3712 against the reference span 3696 (+16)**, which collapses the composition: `split_poc` lands
0 symbols at their reference VA and every residue number becomes meaningless. `gm_AllocSpieler` is exactly
at its span, so it has **zero** headroom: any edit that adds frame must recover the bytes elsewhere in the
same object.

So the divergence is characterised but not bankable on its own. It is worth recording because it is the one
`gm_AllocSpieler` lead that is a *caching* decision rather than a scheduling one, and because the
+16 figure makes the size budget explicit: a future edit must remove 16 bytes elsewhere in the citizen path
before this shape can ship. The file header already records one candidate for that ("bankable only once
those 11 bytes are recovered elsewhere"), which is 5 bytes short of what this needs.

**Measured:** probe +16 obj (span violation, composition collapse), reverted; residue back to 8,628.

Section 44's aliasing lever was tested on `cm_ExProdObjekt` and is a wall there, not a lever. See
section 61a.

## 163. msvc6 canonicalises independent operations: the ORDER of two independent statements is inert (round 1105)

This project's standing rule is "statement order is the only lever that has ever landed". Measuring directly
against the compiler puts a boundary on it: **for two independent operations, source order is inert, and the
emitted order is canonical.** Statement order lands only when it changes the *dependency graph or a barrier*,
not when it permutes independent work.

**Experiment** (`scripts/msvc6_probe.py`, `/O2 /Gd`, the project's own compiler):

```c
int g;
int f(int* p) { int a = *p; int b = g; return a + b; }   /* variant 0 */
int g;
int f(int* p) { int b = g; int a = *p; return a + b; }   /* variant 1: swapped */
int g;
int f(int* p) { int t = g; int a = *p; return a + t; }   /* variant 2: renamed */
```

All three compile to **byte-identical objects**:

```
mov  eax, [esp + 4]
mov  ecx, [g]
mov  eax, [eax]
add  eax, ecx
ret
```

The compiler emits the argument load, then the global load, then the dereference: regardless of the order the
two loads were written in. **A sweep over source order cannot reach a site the scheduler has canonicalised.**

**What does drive it: the expression DAG's shape, not the statement sequence.** Moving the global read out of
the expression into its own statement *does* change the schedule, in an isolated probe:

```c
char* g;
int f(unsigned char* m) { unsigned idx; int lc; char* s;
  idx = *(unsigned short*)(m + 0x14);
  *(volatile int*)&lc = *(int*)(m + 0x16);
  s = g + (idx << 6);                       /* one expression */
  return (int)(s + idx); }
```
```
mov  ecx, [esp + 4]
xor  eax, eax
mov  ax,  [ecx + 0x14]
mov  ecx, [ecx + 0x16]
mov  [esp + 4], ecx
mov  ecx, [g]              <-- the global load, 6th
mov  edx, eax
shl  edx, 6
add  ecx, edx
add  eax, ecx
```

Against the same code with `s = g;` as its own leading statement and `s = s + (idx << 6);` later, which moves the
global load to **4th**:

```
mov  ecx, [esp + 4]
mov  eax, [ecx + 0x16]
mov  [esp + 4], eax
mov  edx, [g]              <-- 4th
xor  eax, eax
mov  ax,  [ecx + 0x14]
mov  ecx, eax
shl  ecx, 6
add  edx, ecx
add  eax, edx
```

So the lever exists, but it is **expression structure**, and it is weak.

**And it does not transfer to a large function.** Applying exactly that change to `cm_ExProdObjekt`
(`recipe_shift = g_item_def_table;` as a leading statement, then `recipe_shift = recipe_shift + (recipe_idx << 6);`
after the `msg` loads) leaves the emitted order **unchanged** in the real 993-byte function: the global load stays
5th where the reference has it 1st. Two other spellings at that site are also inert (rounds 1103-1105).

**The rule this yields.** msvc6's schedule is a function of the **whole function's** DAG and register pressure.
Two independent operations have no ordering in the DAG, so the compiler fixes one, and once a function has more
than a handful of live values, that fixed order is decided by global pressure rather than by anything local. A
probe on a 3-line function therefore cannot predict a 993-byte function's order, and local respelling cannot
steer it. **Matching the reference's order means matching the whole function's DAG**: which is a source-recovery
problem, not a spelling problem.

**Consequence for the "it must be possible" argument.** It is possible: the reference came out of this compiler
from *some* source, and that source's DAG produced this order. What the measurements rule out is reaching it by
permuting what we have. The remaining work is recovering the original expression structure at each differing
site, and `scripts/msvc6_probe.py` is the instrument for that: it compiles a snippet with the project's compiler
and dumps the instructions, so a candidate shape can be tested in isolation before it is applied.

## 164. msvc6 SINKS a load past an intervening store, and hoists it back when the value is USED first (round 1106)

This is the first backend rule this project has derived by querying the compiler rather than inferring it from
a diff, and it explains a whole class of "the global load is in the wrong place" divergences.

**The rule.** msvc6 does not move a load above a preceding store: it has no alias information that would let
it. A load whose value is only needed *later* is therefore scheduled after the store. Give that value a use
*before* the store and the load is hoisted to the top of the block.

**Evidence 1: a copy is not a use.** Source `s = g;` as its own leading statement, followed by a store:

```c
char* g;
int f(unsigned char* m) { unsigned idx; int lc; char* s;
  s = g;
  idx = *(unsigned short*)(m + 0x14);
  *(volatile int*)&lc = *(int*)(m + 0x16);
  s = s + (idx << 6);
  return (int)(s + idx); }
```
```
mov  ecx, [esp + 4]
xor  eax, eax
mov  ax,  [ecx + 0x14]
mov  ecx, [ecx + 0x16]
mov  [esp + 4], ecx        <-- the store
mov  ecx, [g]              <-- the load lands AFTER it
```
The `s = g;` assignment was copy-propagated away, so the load had no consumer above the store and sank.

**Evidence 2: a real use hoists it.** The same source with one dereference added:

```c
  s = g;
  first = *(int*) s;       /* <-- the only change */
  idx = *(unsigned short*)(m + 0x14);
  ...
```
```
mov  eax, [esp + 4]
mov  edx, [g]              <-- the load, now SECOND, ahead of the store
xor  ecx, ecx
mov  cx,  [eax + 0x14]
mov  eax, [eax + 0x16]
mov  [esp + 4], eax        <-- the store, now sixth
```

**Evidence 3: it lands on the real function.** `cm_ExProdObjekt`'s source had the table pointer's only uses
*after* the volatile store:

```c
recipe_idx = (uint)*(ushort*)(msg + 0x14);
*(volatile int*)&loop_count = *(int*)(msg + 0x16);
recipe_shift = g_item_def_table + (recipe_idx << 6);
```
and the load sank to 5th, where the reference has it **1st**. Giving the table pointer both of its real uses
before the store:

```c
recipe_idx = (uint)*(ushort*)(msg + 0x14);
recipe_shift = g_item_def_table + (recipe_idx << 6);
recipe_def   = recipe_shift + recipe_idx;
*(volatile int*)&loop_count = *(int*)(msg + 0x16);
```

moves the emitted block from this:

```
mov ebx,[ebp+0x16]   mov edx,[g_item_def_table]     <-- 5th, reference has it 1st
xor eax,eax          xor eax,eax
mov ax,[ebp+0x14]    mov ax,[ebp+0x14]
mov [esp+0x18],ebx   mov ebx,[ebp+0x16]
mov edx,[g]          mov ecx,eax
mov ecx,eax          shl ecx,6
shl ecx,6            add edx,ecx
add edx,ecx          add eax,edx
```

to this, which matches the reference for its **first five instructions**:

```
mov edx, [g_item_def_table]
xor eax, eax
mov ax,  [ebp + 0x14]
mov ebx, [ebp + 0x16]
mov ecx, eax
```

**The linked result is +6, and that is the informative part.** The head now matches but the *store* moved too
late: the reference interleaves it at `0x1000e21d`, between `mov ecx,eax` and `shl ecx,6`, where the same
restructure puts it after. So the rule is necessary but not sufficient: hoisting the load also changes where the
store lands, and the two must be matched together. The site is now a two-variable problem instead of a
canonicalised one, which is progress of a kind this project had not previously been able to make.

**Why this matters for the standing "is it possible" question.** It is possible, and this is the proof of
mechanism: a source-level change moved an emitted instruction to the reference's exact position, for a reason
that was predicted from the compiler's behaviour before the change was made. The remaining matches need the same
treatment: recover the original's use structure, not permute our statements.

**Method note.** All three experiments came from `scripts/msvc6_probe.py` in one command each. Rounds 1082-1104
spent ~20 probes across five carriers without finding this, because they varied *spellings of the whole
function* and read the link delta; this varied *one structural property* and read the emitted instructions.
The instrument choice was the difference.

## 173. A pointer comparison against a constant is unsigned; an int cast makes it `jl`

Measured on GOLDTL `fcn_004e7390` (0x4e7390) and `fcn_0053f8f0` (0x53f8f0), both
pointer-table drain loops.  The reference's back edge is `cmp esi,<end> / jl`
(**signed**), which a pointer-typed comparison cannot produce:

```c
int* entry;
for (entry = (int*) 0x14d0020; entry < (int*) 0x14d0c20; entry++)  /* -> jb */
for (entry = (int*) 0x14d0020; (int) entry < (int) 0x14d0c20; entry++)  /* -> jl */
```

One byte, and without it the function reports NEAR_MATCHING at an identical
object size (the `72 e6` / `7c e6` opcode pair is the whole difference).  The
same rule applies wherever the target shows a signed conditional on a loop
bound that the source naturally spells as a pointer: cast the comparison, not
the loop variable.

## 165. NaN-safe `fcom` vs `fcomp`: `test ah,5 / jp` is a `<`, not a `<=`

Measured on GOLDTL `fcn_004514d0` (0x4514d0, 38B):

```asm
fcom   dword ptr [0x6628f8]   ; st(0) vs the constant
fnstsw ax
test   ah, 5                  ; C0 | C2
jp     <ret>                  ; taken when st(0) >= mem, or unordered-with-C2-clear
fadd   dword ptr [0x6628c8]
ret
```

Decoding the taken path (`test ah,5` sets PF from `C0|C2`; `jp` takes it when
their parity is even): the add runs when `st(0) < mem` **or** the comparison is
unordered, i.e. the C is `if (value < c) value += k;`.  Both `!=` and `<=`
produce `test ah,0x41 / jnp` instead (same size, NEAR_MATCHING).  Write the
**less-than** direction, not the complement.

## 174. A constant-size struct assignment is `rep movsd`; `memcpy` of the same size is not

Round 105 of the goal session found a 40-member family of GOLDTL message
builders, all of one shape:

```asm
sub  esp, 0x9c
push esi / push edi
mov  esi, [esp + 0xa4]          ; the payload pointer
mov  ecx, COUNT                 ; constant
lea  edi, [esp + 0x18]          ; buf + 0x10
lea  eax, [esp + 8]             ; buf
mov  byte [esp + 8], TAG
push eax
rep  movsd es:[edi], [esi]
call fcn_004c4330
```

The C is a stack buffer plus two stores:

```c
char buf[0x9c];

buf[0] = TAG;
*(Body*) (buf + 0x10) = *a1;    /* struct assignment, NOT memcpy */
fcn_004c4330(buf);
```

**`memcpy(buf + 0x10, a1, 20)` produces 44 bytes of unrolled `mov`s** (round
1408 recorded the family as blocked on this).  The struct assignment of the
same 20 bytes emits `mov ecx,5 / rep movsd` and matches.  The threshold runs
the other way for larger counts: at 58 bytes (`memcpy(…, 0x3a)`) the intrinsic
does emit `mov ecx,0xe / rep movsd / movsw`, so 0x4c62c0 needs `memcpy` while
the small counts need the struct assignment.  When a `rep movsd` of a constant
size shows up and `memcpy` unrolls, try a struct assignment; when the copy has
an odd tail, try `memcpy` with the exact byte count.

**Odd sizes need `#pragma pack(1)`.**  0x4c63f0 copies 9 bytes: a dword, a
dword and a **byte** at +8 (`mov al,[eax+8] / mov [esp+0x1c],al`).  An
unpacked `struct { int a; int b; char c; }` has sizeof 12 and msvc6 copies all
three dwords; wrapping the typedef in `#pragma pack(push,1)` / `#pragma pack(pop)`
gives sizeof 9 and the member-wise dword/dword/byte copy the reference has.
Same for `{ int; int; short; }` (10, `0x4c6b60`) and `{ int; short; char; }`
(7, `0x4c6360`).

**Inventory sizes include trailing padding.**  0x4ce260's inventory entry says
74 bytes; the body ends at 63 and the last two "target instructions" in
`rebrew diff` are the next function's `nop` + `sub esp,0xe4`.  When `rebrew
diff` reports *0 structural differences* and only "target instruction(s) not yet
decompiled", set `// SIZE:` to the matched extent (the candidate's own size):
the file then promotes from SIZE_MISMATCH to RELOC with no code change.

**Two of the family are scheduling-hard** and were left reversed: 0x4c5b00 and
0x4ce210 have the right instructions and the right operands but the reference
hoists the call's `push` later than msvc6 does for any statement order tried
(struct param, `#pragma pack(1)` param, field-wise stores, named value local).

## 175. `fld dword ptr [g]` + `call <helper>` with no stack store is a float→int cast

Measured on GOLDTL `fcn_004c54c0` (0x4c54c0, 97B), which fills a message and
then stores two globals:

```asm
mov   ecx, dword ptr [0x67db54]
...
fld   dword ptr [0x67db50]      ; NO fstp, NO push
call  0x64d228                  ; returns the int in eax
mov   dword ptr [esp + 0x24], eax
```

A bare `fld` before a `call`, with no stack argument and no `add esp` after,
means the callee takes its argument in `st(0)` and returns in `eax`: the
`__ftol` convention (see the `__ftol` entry above).  The C is therefore

```c
*(int*) (buf + 0x24) = (int) g_67db50;   /* float global -> int */
```

Spelling it as a call to the helper (`fcn_0064d228(g_67db50)`) does **not**
reproduce it: msvc6 pushes the float as a dword and adds 4 to `esp` afterwards
(`mov eax,[g] / push eax / call / add esp,4`).  The cast is the source.

## 176. `push imm32` of a data address is `push offset g`, not `push [g]`

GOLDTL `fcn_004c5700` (0x4c5700, 98B) opens with `push 0x7f4c00`: the
*address* of a data object, as an immediate.  Declaring the global as a scalar
and pushing it (`fcn(a1, g_7f4c00)`) makes msvc6 hoist `mov eax,[0x7f4c00]` to
the top of the function and `push eax` later: same object size, 29 structural
differences, every instruction shifted by one.  Declare it as an array
(`extern char g_7f4c00[];`) and pass the name: the compiler then emits
`push offset g_7f4c00`, which matches.

The same function is another inventory-padding case: the entry says 112 bytes,
the body is 98.

## 177. A destination struct with internal gaps: spell the offsets, not the struct

GOLDTL `fcn_004c64b0` (0x4c64b0, 117B) writes a 7-parameter message into
`buf+0x14`: a byte, an int at **+3**, an int at **+7**, three bytes at +0xb,
+0xc, +0xd, then `strcpy` into +0x12.  A `#pragma pack(1)` typedef
`{ char a; int b; int c; char d; char e; char f; char g[]; }` puts `b` at +1
(and every later field 2 bytes early): NEAR_MATCHING, 6 structural diffs, all
of them displacements.

The destination is not one struct: the gaps at +1..+2 and +0xe..+0x11 belong
to something the function does not touch.  Spelling each store as
`*(int*) (buf + 0x17) = a2;` (etc.) reproduces the reference exactly.  When a
struct copy's *only* difference is a constant displacement, stop adjusting the
typedef and write the offsets.

## 178. Locals whose only use is an escaping pointer are dead-store-eliminated: group them

Measured on GOLDTL `fcn_00403040` (0x403040, 149B), which fills a three-float
vector and passes its address to `fcn_00402ab0`:

```c
float x, y, z;                 /* 10/149: the compiler keeps only x */
x = ent->f4c + e->f54;
y = ent->f50 + e->f58;
z = ent->f54 + e->f5c;
fcn_00402ab0(e, &x, 0);

float v[4];                    /* 137/149: all three stores survive */
v[0] = ent->f4c + e->f54;
v[1] = ent->f50 + e->f58;
v[2] = ent->f54 + e->f5c;
fcn_00402ab0(e, v, 0);
```

An individual scalar whose address is taken for one call is still a dead store
to everything that is never read through a *different* name; the compiler
drops `y` and `z` and the body comes out 34 bytes short.  The same three values
written into **one aggregate** cannot be dropped, because the callee receives a
pointer to the whole object.  When a reference computes several values and
passes only the first, write them into an array (or struct) and pass that.

The frame also settles: `float v[4]` gives the reference's `sub esp,0x10`
(three floats plus padding) where `float v[3]` gives `sub esp,0xc`.

## 179. `[esp + N]` argument reads: count every push that is still on the stack

The single most expensive misread in a `--no-ebp` function is a parameter
offset, because a wrong parameter index silently changes a *role* while the
instruction stream still looks plausible.  Three measured cases from the
GOLDTL `fcn_0051af00` caller family (round 136):

* `fcn_005b2810` (0x5b2810, 112B): `sub esp,0x40; push esi; push edi; push 2;
  call f; mov edi,[esp+0x50]`.  The `push 2` is **not yet popped**: its
  `add esp,4` comes four instructions later, so at that point `esp` is
  `E-0x4c` and `[esp+0x50]` is `E+4`, the **first** parameter.  The function
  takes one pointer, not two; declaring `(void* a1, void* a2)` moves every
  later offset by four bytes and the object comes out a copy away from the
  reference.  The same reading also identifies the untouched id value:
  `mov si,ax; and esi,0xffff` is an `int` local assigned from a callee
  declared `unsigned short` (a `unsigned short` local defers the mask into the
  branch instead).
* `fcn_005b33a0` (0x5b33a0, 100B): after the five pushes of the first call,
  `[esp+0x24]` is `E+0xc`: the **third** parameter, not the second.  Reading
  it as the second passes the wrong pointer to the second call and the
  register allocator then caches a value the reference reloads (`esi` for the
  wrong argument), so only 44/100 bytes match.
* `fcn_004f7740` (0x4f7740, 107B): the prologue is `mov edx,[esp+8]; push ebx`:
  the load happens **before** the push, so `edx` is the second parameter
  while the later `mov ecx,[esp+8]` (after the push) is the first.  Two
  parameters, both live, and `test bh,4` on `[ecx+0x1c8]` is `0x400`.

Procedure: write the running `esp` value under every instruction, count the
argument pushes that have not been undone (cleanup is often lumped at the
function end, see `fcn_005b2810`'s single `add esp,0x2c` for three calls), and
only then convert `[esp+N]` to a parameter index.  A mismatch in *which*
parameter is used shows up as a register-allocation difference (wrong
callee-saved register, an extra reload), which is much harder to read back from
the diff than the offset itself.

## 180. An early `int i = 0;` puts the loop counter in `esi`; `for (i = 0; …)` drops it to `eax`

Measured on the GOLDTL pool allocator `fcn_00403200` (0x403200, 110B) and its
GOLD twin `fcn_004029c0` (0x4029c0, 110B).  The reference prologue is

```
push esi / push edi / push <name> / push 0x244 / xor esi,esi / call <alloc>
```

`xor esi,esi` sits **above** the allocation call, and the loop counter never
leaves `esi`.  With `int i;` declared at the top and assigned after the
`memset`, MSVC gives `i` to `eax` (the accumulator is free once `rep stosd` has
zeroed it) and the function loses the `push esi`/`pop esi` pair: 95 bytes
instead of 110.  Spelling the declaration as a C89 **initialised** declaration

```c
	int i = 0;
	int v;
	void* p;

	p = (void*) fcn_0041db70(0x244, g_67536c);
	memset(p, 0, 0x244);
```

moves the initialization ahead of the call in source order, so `i`'s live range
crosses the call and the allocator must give it a callee-saved register: `esi`,
exactly as the reference.  A later `for (i = 0; …)` re-initialization dead-store
eliminates the early store and puts the counter back in `eax`; keep the loop's
init out of the `for` header.  Cost of the discovery: three probe batches.

## 181. A look-ahead `g[++i]` scan is the only spelling that rotates the free-slot loop

Same function.  After the counter colouring is fixed, twelve loop spellings were
compiled with the client toolchain.  All of the obvious ones:
`for (i = 0; i < 0x300; i++) if (g[i] == 0) break;`, the same as a top-tested
`while`, `while (i < 0x300 && g[i] != 0) i++;`, and `do { … } while (…)`, emit
the same *unrotated* body:

```
mov ecx,[esi*4+base] / test / je store / inc esi / cmp esi,0x300 / jl top
```

The reference instead has the first compare peeled to an absolute load plus a
rotated body that reads **one slot ahead**:

```
mov eax,[base] / test / je store
top: cmp esi,0x300 / jge fail
     mov eax,[esi*4+base+4] / inc esi / test / jne top
     cmp esi,0x300 / jge fail
```

Only the look-ahead spelling reproduces it byte for byte:

```c
	if (g_14d0020[i] != 0) {
		while (i < 0x300 && g_14d0020[++i] != 0) {
		}
	}
```

Two further points, both measured: the guard must read `g[i]` (index 0, so the
address folds to the absolute `mov eax,[base]`), and the **store-first** source
order after the loop (`if (i < 0x300) { store; return p; } fail;`) is what keeps
the found path inline and the failure epilogue out of line: the mirrored
`if (i >= 0x300) { fail } store;` order inverts only that last compare's
polarity (`jl` against `jge`) and no longer matches.

## 182. `K + (c ? 3 : 0)` fuses into an LEA; `c ? K+3 : K` does not

Measured on the GOLDTL/GOLD shared `fcn_005b24b0` / `fcn_005a9030` (162B), whose
4th log argument is one of two adjacent message ids:

```
mov cl,[esi+9] / neg cl / sbb ecx,ecx / and ecx,3 / add ecx,0x1330 / add eax,ecx
```

The obvious spelling `(rand() & 0xffff) + (0x1330 + (cond ? 3 : 0))` does **not**
produce it: MSVC folds the constant into a three-term LEA
(`lea edx,[eax+ecx+0x1330]`), one byte short, and the follow-on register
assignment then differs too (the sum lands in `edx` instead of `eax`, so the
next word load picks `ecx`/`ax` instead of the zeroed `edx`).  All of these
were tried and all fuse: the same sum with the constant first, with an explicit
`(unsigned char)` condition, with an `(int)` cast around the whole sum, and with
the condition materialised through the comma operator: the last one instead
hoists the temporary into `edi` across the call.

What reproduces the reference is writing the message id as a **two-constant
ternary**:

```c
    (fcn_0042e410(3) & 0xffff) + (*(char*) ((char*) a2 + 9) ? 0x1333 : 0x1330)
```

MSVC lowers a constant-pair ternary whose difference is a small mask as
`neg/sbb/and (K1-K2); add K2`, and that `add K2` is then a real instruction, not
a displacement, so the outer sum stays `add eax,ecx`.  Rule: when a reference
has `and reg,N; add reg,K; add acc,reg` for a condition-dependent constant, the
source wrote the two full constants in a ternary, not `K + (c ? N : 0)`.

## 183. One source for two targets: only data addresses need per-target markers

Measured while sharing `fcn_004ec660` (GOLDTL 0x4ec660) with its GOLD twin
0x4ea8e0.  The two bodies differ in four addresses only: three call targets
(0x4e8d10/0x4e7150, 0x51af00/0x517700, 0x545d40/0x53e000) and one `push imm32`
string (0x68deb8/0x60f188), and the **call targets do not matter**: an `e8`
target is a relocation slot, masked in the RELOC comparison, so the shared file
may keep calling the GOLDTL names and the GOLD object still scores 174/174.
The absolute data address does matter (no fixup), so it gets a marker pair:

```c
// GLOBAL: GOLDTL 0x68deb8
extern char g_68deb8[];
// GLOBAL: GOLD 0x60f188
extern char g_68deb8[];
```

Three practical rules, all hit this round:

* each marker must be **immediately** followed by a declaration of the symbol it
  names, otherwise the reloc scanner warns "has no declaration on the following
  line" (a marker stacked on another marker does not count);
* if the symbol is already annotated for that target in an owning file, do not
  repeat its marker: declare a bare `extern` there and keep only the *other*
  target's marker in the shared file (`g_774a80` is owned by
  `GOLDTL.fcn_005b2a00.c`; repeating `// GLOBAL: GOLDTL 0x774a80` raises the
  "also annotated in" warning);
* new GLOBAL markers need their SECTION metadata or they add W016 warnings;
  `rebrew lint --fix --all-targets` backfills it into the read-only
  `src/rebrew-data.toml` (never hand-edit that file, it is mode 444).

## 184. A bound spelled `base + constant` still encodes as one immediate

Round 167 (TODO) recorded that replacing a literal loop bound with a **symbol**
defeats the loop analysis and changes the shape, so address-differing twins whose
bound is an immediate were left alone.  Measured again on the shared
`fcn_004ea560` (GOLDTL 0x4ea560) / `fcn_004e87e0` (GOLD), where the loop walks
0x300 entries of stride 0x21c and both the start and the end are immediates in
the reference:

```
mov esi, 0x7f4ca4            ; GOLD: 0x770b84
...
cmp esi, 0x85a0a4            ; GOLD: 0x7d5f84  (= start + 0x65400)
```

Declaring the start as a per-target symbol and deriving the bound from it is
byte-identical on **both** targets:

```c
extern char g_7f4ca4[];                    /* GOLDTL 0x7f4ca4 / GOLD 0x770b84 */
...
    p = g_7f4ca4;
    ...
} while ((int) p < (int) (g_7f4ca4 + 0x65400));
```

The `cmp` keeps its immediate form because `symbol + constant` is a relocatable
expression the assembler folds into the fixup's addend; nothing is spilled to a
register and the loop shape is unchanged.  What breaks (round 167) is a bound
that is an **unrelated** symbol, not the start plus a constant.  Note also that a
*plain literal* immediate carries no fixup at all, which is why the shared file
must not use one: the two targets' literals differ and are not masked.

The symbol may already be owned by another file (`g_7f4ca4` is annotated in
`GOLDTL.fcn_00549330.c` for both targets), declare a bare `extern` here and add
no markers (section 183).

## 185. `ServerMainThread`'s transfer-size packet: dropping `volatile` fixes the push order and costs 4 linked bytes

At 0x100093a0 the `if (sent_bytes == 0xffffffff)` arm builds a command packet. The reference
pushes both call arguments first and fills the packet after them, storing `eax` (still holding
the compared `-1`) at `cmd+4` and the total size from `ecx`:

```
mov ecx, [0x101deac0] / lea edx,[esp+0x10] / push edx / push ebp
mov byte [esp+0x18],8 / mov byte [esp+0x1b],0xff / mov [esp+0x1c],eax / ... / mov [esp+0x28],ecx
```

The shipped source stores `sent_bytes` through a `volatile` cast to block the constant. That
barrier is what holds the packet stores *above* the pushes. Measured with
`scripts/probe_function.py` and `scripts/instr_diff.py` on a copy of the file (round of
2026-09-24, aligned instructions out of 627):

| spelling of the `cmd+4` store and the read | aligned | effect on this hunk |
|---|---|---|
| shipped: volatile store of `sent_bytes` | 576 | stores above the pushes |
| plain store of `sent_bytes` or of `0xffffffff` | 579 | push order now matches; only `0xffffffff` for `eax` and `eax`/`ecx` for the size remain |
| `volatile` moved to the `cmd+0` or `cmd+0x10` store | 576 to 577 | stores above the pushes again |
| size read moved to the store (`= *(unsigned int*) 0x101deac0`) | 483 | 3 bytes short, layout shifts |
| store `*transfer_progress` instead of `sent_bytes` (read volatile or not, first or in order) | 466 to 530 | the loop pointers swap `ebx`/`ebp` |
| one-case `switch (sent_bytes)` in place of the `if` | 520 | the case block moves out of line |

So the hunk reduces to one mechanism: with no barrier, msvc6 knows `sent_bytes == -1` on the
edge and emits the immediate, which frees `eax` for the size load. Every killer that keeps
the `cmp eax,-1` isel is still missing.

**Linked result: the plain store is +4 worse.** `scripts/linktest.sh` on a fresh worktree
build, baseline and candidate differing only in that one `volatile`, each run twice with identical
results: linked `.text` residue
11,735 -> 11,739. The better push order does not pay for the substitution and the register
swap it exposes, so the shipped `volatile` stays. `rebrew test --linked` cannot judge this
function: its shell DLL does not provide the Win32 imports or CRT (`LNK2001` on
`__imp__GetPrivateProfileIntA@16`, `_strrchr`).

## 186. `gm_AllocSpieler` has unreversed client twins: the same compiler with the Processor Pack code generator

The server's 0x10018850 references six strings; two of them (`gm_AllocSpieler: array
overflow...` and `gm_AllocSpieler(): gm_CurrentHumanFamilyCount overflow`) also exist in both
clients, and exactly one function in each client references them:

| target | VA | size |
|---|---|---|
| SERVER | 0x10018850 | 3689 |
| GOLDTL | 0x50a7e0 | 3888 |
| GOLD | 0x507690 | 3872 |

Neither client twin is reversed (no marker in `src/`, no metadata entry), and `rebrew
cross-import --from server.dll` does not propose the pair. The clients are 199 (GOLDTL) and 183
(GOLD) bytes larger, so the bodies are not interchangeable. All three binaries come from the
same compiler, cl 12.00.8804; only the code generator differs, Processor Pack for the clients
and plain for the server (`general-knowledge.md`). Where the server's output leaves the source
shape ambiguous (the sympathy-loop zero-extend, codegen-walls §34), the client disassembly is a
second compile of the same function through the other code generator, the way section 90 used
sp5-pp. Found by matching string
contents across images (`pefile`: collect the function's imm32 string pointers, find the same
bytes in the client, list client functions that reference them).

**Checked at the largest wall (codegen-walls §34).** Every `lea r, [eax + eax*2]` in the three
bodies, with the four instructions before it, disassembled with capstone: the server's seven
`xor eax,eax` + `mov ax, word ptr [reg]` zero-extends (0x1001911b onward) appear at the same
seven sites in GOLDTL (0x50b0b3 onward) and GOLD (0x507f63 onward), with the same `edi` cursor
and the same interleaved `push 0x40`/`push 0x20`. The one register difference is the third
site's base, `[esi]` in the server against `[edi]` in both clients. So both code generators emit
the reference's idiom from the original source, and the client bodies give no independent
signal at this wall. What they do establish: our `and eax,0xffff` comes from how our C spells
that read, under the same compiler, not from the code generator.

## 187. A raw integer address is not a symbol: msvc6 keeps loads through it across calls

Measured on `gm_AllocSpieler` (0x10018850), `/O2 /Gd`, and reduced to a minimal file with the
function's own declarations. The mutual-sympathy block reads the new entity's id
(`*(unsigned short*) slot`) around four `gm_RandomMod` calls; the reference reloads it for
each statement (8 loads), our build loaded it once and kept it in a callee-saved register.

- In isolation the block reloads exactly like the reference: calls kill the load.
- One preceding `if` restores the reuse, whatever its body (`if (x) g_citizen_count--;`,
  `if (x) ahm_ResetEntityState(slot);`, `if (x) *(int*) 0x10035434 = 0;` all do; the
  unconditional statement or the bare load does not). The branch makes the id load a global
  CSE candidate, and in that pass the calls do not kill it.
- The deciding factor is where `slot` comes from. `slot = (char*) 0x100358a0 + idx * 0x21c`
  (raw integer address) keeps the reuse; `slot = (char*) g_slot_table + idx * 0x21c` (the
  project's symbol for the same address) reloads after every call, 8 or 9 loads, as the
  reference does. Spelling the scan loop, the address arithmetic or the store form
  differently changes nothing.

So msvc6 treats memory reached from a raw integer constant as something a call cannot
modify once global CSE sees it, and memory reached from a global symbol as something any
call may modify. The original was written against symbols. Consequences on this function:

- the two sympathy loops needed `volatile` reads only because the raw addresses let msvc6
  keep the id; through `g_slot_table` and `g_relationship_matrix_primary/secondary` the
  plain reads reload and emit the reference's `xor esi,esi; mov si,[ebp]` zero-extend
  (the `and 0xffff` count against the reference fell from 14 : 8 to 10 : 8);
- `g_entity_type_table` in place of `*(unsigned char**) 0x100a8c30` moved the link
  12,060 -> 11,917 by itself.

A symbol only works where the build defines it: a name listed in `rebrew-data.toml` still
needs a definition in `src/link_stubs.c` (postlink replaces the data and rewrites the
operand addresses), or the link fails with `LNK2001`.
Before adding `volatile` to force a reload anywhere in this tree, check whether the address
has a symbol and try that first.

## 188. Read a parameter load net of the pushes still on the stack

At `0x10018d35` `gm_AllocSpieler` loads `[esp+0x43c]` for the father lookup. With the
frame at `0x41c` and four saved registers, `[esp+0x43c]` is the fourth parameter at
function entry, and the reconstruction passed `arg4`. But the mother's id is still
pushed for the first lookup (`push edx` at `0x10018d2d`, cleaned up by the `add esp,8`
after the second call), so the load is `[entry esp + 0x438]`: parameter 2, the value both
paths store at `slot+0x64` beside the mother id at `+0x60`. Looking the father up by the
right parameter also freed `edi`, which gave `arg6` the `ebx` the reference gives it (a
23-byte segment closed with no other change).

Two more of the function's semantic bugs came from the same kind of reading:

- a jump target: the two-parent path's mutual block ends in `jmp 0x10019572`, the
  *second* `gm_RandomMod(0x10)`, so the stat modifiers, counters and 1000.0f block belong
  to the no-parent path only. The reconstruction fell through into them and ran
  `gm_RandomQuadratic` and a counter increment twice;
- a frame slot: mother lives in `[esp+0x20]` and father in `[esp+0x18]` (the stores after
  each lookup), and the `+0x50/+0x58/+0x54` copy block tests `[esp+0x18]`, the father's
  type. The reconstruction tested the mother's.

Before reversing a spelling problem, map every `[esp+N]` load to its variable with the
push depth at that instruction.

## 189. `(double)` on one factor of a `float * float` product decides which operand loads

`*(float*) (slot + 0x1c) * g_float_const_b8` emits `fld [const]; fmul [slot+0x1c]`; the
reference has `fld [slot+0x1c]; fmul [const]`. Operand order in the source is inert
(msvc6 canonicalises commutative products), so are float-typed stores of the constant.
`(double) *(float*) (slot + 0x1c) * g_float_const_b8` (or the cast on the constant) loads
`slot+0x1c` first, at all three `+0x10` sites of `gm_AllocSpieler`.

## 190. In an x87 loop, the order the locals were initialised sets the evaluation order

`gm_AllocSpieler`'s aging loop is `acc = acc - decay + decay / acc` with `decay` a float
local in a stack slot and `acc` on the FPU stack. The reference evaluates the quotient
first and keeps `acc` for the subtraction (`fld [decay]; fdiv st(1); fxch st(1); fsub
[decay]; faddp`); with `acc = ...; decay = ...;` msvc6 duplicated `acc` instead
(`fld st(0); fsub; fld; fdiv st,st(2); faddp; fstp st(1)`). Assigning `decay` before `acc`
gives the reference's loop at both sites. Rewriting the expression does nothing: msvc6
reorders the commutative add, and `acc += decay / acc - decay` computes a different sum.
A `double` `decay` also reorders the loop but keeps it on the FPU stack, not in memory.

## 191. A pointer local keeps an address apart from the load or store through it

Two forms the reference has only with a named pointer:

- `char* p = table + key * 0x24d; if (*p ...)` emits `lea eax,[edi+eax*4]; mov al,[eax]`
  where a byte local folds to `mov al,[ebx+eax*4]` (`gm_AllocSpieler`'s location block,
  the same spelling as `gm_CheckEntityType` in `spiel6.c`, RELOC);
- `stat = slot + 0x82 + rnd; *stat = (char) (*stat + 0x2a);` emits `mov cl,[eax+ebp+0x82];
  lea eax,[eax+ebp+0x82]; add cl,0x2a; mov [eax],cl`, where every indexed spelling
  (`+=`, casts, `(slot + 0x82)[rnd]`) folds to `add byte ptr [eax+ebp+0x82],0x2a`,
  10 bytes shorter.

## 192. `unsigned short` for a 16-bit draw: one mask, and `fild` before the product

These `gm_AllocSpieler` call sites narrow the `gm_RandomMod` result to 16 bits
with `and eax,0xffff`; that consumption does not establish the helper's declared
return type. Stored into an
`int` with `& 0xffff` and used as `(double) (unsigned short) rnd`, it is masked twice;
without the cast msvc6 folds it into `fiadd [temp]`. An `unsigned short` local masks once
and converts with `fild` ahead of the `slot+0x1c` products, as the reference does at all
three `+0x10` sites. It must be its own variable: the four-way pick in the same function
compares its roll as a 32-bit `int` (`cmp eax,3`), and retyping that one emits `cmp ax,3`.

## 193. Byte arithmetic in a `char` temporary; index expressions without an index local

- `colv = (char) (0x7f - gm_RandomMod(0x20)); *p = (char) colv;` with `int colv` emits a
  `movsx` per store; a `char` temporary gives the reference's `mov cl,0x7f; sub cl,al`.
- A named index (`colv = id + j * 0x300; P[colv] = ...; S[colv] = 0;`) loads the id straight
  into the index register and adds. Writing the index into each store lets msvc6 share it
  as its own common subexpression: the id goes to a scratch register and the index is
  formed with `lea` into a callee-saved one, 2 bytes longer per loop, as in the reference.

## 194. Table reads through a symbol emit `[r*2+disp]`; a raw integer base emits `[r+r+disp]`

`*(char*) (0x10030ba5 + x * 6)` compiles to `lea eax,[eax+eax*2]; mov cl,[eax+eax+0x10030ba5]`.
Through an `unsigned char` array symbol, `g_stat_table_30ba0[x * 6 + 5]`, the load is
`mov cl,[eax*2+g_stat_table_30ba0+5]`, the reference's encoding. Same length, different
bytes. Like section 187: when a raw address is in the source, try the symbol.

## 195. Symbolising only some constants can flip an unrelated FPU arm

In `gm_AllocSpieler`'s per-trait selection the three arms share the reference's tail
`fmul [0x100256b0]` only in some builds; in others arm 2 loads the constant first
(`fld [c]; ...; fild; fmulp`, 8 bytes longer) and the tail is not shared. With the float
constants as raw addresses or all as symbols, arm 2 matches; symbolising one of them
(`0x100256b0`, `0x10025714`, or the `c4`/`c8` pair) or several other unrelated edits flip
it. The mechanism is not known; treat an arm-2 regression after an unrelated edit as a
tie-break, not as a property of that edit.

## 196. `ServerMainThread` to byte-exact: symbols, plain memory reads, a promoted flag, and a `while`

`ServerMainThread` (0x100093a0, 2434 bytes) had sat at 576 of 627 aligned instructions with
its residue documented as walls (register roles, the packet's constant substitution, the
`lea`/`add` payload address, the loop-tail polarity). Four source changes made it
byte-exact in the linked build; each was measured alone.

1. **Every global through a symbol** (`g_connections`, `g_download_*`, `g_players_synced`,
   ...) instead of `*(T*) 0x...`. The section 187 effect on a whole function: the packet
   store/push order, the payload `lea esi,[eax+ecx]` (the reference's three-operand form,
   where raw addresses gave `add`), the sync-block read order and several register choices
   all changed to the reference's. Aligned 77.5% -> 86.9% in one step.
2. **Read the memory, not a local copy, where the value is compared.** The transfer loop
   tests `*transfer_progress == 0xffffffff` and stores the same value into the packet. With
   `sent_bytes = *transfer_progress; if (sent_bytes == -1) ... = sent_bytes;` msvc6
   propagates the compared constant into the store (`mov [..],0xffffffff`); reading
   `*transfer_progress` in the test, the store and the other branch's address keeps the
   register (`mov [esp+0x1c],eax`), as the reference does.
3. **A global cleared inside its scan loop is promoted.** `g_players_synced = 1; do { if
   (...) g_players_synced = 0; } while (...);` makes msvc6 keep the flag in `edx` through the
   loop and emit the initial store of 1, which the reference has. Clearing a local and storing
   it after the loop drops that store as dead (6 bytes).
4. **Loop form decides the back-edge encoding.** `phase_complete = 0; while (phase_complete
   == 0) { ... }` compiles its tail to `je top; jmp exit`, the reference's; `do {} while`
   and `for (;;)` with a `break` all give `jne exit; jmp top` (codegen-walls section 19).

The definitions for the new names live in `src/link_stubs.c`; postlink moves every operand to the
reference address, so only the name has to resolve.

## 197. A fill loop is not a `memset`: the destination keeps its own register

msvc6 /O2 turns a counted store loop (`for (i = 0; i < 8; i++) p[i] = -1;`) into the
same `rep stosd`, or the same run of `mov`s for a short count, that the intrinsic `memset`
emits. The difference is the destination. `memset(dst, v, n)` compiles `dst` straight into
the pinned `edi` (`lea edi,[edx+disp]`). The loop keeps the destination as a register
candidate of its own, which the colourer places wherever it can: `lea edx,[edx+disp];
mov ecx,8; mov eax,esi; mov edi,edx` in the reference header of `gm_AllocSpieler`
(0x100188fa), or `lea edi,[ebp+0x5c]` ahead of `mov ecx,8` (0x10019455). For a run of
stores the loop also keeps the fill value out of the function-wide constant CSE: the
parent path's five `-1` stores use `or ecx,-1`, and the following loops compare with
`cmp eax,-1`, where five separate assignments share one `-1` register across both loops.

Signatures in the reference:

- `mov edi,<reg>` right before `rep stosd`, where `<reg>` is dead afterwards.
- `lea edi,...` scheduled before `mov ecx,<count>`.
- A zero or `-1` in a different scratch register than the surrounding code would pick,
  shifting the next temporaries by one (`eax` -> `ecx` -> `edx`).

`gm_AllocSpieler` had four such fills written as `memset` or as separate stores: the header
`-1` fill, the no-parent `-1` fill, the parent path's `slot[0x68..0x78] = -1`, and the 16-byte
clear at `+0x1b4`. Rewriting each as a loop took the probe from 327 to 2984 of 3689 bytes
matched positionally, with the size exact, and the linked residue for the function to 515
bytes. The fourth alone moved it from 1633 to 2984: the misplaced zero register had
shifted every scratch choice after it.

A `do { p = ...; } while (0);` around the pointer assignment reproduces the header form
too; a plain `{ }` block does not, and neither does a pointer local, `__inline`, a
parameter, `volatile` or any destination spelling (some 40 spellings, in the function and
in a 40-line reproduction). `memset(slot, 0, 0x21c)` and `memcpy(slot + 0x88, ...)` stay library calls: as loops they
compile identically or worse.

`ahm_ExAllocAlchemist` (0x1000bdf0) has the same header signature (`lea edx,[edx+0x100358fc];
mov edi,edx` at 0x1000bef4). The loop form there makes its instruction count equal the
reference's (286) but lowers alignment while its `volatile` workarounds remain; not applied.

## 198. `gm_AllocSpieler` from 515 to 17 linked bytes: temporaries and variable identity

After section 197 the remaining residue was register rotation and frame-slot order. Each
item below was found from the reference's code and measured alone:

- **The draw inline in the blend.** The citizen path's `+0x10` value calls
  `gm_RandomMod(...)` inside the expression; a `draw` local made the draw block count as a
  candidate in the block where `ent`'s uses are weighed (msvc6 multiplies a candidate's uses
  by the number of candidates referenced in the same block, `msvc6-allocator.md`), which put
  `ent` ahead of the parent loops and rotated every parent-path register. With the call
  inline all five loops take the reference's registers.
- **Double temporaries.** `blend = gm_RandomQuadratic() * c;` before the `12.0f` store, and
  a second double for `[0x124]`/`[0x128]` (`scale = ...; [0x124] = (float) scale;
  [0x128] = (float) (scale * c);`). Re-reading `*(float*) (slot + 0x124)` keeps the later
  stack stores behind the `fst`; reusing one double for both sites leaves it on the x87 stack
  (`fld c; fmul st,st(1); fstp st(0)`).
- **Statement order around the scratch rotation.** `slot[0x18] = slot[0x1c]` after the
  `+0x10` blend, and `g_citizen_count++` before `slot[0x216] = 0`. msvc6 hands out
  `eax`/`ecx`/`edx` in rotation, so the order of two temporaries decides every scratch
  register after them (`msvc6-allocator.md`).
- **Variable identity sets the frame.** The per-trait weight is its own block-local float;
  the citizen aging uses its own `decay` but the shared `age`; the tail aging keeps its decay
  in the variable the per-trait loop used. Slots follow the variables, not the values: the
  reference's two aging blocks put `age` in one slot and `decay` in two.
- **One semantic fix surfaced on the way:** the no-parent trait loop stores the random value
  to `dst[2]` and `dst[0] * c` to `dst[1]`, like the parent loop's `0x90`/`0x8c`.

Two ordering differences remain with identical instructions on both sides: the order of the
two parameter reloads in the edge blocks at 0x10018c28/0x10018c38, and where `push 0xa` sits
in the parent 14-trait blend. Declaration order, loop-counter identity, cast spellings,
adjacent store swaps and aliasing (no escaped locals) all leave both unchanged; the traced
mechanisms and every later attempt are in `codegen-walls.md` section 49.

## 199. A two-constant ternary: of the spellings tried, only `c ? A : B` gives `setcc; dec; and A-B; add B` with a dword add

For a byte store of `rnd < K ? A : B`, msvc6 emits `cmp; setge; dec; and (A-B); add B`
with a dword `add` (`83 /0 ib`). Measured on the five class-pick stores of
`gm_AllocSpieler` (0x10018bb7 and 0x10019245..0x1001928a):

- `B + (c ? A-B : 0)` and `(c ? A-B : 0) + B` emit the same sequence with a byte add
  (`80 /0 ib`, `add dl,B`): one byte off per site.
- The swapped condition `rnd >= K ? B : A` (or `!(rnd < K)`, `K <= rnd`) emits `setl`,
  `and (B-A)`, `add A`: three bytes off. `K > rnd ? A : B` is the same IL as the original.
- `B - (c ? B-A : 0)` loads the base first (`mov cl,B; ...; sub cl,al`) and grows the code.

c2 creates register candidates for both arms and for `A - B` even where they are not
emitted, so these spellings also move node ids (`msvc6-allocator.md`, "Node ids are
recycled"). Constant spellings c1 folds leave the IL unchanged: `0xffu`, `(char) 0x7f`,
`'>'` for `0x3e`, `0x17fff` or `-0x8001` stored to an `unsigned short`, `*&param`.

## 200. Carrier wave, round 1145: the documented walls that were source shapes

Nine carriers closed to 0 linked bytes in one round (cm_ExCopyEntityData, ls_LoadBuildingEntityState,
vfs_OpenStream, gm_FindNextFilteredEntity, cm_ExSellObjekt, gm_CheckInventoryCapacity,
gm_ObjectsAvailble, vfs_ReadCompressed, cm_ExProdObjekt), and gm_AllocGebaeude went 328 -> 19. Every
change is in the function's own `.c` file and its header records the load-bearing shape. The shapes,
each measured with `scripts/linktest.sh`:

- **A pointer-compare scan is a counted index loop.** `cmp ptr, base+n*stride; jb/jl` comes from
  `for (i = 0; i < N; i++)` over `base + i*stride`: c2 strength-reduces the index to the pointer test,
  and a constant `0 < N` start folds the entry test. Hand-written pointer loops gave rotated scans,
  lost `mov ebp,0xffff` guard constants and merged epilogues (cm_ExCopyEntityData -463,
  ls_LoadBuildingEntityState, gm_ObjectsAvailble, gm_CheckInventoryCapacity, cm_ExProdObjekt).
- **A `return` inside a loop merges every return into one far block.** Without it, each entry guard
  keeps its own inline `xor eax,eax; pop esi; ret` (gm_FindNextFilteredEntity -226). This retires
  codegen-walls 2 and 39-43 as walls.
- **Duplicated source arms become the reference's out-of-line block.** `else { x = 0; goto done; }`
  written per case is merged by msvc6 into one block placed out of line; a single `else` or an
  `&&`/`||` chain places it inline (vfs_OpenStream, gm_FindNextFilteredEntity).
- **Clamps assign a separate variable in every arm**, `clamped = val` in the in-range arm too. That
  gives the reference's empty in-range `jmp store` and register arms; clamping in place gives byte
  immediates and out-of-line cold arms (cm_ExCopyEntityData).
- **One expression holding two calls keeps the first result in a compiler temporary** across the
  second. cm_ExSellObjekt's unexplained 4-byte frame hole was that temporary; writing the weight check
  as one expression matched every frame slot (-662).
- **A `volatile` load is the C form of the scheduling barrier.** c2 does not fold it into `[eax+ebx]`,
  so `mov ecx,eax; add ecx,ebx; mov cl,[ecx]` comes out (gm_AllocGebaeude; supersedes the "asm only"
  conclusion of section 69 and codegen-walls 4 and 6). Conversely, `volatile` reads added to pin a
  register were often the cause of the residue: removing them paid in cm_ExCopyEntityData,
  cm_ExSellObjekt, ls_LoadBuildingEntityState, vfs_ReadCompressed and cm_ExProdObjekt.
- **Byte flags through a bitfield struct** give `and al,0xf6; xor al,cl; or al,bl` and the matching
  register roles (vfs_OpenStream). The same rewrite exposed a real bug: `sprintf` was passed mode18
  twice where the reference passes mode14 then mode18.
- **A float blend as `v += a; v -= b;` on one local** gives `faddp`/`fsubp` with no trailing
  `fstp st(0)` (ahm_ExAllocAlchemist; the header had called `faddp` unreachable).
- **A state block written as `memset` plus `|= 1`** adds allocation candidates that give the -1
  sentinel `ebp` (ls_LoadBuildingEntityState). A 14-byte struct copy from a named global gives
  absolute operands where a literal-address cast puts the address in a register (gm_AllocGebaeude).
- **A dead initialiser orders frame slots.** `query = 0;` at the top put `query` and `slots` on the
  reference's `[esp+0x10]`/`[esp+0x14]` (gm_ObjectsAvailble).

- **A literal-address global read next to an address-taken local is pinned behind that local's
  stores**, because c2 must assume the literal may alias it; the named `extern` lets c2 fold the load
  into a scratch temporary and schedule it first, which put gm_AllocGebaeude's whole scratch rotation
  in the reference's order (-19, byte-exact). Only the sites that need it change: symbolising all
  four uses swapped the base/index operands of a later table fill.
- **An `int` shadow of a pointer local changes which copy feeds a store.** m_AllocTracked's `nodev`
  shadow made c2 store `count_max` from the compare's eax; with `node` used directly it stores from a
  second copy of `count_total` (`mov ecx,edi`) as the reference does (-15, byte-exact).

- **Cross-jumping only merges into the block that falls through to the jump target.** Two jumps to
  one label with identical tails never merge; the group needs its own join block whose statement
  compiles identically at every site and needs no scratch register (CrashDump's group-A switch arms
  join on the `hCrashLog` and `pStack` stores; an empty label collapses). Arms with three scratch
  temporaries keep a group on one starting register (the picker rotates eax, ecx, edx per function).
- **Deferred callee-saved saves need a join inside the region.** c2 saves ebx/edi late only when the
  paths through the region meet at a join block inside it, before the exit the skipping paths also
  reach (CrashDump: one exit, shared `VirtualFree`/`CloseHandle` cleanup; a late pass then copies
  the short cleanup and pops per path, as in the reference). Per-path cleanup or an all-`goto` exit
  saves all four registers in the prologue; separate early returns also defer but leave a second
  copy of the exit code.
- **`and r8,1` on a flag comes from a masked register candidate:** `if (...) { flag = (x > 0) & 1; }
  else { flag = 1; }`. With the constant assigned before the `if` the flag gets a stack slot; without
  the mask c2 folds it into the compare (CrashDump, -387 linked once the 2 bytes realigned the
  jump tables).

- **A may-alias store edge raises a store's scheduling priority.** The slot header's `or eax,-1`
  before `mov word [ebp],0xffff` (ahm_ExAllocAlchemist, gv_ExAllocGraveyardWorker) needs the word
  store's priority between 37 and 41: write it through the slot pointer and the following +4 store
  through the `g_slot_table` symbol, so c2 cannot prove them disjoint and adds an edge (priority 40
  -> 41). A `volatile` store is a barrier (edges to every later root); a plain store with no such
  edge ranks lowest and issues last. The 0xffff store and the later slot-index store must not both
  go through the slot pointer, or the 0xffff store dies as dead.

- **An overwritten store survives when the two stores spell the address differently.**
  ahm_ExAllocAlchemist writes 0xffff through `g_slot_table + idx * 0x21c` and the slot index
  through `slot`, with a named `g_citizen_count` read between: both stores stay. With both through
  `slot`, c2 drops the first. The earlier workaround, a literal-address read
  (`*(int*) 0x10035434`) that may alias `slot`, matched too but left the operand unrelocated.

- **A relocation to the wrong symbol is an object mismatch the link hides.** cm_ExSellObjekt
  (0x1000d930) sat at NEAR_MATCHING with 8 differing bytes, the `push imm32` operands at
  0x1000dd46 and 0x1000dec7: the source passed `g_error_msg_sell_no_source` / `_no_dest` where the
  reference pushes 0x1002cd48 (`g_error_msg_sell_failed`) / 0x1002cd14 (`_no_source`). The postlink
  data fixer rewrites `.data` operands, so the linked residue was already 0 and only `rebrew test`
  saw it. Resolve each differing `push` operand in the reference (`rizin -c 'pr 60 @ <addr>'`) and
  match the symbol in `src/rebrew-data.toml`: the fix changes the logged message to the original's.

- **A dead may-alias store keeps a single-use local a colouring candidate** (ahm_ExAllocAlchemist,
  closed to RELOC, -10 linked). `kind = cmd[0x10]; slot[0xa] = 0; slot[0xa] = kind;`: c2 does not
  forward a load past a store that may alias its source, so `kind` survives as a candidate, and
  only later deletes the dead store. Coloured before the constant 1, `kind` takes ecx and leaves the
  1 `dl` (allocator Finding 72); the post-register-allocation scheduler then hoists the
  `mov ecx,[esp+0x1c]` pointer load to 0x1000bf38, right after ecx's last counter use. Without the
  dead store `kind` is forwarded, the pointer load becomes a scratch pick (the 1 takes `cl`, every
  later scratch register rotates by one). The `volatile` read it replaces held the load behind the
  +0x1f0..+0x1e4 stores, and while it was in the source the 0x21c stride chain at 0x1000bebb used
  eax where the reference uses edx; every variant without it gives edx. Measured on the object: every spelling that copies `cmd_payload` into a local
  (plain, `register`, `*(int*)&x` and cast forms, a second use of the copy, `(void)&cmd_payload`) is
  forwarded or propagated away.

Flags follow the source: after these rewrites cm_ExSellObjekt and ls_LoadBuildingEntityState match
only without their `/Ow`, and the `vfs_OpenStream` size is its 701-byte COMDAT extent (jump table
included), not the 667-byte body.

## 201. `gv_ExAllocGraveyardWorker` (0x10011bf0) closes under plain `/O2`: the `/Ow` flag was the wall

The function matches (RELOC, 0 linked bytes) with `/O2 /Gd`, the flags of every other function in
`friedhof_logic_c`, and the slot-init stores written in the reference's order (+2, +0x1f0, +0x210,
+0x215..+0x218, ...). Under `/Ow` the best of the same sweep is 43 object bytes. What decides it,
traced in c2 (post-allocation list scheduler `0x10727977`, colouring select `0x1071f7b3`):

- **`/Ow` chains every store through `grave`** in source order, so symbol stores (the citizen
  count) have no edge into the chain and sink or float by register edges alone. Plain `/O2` adds no
  such chain: stores of equal height issue in source (sequence) order.
- **The citizen store's position comes from its one memory successor.** It may alias the later
  `req+0x15` read, so its height equals the grave stores' before that read: it ties with the +2
  store and, being earlier in sequence, issues right after the slot-index store (0x10011dff). The
  slot-index store goes through `g_slot_table`, may alias every later grave store and so outranks
  them; through `grave` it kills the 0xffff store as dead.
- **The `req` byte copy is a named local** (`type = *(volatile unsigned char*) (req + 0x15);`). As
  a colouring candidate it is coloured before the constant 1 and takes ecx over the 1's range, so
  the 1 takes dl (Finding 72) and the `req` reload lands at 0x10011df5 behind the object-id store
  (ecx write-after-read edge). Inline, the 1 takes cl and the reload edx (+68 object bytes);
  a plain local read hoists the reload above the counter stores (+68); `volatile` on the pointer
  instead (`*(char* volatile*) &req`) puts the citizen store ahead of the read (+15).
- `g_citizen_count++` stays between the entity stores and the object-id bump: that position gives
  the citizen temporary edi, and the load hoists to 0x10011dd2.

This supersedes sections 131 and 132 for this function: the `xor ecx,ecx; mov cx,[ebp]` zero-extend
and the `lea edi,[ecx+esi]` addressing both come out unchanged once the flags are right.
Measure a function's flags against its file siblings before treating a residue as a wall.

## 202. GOLDTL near misses closed by source shape (Processor Pack client)

Measured with `rebrew test --target Europa1400Gold_TL.exe` (Processor Pack code generator). Each
entry is keyed by the client address; the function's file header carries the load-bearing line.
The c2 routines used in the traces, and the client cases still open, are in `msvc6-allocator.md`
Finding 74.

- **0x402090: block scope shares frame slots.** Address-taken locals (`&w`, `&h`) and the locals of
  the inline-asm fill (`len`, `d`) declared in inner blocks give up their slots when the block ends:
  `pix` then lands in `w`'s slot (the dead parameter slot `[ebp+8]`), `len` in `h`'s, and the qword
  conversion temporary over `d`'s. Declared at function scope they keep their own slots (frame
  0x728 against 0x720).
- **0x41c190: a spilled local homed in a dead parameter slot.** The heap sift-down spills the
  midpoint `count >> 1` to the incoming slot of its first parameter (`[esp+0x20]`) and `idx` to the
  frame. With a separate `half` local c2 gave `idx` the parameter slot and `half` the frame slot.
  Declaring the parameter as the midpoint and copying it to the index first (`i = half; half =
  g_6b6f38 >> 1;`) gives the reference's slots, RELOC. A plain assignment is enough; section 14's
  `volatile` read is not needed when the value only has to live in memory.
- **0x41f8f0: test the global, then load it.** `if (g_6b6f84 != 0) { p = g_6b6f84; while (p->prev
  != 0) ... }` gives the walk pointer ecx and the CSE'd link eax, as in the reference. Testing a
  local copy (`p = g_6b6f84; if (p != 0)`) colours the pointer eax; the `q = p->prev; p = q` form is
  copy-propagated to `[eax+4]`.
- **0x43a3f0: a local pointer for an element load.** `h = *(int**) (b + 0x31c); x = f(h[i], 1);`
  gives `mov eax, [eax + edi*4]`; the inline `(*(int**) (b + 0x31c))[i]` loads into a new register.
  In the same function the bitfield clear `v->f0 = 0` written before `v->r = 0xff` puts the flag
  byte in `bl` and the bitfield byte in `dl`, as in the reference.
- **0x4af050, 0x4af800, 0x4afb60: frame slot order in block-fill prelude functions.** The fill
  pointer of the prelude (codegen-walls 6b) and the parse position passed as `&p` must be two
  locals in disjoint block scopes: the fill pointer in one block, the position with `rest` in the
  next. One shared `p` collects both sets of references plus the `__asm` tuple's operand lists
  (which name every address-taken local), so it reaches 6 references for 4 in the code, and since
  slots run by references per byte (allocator Finding 71) it sorts above `found` and `ids`. The
  two block-scoped locals share one slot, which is the reference's frame (`[ebp-0x14]` in
  0x4afb60, frame 0x22c in 0x4af800); at function scope they never share a slot. Frame weight
  trace: allocator "Frame slots", Processor Pack paragraph (GOLDTL 0x4af800).
- **0x4c8a30: stream pointer and destination in eax/ecx swapped.** `off = *(unsigned short*) p;
  dst = base + off;` with `unsigned int off`. Defining `dst` by the zero-extending load gave it six
  counted uses per loop block and priority 318 against the stream pointer's 316; with the offset in
  its own temporary the pointer is coloured first and takes eax.
- **0x4dc5f0: the common tail written in each arm.** The result store and the trailing `sprintf`
  repeated in both `if`/`else if` arms are cross-jumped into one tail whose `add esp,0x18` pops the
  arm call's 0x10 argument bytes with sprintf's 8; written once after the arms, c2 pops the 0x10 at
  the join. The same change moved the two pointer parameters onto the reference's esi/edi.
- **0x4ee6d0, 0x4f45b0: clamps are min/max macro expansions.** `#define MAXV(a, b) (((a) > (b)) ?
  (a) : (b))` and `MINV` likewise. `MAXV(MINV(100000.0, x), 10000.0)` gives the reference's repeated
  `100000.0` compare and shared `fld` arm; `MINV(MAXV(v, 0.0f), 1.0f)` puts the 0.0f and 1.0f cold
  arms in the reference's order. Hand-written `if`/`else`, `else if` chains and nested ternaries
  reach the same tests but not the layout; of the eight argument orders only these match. Same
  family as 0x4fc280.
- **0x4f0cc0: `fcom` issued before the first `fst`.** `v = *f - x; *f = v; if (!(v > 0.0f)) v =
  0.0f; *f = v;` with the literal: an `extern float` holding 0.0 may alias the store through `f`,
  so the compare's load gets an edge behind the store. The literal still compiles to `fld dword
  [const]`, not `fldz`, and matches the reference's 0x6628a8 load (RELOC).
- **0x4f58b0: a goto loop tested at the top.** `loop: if (i >= 0x800) goto end; ... i++; goto
  loop;` lays out the `-1` exit with its own epilogue ahead of `mov eax,-2`, which falls into the
  epilogue shared with `return res`. `for` and `while` emit the same instructions but let the `-1`
  exit fall into the shared epilogue and give `-2` the duplicated one. Found by `rebrew match run` (GA).
- **0x4fc280, 0x4fc2e0: two-sided clamp.** `return MIN(1.0f, MAX(-1.0f, (a - b) / b));` with
  `MIN(a, b) ((a) < (b) ? (a) : (b))` and `MAX(a, b) ((a) > (b) ? (a) : (b))`, the quotient written
  inline. The macro repeats the inner `MAX`; literal bounds let the compiler fold `1 < -1`, which
  gives the reference's jump from the first compare straight to the repeated `MAX`. Extern bounds
  compile to 95 bytes; a named quotient local is spilled to `[esp]`.
- **0x4fc3a0: counter and array pointer in swapped callee-saved registers.** Indexing `w` and `out`
  with a second counter `k` beside the call argument `i` gives the weight pointer esi and `i` edi.
  With `w[i - 0x11]` the user counter and the compiler's pointer tie at colouring priority 64 and
  the counter is listed first; with `k` both are compiler induction temporaries and the pointer is
  listed first. The product goes through a float local (`f = buf[6] * w[k];` before `out[k] =
  buf[6];`), so `fild` issues before the int store that may alias `buf`.
- **0x4ff080: `fxch st(1); fxch st(1)` before `faddp`.** Two named `float` locals for the addends
  (`a = x / v * 0.8; b = v * 0.001f * 0.2; return a + b;`): their rounding stores are dropped after
  the x87 stack is laid out and leave the exchange pair. Casting both terms to `float` leaves one
  `fxch`; `double` locals or a single expression leave none. The function must sit in the
  `fcn_004fef80` file (callees earlier in the unit keep edx/ecx live across the calls).
- **0x5b4f70: a 0/0xff call argument is two calls.** `f(..., type == 13 ? 0xff : 0)` gives `setne;
  dec; and`; `if (type != 13) f(..., 0); else f(..., 0xff);` gives the reference's `push 0; jmp` /
  `push 0xff` arms into one shared call. The clamp before it needs a separate variable in both arms
  (section 200) for the reference's register roles.
- **0x5c80f0: statement order decides colour.** Taking `me_h = &g_7f4ca0[g_774970]` before
  `district = sel + 0x59a` and reading `me_h->handle` gives the reference's ecx/edx/eax roles for
  the district block and folds the `* 4` into `[edx*4 + disp]`.
- **0x5c8400: two stores through one symbol chain each other and raise an earlier store.** The loop
  stores `lines[i].bar` from `eax` and then indexes `list[i]`; the reference issues the store before
  the `i` reload. Traced: the store's height was 22 and the `i` reload 15 plus the memory-read bonus
  (8), so the load won by one. The table stores `g_1016198[bar*0x3cc+0x34]` and
  `g_1015f40[bar*0x3cc+0x18]` are fields of one 0x3cc-byte array (0x1016198 = 0x1015f40 + 0x258);
  written through the same symbol (`g_1015f40 + bar*0x3cc + 0x28c`), c2 cannot prove them disjoint
  and adds a store-store edge, the chain gets one longer, the `bar` store reaches height 23, ties the
  reload and wins on sequence. RELOC. Same family as section 200's "may-alias store edges raise
  store priority", here through a shared base symbol instead of a pointer.
- **0x5d63e0: message header stores issued before the argument push.** The message struct is
  declared in the block that fills and sends it. At function scope the header stores written before
  the `e + 4` load get a may-alias edge to it (height 11 against the push's 9) and issue ahead of the
  push; block-scoped, the same stores have height 8 and issue after it, as in the reference.
  Measured on the scheduler trace, same statement order in both.
- **0x5dc990: two arms that send the same message.** `result` assigned on every path (`1` after
  each arm's send, `0` in each null branch) and one `return result;` keep the arms' call-and-return
  tails apart; with `return 1;` in the arms the second arm's call was cross-jumped into the first.
  Each arm declares its own message struct, which lets arm 2 store the type byte before the `e + 4`
  load (as in 0x5d63e0) while arm 1 stores `f8` first.

## 203. A separate product local preserves the field-first x87 load with a shared constant

Measured on `ahm_ExAllocAlchemist`, server VA `0x1000bdf0`, plain MSVC 6.0 SP5,
`/O2 /Gd /DREBREW_ALLOW_NAKED`. The complete reference extent is 1002 bytes.
Replacing the literal `0.33f` with `g_const_0_33` in an inline product changes
`fld [esi+0x1c]; fmul [constant]` to `fld [constant]; fmul [esi+0x1c]`:
998/1002 bytes match. Commuting the factors or reading the constant through a
`const float*` produces the same failure.

The matching source loads the field into a local and multiplies that local in
a separate statement:

```c
float v = (float) rand_value;
float* fp = (float*) (slot + 0x1c);
float product;

product = *fp;
product *= g_const_0_33;
v += product;
*(float*) (slot + 0x18) = *(float*) (slot + 0x1c);
v -= (double) *fp * g_const_0_1;
*(float*) (slot + 0x10) = v;
```

This keeps the reference's separate `fild`, field-first `fld`/`fmul`, popping
`faddp`/`fsubp`, and the `slot+0x18` copy between the updates. The product local
introduces no emitted memory spill in this function. A float local declaration
alone is not evidence of a rounding store; inspect the emitted instructions.
The `(double)` factor remains necessary for this subtraction's `fsubp` form.
Using a double factor for the *0.33 product* instead gives 1004 bytes and only
634 matching bytes here; §189's success on `gm_AllocSpieler` is site-specific.

The actual production file tests RELOC, **1002/1002**, with 46 relocation
slots. The shared constant's reference address is `0x100256b8`. Evidence:
`.scratch/native-float-scheduling/ahm-33-product-production.json`, the
`ahm-33-product.c` diagnostic, and the adjacent rejected `ahm-33-*.json` files.
The native linked audit confirms removal of one duplicate four-byte float;
the effect on section extent is discussed in `msvc6-link-layout.md` §10.

## 204. Extern float reads can change scheduling even when the value and width agree

Same plain SP5 `/O2 /Gd` profile as §203. Two literal-to-symbol replacements
in `ahm_ExAllocAlchemist` preserve all 1002 bytes:

```c
float fv = gm_RandomQuadratic() * g_const_7;
*(int*) (slot + 0x20) = 0x41400000;
*(float*) (slot + 0x14) = (fv + 30.0f) - g_const_2f;
```

The initializer keeps `fmul [g_const_7]` ahead of the `slot+0x20` integer
store. Replacing `30.0f` with `g_const_30` does not preserve the following
memory `fadd`: it hoists `fld [g_const_30]` above that store, uses a stack
`fadd`, and adds a trailing `fstp st(0)`. The object grows from 1002 to 1006
bytes. Values and native fixups are correct, but the instructions are not.

In `gv_ExAllocGraveyardWorker` (`0x10011bf0`, reference 1040 bytes), replacing
the 1000/8/4 float literals with their existing readonly symbols leaves the
body at 1040 bytes but only 1026 match. The remaining difference includes an
early `fdivr` ahead of the nearby integer stores. Replacing only 4 and 8 also
reproduces the 14-byte mismatch. These literal spellings remain necessary to
preserve these two bodies in the measured profile. Section 211 removes their
duplicate definitions by changing the other readers to literals instead.

The following negative controls are saved to avoid repeating them:

| Site and variant | Object bytes | Matching bytes | Result |
|---|---:|---:|---|
| Alchemist: direct extern 30; compound add/sub; commuted add; double `fv` local | 1006 | 571 | SIZE_MISMATCH |
| Alchemist: `*(float*)&g_const_30` or a mutable pointer local | 1006 | 571 | SIZE_MISMATCH |
| Alchemist: block-scoped extern before or after the `fv` declaration | 1006 | 571 | SIZE_MISMATCH |
| Alchemist: local const definition before/after the function, or local `selectany` owner | 1006 | 571 | SIZE_MISMATCH |
| Alchemist: file-static const, file-static mutable float, or block-static const owner | 1006 | 571 | SIZE_MISMATCH |
| Graveyard: const pointer/array read, quotient local, counter first, `for` initializer, commuted add | 1040 | 1026 | NEAR_MATCHING |
| Graveyard: mutable-pointer dividend or all three constant reads | 1040 | 1026 | NEAR_MATCHING |
| Graveyard: block-scoped externs before or after the float/int locals | 1040 | 1026 | NEAR_MATCHING |
| Graveyard: local definitions of all three constants before/after the function, or `selectany` owners | 1040 | 1026 | NEAR_MATCHING |
| Graveyard: file-static const, file-static mutable floats, or block-static const owners | 1040 | 1026 | NEAR_MATCHING |
| Graveyard: volatile result/stores | 1040 | 1023 | NEAR_MATCHING |
| Graveyard: float divisor | 1044 | 811 | SIZE_MISMATCH |
| Graveyard: double add | 1044 | 814 | SIZE_MISMATCH |
| Graveyard: volatile dividend, with or without volatile stores | 1044 | 835 | SIZE_MISMATCH |

The cast probes only read the existing const objects; they do not change their
definitions. Moving the externs changes their first declaration's scope, but
does not fix these cases. This rejects these particular spellings, not every
possible aliasing or declaration-order mechanism. An `/Oa` probe also failed;
a bounded three-minute flag sweep found no match and was not exhaustive.

The local-owner controls define the real constant values in the consuming
translation unit and replace the literals with their names. Definitions
before the function, definitions after it with preceding extern declarations,
and `__declspec(selectany)` definitions all reproduce the same failures.
Both unchanged literal controls still pass their complete 1002/1040-byte
bodies. Local readonly ownership alone does not recover these instruction
schedules. These isolated sources were tested with `--no-promote`; no
production source, metadata, library or link changed. The first graveyard
after-definition control lacked the declarations and failed to compile;
it was corrected before recording the body comparison.

Private ownership does not rescue these cases either. Fresh unique names
with file-scope `static const float`, file-scope `static float`, and
function-scope `static const float` all reproduce the same 1006/571
alchemist and 1040/1026 graveyard failures. Their unchanged literal controls
again pass both complete bodies. These tests distinguish internal linkage,
mutability and static block scope from the prior extern-visible owners;
they do not establish what MSVC would do for every constant expression or
optimization profile. None was promoted or linked into the canonical DLL.

Evidence: `.scratch/native-float-readers/`,
`.scratch/native-float-scheduling/{ahm-summary,summary}.json`,
`.scratch/native-float-scheduling/graveyard-quick-sweep.json`, and all eight
`.scratch/native-float-aliases/*.json` with their corresponding C files.
Local-owner controls and their unchanged full-match baselines are in
`.scratch/native-local-float-owners/{probe.py,audit.json,*-*.c,*-*.json}`.
Private-owner controls are in
`.scratch/native-static-float-owners/{probe.py,audit.json,*-*.c,*-*.json}`.
Production changes require a complete-body match before promotion.

## 205. Recover a native address operand without changing its scale or access width

Measured on the server with plain SP5 `/O2 /Gd`; office and kill-player tests
also carry `/DREBREW_ALLOW_NAKED`. `gm_AllocGebaeude` retains its existing
`#pragma optimize("y", off)` and existing block-fill prelude. These five
complete bodies recover eight formerly numeric address operands:

| Function | VA | Bytes | Newly native operands | Final object result |
|---|---|---:|---:|---|
| `plt_TableLookup` | `0x100151b0` | 41 | 2 | RELOC, 2 slots |
| `amt_ExecuteOfficeAssignment` | `0x1000b4d0` | 836 | 3 | RELOC, 37 slots |
| `gm_AllocBuildingDefaults` | `0x10017330` | 207 | 1 | RELOC, 9 slots |
| `gm_KillSpieler` | `0x10017fb0` | 278 | 1 | RELOC, 15 slots |
| `gm_AllocGebaeude` | `0x100174d0` | 1078 | 1 | RELOC, 49 slots |

**Record fields preserve the scale.** The plant table at `0x1002da30` contains
0x58 records of two ints, stride eight. Reading its fields emits the original
scale-eight loads, with native DIR32 fixups for both displacements:

```c
*out = g_plant_pair_table[index].first;
*(int*) ((char*) out + 4) = g_plant_pair_table[index].second;
```

**Narrow the read at the field, not the owner.** The office record is 24 bytes
at `0x10029bb8`. The original reads at `0x10029bc0 + role*24` are byte reads
of its int field `f8`; use `*(unsigned char*)&g_office_role_templates[role].f8`
at both sites. The read at `0x10029bc8 + role*24` uses the int field `f10`.
Declaring the whole table as bytes or comparing the full `f8` int would lose
the recovered record stride or access semantics.

**A packed record bound still folds into an immediate.** Building defaults
start at `0x10030860`, 37 records of 21 bytes. The bound at `0x10030b6a` is
one byte beyond the record array:

```c
(int) table_ptr < (int) (g_building_defaults + 37) + 1
```

This is a native symbol-plus-addend `cmp` immediate, without an extra load;
`0x10030860 + 37*21 + 1 == 0x10030b6a`. See also §184.

**Keep the low-word memory read of a wider owner.** The kill-player store is
`*(short*)(entity + 0x28) = *(short*)&g_current_year;`. The owner is an int
at reference `0x10035880`; the reference instruction reads only its low
16 bits. This spelling preserves that read and adds its native fixup.

**A plain symbol read can already give the required schedule.** The building
ID store now reads `g_next_object_id` directly:

```c
*(int*) (geb + 1) = g_next_object_id;
```

This preserves 1078/1078 bytes. Reading through `volatile int*` instead keeps
the size but matches only 982/1078: cleanup, the read, and subsequent stores
are rescheduled. The older comment requiring a raw address was stale. Retest
such comments against the current TU and flags before adding a barrier.

Evidence: `.scratch/native-symbol-operands/*-test.json` and the saved
`*-before.c` files. The canonical full verify passes 262/262 functions;
all 597 mapped functions retain their addresses, and the linked image now
has 3499 live base relocations, equal to the reference count. **Placement is
still wrong at 164 sites** (145 data, 18 readonly, one final unwind operand).
EXACT becoming RELOC here records real native fixups; it is not a loss of
instruction matching and does not establish correct linked data placement.

## 206. An unused extern declaration can affect another function's emitted schedule

Removing only `extern const unsigned char g_rdata_restore[];` from
`src/Develop/rebrew_globals.h` changes 80 bytes of `gm_Open`'s scheduling.
Restoring it recovers the complete match. The declaration has no storage
definition or active use; it does not restore the removed readonly blob.
Mapped function addresses remain unchanged in this control.

This is an empirical translation-unit sensitivity, not a demonstrated rule
that declaration order controls a particular register or alias edge. Compiler
symbol ordering is a hypothesis. §204's block-scoped float extern controls
did not reproduce a useful scheduling change. Keep unused-declaration removal
in the measured diff when cleaning a matching TU, and verify its affected
functions. The native readonly-owner checkpoint and restoration are recorded
in `docs/HANDOFF.md`; §195 describes a related declaration sensitivity.

## 207. Inline pointer tables can cause a false instruction diff despite a full byte match

This is a comparison-tool finding, not an MSVC instruction-selection rule.
`gm_AllocGebaeude`'s 1078-byte body contains inline pointer-table data. Before
the Rebrew fix, disassembling target addresses and candidate zero relocation
slots produced different instruction boundaries: `rebrew test` passed the
whole body while `rebrew diff` invented 39 structural rows and a missing tail.
The scorer could also assign a nonzero mnemonic penalty to an explicit
complete relocated-byte match.

Whole-buffer equality after masking the **provided valid relocation slots**
is decisive. Rebrew now uses reference boundaries for the equal candidate
buffer, retains the candidate's raw bytes, and emits `db` for slices that
cannot decode at that width. The scorer returns zero structural/byte metrics
for this equality case, preserving its existing prologue bonus. A wrong
unmasked byte or invalid relocation marker still follows the mismatch path.

Regression example: `c3 39 78 01 10 15 78 01 10 90 c3` against
`c3 00 00 00 00 00 00 00 00 90 c3`, relocation offsets `[1, 5]`. These
are equal after explicit masking; decoding the pointer bytes as code is not
evidence of a source mismatch.

The actual building diff now has 295 exact rows, 51 relocation rows, and zero
structural rows. Fix and regressions are in sibling Rebrew's
`src/rebrew/matcher/scoring.py` and `tests/test_scoring.py`; 321 targeted
scoring/diff/matching tests pass. Evidence:
`.scratch/native-symbol-operands/building-symbol-fixed-diff.json` and
`.scratch/native-symbol-operands/rebrew-matching-tests.log`.

## 208. Multidimensional struct arrays nest declarators in the C AST

This is a type-tool finding, not an MSVC codegen rule. Running `rebrew types check`
on the current source tree crashed on `float m[4][4]` in
`src/GOLD.fcn_004497f0.c`. Tree-sitter represents this as an outer
`array_declarator` whose `declarator` is another `array_declarator`, rather
than a direct `field_identifier`. Assuming an immediate identifier raises
`StopIteration` before layout checking begins.

The shared struct parser now follows the declarator chain to the field name,
keeps every array suffix, and returns an incomplete layout when no supported
field identifier exists. Existing recursive type sizing/alignment supplies
the multidimensional layout. The regression includes `float m[4][4]` and
`double grid[2][3][4]` after a byte field, checking names, full spellings,
offsets, alignment and final size.

The actual command now parses 1016 structs with zero findings; that absence
is not proof of every layout because the command only checks available
decompiler evidence. All 34 type-model/CLI tests, Ruff check/format and mypy
pass. The fix benefits the CLI, decompiler naming and BinSync consumers at
their shared parser. Evidence:
`.scratch/native-header-controls/canonical-release-types.json`; sibling
Rebrew's `src/rebrew/types.py` and `tests/test_types.py`.

## 209. A masked call match does not establish the callee's identity

Plain MSVC 6 SP5, project `/O2 /Gd` plus `/MT`: `vfs_FlushStream` at
`0x10003b90` in `src/Develop/Units/vfs/vfs2.c` had the wrong API at its
flush call. `fread(buffer, 1, used, stream)` and
`fwrite(buffer, 1, used, stream)` have the same argument shape. The reference
call at `0x10003bc5` targets stock `fwrite` at `0x1001a931`; the old native
call targeted `fread` at `0x1001aa6a`. Changing the C callee to `fwrite`
preserves all 182 bytes under object relocation masking (RELOC, two fixups)
and corrects the linked call. The stream's write-mode check and compressed
buffer flush agree with that binding. This is a source-semantic correction,
not an optimization-flag change or a CRT reimplementation.

Stock `memcpy` and `memmove` present a stronger ambiguity: both COFF `.text`
contributions are identical across all 821 bytes and 46 relocations.
`lib-match` correctly reports both names; body equality cannot choose one.
Their genuine CRT callers identify the reference binding. Swapping their
existing `/INCLUDE` positions puts `memmove` at `0x1001b200` and `memcpy`
at `0x1001eab0`, fixing ten linked CRT callsites without changing either
stock body. Details and callers are in `msvc6-link-layout.md` section 19.

The final raw PE `.text` audit masks only the actual HIGHLOW slots, not all
COFF relocation fields. A resolved direct-call REL32 displacement is not a
PE HIGHLOW slot, so wrong callees remain visible to this audit even when the
object comparison passes. After the binding fixes and section 20's native
alignment correction, the complete 143360-byte raw section has zero
unmasked differences and the same 3140 HIGHLOW sites. There are still 4644
raw differing bytes inside those slots because data/IAT addresses differ;
this establishes neither raw code equality nor whole-file equality.

Evidence: `.scratch/native-data-layout-audit/flush-fwrite-test.json`,
`unmasked-text-instructions.json`, `memory-section-hashes.json`,
`correct-memory-callers.json`, and
`canonical-alias-audit.json`.

## 210. Zero-code CRT aliases belong in library identity candidates

This is a library-tool finding. The unmodified SP5 `LIBCMT.LIB` has 40
`build\intel\st_obj\tcmap` members with machine zero, one empty `.text`,
and weak `SEARCH_ALIAS` symbols. For example `__tcschr` forwards to
`__mbschr`. LIEF rejects the machine-zero object, and a body-only library
index omitted its alias. It could consequently report `__mbschr` as
uniquely identified when the bytes cannot distinguish the two names.

Rebrew now parses these symbols with LIEF, normalizing the machine in an
in-memory parser copy only, and resolves aliases after indexing archive
bodies. No stock library or linker input is changed. AUX records count in
the target's raw symbol index; the compact LIEF symbol iterator does not
include them, so the lookup explicitly accounts for them. Alias chains
forward the existing body and relocation mask. Unresolved targets and
cycles without a body do not supply bytes or match anything. Provenance
records the alias member followed by the actual code owner.

The real `lib-match --va 0x1002377b` now returns `__mbschr` and `__tcschr`
as candidates, with null unique symbol/object fields. Regression checks
exercise machine-zero and ordinary i386 objects, raw indices after an AUX
record, chains, absent targets, cycles, batch/single-VA JSON, and an unchanged
archive. All 40 stock aliases are now indexed with no unresolved targets,
and the archive's SHA-256 remains unchanged. All 89 library/COFF tests pass;
Ruff and mypy pass. Evidence:
`.scratch/native-data-layout-audit/{alias-libmatch,stock-alias-index}.json`; fix in sibling
Rebrew's `gen_flirt_pat.py`, `lib_match.py`, `tests/test_lib_match.py`, and
`CHANGELOG.md`. Section 20 of the linker companion records what retaining
one such stock member does to native alignment.

## 211. Change the other readers to literals when symbolizing a literal breaks scheduling

Plain SP5 `/O2 /Gd`: the three `g_const_30` reads inside `gm_AllocSpieler`
at `0x10018850` can instead use `30.0f`, preserving all 3689 bytes under
relocation masking (140 fixups). The existing unused extern declaration is
retained. The reverse transformation need not reproduce section 204's
alchemist scheduling failure: these are different functions and expressions.

`gm_CalculateProductionValue` at `0x10019720` uses project
`/O2 /Gd /DREBREW_ALLOW_NAKED` and its existing scoped
`#pragma optimize("a", on)`. Changing the no-manufacturer arm from
`mod_value = g_graveyard_const_c;` to `mod_value = 4.0f;` preserves the entire
396-byte body and its 16 fixups. Full unchanged controls pass both bodies.
The pragma, declarations and other source shapes are retained.

These were the remaining active readers of the named 30/4 float owners.
The named 1000/8 owners already had no active readers. All four duplicate
ordinary `.rdata` definitions can therefore be removed, keeping the real
compiler literal COMDATs already required by alchemist and graveyard code.
The extern declarations in `game_float_constants.c` retain inventory labels
and define no extra storage. No assembler aliases, accessor functions,
library changes or postlink rewriting are needed.

Two native links check more than the isolated bodies. Changing the readers
alone leaves all extents unchanged and gives 31477 overlapping differences
at that diagnostic timestamp. Removing the four definitions as well reduces
`.rdata` VirtualSize from `0x2ea1` to `0x2e91`, leaving 16 bytes of excess
against `0x2e81`; the diagnostic has 30088 differences and the unchanged
16384-byte length gap. All existing mapped function positions, the 100 import
identities, DLL order, 23 displaced IAT slots and named hints remain unchanged.
The complete raw `.text` still matches after masking only its actual HIGHLOW
sites, and both images have precisely the same code fixup sites.

The readonly checker explicitly maps the four inventory labels to their real
MSVC `__real@4@...` symbols. It checks bytes, readonly flags and full extents
for all 52 values, and rejects a remaining named duplicate. The current
native build passes; the old native diagnostic fails with
`Duplicate literal owner: g_graveyard_const_a`. This checks values at their
actual native locations, not equality of their locations with the reference.
At this checkpoint the compiler pools are at `0x100252e8..0x100252f4`, and
placement remains unfinished. Linker companion section 23 records the
ownership result; section 24 restores the two strings' positions with native
object ordering and documents rejected constant and `/ORDER` controls.

Evidence: `.scratch/native-crt-storage-builds/literal_callers.py`,
`literal-callers-audit.json`, `link_literals.py`, `literal-links-audit.json`,
`canonical-literals-readonly.txt` and `rejected-duplicate-readonly.txt`.

## 212. Literal doubles can preserve memory operands and share the stock CRT pool

Plain SP5 `/O2 /Gd`, project `/MT`: both `g_const_one_d` reads inside
`gm_AllocSpieler` at `0x10018850` can use `1.0`, retaining the complete
3689-byte RELOC body and 140 fixups. The two expressions subtract a float
random value from the double constant before trait interpolation. Existing
casts, statements and unused extern declarations are kept. In these
expressions the literal rewrite preserves the required memory operands;
do not assume that every literal one becomes `fld1` or every operation folds.

`cm_ExChangeDesire` at `0x1000e9c0` can likewise replace its three active
`_g_stat_min_d` reads with `0.0`: two comparisons and the clamp assignment.
Its whole 214-byte body still passes RELOC with ten fixups. Keep the goto
join, double temporary, slot-addressing macro and extern declarations.
In this source shape zero does not introduce a shorter incompatible `ftst`
or load. Full unchanged controls pass both functions.

These remove all active readers of the two named double definitions.
Those definitions become extern inventory labels; the actual
`__real@8@00000000000000000000` and
`__real@8@3fff8000000000000000` COMDATs provide zero and one. Stock CRT
`cvt.obj` and `testfdiv.obj` use these same pool symbols. The reference
pointer operands prove the intended sharing: stock `__positive`'s operand
at `0x1001f2bb` targets `0x10025698`; `__ms_p5_test_fdiv`'s operand at
`0x1001f1d0` targets `0x100257d8`. Previously the native CRT instead read
separate doubles at `0x100260f0` and `0x100260b0`. Equal values alone would
not establish that ownership relationship. No CRT body is changed.

A separate successful but unpromoted probe changes only graveyard's
`1000.0f` read back to `g_graveyard_const_a`, adding its const extern
declaration. `gv_ExAllocGraveyardWorker` at `0x10011bf0` remains 1040-byte
RELOC with 34 fixups. This leaves its 8/4 literals unchanged. It does not
contradict section 204's failed rewrite of all three values at once; the
individual transformation has a different scheduling effect. Keeping the
named 1000 owner in native controls worsens placement, so it stays diagnostic.

The double rewrites and shared providers are promoted. All 52 readonly
checks now include six actual compiler-pool owners. The pre-change native
DLL fails the new duplicate guard for `_g_stat_min_d`. Native placement
results and the rejected zlib/code-order controls are in linker companion
sections 25–26. Evidence: `.scratch/native-pool-ownership/{readers.py,
readers-audit.json,pool-users.json,link.py,links-audit.json}` and
`rejected-double-owners.txt`.

## 213. A pooled empty string can occupy writable BSS

Measured in the native plain-SP5 CMake build, `/O2 /Gd /MT`, with the existing
Win32 and `REBREW_ALLOW_NAKED` project definitions. `zutil.c` contains:

```c
const char *z_errmsg[10] = {
    "need dictionary", "stream end", "", "file error", "stream error",
    "data error", "insufficient memory", "buffer error",
    "incompatible version", ""
};
```

Both empty strings use the same public compiler symbol
`??_C@_00A@?$AA@`. Its actual COFF section is a **one-byte `.bss` COMDAT**,
flags `0xc0301080` (uninitialized, writable, align four). It has no initialized
file bytes. The other message literals occupy initialized `.data` COMDATs.
The pointer table itself is 40 initialized bytes with ten DIR32 fields.
`const char *` qualifies the pointed-to characters; this declaration does
not make the pointer array readonly.

The matched code's references establish `_z_errmsg` at reference
`0x100294d4`, versus native `0x100294d0`. Its two empty-message pointer
fields, reference `0x100294dc` and `0x100294f8`, both target `0x10034620`.
The corresponding native fields at `0x100294d8` and `0x100294f4` both target
`0x117650c8`. Thus the small zero at the reference address has a real compiler
literal owner, even though it is not a direct code operand or an initialized
string contribution. No new definition or padding is added.

Storage classification is not determined by zero bytes alone. Section 212's
double-zero literal is a readonly `.rdata` COMDAT, and the named
`const float g_const_0_0 = 0.0f` remains in ordinary readonly `.rdata`.
Those existing native value checks pass. This empty-string observation is
specific to the measured source/profile; it is not a rule for every string
qualification or compiler flag.

Evidence: `.scratch/native-storage-bindings/{audit.py,audit.json,operands.json}`,
the canonical `zutil.c.obj`, and its source in `references/zlib-1.1.3/zutil.c`.
Linker companion sections 27–28 document the operand-based storage audit and
the separate successful type-table ownership change. No zlib or CRT body
changes accompany either finding.

## 214. Data-only `selectany` makes readonly owners independently orderable

Measured with plain `msvc-6.0-sp5`, the canonical `/O2 /Gd /MT` flags and
unchanged project definitions/includes. This repairs the source readonly run
`0x100241a0..0x10025fc0`, including the six previously misplaced game/CRT
literal pools. Keep the literal readers from sections 211–212 unchanged.

For each of the 69 existing initialized readonly definitions, use the native
C declaration attribute:

```c
__declspec(selectany) const double g_const_2 = 2.0;
__declspec(selectany) const float g_cost_rate_table[5][3] = {
    /* Existing values unchanged. */
};
```

For the zlib data that was private, replace only its `local const` data
prefix with `__declspec(selectany) const`; code helpers retain `local`.
The measured owners are in `crc32.c`, `deflate.c`, `infblock.c`, `inftrees.c`,
`trees.c`/`trees.h`, `rdata_restore.c`, `type_adjustments.c` and
`game_float_constants.c`. No runtime archive is edited, and no CRT function
or storage definition is added. Extern inventory labels for the six compiler
pools remain extern declarations.

Each initialized definition now emits a separate readonly `.rdata` COMDAT
with a public symbol. Section order in the objects is often reversed from
source declaration order; native `/ORDER` supplies the final order.
Alignment depends on the actual declaration:

| Actual owner | Bytes | COFF flags | Alignment |
|---|---:|---|---:|
| `g_const_2`, `_g_stat_max_d`, other double scalars | 8 | `0x40401040` | 8 |
| The two `TypeAdjustment` arrays | 600 / 200 | `0x40401040` | 8 |
| zlib `configuration_table` | 120 | `0x40401040` | 8 |
| `g_cost_rate_table`, `g_interval_values`, `g_player_trait_ranges` | 60 / 40 / 1904 | `0x40301040` | 4 |
| zlib `static_ltree` / `static_dtree` (`ct_data` arrays) | 1152 / 120 | `0x40301040` | 4 |
| zlib `bl_order` and copyright strings | 19 / 53 / 47 | `0x40301040` | 4 |
| Named float/int scalars and other measured float/int/byte arrays | actual declaration size | `0x40301040` | 4 |

Thus a struct array does not universally acquire eight-byte section
alignment: `static_ltree` naturally lands at reference `0x10024a04`.
The compiler/linker supply the required alignment between real owners,
including four bytes before the second type table and three bytes after the
41-byte extension string. This change adds no padding arrays or explicit byte sections.

All 37 code sections across the five affected zlib objects retain their
complete 17200 bytes, section flags and relocation positions/types; differences
outside their actual COFF fixup fields are zero. The clean native link also
preserves all 598 mapped function bindings, all 3140 actual code HIGHLOW sites
and every raw code byte outside those sites. Its 75 readonly owners (69 named
plus six pools) all match their reference VAs and full values; the complete
7712-byte source readonly span matches byte for byte, including pointer
initializers and natural alignment. Link details and canonical verification
are in companion linker-layout section 30.

Do not broaden this into a declaration-wide textual rewrite. The first
scratch probe applied the attribute to column-zero K&R parameter declarations
`const uIntf *d;` and `const uIntf *e;` in `inftrees.c`; MSVC emitted C4042
(`has bad storage class`). The resulting code happened to preserve the same
body shapes, but the clean probe restricts changes to known initialized data
declarators. It compiles without warnings and reproduces the native layout.
Function return declarations and K&R parameters in production are unchanged.

An inherited source detail remains unresolved: `infblock.c` already appends
`0xffff0000` after the 19 indexed `border` entries, reproducing the reference
dword at `0x1002469c`. This experiment leaves that value unchanged. A full
readonly byte match does not establish whether that dword belonged to the
original table or to another owner; the original code indexes only entries
0–18. Recovering its actual ownership remains part of removing manual layout
stand-ins from the complete build.

This complements the failed section 204 local-ownership probes and linker
section 13 duplicate-float probe: changing readers/local ownership can alter
instruction scheduling, and independent `selectany` values do not imply
folding with compiler literal pools. Here readers stay unchanged, duplicate
pools are already removed, and all preceding readonly source data participates
in the measured native order. It also avoids section 26's public-code-helper
ICF failure by keeping those helpers private.

Evidence: `.scratch/native-readonly-order/{compile_owners.py,compile_zlib.py,
selectany-shapes.json,zlib-selectany-shapes.json,
zlib-selectany-code-checks.json,broad-declaration-warnings.txt,link.py,
ordered-argv.json,ordered-link.log,ordered-audit.json,ordered-owners.json}`.
At this checkpoint the strengthened `scripts/check_game_readonly.py` checks all 54 annotated game
values at their exact reference addresses and the full 7712-byte readonly run.
The previous canonical DLL is a negative control: it fails
`Misplaced readonly symbol: g_graveyard_const_a`.

Linker-layout section 31 subsequently extends this readonly guard to 9320
bytes by requesting the existing stock CRT data members in native order;
there is no further C spelling or compiler-flag change.

## 215. A shared initialized string can replace a displaced compiler pool without changing code

Measured with MSVC 6 SP5 and the canonical `/O2 /Gd /MT` profile.
The reference's three `"rb"` operands target the same writable string at
`0x1002944c`: `srv_RecvGame` operand `0x1001426e`, and `gm_Open`
operands `0x10015a7c` and `0x10015b4b`. The previous native build instead
used compiler pool `??_C@_02JKAF@rb?$AA@` at `0x1002d7b0`, first supplied
by `srv_RecvGame`. The ordinary VFS data contribution therefore lacked its
opening string and started its gzip magic dwords four bytes early.

Use one actual C string definition immediately before the existing VFS magic
values, and refer to it from all three original call sites:

```c
char s_gzip_mode_rb[] = "rb";
unsigned int g_gzip_magic_1f = 0x1f;
unsigned int g_gzip_magic_8b = 0x8b;
/* Existing VFS path and message definitions follow. */

/* In the two reader translation units: */
extern char s_gzip_mode_rb[];
/* gm_Open, twice: */
file_handle = fopen((char*) path_buf, s_gzip_mode_rb);
/* srv_RecvGame: */
file_handle = vfs_OpenStream((char*) g_download_buffer,
                           (char*) g_download_total_size,
                           (int) s_gzip_mode_rb);
```

The array owns three bytes, including NUL. MSVC supplies one alignment byte
before the following DWORD; no four-byte array, padding declaration or byte
patch is required. `vfs4.c` ordinary `.data` grows 81 -> 85 bytes, flags
`0xc0300040`, with offsets mode 0, first magic 4, second magic 8, path 12,
message 40. The full 85-byte run, including natural alignment, matches at
`0x1002944c`. The old anonymous pool is absent from the native MAP, and
all three complete four-byte code operands equal the reference target.

The reader code sections remain 864 bytes (`gm_Open`) and 896 bytes
(`srv_RecvGame`), including their native section tails. This is not a claim
that those section lengths equal each function's annotation size. Both VFS
code sections also retain their full lengths (144 and 304 bytes).
All COFF relocation positions/types and section flags remain unchanged, with
zero differences outside actual COFF fixup fields. The spelling changes
relocation targets, rather than instruction selection. This result is specific
to these call-argument uses; it does not contradict the float scheduling
failures in section 204.

The existing server metadata described this string as `char[4]`, conflating
its logical size with the following alignment. Correct its type to `char[3]`
and size to 3 through separate `rebrew data set --type` and `--set-size`
calls. The CLI accepts repeated options within one setter family, but rejects
mixing setter families in one invocation before making changes. Five alchemy
string sizes were also stale at one byte; correct to their full NUL-inclusive
sizes 17, 50, 40, 50 and 46. Per-symbol checks of the former one-byte sizes
were not evidence of full-string equality. These are corrections using the
existing managed metadata API, rather than a new tooling feature.

Evidence: `.scratch/native-mutable-owners/{probe.py,code-checks.json,
vfs4.obj,gm_Open.obj,srv_RecvGame.obj,metadata-full-string-sizes.json,
metadata-read-mode-type.json,combined-values.json,link-controls.json}`.
Linker-layout section 32 records separate controls and the successful combined
layout repair.

## 216. Unused named copies do not replace the compiler's live string literals

The four alchemy diagnostic strings already occur as compiler pools in
`ahm_ExAllocAlchemist.c`. The separate initialized arrays in
`alchemistry_logic2.c` emit another copy of each string. A census of every
COFF relocation section in 191 source objects and 124 selected stock SP5
members finds zero references to those four public array symbols. Public
references are counted by COFF storage class, avoiding private-name collisions.
The actual alchemy tag and tables have references and remain defined.
No `/INCLUDE` or `/ORDER` directive requests the four duplicate array symbols.

Replace only the four unused initialized definitions with extern inventory
labels; leave the reader's literals unchanged. Keep their stable DATA markers
and full metadata sizes. The live pools supply the following reference values:

| Reference VA | Full size, including NUL | Value |
|---|---:|---|
| `0x1002a10c` | 50 | `D:\Develop\DieGildeAddOn\game\alchemistry_logic.c` |
| `0x1002a140` | 40 | `ahm_ExAllocAlchemist: array overflow...` |
| `0x1002a168` | 50 | `ahm_ExAllocAlchemist: wrong type of target geb...` |
| `0x1002a19c` | 46 | `ahm_ExAllocAlchemist: cant find target geb...` |

The four duplicate arrays consume 192 bytes with native internal alignment.
The existing preceding header contains two initialized floats and the
17-byte `ahm_AllocAhmInfo` tag. Move those three actual definitions into the
small data-only `alchemy_header.c`, retaining extern declarations in the
original code owner. The new object emits 25 ordinary initialized bytes,
flags `0xc0300040`, with offsets 0, 4 and 8. LINK naturally aligns the next
contribution to four bytes, so the header occupies 28 bytes in the final
layout. This is actual data, rather than an explicit alignment declaration.
The remaining alchemy table contribution shrinks 8960 -> 8740 bytes; its
7812-byte random table now starts at offset zero, followed by its 928-byte
entity table at offset 7812.

All ten code sections in `alchemistry_logic2.c` retain their complete lengths,
flags and relocation positions/types, with zero non-fixup differences.
Together with section 215, the four changed objects contain 14 full code
sections totaling 3536 bytes. Moving these three definitions does not prove
the original translation-unit boundaries; the native link order is validated
separately against actual reference operands and complete data spans.

The census also finds 18 unreferenced ordinary-BSS definitions and three
unreferenced COMMON placeholders in `link_stubs.c`. They are not removed in
this change: an unused zero definition and a numerical extent difference do
not establish the original BSS ownership. Referenced large arrays, all live
alchemy tables and the separately referenced office strings remain protected.
In particular, the office strings in `aemter2.c` are used by
`amt_fio_LoadAemter`; this duplicate-string result does not justify removing
them.

Scratch harness failures: resolving every quoted include relative to its
source directory wrongly made `zlib.h` absolute and caused C1083; retain
canonical include-path resolution unless that local header actually exists.
The first assertion expected four `gm_Open` reads; the source contains two.
Correct the harness before measuring. These are experiment setup errors,
not compiler limitations. VFS compilation retains its existing C4133/C4013
warnings; the new data-only header compiles without warnings.

Evidence: `.scratch/native-mutable-owners/{census.py,census.json,census.stdout,
probe.py,alchemy_header.obj,alchemistry_logic2.obj,code-checks.json}`.
Linker-layout section 32 explains why removing duplicates alone leaves the
reference layout displaced, and why both measured ownership repairs matter.

## 217. A real character array before a static pointer restores shared version storage

Measured with MSVC 6 SP5, canonical `/O2 /Gd /MT`, and the section 32
native build. `deflateInit2_` deliberately uses an initialized static pointer:

```c
static const char* my_version = ZLIB_VERSION;
```

Its pointer is writable initialized data: `const` qualifies the characters,
not the pointer itself. The old object emits a four-byte ordinary `.data`
contribution before its separate six-byte `"1.1.3"` compiler pool. Native
LINK places the pointer at `0x1002706c` and the string at `0x10027070`.
The reference instead has the string at `0x1002706c` and pointer at
`0x10027074`. The complete 12-byte run differs; subsequent owners already
match and should remain fixed.

Use one real, shared writable array at file scope in `deflate.c`, retaining
the original static pointer inside `deflateInit2_`:

```c
char g_zlib_version[] = ZLIB_VERSION;
/* Inside deflateInit2_: */
static const char* my_version = g_zlib_version;
```

Declare the array extern in `inflate.c` and `vfs_OpenStream.c`.
`inflateInit2_` compares `version[0]` with `g_zlib_version[0]`; the two VFS
initialization calls pass `g_zlib_version` instead of the macro's string
literal. All uses must share the owner: retaining a literal reader in a
second object would emit another compiler pool. The identifier describes
recovered storage; it is not a recovered original symbol name.

The new deflate object emits 12 ordinary initialized bytes, flags
`0xc0300040`: six array bytes at offset zero, compiler alignment to offset
eight, then the existing static pointer. Its DIR32 initializer targets the
array. No padding array, explicit section or extra translation unit is used.
The complete linked 12 bytes match at `0x1002706c`, including the native
alignment bytes and pointer value. The former anonymous version pool is
absent. Actual code operands now all equal their reference targets:

| Operand VA | Target VA | Owner |
|---|---|---|
| `0x10001346` | `0x10027074` | Deflate static version pointer |
| `0x100057d4` | `0x1002706c` | Inflate version characters |
| `0x10009139` | `0x1002706c` | VFS inflate initialization argument |
| `0x100091f9` | `0x1002706c` | VFS deflate initialization argument |

All 18 complete code sections across these three objects retain their 7088
bytes, flags, relocation positions/types and zero differences outside actual
COFF fields. The static pointer remains a pointer: substituting an array
for the pointer expression was not part of this measured control. The full
native link preserves all function bindings, readonly values and the game
writable span from section 32. This repairs source-library storage from the
existing zlib sources; stock CRT functions and archives remain unchanged.

Evidence: `.scratch/native-version-owner/{probe.py,checks.json,
deflate.obj,inflate.obj,vfs_OpenStream.obj,link.py,version-argv.json,
version-objects.rsp,version-audit.json,version-values.json}`.
Linker-layout section 33 records the whole-file effect and remaining limits.

The canonical rebuild retains the existing `vfs_OpenStream` C4028/C4142
warnings from its CRC prototype; the new version owner changes no prototype.
The two zlib sources compile without warnings in this control. A single
initialized-data spelling correction is enough; no flag sweep or extra
library build is involved.

## 218. Explicit-zero selectany globals become independently orderable BSS COMDATs

Measured on the section 33 native server build with plain MSVC 6 SP5 and
the actual CMake per-object flags, including `/O2 /Gd /MT`. Prefixing an
existing external zero definition with `__declspec(selectany)` changes its
storage contribution without changing its logical size:

```c
__declspec(selectany) int g_array_count = 0;
__declspec(selectany) char g_crash_dump_all_frames = 0;
```

Each definition emits its own default `.bss` COMDAT, flags `0xc0301080`,
with four-byte alignment. The char owns one byte; the next DWORD receives
natural alignment. The previous explicit-zero definitions were combined
ordinary `.bss`, flags `0xc0300080`. This is distinct from uninitialized
external COMMON storage (linker-layout section 9).

The full-source control changes 12 real definitions across seven existing
objects: panic and crash callbacks, log-mode flags, the crash-frame char,
allocation counter, four allocator statistics, array count, allocation-report
groups and array pointer. All 12 complete code sections retain their 5008
bytes, flags and relocation positions/types, with zero changes outside COFF
fixup fields. Private helper visibility and the original compile flags are
preserved. The successful code-shape result includes `gm_Open`'s whole
864-byte code section, rather than just its annotated function prefix.

Attributes alone leave these definitions late in BSS and do not improve the
whole-file difference count. Adding the following group immediately before
the existing `g_sequence_counter` entry in native `/ORDER` places all 13
owners at their reference addresses. The extra owner is zutil's existing
one-byte empty-string compiler COMDAT, not a new zero declaration.

| Native ORDER spelling | Reference/native VA | Logical bytes |
|---|---|---:|
| `g_panic_callback` | `0x10034610` | 4 |
| `g_crash_callback` | `0x10034614` | 4 |
| `g_log_mode_flags` | `0x10034618` | 4 |
| `g_crash_dump_all_frames` | `0x1003461c` | 1 |
| `??_C@_00A@?$AA@` | `0x10034620` | 1 |
| `g_array_count` | `0x10034624` | 4 |
| `g_stat1` | `0x10034628` | 4 |
| `g_stat2` | `0x1003462c` | 4 |
| `g_stat3` | `0x10034630` | 4 |
| `g_stat4` | `0x10034634` | 4 |
| `g_alloc_counter` | `0x10034638` | 4 |
| `g_alloc_report_groups` | `0x1003463c` | 4 |
| `g_array_ptr` | `0x10034640` | 4 |

The 46 logical bytes occupy a 52-byte run through `0x10034643`, with
six bytes of native alignment. Require the MAP bindings and actual complete
operands: all 81 code HIGHLOW operands into this run equal the reference,
and zutil's initializer fields at `0x100294dc/0x100294f8` both target
`0x10034620`. Matching zero bytes alone would not prove those bindings.
Native ORDER uses undecorated C names and leaves this C++ literal spelling
unchanged.

Both ordered controls preserve all 9320 readonly bytes, 54 readonly game
values, the 85-byte VFS run, the 16872-byte game writable run and the full
12-byte version owner. They also retain 598 function bindings and all 3140
code HIGHLOW sites, with zero unmasked raw-code changes. Nevertheless,
later allocations move, `.data` VirtualSize grows by 32 natural bytes,
and total file differences increase. **This is a measured placement mechanism,
not a promoted complete BSS repair.** Linker-layout section 35 records all
three controls and their limits. No production BSS declarations are changed.

Harness corrections: a definition followed by a comment was missed by an
end-of-line initializer pattern; accept the semicolon before that comment.
Resolving the venv Python symlink selected the system interpreter without
LIEF; retain the venv executable path. Both are setup errors; corrected
compilation and value checks pass.

Evidence: `.scratch/native-early-bss/{probe.py,checks.json,shapes.json,
replacements.json,link.py,controls.json,check_values.py,full-gates.json,
*-argv.json,*-includes.rsp,*.order,*-link.log,*-check_values.stdout}`.

## 219. bss_seg applies to tentative globals; an explicit zero can bypass it

Isolated native MSVC 6 SP5 `/O2 /Gd /MT` controls, without game code:

```c
#pragma bss_seg(".bss$Z")
int late_tentative;
unsigned char late_array[64] = {0};
__declspec(selectany) unsigned char late_comdat[64] = {0};
#pragma bss_seg()

#pragma data_seg(".bss$Y")
int data_seg_zero = 0;
unsigned char data_seg_array[64] = {0};
#pragma data_seg()
```

| Definition | Observed COFF contribution |
|---|---|
| Tentative `late_tentative` under `bss_seg` | Four-byte ordinary `.bss$Z`, `0xc0300080`; not COMMON |
| Explicit-zero `late_array` under `bss_seg` | Default ordinary `.bss`, `0xc0300080`; pragma does not select its section |
| Explicit-zero selectany array under `bss_seg` | Separate default `.bss` COMDAT, `0xc0301080` |
| Explicit-zero scalar and array under `data_seg(".bss$Y")` | 68-byte **initialized-data** section, `0xc0300040` |

The pragmas compile without warnings. A section named `.bss$Y` is not proof
of uninitialized storage: inspect its COFF flags and actual raw contribution.
The same bypass is observed for a scalar initialized to zero under
`bss_seg(".bss$A")`. These results describe these tested definitions;
they do not establish every pragma/declaration combination.

A native LINK toy uses `/DLL /NOENTRY /NODEFAULTLIB /OPT:REF`,
`/INCLUDE:_ordered_zero` and `/ORDER` containing `ordered_zero`.
It places the selectany DWORD at `0x10001000`, ordinary zero DWORD at
`0x10001004`, and a tentative 256-byte `.bss$Z` array at `0x10001008`.
Its unused default COMMON is discarded. Retaining that COMMON with
`/INCLUDE:_default_common` puts it at `0x10001008`, before the suffixed
array at `0x1000100c`. Thus moving game arrays to a suffixed BSS section
would not by itself place stock default COMMON after them. No such source
or section strategy is promoted, and no toy storage enters the server build.

Evidence: `.scratch/native-bss-sections/{shapes.c,shapes.obj,shapes.json,
shapes-compile.log,order.c,order.obj,order.txt,order-argv.json,
order-compile.log,order-link.log,order.map,order-common-link.log,
order-common.map}`. These toy addresses have no reference-server VA claim.

## 220. A stock archive member can retain private storage without appearing in MAP owners

On section 33's native stock-SP5 link, the MAP exposes 124 LIBCMT member
owners. That is a visible-member count, not a complete selected-member count.
Untouched `setlocal.obj` has a surviving ordinary initialized-data section
even though none of its public names appears in that MAP:

| Private field | COFF offset |
|---|---:|
| `__clocalestr` | 0 |
| `_?cachein@?1??_expandlocale@@9@9` | 4 |
| `_?cacheout@?1??_expandlocale@@9@9` | 136 |

The full section is 267 bytes, flags `0xc0300040`, with no relocations:
`C\0` at offsets 0, 4 and 136, zero elsewhere. Match the **entire**
initializer, including zeros. It occurs uniquely at native `0x10033ef8`
and reference `0x10033bc8`; the next contribution aligns naturally to
268 bytes. The physical stock input census therefore includes at least
125 members. Earlier censuses described as "124 selected" should be read
as "124 MAP-visible"; their omission does not identify a missing 267-byte
definition or justify adding another one.

This member's ordinary 12-byte BSS contains private cache ID/code-page
state, but the current active code supplies no binding anchor for it.
Its zero contents do not prove a reference BSS base. The member's public
code COMDATs, 72-byte locale-category COMDAT and its own string COMDATs
are discarded. Retaining `___init_dummy` emits its three-byte
`xor eax,eax; ret` code and changes other code layout. A better aggregate
file count with that extra function is not a successful code match.

VC6 `/VERBOSE:LIB` in the measured link prints searched library paths but
does not provide a loaded-member trace. Adding an unreferenced selectany
function pointer to `__init_dummy` can trigger dependency consideration
before GC; both the pointer and dummy code disappear from the final MAP,
yet the three tested input placements do not improve the measured layout.
No helper pointer table, extracted stock object or extra code retention is
promoted. Stock CRT code remains supplied by unchanged stock archives.
Linker-layout section 34 records their full native control results.

Rich input counts are complementary composition evidence: original stock
has 124 compiler-8047 C inputs versus 114 native, six product-12/build-7291
inputs versus one, and 126 unmarked inputs versus 109. These differences
do not identify ten particular missing members or explain the 3456-byte
BSS extent deficit. Do not choose unused members merely to fit those totals.

Evidence: `.scratch/native-crt-data-order/{census.py,census.json,
setlocal-full-value.json,setlocal-pools.json,ghost_candidates.py,
ghost-candidates.json,whole_object.py,whole-object-controls.json,
selection-trace-link.log,dependency.c,dependency.py,
dependency-controls.json}`. The archive hash remains
`28b9f04962378ec4668072f37d7fd2835cd6cacc17b40cf22002c57bd8e76714`.

## 221. Native ORDER rejects ordinary initialized data as well as ordinary BSS

The section 36 native build has ordinary stock `.data` contributions:
`cmiscdat.obj`'s 24-byte conversion table, `ctype.obj`'s 522-byte pointer/table
run and `nlsdata1.obj`'s 12-byte locale scalar/pointer run. All three have
COFF flags `0xc0300040`, rather than COMDAT flags. Their known bindings
do not make them independently orderable.

Two native LINK controls insert entries immediately before the first game
COMMON entry, retaining plain SP5, the actual CMake flags, original objects,
stock archives, `/OPT:REF`, and section 36's three data-retention anchors:

```text
_cfltcvt_tab
_pctype
__mb_cur_max
```

LINK adds the x86 C underscore correctly, then emits LNK4065 for each
actual symbol: `__cfltcvt_tab`, `__pctype`, `___mb_cur_max` cannot be ordered
and are ignored. This is not the incorrect-decoration failure from section
211. Adding `_clocalestr` between table and ctype emits LNK4037:
`__clocalestr` does not exist in LINK's orderable symbol namespace. It is
private storage-class-3 data in `setlocal.obj`, despite surviving in the
ordinary section identified in section 220.

Both controls retain all 598 function bindings, identical 3140 code
HIGHLOW sites, and zero unmasked code changes. Their complete raw `.text`,
`.data` and `.reloc` sections equal the canonical build; the only readonly
differences are the actual export timestamp bytes at RVAs
`0x26e34/0x26e35`. All VirtualSizes and raw lengths are unchanged.
The overlapping count is 6236 versus canonical 6235 because timestamps and
checksums remain in the strict file comparison. **No placement changes.**
These ORDER entries are not promoted. Changing actual contribution selection
or ownership is still needed; repeating ordinary-data ORDER cannot supply it.

Evidence: `.scratch/native-ordinary-data-order/{probe.py,controls.json,
public-data.order,with-private-locale.order,*-argv.json,*-link.log,
*-audit.json,versus-canonical.json}`. Linker-layout section 37 records the
relationship to the current native allocation problem.

## 222. Native build clocks change CL's builtins and COFF stamp, preserving this full code shape

Plain SP5, Docker Wine 8.0, `/O2 /Gd /Gy`, native `rebrew-cmake-cl`
with the production clock helper. The same unchanged C89 source is compiled
at decimal epochs 1071482016 and 1771046057:

```c
char build_date[] = __DATE__;
char build_time[] = __TIME__;
int __cdecl build_second(void)
{
    return build_time[0];
}
```

At the first epoch the complete ordinary `.data` is 21 bytes:
`Dec 15 2003\0` followed by `09:53:36\0`. At the second it is
`Feb 14 2026\0` followed by `05:14:17\0`. Both use flags
`0xc0300040`, with no data fixups. There is no gap between the two real
arrays. These are native builtin expansions, not source substitutions.
Both COFF object-header timestamps also equal their respective epochs.
The source file and its mtime are not changed between compiles.

Both **complete 16-byte CODE sections** are identical, including native
compiler alignment, flags `0x60501020`, and the single DIR32 relocation
at offset 3 to `_build_time`:

```text
0f be 05 00 00 00 00 c3 90 90 90 90 90 90 90 90
movsx eax, byte ptr [build_time]
ret
```

The eight trailing NOPs are compiler output under `/Gy`, not a source
padding declaration. This isolated example establishes the builtin/data
and complete-code behavior for this source and these flags. It supplies
no function VA or storage owner in the reference DLL, and no probe source
is linked into production.

The clock affects object bytes even when the source and flags are unchanged.
Rebrew therefore hashes SOURCE_DATE_EPOCH in both the object cache and the
verification configuration; changing or removing it cannot re-serve a dated
object/verdict from another epoch. CMake Wineprefix initialization remains
under real time; the clock is enabled only for the native tool invocation.

Harness correction: `/Fo:<absolute path>` inserted a literal colon into
CL's output filename and failed with C1083. Native `/Fo<absolute path>`
works. This was an invalid probe invocation, not a bridge path defect.

Evidence: `.scratch/native-export-exp/{date-macros.c,date-macros.py,
date-macro-controls.json,date-macros.stdout,date-*.obj,date-*.log,
date-Fo-colon.stdout,date-Fo-colon.log}`. The executable checker asserts all
21 data bytes, all 16 code bytes, section flags and the exact relocation
shape. Linker-layout sections 39–40 record the independent native LIB/LINK
stamps, rejected older-clock controls and final production validation.

### 223. Removing stale size comments and wrapping tables preserves complete native contributions

Lint cleanup on 2026-10-02 removed the stale inline `SIZE: 256` from
`cm_ExChangeAttribute` at `0x1000e7d0` and `SIZE: 144` from
`cm_ExChangeFloat` at `0x1000eb70`. Their managed function sizes are 242
and 135; the larger values describe compiler contributions including
alignment, rather than those function extents. The metadata was not
hand-edited. `TypeAdjustment` now has its actual `SIZE 0x28` struct marker:
one 32-bit kind and nine 32-bit floats. Dispatch-table and trait-range rows
were wrapped without changing their tokens, values, order or declarations.

An ordinary native CMake rebuild with each source's existing production
flags proves all five edited objects retain every non-debug contribution:
**5042 bytes**, section flags, and every relocation offset/type/target.
Their four complete CODE sections total **688 bytes**, with **14 fixups**:
256 and 144 bytes for the two command handlers, and two 144-byte dispatch
bodies in `alchemistry_logic3.c`. All four retain flags `0x60501020`.
The constant and struct-table objects add no CODE. This comparison includes
native alignment bytes; it does not trim sections or mask code fixups.
The complete resulting DLL remains byte-for-byte identical to the previous
native build, SHA-256
`b80c45a32235a45be89f34c58b4d94a0819b355d3d7b015c0fe45e2026994904`.
These observations apply to the edited sources and their actual flags;
line wrapping can affect other sources that use `__LINE__`.

Two linter defects were fixed directly in sibling Rebrew. W021 now allows
same-address annotated extern references beside their single initialized
owner. It retains the owner through later references and still warns about
a second initialized owner or a conflicting address, including DATA/GLOBAL
marker pairs. Positive and rejected-collision controls exercise both scan
orders. W033 now uses the first declared target for the shared scaffold,
matching `init --refresh-agents`; selecting either client target previously
reported a freshly refreshed scaffold as stale. Both selected-target
controls pass and an actually edited skill still warns.

Default lint: **4122 passed, zero errors, zero warnings**. All-target lint
reports the same result for each of the three configured targets. Generated
instructions were refreshed through the CLI; `init --check` reports zero
drift. Rebrew lint/recommend tests: **282 passed**; Ruff, format checks,
mypy and import-cycle/layering checks pass. Function verification remains
**262/262**, 22 EXACT and 240 RELOC, with no size divergences.
No warning rule was disabled,
line-length limit raised, global definition duplicated or native input
allocation changed. The strict whole-file objective remains incomplete.

Evidence: `.scratch/lint-clean-{start,final,all-targets-final,agents-final}.json`,
`lint-clean-objects-before.json`, `lint-clean-codegen-check.json`,
`lint-clean-build.log`, and the Rebrew test/type/boundary logs. The object
check compares complete section bytes and named fixups before/after;
the final DLL check compares the complete SHA-256.

## 224. Five late server globals become COMMON without changing their complete code

Native SP5 controls remove only the explicit `= 0` initializers from
`g_thread_handle` in `server.c`, `g_max_players`, `g_tick_rate` and
`g_players_synced` in `ServerMainThread.c`, and `g_chain_id_start` in
`cm_ChainAssignId.c`. All retain their original C types. They remain
zero-initialized by C storage semantics. The existing 4-byte definitions
change from ordinary `.bss` symbols to external COMMON symbols with
section zero and COFF value four, which means allocation size.

Whole-source native CL uses the actual production CMake flags, including
`/O2 /Gd` and `/MT`; complete argv files are retained. All five CODE
contributions are **byte-identical**, with identical section flags
`0x60501020` and named relocation offset/type/target shapes:

| COFF function | Complete CODE bytes | Fixups |
|---|---:|---:|
| `_DllMain@12` | 16 | 0 |
| `_Init` | 48 | 3 |
| `_Exit` | 80 | 8 |
| `_ServerMainThread@4` | 2448 | 170 |
| `_cm_ChainAssignId` | 32 | 3 |
| Total | 2624 | 184 |

The check includes native alignment bytes and does not mask fixup fields.
The prior source section conflicts are real: the handler and thread handle
cannot share one reference block, and the chain ID must interleave the
main-thread fields. Native ORDER can now place the five real globals
immediately after the existing nine connection slots. Their offsets
0/4/8/12/16 match reference storage at `0x11764084..0x11764094`;
their native addresses remain `0x11762e84..0x11762e94`, uniformly
`0x1200` too early. The connection-array extent is unchanged
(`9 * 0x264264 = 0x1585584`). Its alignment gap before the existing
allocator accommodates the five fields without adding storage or changing
the final `.data` VirtualSize. This fixes relative composition, not their
absolute reference addresses.

The thread-only control leaves 6232 overlapping differences and puts the
thread at the start of that gap, before the other still-ordinary fields.
Main-thread plus chain control gives 6202. The combined control gives
**6198**, preserves all 598 function bindings and the identical 3140
code HIGHLOW sites, and passes all existing complete data-value gates.
Only the combined source/order change is promoted. A fresh source/stock
storage audit reduces conflicting game BSS sections from three to one;
`gm_Open.c` remains unresolved. Linker-layout section 41 records the
whole-file measurements and the remaining offset limits.

Probe correction: a broad declaration mutation also selected assignments
inside the main-thread body. Its count assertion stopped before that
source was compiled. The executable control uses the five exact existing
declarations instead. This is a harness mistake, not a compiler or Rebrew
defect. No erroneous source or object reached a link or production.

Evidence: `.scratch/native-late-bss/{probe.py,checks.json,shapes.json,
rejected-broad-mutation.log,controls.json,changed-operands.json,
canonical-late-bindings.json,canonical-build.log,canonical-clock-audit.json,
canonical-verify.json,canonical-gates.json,audit.json}` and the three
control directories with native command logs. No CRT implementation,
library/object patch, manual gap declaration or postlink edit is added.

## 225. Splitting gm_Open's six zero definitions does not establish their placement

The six explicit-zero definitions at the end of gm_Open.c originally emit
one ordinary 24-byte BSS contribution: array_count, alloc_report_groups,
array_ptr, stream_pool, stream_count, connection_counter. Their reference
addresses are 0x10034624, 0x1003463c, 0x10034640, 0x10034670,
0x10034678 and 0x1003467c; they cannot be this single contiguous block.

Five whole-source controls retain the complete gm_Open CODE contribution:
**864 bytes, 69 named fixups, flags 0x60501020**, including the compiler's
alignment after the annotated 861-byte function. All bytes, named relocation
targets/types/positions and flags are equal, with no masking or trimming.
They use the actual CMake /O2 /Gd /MT flags, defines and includes.

| Storage control | ORDER placement | Overlapping file differences |
|---|---|---:|
| Canonical before this turn | Existing order | 6198 |
| Pool alone becomes 4-byte COMMON | Before sequence_counter | 6925 |
| Pool/count/counter become COMMON | Before sequence_counter | 6903 |
| All six become COMMON | Before sequence_counter | 6747 |
| All six become COMMON | Existing order, names omitted | 6215 |
| All six use selectany explicit zero | Existing order, names omitted | 6198 |

Tentative definitions are external section-zero COMMON symbols of size four.
The selectany definitions instead each emit a four-byte BSS COMDAT,
0xc0301080. Without ORDER their six bindings appear in reverse declaration
order, whereas the original ordinary BSS offsets follow declaration order.
None of these five controls is promoted. An equal byte-distance score does
not establish the original grouping or ownership. All controls preserve the
598 function bindings, 3140 CODE HIGHLOW sites, zero unmasked code differences
and existing complete readonly/writable/version/conversion-table value gates.

Evidence: `.scratch/native-gm-open-bss/{probe.py,probe-unordered.py,
controls.json,unordered-controls.json}` and each control directory's source,
native argv/logs, code/storage proof, MAP, DLL, audit and gates. These are
new controls of the remaining six fields, not a repeat or promotion of
section 218's earlier thirteen-owner placement. No additional pool word is
created; matched m_PoolAlloc/m_pool_free only access the head pointer.

## 226. Eight real allocator globals form one ordinary 32-byte BSS block

Their actual users and source paths identify allocation tracking state,
previously spread among gm_Open.c, m_alloc.c and m_alloc2.c. Moving the
existing definitions into m_alloc.c, retaining extern declarations at the
other files, emits the following complete ordinary BSS contribution:

| Offset | Symbol | Reference VA |
|---|---|---|
| 0 | g_array_count | 0x10034624 |
| 4 | g_stat1 | 0x10034628 |
| 8 | g_stat2 | 0x1003462c |
| 12 | g_stat3 | 0x10034630 |
| 16 | g_stat4 | 0x10034634 |
| 20 | g_alloc_counter | 0x10034638 |
| 24 | g_alloc_report_groups | 0x1003463c |
| 28 | g_array_ptr | 0x10034640 |

All types and explicit-zero initializers stay unchanged. The result is
32 bytes, flags 0xc0300080, without a gap field, larger array, synthetic
owner or added storage. Actual COFF symbol offsets and the matched callers'
DIR32 addends agree on one reference base, 0x10034624. This proves the block's
relative geometry; original source provenance is inferred from the allocator
users and their shared m_alloc.c path, not recovered source text.

Full-source compilation preserves **six complete CODE sections, 1936 bytes,
140 named fixups**, flags 0x60501020. This includes m_FreeTracked (192),
m_init (176), m_ShutdownAllocator (288), m_PoolAlloc (272), m_pool_free (144)
and gm_Open (864); compiler alignment remains included. Canonical rebuilt
objects also equal the validated scratch contributions byte for byte, in
flags and named fixups. The isolated ownership control leaves all section
extents and the 6198 file differences unchanged. It is promoted alongside
linker-layout 42's stock COMMON order because it restores this actual block
without losing the native link improvement.

After promotion, the block is still misplaced at **0x117663a8**. Its eight
reference anchors all imply the same base; zero values are not evidence for
correct absolute bindings. gm_Open's remaining ordinary block is 12 bytes:
pool/count/counter at offsets 0/4/8. It still implies two reference bases
because the pool-to-count interval is eight bytes in the binary. That second
word's owner is unproved and is not appended. The fresh storage audit still
has one conflicting game BSS group, with its allocator conflict removed.

Evidence: `.scratch/native-allocator-owner/{probe.py,code.json,storage.json,
server.dll,server.map}` and `common-combined/`; canonical proof in
`.scratch/native-crt-common-order/{canonical-code.json,audit.json,
operands.json,canonical-verify.json}`. No CRT implementation or library edit.

## 227. A live COMMON request can select a hidden member before its code is discarded

The stock setlocal.obj initializer from section 220 was already present,
but misplaced at 0x10034110. Requesting one of that member's existing live
COMMON symbols immediately after __cfltcvt_tab changes its archive selection
position. The minimal promoted directive is:

```text
/INCLUDE:__cfltcvt_tab
/INCLUDE:___setlc_active
/INCLUDE:__pctype
/INCLUDE:___mb_cur_max
```

Three complete native links test ___setlc_active alone,
___unguarded_readlc_active alone, and both names together. All produce the
same entire DLL, SHA-256
**27d2ff2ab733cdf24957b17719ba561c55d582b2923e14e28fa1bfc29c476c71**.
Each puts the complete 267-byte private initializer at **0x10033bc8**,
its unique reference address. The three C-NUL pairs at offsets 0/4/136 and
all other zero bytes match; no source or extracted object supplies them.
The ordinary stock section remains 0xc0300040 and aligns the next member
to 268 bytes. The initializer's owner still has no live public MAP label.

The two requested symbols were already four-byte stock COMMON definitions,
live in the canonical MAP and existing ORDER tail. The request adds no
storage or function. Their 28-symbol stock tail geometry remains -0x1200
from reference. All of setlocal.obj's CODE COMDATs, its 72-byte category
COMDAT and its own string COMDATs remain discarded. The physical stock
census remains 125 members, not 126. This root request changes selection
order, unlike retaining ___init_dummy's unwanted three-byte body in
section 220. No helper pointer, library patch, object edit or target CRT
implementation is added.

All 598 function bindings and the identical 3140 CODE HIGHLOW sites remain;
there are zero raw-code differences outside those fields. Of 200 CODE
operands that move, 95 improve in byte distance, seven worsen and 98 stay
at the same distance, net **166 fewer CODE differing bytes**. Every formerly
exact CODE operand retains its reference binding. This is linked-address
movement: no source CODE contribution is edited or recompiled for promotion.
Whole-file measurements and complete data evidence are in linker-layout 43.

Evidence: `.scratch/native-locale-common-anchors/{probe.py,controls.json,
changed-operands.json,changed-summary.json}` and setlc/readlc/both native
argv/logs, DLLs, MAPs and audits. The stock archive SHA remains
`28b9f04962378ec4668072f37d7fd2835cd6cacc17b40cf22002c57bd8e76714`.

## 228. Data roots can preserve CODE while moving alignment, or move existing CODE too

After section 227, three further controls request existing stock data
symbols immediately after the existing ___tzset retention anchor. None
changes a source definition or archive byte:

| Requested roots | File differences | Unmasked CODE differences | CODE HIGHLOW topology |
|---|---:|---:|---|
| Canonical locale root | 5320 | 0 | Equal |
| __lpdays | 6164 | 0 | Equal |
| __XcptActTab | 22015 | 13304 | Different |
| __lpdays, __XcptActTab | 20797 | 13304 | Different |

The day table is a code-free 104-byte ordinary .data contribution,
0xc0300040. Its root moves it to 0x1003403c rather than reference
0x10034034. The native .data VS becomes 0x173f820 and the connection array
moves 32 bytes, to 0x101dd920. All function bindings remain unchanged,
but the full file gets worse. This control is not promoted.

The exception table is a 136-byte ordinary .data contribution,
0xc0400040, in winxfltr.obj alongside CRT CODE COMDATs. Its data root moves
already-present functions: the MAP still has 598 function labels, yet their
positions and actual CODE HIGHLOW sites change. A constant function count
does not prove constant code. The two exception-table controls fail the
native audit and are not promoted. The combined control happens to place
___lc_time_c at its reference 0x10034260; that isolated data binding cannot
justify the code-layout regression. Its exception table is still eight
bytes late at 0x100340a8, reference 0x100340a0.

Archive recon also compares ctype/nlsdata1/timeset's ordinary data shapes
in available VC6 RTM/SP4/SP5/SP6 archives. These keep sizes 522/12/148 and
four-byte section alignment. Their whole object hashes differ, so this is
a section-shape observation, not a whole-member identity claim. VC7 instead
has eight writable ctype bytes plus 1036 readonly bytes, and 152 timeset
bytes with eight-byte alignment; that is not this reference's data model.
No alternate archive or member is linked. The runtime-error table actually
belongs to crt0msg.obj: its private _rterrs section is 144 bytes and
eight-byte aligned. A guessed rterr.obj filename is not its owner.

Evidence: `.scratch/native-crt-later-data/{probe.py,controls.json,
table-bindings.json}` and three native link/audit logs;
`.scratch/native-locale-common-anchors/stock-ordinary-shapes.json`.
No new Rebrew tooling deficit is inferred from these rejected native
layouts. All production code and stock-library constraints remain enforced.

## 229. Redundant import retention pragmas do not determine this WinSock IAT

On MSVC 6 SP5, crt_imports.c compiles to a directive-only object: it has
no emitted CODE or storage. Two full-source controls remove either all
16 WinSock `/include:__imp__...` pragmas, or just the seven whose function
symbols are already retained by native-archive-includes.rsp. Both native
links produce the **entire canonical DLL unchanged**, SHA-256
`27d2ff2ab733cdf24957b17719ba561c55d582b2923e14e28fa1bfc29c476c71`.
All 100 imports, 23 displaced IAT slots, hints, 598 function bindings and
3140 CODE HIGHLOW sites remain unchanged. This rules out those pragma
seeds as a slot-order control at this checkpoint; it does not establish a
general import-sorting algorithm. No production source change is needed.

Read actual short import headers before interpreting their WORD at offset
16. For ordinal imports it is the ordinal; for named imports it is a hint.
The same numeric WORD occurs on unrelated named members. Filtering the
stock WinSock records to import/name type zero confirms the existing
ordinal-to-name mapping, including WSAGetLastError111, WSAStartup115 and
WSACleanup116. There is no stale seed-name repair to make.

Evidence: `.scratch/native-import-seeds/{probe.py,controls.json,
ws2-symbol-order.json}` and both complete native link/audit logs.

## 230. Eliminated function-address expressions do not seed VC6 undefined symbols

Two server2.c controls insert `(void)function_name;` expressions for all
16 WinSock APIs into srv_Init, after its declarations. One follows the
reference's import order; the other reverses it. CL eliminates the
expressions before emitting undefined symbol references. Neither adds a
symbol, including the two APIs otherwise unused by this TU, htonl/sendto.
The complete ordered list of import-pointer undefined symbols remains
identical to the original object.

Both controls preserve all seven complete CODE contributions: **2112 bytes,
100 named fixups**, identical bytes, flags and named relocation tuples,
including compiler alignment. These are compile-only negative controls;
they have no changed symbol order to test through LINK and are not promoted.
Do not add no-op expressions to production as an import-order recipe.

Evidence: `.scratch/native-import-symbols/{probe.py,controls.json}`,
reference-order/reverse-order source clones, native compile argv and logs.

## 231. Tentative globals have stable COFF order independent of their textual declaration order

Native SP5 `/O2 /Gd` controls define eight ordinary tentative `int` globals
plus one explicit-zero ordinary-BSS anchor. Combining the eight globals in
one C object emits their COMMON symbols in this COFF order:
`rho, mu, delta, zeta, alpha, gamma, omega, beta` (all prefixed `_g_`).
Reversing every C declaration emits exactly the same COMMON-symbol order.
Each is external storage class 2, section 0, value 4; value is its required
allocation size, not a section offset. The initialized-zero anchor instead
has an ordinary BSS definition.

Native LINK allocates these COMMONs in the reverse COFF order in the tested
single-object cases. Splitting them into two objects and reversing link
inputs reverses their allocation groups. Thus changing declaration order
alone cannot provide the required native COMMON geometry. This measures
the emitted table and actual map order; it does not establish the compiler's
internal hash algorithm. Linker-layout50 records the link and coalescing
controls. Evidence: `.scratch/native-common-allocation/{probe.py,audit.json,
coff-order.json}`, native C sources, objects and command logs.

## 232. Removing the inherited border word preserves all four complete zlib functions

A full-source infblock.c control removes only the inherited twentieth
initializer, 0xffff0000, leaving the stock 19 indexed entries. It uses the
actual CMake SP5 flags, defines and includes. The border COMDAT becomes
76 bytes, flags 0x40301040, with no trailing word emitted by CL.

All four complete CODE contributions are identical to the canonical
object: **3680 bytes, 55 named fixups**, including compiler alignment.
The checker compares every CODE byte, section flag, relocation offset/type
and target name without masking or trimming. An unused extra array element
therefore has no effect on these functions' compiled bodies; this does not
prove that the extra word belongs to the original array.

The unchanged native link recipe shifts 17 readonly owners by four bytes,
starting with inflate_copyright at0x1002469c instead of0x100246a0.
Function positions and CODE fixup topology remain unchanged, but26
previously exact CODE operands lose their bindings. Whole-file overlap
differences worsen5320 ->6236. The readonly guard fails; other complete
game-writable/version/conversion-table guards pass. The control is not
promoted; linker-layout51 records the related-binary and IDA evidence.

Evidence: `.scratch/native-infblock-tail/{probe.py,compile-argv.json,
compile.log,infblock.c,infblock.obj,link-argv.json,link.log,audit.json,
changed-map-bindings.json,changed-code-operands.json,gates.json}`.
No source, library, compiler object or DLL in the production build changes.

## 233. Removing unreferenced COMMON placeholders leaves the native image unchanged

An SP5 full-source link_stubs.c control removes exactly three tentative
definitions: g_crc_table[256] (1024B), g_msg_buf[1] (1B) and
g_record_table[1] (2B). No reversed source or inspected native input fixup
references them. Their removal changes only the COMMON-symbol set; every
remaining COMMON retains its size. All non-debug sections retain their
complete bytes, flags and named fixups, including the ordinary68B BSS
contribution. No initialized data or CODE is removed from this object.

The native link reproduces the entire canonical DLL, SHA256
`27d2ff2ab733cdf24957b17719ba561c55d582b2923e14e28fa1bfc29c476c71`.
The control is promoted. Removing declarations that GC already discarded
does not shrink the output or explain missing original storage.

The old g_crc_table DATA marker incorrectly described a writable, zero-filled
COMMON at the reference's readonly CRC-table VA. Move the owner annotation
to the existing initialized crc_table in references/zlib/crc32.c; the shared
header now declares its actual const unsigned long[256] type. Managed
name/type/size updates use rebrew data set, followed by fresh verification.
The actual MAP symbol is0x100241a0 and all1024 readonly bytes match directly.
This is a declaration/owner repair, not another copy of the library table.

The annotated CRC source's complete native object contributions equal the
saved pre-change compiler object. Its one CODE contribution is320B with
nine named fixups; the readonly table is1024B. No code byte, relocation,
section flag or constant changes. The canonical rebuild preserves the
entire DLL. Linker-layout54 records the full verification and limits.

Evidence: `.scratch/native-crc-owner/`, including the full-source control,
native argv/logs, audit.json, managed-field CLI results,
canonical-owner-audit.json and canonical-crc-object-audit.json.

## 234. An empty stock data section still contributes native alignment

SP5 `/O2 /Gd /MT` compiles a 148-byte initialized byte array to ordinary
`.data`, flags `0xc0300040`. A separate object containing two initialized
doubles followed by three initialized ints has exactly28 data bytes,
flags `0xc0400040`: the ints begin at offset16. With just these objects,
native LINK places the second contribution at relative offset152, with
180 bytes of data VirtualSize. `/OPT:WIN98` and `/OPT:NOWIN98` leave those
measurements unchanged.

The unchanged stock ulldiv.obj has a **zero-byte** `.data` section with
flags `0xc0500040`, requesting16-byte alignment. Insert that complete object
between the two C objects and the second contribution moves to offset160;
data VirtualSize becomes188. Place it first and the original152/180 results
return. Place it last and the second contribution remains at152, while
VirtualSize rounds up to192. All three stock-object toys retain its104-byte
ordinary CODE contribution. Their `.data` RVA consequently differs from
the C-only toys; the reported offsets are relative to the prefix symbol.
No object is edited and no alignment storage is declared in C.

Thus an initialized-data census that drops every zero-size input can miss
real layout effects. This is not evidence for an invented owner or a general
formula for the server's missing extent. In the actual server, the existing
ulldiv/ullrem retention roots precede tzset; moving the code-free timeset
root after them restores tzset's28 bytes at0x10034018. All192 production
compiler objects are unchanged. Linker-layout55 documents the coupled
locale-table anchor, rejected alternatives and native output validation.

Evidence: `.scratch/native-ordinary-data-alignment/{probe.py,prefix.c,tail.c,
shapes.json,audit.json,*-compile.log,*-link.log,*-argv.json}`. The extracted
whole stock ulldiv.obj SHA256 is
`64126082ad755d49692d7a74ce26b6e6beb1bcd0b55809a949323fd06b033e94`;
the linked stock archive is unchanged.

## 235. An unused stock duplicate can change the native ICF survivor

Four unchanged SP5 stock members contain two pairs of identical43-byte CODE
COMDATs, flags `0x60101020`. The private _strncnt helpers in a_cmp.obj and
a_map.obj have storage class3 and no fixups. Public __strdup and __mbsdup
have storage class2, with identical complete bodies and three identical
REL32 fixups at offsets11/18/31 to strlen/malloc/strcpy. These are complete
object comparisons, including section size/flags and named fixup identities.
No CRT function is reconstructed or modified.

The previous canonical link forcibly selects mbsdup.obj despite zero
__mbsdup input-fixup references. Both public labels fold to0x10023812.
Its verbose trace reports86 bytes of ICF savings:43 for each pair.
Early selection of the actual days and exception tables changes both ICF
survivors while savings remain86. The private helper moves from reference
0x1002350a to0x1001f855, changing96 function bindings and13304 CODE bytes
outside the relocation fields. Complete initialized-data improvements do
not justify that executable-code regression.

Remove only the unsupported /INCLUDE:__mbsdup root. With the two early table
roots, native ICF again selects a_cmp's private helper at0x1002350a; savings
are43. The actual _strdup body remains at0x10023812 with all43 reference
bytes. Every remaining597 function label keeps its address; only the unused
__mbsdup MAP alias disappears. All192 C objects and the stock archive are
unchanged. The measured selected-member count becomes137 rather than138.

This demonstrates that an extra identical input can affect a different
folded pair's survivor. It does not establish a general ICF ordering rule
or prove the original's unused input composition. Byte-identical bodies
alone do not justify retaining every matching library symbol. Linker-layout57
records the native controls, full guards and accepted source of progress.
Evidence: `.scratch/native-crt-exception-root/{folded-stock-bodies.json,
probe.py,validate.py,accepted-checks.json,accepted-gates.json}` and native logs.

## 236. A tentative pointer and an initialized pointer use different native storage

Under the production SP5 C89 flags, `void (*g_panic_callback)(void) = 0;`
defines four bytes in ordinary `.bss`. Removing its explicit initializer
produces a COFF COMMON external: section0, value4, storage class2. Native
LINK `/ORDER` accepts that actual COMMON symbol and places it at the reference
0x10034610. The emitted storage remains one zero-initialized four-byte pointer.
The six input DIR32 references all have addend0 and bind to this owner.

A separate `__declspec(selectany)` initialized-pointer control also permits
native ORDER placement. It and the tentative-definition control produce
identical complete DLL bytes in the initial experiment, despite different
input storage forms. This is measured equivalence for this link, not a general
COMMON/COMDAT allocation rule. Each independently inserted callback shifts
the later bulk arrays32 bytes and increases file differences3900->4820.
Six exact operand gains alone do not justify that layout regression.

The existing entity pointer occupies four bytes followed by a28-byte native
alignment interval. All13 CODE references use its pointer value with addend0;
`gm_Open` allocates and clears the pointed-to0xa900-byte region, not an enlarged
pointer object. The actual sequence counter is another four-byte COMMON
external with five addend0 references. Move its ORDER entry immediately after
the entity pointer and use the tentative callback in its former early slot:
the counter uses four bytes of the existing interval, leaving24 bytes before
the next actual array. Every other mapped symbol keeps its prior address.
No object extent, array bound, fake allocation or padding definition is added.
The counter remains displaced from its reference0x10035408; its five operands
still bind to its actual new owner0x1014c6c4. No formerly exact operand is lost.

Converting the18 other ordinary zero-initialized support placeholders to
COMMON is an unpromoted control. They are not allocated by that control;
data VirtualSize becomes0x173f7e0 instead of0x173f800, but the same4820 file
differences remain. This does not prove the original ownership of these
placeholders or explain the missing3484-byte extent. Production leaves all18
definitions unchanged. Only the real callback declaration and two ORDER
positions are changed. Linker-layout59 records the accepted native build.

Evidence: `.scratch/native-panic-owner/{probe.py,validate.py,accepted-checks.json,
canonical-ownership-audit.json,member-audit.json,storage-audit.py,audit.json,
operands.json}` and each control's native source/object/DLL/MAP/argv/logs.
The generation probe asserts the superseded7bc baseline and must not be
rerun against the promoted77f build without deliberately updating its context.

## 237. A preceding COMMON array can consume an apparent alignment gap

The next actual logging owners are a four-byte crash callback, a four-byte
unsigned mode field and a one-byte crash-dump flag. Remove only their explicit
zero initializers in their three original C translation units. SP5 emits
COMMON externals with section0/storage class2/values4,4,1. All executable and
initialized-data contributions remain identical to the canonical objects,
including every section size/flag, byte and named fixup. No function body,
data type, object extent or stock member is reconstructed or patched.

Native ORDER immediately after the already-correct panic pointer puts these
owners at reference0x10034614/18/1c. Their20 complete DIR32 operand values
then match (crash callback3, mode15, byte2), with zero lost exact operands.
The nine bytes of real storage move the next COMMON from0x10034614 to
0x10034620: twelve bytes including native alignment. However the earlier
32-byte `g_save_extra_field` array moves from0x10034660 to0x10034680, rather
than0x1003466c. Its alignment consumes an additional20 bytes, moving every
large array32 bytes. A gap between the clock's end and the first large array
therefore does not prove capacity for a preceding insertion. This control
has4745 file differences versus3881 before and is unpromoted.

The actual dynamic-count and two family-count COMMONs are each four bytes.
Move their three ORDER entries after the existing sequence counter in the
entity-pointer interval. This removes exactly twelve allocated bytes before
the save array and restores its old address. The existing pointer plus four
real counters occupy20 of32 bytes before the next array, leaving12 bytes of
native alignment. No invented storage or padding declaration is added.
The three moved game counters remain unmatched; their matched bodies and
COFF fixups still bind to their actual owners. The other89 previous COMMON
bindings, including every large array and the sequence counter, stay fixed.

Removing the three ordinary BSS definitions also changes tail alignment.
Thirty-one other ordinary symbol addresses move twelve bytes earlier;
thirty-six move sixteen bytes earlier after native alignment. All were
already displaced, and no exact operand is lost. Data VirtualSize falls
sixteen bytes to0x173f7f0; its deficit grows3484->3500. Raw file length stays
270336B. The resulting actual native file has3816 differences,65 fewer;
whole-file identity remains incomplete. Linker-layout60 records promotion
and complete verification. The unchanged18 support placeholders and unknown
3460-byte original span remain unproved.

Evidence: `.scratch/native-log-common/{probe.py,gap.py,validate.py,shapes.json,
accepted-checks.json,accepted-gates.json,canonical-ownership-audit.json,
storage-audit.py,audit.json,operands.json}` and native sources/objects/MAPs/logs.
The generation probes assert the superseded77f context and should not be
rerun against the promoteddbcc build without deliberately updating it.

## 238. One real COMMON provider preserves storage sizes but changes physical order

The earlier39-provider duplicate experiment in linker-layout50 did not
move the original definitions. This control instead replaces every actual
tentative definition with an extern in eight full C source files and moves
the39 exact declarations into the existing first input, crt_imports.c.
The shared tree-sitter parser identifies the declaration spans. Sizes/types
are preserved, including the real GroupNode and DownloadState definitions.
No duplicate provider, extra source object, enlarged array or padding
declaration is introduced. The39 globals total24316040 bytes of COMMON.

Native SP5 compiles all nine full replacement objects. Each executable and
initialized-data contribution is identical to its canonical counterpart,
including complete section bytes/sizes/flags and named fixups. The provider
has exactly39 COMMON symbols with their existing sizes; all eight previous
owners have none of those symbols left. Two same-file tentative declarations
of the owner-window symbol are both replaced; they previously emitted one
COMMON. A provider count checks the actual objects, not just source text.

Use the shorter ORDER prefix through the actual save-extra field, leaving
the late game COMMONs unordered. Native LINK allocates the39 globals in the
reverse of the new provider's measured COFF symbol-table order. This is not
their reference order: town records appear first at0x10034b00, while the
clock globals scatter into the late bulk region. A single provider therefore
cannot reproduce the earlier separate-object prefix order merely by owning
the same declarations. The control changes138 mapped symbols while keeping
all597 function bindings,3499 live HIGHLOW sites and fixed CODE bytes.
It gains no exact operand and loses none, including the26 corrected logging
fields from59-60. All five complete value guards still pass.

The file worsens3816->5226 differences and remains16384B short; unpromoted.
Raw text differences2203->3643, readonly1270 unchanged, data62->32,
relocations0 unchanged. Data VirtualSize grows44 to0x173f81c through native
allocation/alignment although no declaration byte is added. That is not
proof of a missing owner. No production source/layout/tooling input changes.
Linker-layout61 records the original-input census and evidence boundaries.

Evidence: `.scratch/native-common-single-owner/{probe.py,analyze.py,shapes.json,
provider-symbol-order.json,audit.json,gates.json}` and all native sources,
objects, argv, logs, DLL and MAP. Probes require the canonicaldbcc context;
they are scratch controls, not a source-generation step for production.

## 239. Debug records can change COFF without changing the runtime DLL

The saved SP5 control compiles this complete C89 input with `/O2 /Gd /MT /Gy`,
then separately with `/Z7`, `/Zi`, and `/Zd`:

```c
int value = 7;
int zero;
int *pointer = &zero;
int __cdecl read_value(void) { return value + *pointer; }
```

All four objects have identical complete runtime code and initialized data,
including section sizes, flags, bytes, and named fixups. The eight-byte data
contribution contains one DIR32; the sixteen-byte function contains two.
The plain object already has a sixteen-byte `.debug$F` with one DIR32NB.
`/Z7` and `/Zi` add `.debug$S` records with SECTION (10) and SECREL (11)
relocations. `/Zd` adds no extra relocation-bearing section in this input.

Native links use `/DLL /NOENTRY /NODEFAULTLIB /INCREMENTAL:NO /OPT:REF`,
retain `_read_value`, and omit linker `/DEBUG`. All four complete DLLs are
byte-identical, SHA256
`9e70690c8077ca0289a802237f87297113c917dc10e556a93290d3879e5109ad`.
They have three live HIGHLOW entries, a 24-byte relocation directory,
26-byte `.reloc` VirtualSize, and no debug directory. Compiler debug flags
therefore do not change reservation in this measured input. This does not
establish the behavior of every server translation unit or of linker
`/DEBUG`; the CMake debug option couples compiler and linker flags.

When comparing runtime contributions, exclude `.debug*` by name. Testing
only initialized-data/code flags also admits `.debug$S`, so it incorrectly
reports runtime drift for this control. The initial scratch assertion was
corrected; no shared Rebrew defect was found. No production input changed.

Evidence: `.scratch/native-debug-reservation/{probe.py,audit.json,recheck.py}`
and all four native source/object/DLL/argv/log sets. `recheck.py` validates
the saved artifacts without invoking the compiler, linker, or Docker.
Linker-layout62 records the same bounded negative result.

## 240. Live COMMON extent can change relocation reservation without changing code

Seven native SP5 controls vary only `storage`'s extent in this C89 input:

```c
int value = 7;
unsigned char storage[4064];
unsigned char *pointer = storage;
int __cdecl read_value(unsigned int index)
{
    return value + pointer[index];
}
```

Use extents 1, 4000, 4064, 4065, 4096, 8192 and 32768. All executable and
initialized-data contributions have identical complete bytes, sizes, flags
and named fixups. Each object has exactly three DIR32 records and one
`_storage` COMMON with the requested extent; each native DLL has three
live HIGHLOW entries and a 24-byte relocation directory. The indexed read
uses the real array; no diagnostic storage enters the server build.

The one-byte COMMON begins eight bytes into `.data`. The measured larger
arrays begin at offset32 through native alignment. Extent4064 gives data
VS4096 and relocation VS26. Changing only that extent to4065 gives data
VS4097 and relocation VS36. The still-larger controls retain VS36.
This directly tests the page transition and cap proposed in linker-layout63,
rather than inferring them from different import/function inputs.

Docker access is verified in this continuation (daemon29.8.1); all seven
compiler/linker calls use the pinned project wrappers and stock SP5 image.
Canonical input/output is protected by a before/after hash. The independent
toy probe does not require a particular unrelated server hash to rerun.
Evidence: `.scratch/native-reloc-pages/{probe.py,audit.json}` and seven
complete source/COFF/DLL/MAP/argv/log sets. Linker-layout64 records the model
boundary and its remaining limits.

## 241. Actual allocator COMMONs can occupy the reference run without moving bulk arrays

The eight allocator globals already belong to `m_alloc.c` in their measured
32-byte sequence. Remove only their explicit zero initializers: array count,
four statistics, allocation counter, report-groups count and array pointer.
They become eight four-byte COMMON definitions; types and static zero
initialization stay unchanged. The same complete allocator code and
initialized data compile, including every section byte/size/flag/named fixup.
All other source objects stay unchanged.

Native ORDER after the corrected crash-dump byte places zutil's existing
one-byte empty-string BSS COMDAT at0x10034620 and the eight allocator fields
at0x10034624..0x10034640. The literal requests four-byte section alignment;
no new empty owner or gap declaration is supplied. All55 complete allocator
CODE operands and both zutil initializer pointers become exact. No formerly
exact relocation field is lost.

The allocator-only control moves the save array and every bulk array64
bytes and worsens file differences3816->4531. The save-array alignment
again consumes more than the nominal36-byte insertion. Do not promote it.

The accepted coupled control moves nine existing four-byte game fields
from the early ORDER region into existing alignment intervals. Seven fill
the28 bytes after the100-byte manufacturer table, ending exactly at the
next dispatch table. Two use eight of the twelve bytes after the existing
human-family counter, leaving four bytes before the next relationship
array. These are actual unchanged definitions, not duplicate providers,
new storage or padding. Their own reference addresses remain unmatched.

All bulk, clock, save-array, logging, and other protected COMMON bindings
stay fixed. Seven remaining early fields move naturally as byte fields
pack and DWORDs align; they were already displaced. Native ordinary BSS
shrinks32 bytes because the allocator definitions leave it. Data VS becomes
0x173f7d0,3532 short; the file remains16384 bytes short. Despite this extent
deficit, actual operand/file agreement improves:57 gained/zero lost exact
fields,161 fewer text differences and eight fewer data differences.
Native CMake reproduces the validated candidate exactly, with one source
object changed and191 other direct inputs unchanged, including EXP.
Linker-layout65 records the accepted build and complete verification.

Evidence: `.scratch/native-allocator-common/{probe.py,validate.py,shapes.json,
audit.json,accepted-checks.json,gates.json,canonical-ownership-audit.json}`
and both native controls. The generation probe requires the supersededdbcc
context; validation instead uses the captured before DLL/MAP and accepts
an explicit current candidate path.

## 242. Pool-root access does not establish an IDA array extent; a separate flag can be COMMON

The three definitions at the end of `gm_Open.c` occupy twelve ordinary
BSS bytes: `g_stream_pool`, `g_stream_count`, `g_connection_counter`, each
four bytes at object offsets0/4/8. Their reference addresses34670/34678/3467c
give incompatible section-base votes34670 and34674. The desktop IDA
decompilation guesses `_DWORD dword_10034670[2]`; that guess alone does not
establish an eight-byte pool definition.

All three direct live HIGHLOW references to this pool point at34670,
at CODE addresses10008e20/100090ab/1000921c. None targets34674..34677.
The complete `m_PoolAlloc` body (270 bytes, followed by two native NOP
alignment bytes) and137-byte `m_pool_free` body dereference
one pointer word through the supplied root. Their accesses at offsets4/8/12
belong to the separately allocated `BlockNode`, not a second root word.
This establishes the observed one-word access contract, without proving the
complete original root extent or excluding other indirect users. Retain the
four-byte definition until independent ownership/type evidence resolves
the neighboring four bytes.

An unpromoted native control moves the actual pool/count/counter definitions
to their respective caller translation units, replacing their old owners
with externs. Four complete objects preserve executable and initialized
data bytes, sizes, flags and named fixups. Total ordinary BSS stays twelve
bytes, split into three four-byte contributions. Pool/count/handler move
within displaced late BSS, but no full operand gains or loses exactness and
whole-file differences remain3647. Caller location is insufficient evidence
of original translation-unit ownership; do not promote this rearrangement.

The separately measured server-stop flag is a useful native repair:
`int g_handler_started = 0;` becomes `int g_handler_started;` in its
existing `server.c` owner. It emits an external four-byte COMMON (section0,
storage class2,value4); all complete executable/initialized contributions
are unchanged. One ORDER entry before the clock run binds it at reference
10034680. The existing four clock fields move together by four bytes and
retain relative offsets0/4/8/12. This matters because clock CODE uses
`g_current_year+4/+8/+12` across the neighboring declared scalars. Moving
year alone would break that contract. The sixteen-byte run still fits before
the unchanged slot table at100346a0.

Seven complete flag operands become exact; none previously exact is lost.
Those fields remove28 differing CODE bytes. Clock operands add26 differing
bytes because formerly coincident low address bytes change, although no
complete clock field was exact before. Net improvement is only two bytes;
count complete operands separately from differing bytes. Ninety-nine other
COMMON bindings,597 function positions,3499 live sites and non-fixup CODE
bytes remain fixed. Ordinary BSS/alignment effects shrink final data VS by
eight bytes, not simply the scalar's four-byte extent.

Evidence: `.scratch/native-vfs-storage-owners/`, especially both native
controls, their `shapes.json`, full pool disassemblies, direct-reference
census, `validate.py`, captured before inputs and ownership audit. The
generation probe requires the supersededbff baseline; validation accepts
the promoted canonical DLL. Linker-layout66 records the native result.

## 243. Uninitialized section roots affect COMMON placement and can split `.data`

Eight native SP5 controls keep one complete anchor object unchanged: three
DWORD globals, one explicitly zero and two tentative, plus a function that
reads them and an indexed64-byte game array. ORDER contains only the early
DWORD. Every variant has76 logical storage bytes, four live HIGHLOW sites,
identical fixed CODE and a48-byte text extent. Only the array's declaration
or `bss_seg` changes; no toy storage enters production.

Addresses below use the toy base10000000. The first five rows have one
output `.data`; the last row summarizes three separate controls.

| Array definition | Early / ordinary / game / late addresses | Data VS |
| --- | --- | ---: |
| Tentative default COMMON | 2000 / 2004 / 2020 / 2060 | 100 |
| Tentative under `.bss$G` | 2000 / 2004 / 200c / 2008 | 76 |
| Tentative under `.bss$0` | 2000 / 2004 / 200c / 2008 | 76 |
| Tentative under `.bss` | 2000 / 2004 / 2008 / 2048 | 76 |
| Explicit `{0}` in default section | 2000 / 2004 / 2008 / 2048 | 76 |
| Tentative under `.data$G`, `.data`, or `.data$0` | 3000 / 3004 / 2000 / 3008 | 64 + 12 |

The COMMON array receives32-byte alignment and adds24 native padding
bytes. All ordinary array variants emit exactly64 uninitialized bytes,
flags0xc0300080. A suffixed `.bss` contribution follows default COMMONs;
an unsuffixed ordinary `.bss` contribution precedes the late COMMON.
Thus a suffix can preserve game order while placing CRT COMMONs on the
wrong side of the game block. Ordinary default BSS is a distinct route.

The `.data`-named uninitialized controls emit LNK4078 for conflicting
attributes. Native LINK creates two `.data` sections:64B at RVA2000 and12B
at RVA3000, both with zero raw bytes. They do not match the reference's
single data section. Report both extents rather than treating the first
name lookup as the total. The extra virtual section page changes relocation
VS28->38 while all four fixup sites stay fixed; this also fits64's bounded
reservation model. No general section-order algorithm is inferred.

BSS has no raw bytes to fetch: check the loader-zeroed virtual ranges and
COFF uninitialized flags. The initial harness attempted a raw-byte read and
stopped; it also supplied an unsupported timestamp option, ignored with
LNK4044. Both are corrected, using the existing SOURCE_DATE_EPOCH wrapper
interface. The rerun has only the three expected LNK4078 findings. These
are harness/native section findings, not established Rebrew defects.

Evidence: `.scratch/native-bss-group-order/`, all eight complete C/COFF/
DLL/MAP/argv/log sets, `audit.json`, and retained rejected-harness logs.
Linker-layout67 records why no section-suffix strategy is promoted.

## 244. Real game definitions can move into native data archives without changing their readers

Move39 actual game definitions, with their original types/extents, from
eight existing source owners to a scratch data provider. The old definitions
become externs through the shared tree-sitter declaration parser. All eight
complete native objects preserve executable/initialized-data bytes, sizes,
flags and named fixups; other COMMONs keep their sizes. There is one provider
per moved symbol, no duplicate definition, and24316040 logical bytes.

A single data-only C provider gives each scalar an explicit zero and each
array/struct `{0}`. Native CL emits no CODE or initialized data, only a
24316052-byte ordinary BSS contribution, flags0xc0400080. The extra12 bytes
are native internal alignment. Clock offsets remain0/4/8/12, but the first
large array starts at offset16 rather than the reference's32-byte separation.
The original COMMON array alignment is not preserved by this ownership
change. Native LIB packs the complete object; LINK selects it after stock
LIBCMT. All original stock libraries remain unchanged.

A second control emits39 data-only C objects, each containing exactly its
original tentative declaration and one COMMON with the measured size.
No CODE, initialized data or ordinary BSS is emitted. Original providers
remain removed, so these replace definitions rather than coalescing extra
providers. Both native archives preserve every complete COFF payload and
have opposite physical member orders. Both unrooted links nevertheless
produce the same DLL and allocation order. In all four archive-root cases,
physical game allocation reverses the actual member load order.

Reference-order roots reverse game allocation and break the clock's
0/4/8/12 relationship; the full validator rejects that case before value
guards. Reversed roots restore the39-field sequence, but archive position
determines which side of the game block holds CRT COMMONs. Merely obtaining
the game sequence is insufficient. Linker-layout68 records the complete
negative controls and the unchanged canonical deliverable.

Evidence: `.scratch/native-game-data-archive/{probe.py,shapes.json,
data-shape.json,game_data.c,data-compile-argv.json,lib-argv.json,argv.json,
analyze.py,audit.json,gates.json}`; `commons.py`, `link-orders.py`, and
`commons/{shapes.json,archive-audit.json,audit.json,input-order-audit.json}`
with all native sources, objects, archives, links and per-case validators.

## 245. RVA-shaped raw words can be instruction bytes rather than address operands

Scan all 286,717 unaligned DWORD windows in the 286,720-byte configured
reference for absolute addresses in `[0x10034684,0x10035408)` or numeric
RVAs in `[0x34684,0x35408)`. The 3,460-byte BSS span has no absolute hits.
Five words resemble RVAs; decoding from established function starts rejects
all five as evidence of references into the span:

| File offset | Raw DWORD | Actual meaning |
| --- | --- | --- |
| 0x204 | 0x35000 | `.reloc` section's raw file pointer |
| 0x91c7 | 0x347c6 | `c6 47 03 00`: `mov byte ptr [edi+3],0` |
| 0x9cfc | 0x34868 | Prefix of `68 48 03 00 00`: `push 0x348` |
| 0x120ec | 0x34fe8 | Prefix of `e8 4f 03 00 00`: `call 0x10012440` |
| 0x12ed1 | 0x34784 | Inside `0f 84 47 03 00 00`: `je 0x1001321d` |

The CODE anchors are 0x10009020, 0x100093a0, 0x10012000 and 0x10012eb0, with their
current native MAP lines retained. Their reference positions were already
validated; Capstone starts at those anchors rather than treating a raw
matching byte offset as an instruction boundary. None of the five words
is a HIGHLOW relocation site. The existing desktop Hex-Rays export has no
matching literal address either, within this scanner's stated syntax.

This proves absence of those literal encodings, not absence of indirect or
arithmetic accesses. It does not establish an original object extent or
authorize gap-filling storage. The adjacent pool word and missing original
BSS composition remain unresolved. No source declaration changes.

Reproduce with `.venv/bin/python .scratch/native-header-recipe/span_audit.py`.
Evidence: `original-span-literals.json` and `original-span-decode.json` in
that directory, including reference hash, complete scan count, header field
identity, original instruction bytes, MAP anchors and decompiler hash.

## 246. An import-only translation unit has no runtime contribution

The former `crt_imports.c` contains forced `/INCLUDE:__imp_...` directives,
not C function bodies or storage. A native SP5 compile of a comment-only
replacement preserves every executable/data/BSS section's size, flags, bytes
and named relocations, while removing the retention directives. It defines
no external runtime symbol. Actual game calls and unchanged stock archives
still retain all 100 reference import identities and their named hints.

Do not keep the resulting empty source merely to retain a compiler input.
Lint correctly reports E001 for that unannotated file. Remove the source
and both CMake references instead. This leaves 191 C objects and the native
export object. Removing the empty object changes the Rich compiler record
`(id=10,build=8966)` from count192 to191, changes 65 header bytes including
the native checksum, and preserves every byte after the 4096-byte header
region. Both forms have `e_lfanew=0xe0`; neither resolves the established
Rich-free-reference mismatch. No object timestamp or header is patched.

CMake's changed source/custom-flag list triggers native recompilation of
retained objects. A previous direct-input hash manifest cannot be reported
as unchanged after that rebuild: native COFF timestamps can differ. Check
the terminal linker output against the independently validated complete
candidate instead. Linker-layout72 records the whole-file improvement and
the explicit IAT/exact-operand tradeoff, rather than implying that every
individual relocated field improved.

Evidence: `.scratch/native-import-natural/{probe.py,coff-shape.json,
compile-argv.json,compile.log,crt_imports.c,crt_imports.obj,argv.json,
link.log,audit.py,audit.json,gates.json,no_empty_probe.py}` and
`no-empty-object/{argv.json,link.log,server.dll,server.map,audit.py,audit.json}`.
The original source, DLL and MAP are captured under `before/`.


## 247. The tool's CRT can change import layout without changing C contributions

The CRT that runs CL/LINK is a separate input from the stock LIBCMT archive
linked into the game. Installing an unchanged Microsoft MSVCRT DLL in an
isolated tool runtime does not reconstruct any game CRT function.

Ten representative C compilations under Microsoft MSVCRT 6.0.8797.0 retain
all runtime section sizes, flags, bytes and symbol-bound relocations:
`spiel.c`, `spiel2.c`, `spiel622.c`, `server2.c`, `ProcessSendData.c`,
`m_alloc.c`, `loadsave3.c`, `cm_ExChangeAttribute.c`, `rdata_restore.c` and
zlib's `deflate.c`. Complete object hashes differ because the native object
metadata differs. This is ten controls, not proof for all191 translation units.
Do not change the default compiler profile on that evidence alone.

Two full native links reuse the same192 direct inputs and unchanged archives,
changing only the tool runtime. Original Microsoft MSVCRT 6.0.8168.0 and the
official VC6 redistributable's 6.0.8797.0 emit identical complete DLLs. They
preserve every function binding and nonfixup CODE byte while changing import
ordering. Link-layout73 records the actual comparator, the complete-file gain
and the fields that regress. No source, object, archive or executable is patched.

The reproducible experimental image uses the existing recipe generator in
`../recompile-toolchains`. The project opts in through the existing TOML overlay
at `cmake/toolchain-overlays/native-msvcrt.toml`; profile names containing dots
must be quoted TOML keys. The installed pinned Rebrew wheel resolves the
profile without a new registry implementation. The production recipe remains
unchanged pending a smoke compile and canonical CMake link through that image.
No smoke golden is guessed and no files are staged merely to satisfy a check.

Evidence: `.scratch/native-import-writer/compiler-runtime/audit.json`, both
`native-{runtime,redist}/` complete DLL/MAP/argv/log/audits, and the offline
profile/catalog/generation checks. Docker was not invoked during the later
restricted pass; those compilation and native-link observations are saved
results from the preceding work.


The pending runtime smoke bootstrap now has a concrete root fix: link-layout74
and `docs/rebrew-patches/smoke-profile-bootstrap.patch` record recipe-only
`--fixture` selection, nonzero-exit/stale-output rejection and167 offline
checks. These checks mock compilation and establish CLI/gating behavior;
they are not new observations of CL's code generation. The installed pinned
wheel is01e4e8bd...e49bc3; real image smoke and canonical native linking remain
pending, with the production compiler and target archive unchanged.

## 248. Link-only runtime selection preserves every existing compiler input

The Docker clarification supersedes section247's pending native checks.
Two actual compilations of the registered fixture through the new runtime
image produce stable masked object hash547b88f8...e546, equal to plain SP5's
golden. This is a fixed smoke fixture, not a new all-source CL comparison.
Keep production CL on plain SP5 and opt into Microsoft MSVCRT for LINK only
through the existing bridge/overlay mechanism.

Both canonical promotions in link-layout75 reuse all191 C objects and the
native EXP without recompilation or any complete-input hash change. Their
51-byte file improvement therefore comes from native import layout, not a
new C statement shape. Stock LIBCMT remains unchanged and supplies the CRT.
No reversed CRT bodies, empty directive-only C file, guessed golden, enlarged
storage, object patch or postlink step is added.

Reference-order and reversed real IAT roots are distinct controls. Under
Microsoft's runtime the reversed16-root WinSock order repairs all16 IAT slots
and eleven complete operand fields; the same root order under Wine was worse.
Rooting RtlUnwind early also retains its actual code thunk early, moving281
function bindings. Removing that explicit root preserves its natural CRT
reference and restores the semantic checks, but the remaining80-root orders
still worsen whole-file agreement. Preserve these negative controls rather
than treating an import count or normalized match as exact emitted bytes.

Evidence and final fresh262/262 function verification are in link-layout75.
The unresolved917 data fields with shared0x1200 displacement are placement
evidence, not a compiler-shape diagnosis or a proven missing allocation.


## 249. An int formal narrowed to a local byte preserves MSVC6 dispatch code

`DispatchLogOutput` was defined with an unsigned-char formal while its callers
used an int prototype. To compile its real module together, use an int formal
and narrow once to a block-top local unsigned char before the existing flag
checks. Preserve the low-eight-bit behavior rather than widening those checks.

```c
void __cdecl DispatchLogOutput(const char* msg, int output_flags, int level)
{
    char buf[260];
    unsigned int written;
    FILE* stream;
    int idx;
    unsigned char flags;

    flags = (unsigned char) output_flags;
    /* Existing control flow and flag checks follow. */
}
```

With plain SP5 `/O2 /Gd`, the original and this form emit identical complete
290-byte function bodies and identical24 typed relocations. MSVC6 folds the
narrowing into its existing byte loads/tests; the shared callers keep an int
prototype without char-conversion warnings. This is measured for this function,
not a rule that arbitrary narrowing is free.

Use the stock `<stdio.h>`, `<string.h>` and `<time.h>` declarations in the
initializer, `FILE*` for its stream, the actual int crash-filter return type,
and an explicit function-pointer cast for the stored integer callback. The
old hand-declared `void* fopen` conflicts with the real `FILE* fopen` when the
sources share a unit. Genuine SDK types preserve the initializer's complete
404-byte match. The initial six-source compile failed C2371; changing every
caller to a char formal introduced C4761 warnings. Both are rejected controls.
The int/local-byte form and corrected declarations compile the six-source
cohort without warnings, preserving all eleven function sizes, nonfixup bytes
and relocation topology. Full-link data movement still rejects that merge;
link-layout78 records the narrower cohort that preserves runtime bytes.

A Rebrew measurement deficit initially obscured these controls: unchanged and
int-formal sources both reported203/290 because `probe` passed no symbol map to
the fail-closed relocation validator. Its caller now supplies the shared map,
function VA and IAT region, and counts all four bytes in a valid slot for its
historical relocation metric. The validator is unchanged. A wrong catalogued
DIR32 target and a wrong REL32 callee remain rejected; failed catalogs return
an infrastructure error. Root regressions are4failed/6passed before and10passed
after;135 focused tests, Ruff/check/format and targeted mypy pass.

The direct sibling root fix is preserved in
`docs/rebrew-patches/probe-relocation-context.patch` and applied to the pinned
9123ca68 source. Installed noneditable wheel SHA256
`17afd012e0bac10dbc156acee82be0c0ee168afe04808ddb879782ccbcbaa2e8`
changes only `probe.py` and RECORD versus the previous01e4e8bd wheel. Actual
Docker probes now report290/290 for both valid forms,404/404 for the SDK
initializer, and287/290 for a deliberate wrong-global control. A repeated
SDK probe leaves both managed metadata files unchanged. The first whole-run
metadata guard observed a concurrent `verify` writer; that is not evidence
that `probe` writes STATUS. One later ephemeral compile hit its existing
60-second timeout and passed on an unchanged retry; no limits were raised.

Evidence: `.scratch/native-error-tu/` native probe JSON/logs, before/after root
regressions, focused test/mypy logs, installed wheel audit and metadata hashes.


## 250. Live literals restore the original pool and permit the complete Error TU

C-shape249's full merge was rejected because fourteen explicit string/blob
owners were emitted before the remaining automatic literal COMDATs. Their
arrays were a fragment-level reconstruction of the original pool. Restore
actual live literals instead: replace the28 crash-message blob offsets by
their exact terminated strings, the four crash-tail strings by their contents,
and the11 handler/message arrays and `wt` mode by the same live literal values.
The log-level table,96-byte file-name table,newline/default-name owners and
all real mutable/BSS globals retain their definitions. No new storage, unused
literal, pointer table or padding is introduced.

The complete six-fragment cohort compiles in one native SP5 invocation without
warnings. All eleven function sizes, every nonfixup instruction byte and typed
relocation offsets/kinds equal the previous complete control. The casts,
initializer scheduling, joins and flag logic stay as measured; this restores
pool representation rather than changing control flow.

The full linked pool from0x10027078 through0x100274a8 matches the reference
exactly. All four runtime sections equal the accepted baseline byte for byte,
including every relocation operand and table byte. Fourteen explicit data
aliases disappear and44 native live-literal COMDAT symbols replace them;
surviving bindings remain fixed. Do not describe these names as unchanged.
Data metadata still describes the existing byte extents, which are verified
at their actual reference VAs; no fake C array is retained solely for a name.
Remove obsolete source DATA markers for deleted aliases, keep every original
function marker across targets, and retain actual global markers.

The scratch native DLL is c805c9c5aec84c522f27931d98980bd236755e81b97f755dd58f6bda1187b1a9,
2734 overlapping differences,16384 bytes short. Rich's actual C-input count
changes189→186 and its key becomes0x4662de1a; the PE offset remains0xe0 under
the native formula. This is one more header-byte gain and an authentic source
cohort, not complete-file recovery. Section79 of link-layout records the
complete runtime/semantic guards and production validation.

Evidence `.scratch/native-error-tu/literal-cohort/` native compile/link argv,
zero-warning logs, function topology comparison, full candidate audit/value
checks, literal-owner and symbol-change inventories. The obsolete partial
sources are preserved in source snapshots, and all production promotion must
be reproduced by the normal CMake target before acceptance.


## 251. Compiler-equivalent zlib code does not identify the original producer

Compile all twelve actual zlib inputs with the stock `msvc-6.0` profile and the
same CMake definitions, includes and `/O2 /Gd /MT` flags. Eleven preserve every
runtime section's size, flags, raw initializer/instruction bytes and symbolic
relocation bindings. `inflate_blocks` alone changes eight nonfixup bytes in
its unchanged 3328-byte COMDAT. At offsets 0xb90/0xb94 and 0xbf7/0xbfb, SP5
loads EDI from `[esp+0x10]` before ESI from `[esp+0x48]`; the older compiler
reverses those independent loads. All named callees and switch-table local
section/value targets remain identical despite renumbered local labels.
The reference matches SP5's scheduling. No source change is needed to repair
already-correct code, and none is made.

Native LINK establishes the producer record: this profile emits product10,
build8168, not8047. The eleven exact objects therefore cannot explain stock's
additional eleven build8047 C records. The twelve-object full-file count
improves because native headers move, while correct instructions regress;
that is a rejected control, not an accepted byte-match improvement. Replacing
only the eleven exact objects worsens complete-file agreement and adds the
same unsupported build8168 record. LINK-layout80 records both terminal links.
No compiler override is promoted. Evidence `.scratch/native-zlib-producer/`
objects.json, runtime-audit.json, infblock-detail.json, controls-comparison.json
and both full native argv/log/result sets; production objects and DLL stay fixed.


## 252. A shared-source cohort can preserve server code and conflict with Gold ordering

All69 inputs in `command_c/` resolve to `/O2 /Gd`. A direct concatenation
exposes genuine reconstruction conflicts: unsigned-int versus unsigned-short
returns for `gm_AllocSpieler`, void versus pointer results for `gm_AddObjekt`,
char versus short pointers for parent resolution, two incompatible views named
`player_slot`, and narrow/full-width argument declarations. Normalize only
scratch copies: compatible declarations, explicit narrow function-pointer calls
where already required by matched code, separate names for the two equal-size
row views, explicit pointer/integer casts, one missing kill prototype and removal
of one unused local. Resolve relative includes that actually exist; leave shared
include-search names such as `rebrew_types.h` to the original include paths.
The normalized native SP5 compile has zero warnings. All69 complete function
sizes, nonfixup instruction bytes, flags and typed symbolic relocation topology
match the existing objects; local numeric label renaming preserves destinations.

The first full link nevertheless moves35 functions. `cm_RouteCommand`, placed
in the command_c directory, records the real `lobbycommands.c` path in its live
logging string and belongs later at0x10014ca0. Its272-byte span moves to
0x10010530 and shifts the34 intervening functions by272 bytes. The linked
candidate07245cb2...651fc94 has24417 differences. Correct object code alone
is insufficient proof of a whole-TU source grouping. Exclude this other-module
handler rather than adding artificial code order or changing annotations.

The68-handler cohort preserves all four complete runtime sections byte for
byte after native LINK. All597 function MAP bindings,3499 HIGHLOW sites,100
import identities/hints/slots,surviving public bindings,137 stock CRT members
and five value guards pass. Native C count186→119, Rich keyb162ba9f and PE
f0 yield candidate3cae8443...526339f,2735 differences: one more header byte
than the2734-difference production baseline. Rich agreement is nonmonotonic
while input grouping changes; no new byte gain is claimed.

All-target lint then exposes nine unique W030 warnings: these shared functions'
GOLDTL VAs do not ascend in the server's source order. Do not remove accepted
Gold identities, mute W030 or alter correct server bodies to hide this. The
attempted promotion is rejected; all68 fragments are restored from exact
snapshots and the new command.c removed. All114 original identity/global
markers are preserved. Restored all-target lint returns4116 passed per target,
zero errors and warnings. Both native controls remain scratch evidence only.
Future compatible cohorts must satisfy every annotated target's source order
before promotion. LINK-layout81 records the complete controls and restoration.


## 253. Adjacent compatible command cohorts preserve code and shared annotation order

Partition the68 measured command fragments at each annotated-module VA descent.
The resulting contiguous groups contain13,1,7,2,15,6,3 and21 functions. Each
part ascends for SERVER and every GOLD/GOLDTL identity it carries; no identity
is deleted or rewritten. Keep the singleton `cm_ExAllocRaum.c` unchanged and
restore the other67 fragments as seven genuine command source cohorts.
This reduces fragmentation without violating the shared-source order checks
that rejected section252's single object.

Native SP5 compiles all eight controlled cohorts. Restore the real
`void gm_KillSpieler(unsigned int,int)` declaration and, in the two affected
parts, `int gm_eval_SlotVoll(char*,int,int)` instead of relying on implicit int.
Both real callee declarations are found in existing source. These declarations
emit no storage and preserve every already-matched call. Complete68-function
COFF checks establish identical sizes, flags, nonfixup bytes and symbolic
relocation offsets/kinds/targets. All native compile controls are warning-free.

The final source files preserve the controlled compiler token streams after
resolving includes and excluding comments; C89 comment conversion retains all
annotation markers. Seven files preserve110 markers, plus four unchanged in
the singleton, for114 total. The typed callback forms and distinct row-view
names from252 remain as measured. All three targets lint4056 passed with zero
errors and warnings, and an independent per-module order audit passes.

Native LINK yields f12b99461f19ae44e29e44390865d2917ed7633241f1d206eb83e74fe446c6d7,
2563 differences rather than2734, with every runtime section byte unchanged.
C producer count126 replaces186 and the native PE offset becomes the stock e8;
LINK-layout82 records the header prediction and complete semantic gates.
These are real source inputs, not empty objects, extra producers or padding.
The source is prepared and CMake recipes resolve correctly; final normal
production recompilation/verification remains required because this session's
managed permissions now deny access to the Docker socket. The successful
native control predates that access change; the production DLL remains c805c9c5.

Evidence `.scratch/native-command-tu/compatible/`: eight compiler argv/logs,
objects/functions reports, native LINK/audit/gates, source-promotion.json,
source-token-equivalence.json, offline-final-check.json, final-lint-summary.json
and production-readiness.json. No native control is copied into production.

Production validation update, 2026-10-03 01:11 UTC: a separate host build
failed after a canceled duplicate Make invocation deleted the shared
`gv_ExtendProductionTime.c.obj`. Its compile rule and source remain present.
The failed native LINK removed `build/server.dll`; c805c9c5 is now the last
completed production hash. Thirteen concurrent source/header changes also
prevent attributing a future build solely to these cohorts. Fresh offline
lint passes 4052/4052 per target with zero warnings/errors. The scratch control
and its compiler findings remain valid, but current production acceptance is
pending. See `compatible/concurrent-build-failure/` for terminal receipts.

Repair update, 2026-10-03 01:19 UTC: one host native CMake build succeeds
under stable source/config/layout hashes. Production is now 8e02205d...5f0858,
2563 differing bytes and 16384 bytes short. The 171-byte improvement is real
production evidence, while whole-file identity remains incomplete. Other
global-ownership edits make this hash differ from the original f12b9946
control. All 597 function bindings, 3499 live HIGHLOW sites, 100 import
identities and five full value guards pass; complete nonfixup code is identical
to reference. Fresh function compilation remains pending, since the host's
full verify command timed out without a report and this session cannot compile.
LINK-layout 83 records the separate placement-tool reproduction.


## 254. Available alternate CRT archives do not supply the missing original producer

Compare the complete runtime contributions of the fixed 137-member set from
the accepted verbose SP5 control against the available stock RTM, SP4 and SP6
archives. Include section sizes, flags, raw initialized/code bytes, named
fixups and ordinary BSS. Exclude debug/directive sections; do not treat
timestamp or archive packaging differences as runtime faults.

| Stock archive | Equal complete members | Different complete members | Missing names | Selected C/C++ producer build |
| --- | ---: | ---: | ---: | ---: |
| RTM | 103 | 33 | 1 | 8168 |
| SP4 | 101 | 35 | 1 | 8797 |
| SP6 | 100 | 36 | 1 | 9782 |

Each alternate member set contributes 113 C producer records, not the
reference's 124 records from build 8047. Their C++ producer also changes;
the 22 assembler records remain build 7299. `chr.obj` is missing from each
alternate set. Whole contribution differences do not prove every difference
would survive final LINK, but the incompatible producer IDs already reject
these archives as an explanation of the stock header. Do not switch CRT
versions merely to try to enlarge BSS or improve a header count.

SP5 and the available SP5 Processor Pack archive are byte-identical, SHA256
28b9f04962378ec4668072f37d7fd2835cd6cacc17b40cf22002c57bd8e76714.
This is a read-only archive comparison, not a native link experiment, new
production gain or a fresh census of the current link's selected members.
All archives remain unchanged. Evidence
`.scratch/native-crt-archive-alternatives/offline-comparison.json`.


## 255. A real array COMDAT removes COMMON alignment but displaces a correct neighbor

The save loader owns `int g_save_extra_field[8]`; its two users read eight
DWORDs, establishing the complete 32-byte extent. The reference array starts
at 0x10035478, four-byte aligned. Current native COMMON allocation starts it
at 0x10034660, eight bytes after the preceding header DWORD's end. Test only
this definition in a scratch copy of the original owner:

```c
__declspec(selectany) int g_save_extra_field[8] = {0};
```

Native SP5 emits a 32-byte `.bss` COMDAT, flags 0xc0301080, with four-byte
alignment. Every complete executable and initialized-data contribution,
including named fixups, stays identical to the original object. LINK moves
the array to 0x10034658, proving the expected alignment mechanism. It also
moves `g_handler_started` from its correct 0x10034680 binding to 0x10034678
and the game clock eight bytes earlier. The bulk slot table remains fixed.

All 597 function bindings, import slots/hints, live HIGHLOW sites, complete
nonfixup code and five full data guards pass without warnings. Nevertheless
37 fixups change, zero gain exactness and seven lose it. File differences
increase from 2563 to 2570 with the same 16384-byte shortfall. Reject this
control; the reference alignment alone does not prove a weak/selectany
source definition. No production declaration changes. LINK-layout 85 records
the complete comparison. Evidence `.scratch/native-save-array-comdat/`.


## 256. An indexed table load can numerically coincide with another global

`gm_NextEntityQueryMatch` reads
`g_dispatch_table_b[g_query_match_count - 1]`. Native COFF lowers the
displacement to a DIR32 relocation naming `_g_dispatch_table_b`, with raw
signed addend -4. Its field at linked VA 0x10016420 is 0x1013869c in current
production and 0x1013989c in the reference. Those are the respective table
bases minus four; the index register completes the effective address.

Current `_g_query_count` happens to occupy 0x1013869c, immediately before the
table. Matching this field solely by its resolved numeric value therefore
assigns the wrong owner. Moving the counter must leave the table-relative
field unchanged. The native COFF symbol, relocation type 6, signed addend
and reference table base independently prove that relationship. They do
not establish that the source aliases the counter and table.

This was caught while predicting a bounded game-counter ORDER control;
no source/global metadata is changed to repair the mistaken prediction.
The corrected prediction explicitly preserves the table field. Fresh host
ordinary CLI tests pass all 19 changed-reference users as RELOC with full
annotation/object sizes, including this complete function. Evidence
`.scratch/native-early-game-counters/{observed-bindings.json,prediction.json}`
and `.scratch/native-query-pointer-order/focused/`.


## 257. Track ECX definitions before assigning a thiscall signature

Current ordinary `rebrew binary asm show 0x10006e30 --size 137 --target server.dll --json`
labels `m_pool_free` as `thiscall (no stack args)`. Original caller and callee
bytes establish two stack arguments and caller cleanup instead. Preserve the
existing matched `__cdecl` prototype.

At 0x10006e30 the callee loads the item from `[esp+8]`. After saving ESI,
0x10006e65 loads the root argument from `[esp+8]`, now the first argument's
stack position. Earlier ECX is created by `lea ecx,[edx-4]`; it is a scratch
pointer into the item header. Later ECX holds the root loaded from the stack.
Neither use establishes an incoming object pointer in ECX.

Two complete original caller sequences confirm the ABI:

| Caller | Item push | Root push | Call | Caller cleanup |
| --- | --- | --- | --- | --- |
| `CloseVfsStream` | 0x10008e1d `push esi` | 0x10008e1f `push 0x10034670` | 0x10008e2a | 0x10008e2f `add esp,8` |
| `vfs_OpenStream` cleanup | 0x1000921a `push esi` | 0x1000921b `push 0x10034670` | 0x10009220 | 0x10009225 `add esp,8` |

The current root heuristic checks for `[ecx...]` in the first ten instructions
and suppresses its thiscall guess only when the first instruction loads ECX
from memory. It misses ECX's intervening local definition. Root locations are
`../rebrew/src/rebrew/asm.py:401` and the signature consumer
`../rebrew/src/rebrew/skeleton.py:339`; the latter can turn this incorrect hint
into a one-argument `__fastcall` skeleton. These sibling files are outside this
session's writable roots. No tool source, compiler input, prototype, metadata
or native output is changed by this diagnosis.

The same read-only trace inspects all 286717 unaligned DWORD windows in the
untouched reference. Exactly nine literals point into 0x10034670..0x1003467f:
three pool-address pushes, four count accesses and two connection-counter
accesses. All nine are live `.text` HIGHLOW fields, and all current COFF
addends are zero. None points into 0x10034674..0x10034677. Six root accesses in
the two allocator contracts each touch one four-byte word at offset zero;
node accesses at offsets4/8/12 refer to separately allocated blocks.

Source and metadata names/addresses/types therefore have no proved alias
error. The existing 12-byte section places pool/count/counter at offsets0/4/8,
while their original addresses are34670/34678/3467c. Original co-location and
the intervening word's owner/extent remain unproved. IDA explicitly marks its
two-DWORD pool type as guessed. An original allocation/type or symbol/COFF
record is needed to distinguish a larger root, a separate object and native
contribution alignment before changing storage. The literal scan does not
exclude other indirect arithmetic accesses. No new native control is ready.

Evidence `.scratch/native-pool-conflict-trace/{trace.py,report.json,inputs.json,
functions.json,current-pool-free-asm.json}`. Input/definition hashes and
production/reference remain unchanged; the analysis invokes no native tools.


Tool correction (2026-10-03): the sibling checkout is writable in the current
session. `calling_convention` now examines ECX uses before definitions in its
existing ten-instruction window. A local `lea`/load, a partial ECX write,
exchange or unsaved call clobber stops incoming-pointer inference; a preceding
pointer use/save retains it. Ordinary asm now reports `m_pool_free` as cdecl.
The focused asm/skeleton suite passes 236 tests; regression coverage includes
the real pool-pointer opening and preserving valid thiscall cases. This is a
bounded ABI hint, not complete control-flow or stack-argument inference.
The latter is recorded in the upstream ideas file. No game prototype, source
storage, reference byte or production byte changed. Patch and receipts are
`docs/rebrew-patches/goal-abi-and-marker-fixes.patch` and
`.scratch/goal-calling-convention/`.


## 258. Preserve the stream handle when its argument slot becomes the read count

TL `0x004013b0` and `0x004013f0` initially receive a stream handle in argument
one. The first `fcn_004011f0` call writes a byte count into that same argument
slot. The reference preserves the original handle in `esi` and passes it to
`vfs_ReadData` after allocating the output buffer; it returns the overwritten
count. Passing the overwritten argument as the final VFS argument loses that
handle. The prior C emitted 58 bytes against the 60-byte first reference.

The following C89 pattern emits the complete reference body under the configured
msvc-6.0-sp5-pp `/O2 /Gd` profile at both sites:

```c
int __cdecl read_wrapper(volatile int count, int* out, void* tag)
{
    void* buffer;
    int stream;

    stream = count;
    read_count(stream, (int*) &count);
    buffer = allocate(count, tag);
    *out = (int) buffer;
    read_data(buffer, count, 1, (void*) stream);
    return count;
}
```

With an ordinary `int` argument, the preserving copy emits 62 bytes: the handle
is first loaded into `eax`, then copied to `esi` after the initial pushes.
Reordering the two local declarations or declaring `stream` as `register` leaves
that sequence unchanged. The volatile argument emits the reference's opening
`push esi; mov esi,[esp+8]; lea eax,[esp+8]`. This qualifier is a measured C
reconstruction choice, not evidence that the original source spelled volatile.
Both canonical bodies test RELOC 60/60 with equal full object/reference lengths
and three call relocations each. Neither default flags nor sizes were changed.
No linked-client or complete-file improvement is established by these object
checks. Source and receipts: `src/GOLDTL.fcn_004013b0.c`,
`src/GOLDTL.fcn_004013f0.c`, `.scratch/goal-client-loop/stream-variant-results.json`
and `test-4013{b0,f0}-final.json` in that directory.


## 259. Early pointer return and ordered copy setup recover the animation builder

TL `0x00406510` allocates an event, initializes its owner/callback/flags, and
copies the animation name into offset `0xf0`. The original caller at
`0x0040d7f7` tests EAX and sets a flag at returned-object offset `0x18c`; the
old unconditional-zero return was incorrect. Its inventory span is 80 bytes,
but the body ends after 75 bytes and is followed by five NOPs.

The explicit `if (obj == 0) return 0;` followed by a pointer return emits the
early `pop esi; ret` and reaches 63/75 agreement. Loading `s = name` before
the owner store at `+0x14`, then assigning `d = obj + 0xf0` immediately after
that store, emits the reference's ECX source load and ESI destination setup
before the remaining initialization stores. The C89 byte-copy loop remains
`while ((*d++ = *s++) != 0) {}`. This ordered candidate matches RELOC 75/75
under the configured default client flags. Moving the two local declarations
alone is inert; the ordinary pointer return with a conditional body emits
73 bytes and agrees at only 22/75. Scratch evidence is
`.scratch/goal-builder/{early-return,ordered-copy,pointer-return}-test.json`.
The landed C uses a typed owner pointer and symbolic callback declaration;
these preserve RELOC 75/75 while adding a verified callback DIR32 relocation
to the allocator call REL32. Canonical test and fresh per-file verify pass.
This is an object-byte finding; it establishes no linked-client or full-file gain.


The 2026-10-10 restore and rename retains RELOC 75/75 with two relocations under
the current upstream compiler fingerprint. The source now names the inferred
`CreateAnimationEvent`; its two callers are connected through explicit upstream
reference binding. GOLD's original counterpart at 0x405970 has the same body
plus five trailing NOPs, which depress the default import score to 94.393546.
Its actual body scores 100; the extent issue is recorded upstream and no GOLD
builder row was imported. Receipts: `.scratch/goal20/animation-builder-tl-test.json`
and `animation-builder-original-evidence.json`.


## 260. Compare operand order in the task-removal owner guard

TL `0x004050c0` tests whether a task is its owner's list head. Writing
`*(char**) (owner + 0x128) == task` emits `cmp [eax+0x128],edi` (`39`);
writing `task == *(char**) (owner + 0x128)` emits the reference's
`cmp edi,[eax+0x128]` (`3b`). That single-byte correction raises ordinary
object agreement from 97/110 to 98/110 under default client flags. The whole
110-byte length already agrees, with no relocations. The two remaining clear
sites reverse `mov ecx,0x65` and `xor eax,eax`; this is not a byte match or a
measured linked-client gain. Source `src/GOLDTL.fcn_00405080.c`; scratch
`50c0-compare-order-test.json` and `diff-50c0.json` under
`.scratch/goal-character/`.


## 261. Keep the sound scale temporary double until its final float store

Positional sound constructor TL0x418c80 initially emits153 bytes (18/153).
Initializing the source result to null and nesting the work behind all three
pointer guards recovers150 bytes and123/150; it also preserves the original
non-null allocated-slot result when voice->entry is missing. Computing a float
scaled local before object stores reaches142/150. A double local, cast to float
only when writing range, emits the native late fstp and matches150/150.
Applying that double-local shape to request TL0x4193f0 resolves its long-standing
eight-byte rotation:132/132 instead of124/132. No compiler flags changed.

Symbolic extern const double g_662b40 replaces raw scale addresses and preserves
both matches (constructor six relocations, request four). Native TL0x662b40 and
GOLD0x5eba10 contain identical eight-byte5040038e78029a3f (1/39.37). Declaration
is a read-only view with unresolved storage owner, not a new allocation. Direct
literal multiplication and division by39.37 instead schedule the float store
early,109/132; neither literal variant is applied. The original source spelling
of the scale is unestablished. These results are staged, not canonical claims.

Explicit native call/data mappings validate TL constructor150/150 and both
client request132/132. Wrong scale+8 and call+16 controls are rejected. GOLD
constructor148/150 has two actual object-field differences (+0x20c vs TL+0x210),
so unchanged import would be incorrect. Shared game-object layout remains work.
Receipts .scratch/goal-shared-sound/{relocation-check,type-evidence}.json and
check-relocations.py. Baseline/after-header gates still precede acceptance.

Shared sound resolution accepted2026-10-04: TL constructor150/150 and request132/132 are canonical RELOC, voice helper is EXACT29/29 in both clients. Dedicated inferred client_sound.h preserves one84-byte record/API; full all-target comparison94642 has no lost matches or removed rows, zero4110 drift. Earlier staged/pending wall52/shapes261 wording is historical. No raw linked-file gain.


## 262. Separate float distance assignment from the positional sound scale

TL4190d0 / GOLD417b10 body is466 bytes, ending at4192a1/417ce1,
followed14 NOPs. Earlier returns are internal paths; branches419231/419246
remain in the function. A double distance local produces470 bytes/133
positional agreement. A float local with combined sqrt-and-scale expression
produces466/458; separating `distance = sqrt(z*z+y*y+x*x);` from
`distance *= g_662b40;` matches466/466. The native cleanup of the three
coordinate x87 values precedes the scale multiplication. No flags or asm.

The formula preserves linear and curved volume terms, clamps only the
linear integer term at zero, averages them with0.5f and uses threshold5.
Existing/new-voice paths and the retention/replay controls follow native
reload ordering. Shared SOUND_SOURCE layout remains84 bytes. Native slot
checks reproduce all466 bytes in both clients with19 relocations and reject
11 wrong camera/scale/call bindings per client. Retain the original VA in
the control catalog so DIR32 mismatch checking does not become an
uncatalogued-address fallback; override both decorated and undecorated names.
Scratch receipts .scratch/goal-crt-retirement/volume-*.json and
check-volume-bindings.py. Canonical application/import follows the accepted
CRT classification gate; full after-function gate is still required.

### 263. Typed DirectInput prefix calls preserve indexed-vtable code

TL4117c0/4117f0: INPUT_DEVICE pointer plus typed stdcall Acquire/Unacquire
members at0x1c/0x20 emits the same42-byte body as raw int-pointer vtable indices7/8.
Shared header canonical aliases preserve Gold410710/410740, also42 bytes.
Separate INPUT_SYSTEM vtable (CreateDevice0xc) and INPUT_DEVICE vtable prefix
(SetProperty0x18, SetDataFormat0x2c, Event0x30, Cooperative0x34) remove the old
misused Com/placeholder types without changing TL411820’s738-byte body.
SDK DIPROPDWORD replaces the flat20-byte PropDword: four header DWORD fields
under diph, dwData at16, SetProperty takes &dipdw.diph; const GUID/DIDATAFORMAT
objects passed by address preserve all51 relocations. Typed Release ULONG
callbacks preserve shared cleanup107 bytes, including its unusual keyboard-release
then mouse-clear path. Prefix sizes describe recovered views, not complete SDK
interface vtables or backing allocation sizes. Thirteen compile-time layout
assertions pass both MSVC6 profiles. Canonical positive binding audits and52
wrong-slot/call controls pass. Receipts .scratch/goal-input-types/. Full all-target
gate69842 accepted with exactly2 changed TL rows and2 new Gold rows; no losses.
Header filename/types are reconstructed.

## Biased table displacement from a zero-based read view

At TL41a950, `((const int*)0x662bf8)[i - 0x14]`, guarded to indices20..31, folds the 80-byte subtraction into the native indexed displacement: `mov eax,[eax*4+0x662ba8]`. The complete25-byte function remains EXACT under the configured MSVC6 profile. The older `((int*)0x662ba8)[i]` emits identical bytes but describes a base within unrelated strings. The new spelling describes only the actual accessed view, without defining storage or claiming a complete backing allocation. Scratch probe: .scratch/goal-getter-extents/pixel-view-test.json; native evidence: .scratch/goal-input-drain/table-helper-native.json.

## Pointer-typed conditional CRT tail wrapper

At TL42e520/Gold42ecf0, changing `int fcn_0042e520(int a)` plus `int fcn_0066080a(int)` to `char*` argument/return types for both leaves the complete19-byte native body unchanged: byte flag load/test, input pointer returned on true, otherwise a REL32 tail jump to the CRT helper. Native bodies have13 trailing NOPs outside the function. Scratch probes .scratch/goal-net-stats/next-wrapper-typed{,-gold}-test.json are RELOC19; typed COFF audits map native flag/callee and reject four wrong-address+4 controls across both builds (.scratch/goal-net-stats/next-wrapper-bindings.json). Canonical source not changed in this probe. No new CRT implementation.

## Additional unused CRT prototypes can disturb a large server function

Adding two legacy client-only char*-returning function prototypes to crt_globals.h makes server gm_AllocSpieler10018850 lose8 bytes within its3689-byte body (NEAR3681/3689); moving those prototypes from top to end leaves the same8-byte loss. Full308/158-byte stock attribution then establishes the real SDK function _strupr. Restoring the original header declarations and binding the two legacy names to _strupr via preprocessor aliases, using string.h, restores RELOC3689/3689 without changing gm_AllocSpieler source. Both client wrappers stillRELOC19; final all-target gate pending. Receipts server-order-repair.json,server-sdk-alias-repair.json,full-runtime-attribution.json in .scratch/goal-vfs-casefold. This is compiler context sensitivity, not a Rebrew defect.

## Typed table view retains signed integer address iteration

Count/reset probes for TL4737e0/4737c0 andGold476c80/476c60 replace raw start/end constants with `(int)g_1011980` and `(int)(g_1011980 + 6)`, retain an int address iterator, and use `sizeof(Pair0c_1011980)` plus typed key/val accesses. Configured Win32 MSVC6 still emits the native signed JL loop, stride12, end addend72. Complete count25/reset27 bodies are RELOC in bothclients, with two DIR32 relocations for base/end. Native binding checks reject four wrong-table+4 controls. This proves the observed table view without inventing a definition or backing owner; the legacy datatype name and unobserved third word remain unresolved. Evidence .scratch/goal-display-counters/{count,reset}-view-{tl,gold}.json andview-bindings.json. No canonical source changed in these probes.


### Byte parameter suppresses integer extension at the call boundary

Gold40dd90 native loads `mov cl,[eax]`, pushes ECX, calls453890, and returns1 (complete21 bytes). The callee453890 reads only byte[esp+4]. Existing caller declares the callee parameter int, so an unsigned-char expression requires extension and mismatches. A scratch prototype `int __cdecl fcn_00453890(unsigned char)` preserves the existing expression and emits all21 native bytes after resolving its sole REL32. Wrong callee+4 rejects with the correct-native sentinel retained; IAT wildcard disabled. This proves a byte-width parameter for this call, not original signedness or the callee return type. Scratch only; no canonical source/header/metadata edit. Evidence .scratch/goal-small-extents/next-gold-{40dd90-probe,40dd90-bindings,453890-native}.json.

Canonical follow-up (2026-10-04): DISPLAY_COUNTER uses id/value plus four uninterpreted bytes, retains12-byte stride, and replaces duplicate local record views. All18 updater/renderer/initializer/caller objects reproduce their old bytes; typed relocations are identical except the explicit Rebrew CLI reset/count names. Reset/count remain complete27/25 native-byte RELOC matches with correct table base/end and four wrong-address controls rejected. Signed integer-address iteration remains deliberate. This is object/codegen evidence; full shared-header regression40361 remains pending. Receipts goal-display-counters/{canonical-bindings,users-object-audit}.json.


### Existing byte/constant callers can share a byte-width prototype

TL450a00 ignores its incoming flag. Replacing its void(void) definition with void(unsigned char flag), adding (void)flag, and using one canonical prototype preserves all38 object/native bytes. TL40eca0 previouslydeclared int(char); its return value is unused and wrapper returns1, so the canonical void(unsigned char) declaration preserves its21 bytes. Constant0/1 callers previouslyusing void(int) keep their argument pushes. All11 affected build objects are byte-identical, with typed relocation records identical after normalizing only the corrected TL40ec60 callee identifier from453890 to450a00. Six independently resolved wrong-address controls reject. One callerTL43ace0 uses E9 tail transfer, not E8 CALL; the initial audit assuming onlyE8 failed and was corrected, without changing C. This establishes codegen/interface compatibility, not original signedness or return-type attestation. Evidence goal-client-call-api/{canonical-bindings,users-object-audit,users-object-audit-attempt1}.json; full67476 remains pending.


### Random-helper return declarations affect copies before widening (2026-10-04)

Scratch probes with the configured MSVC6 PP profile show that TL caller 0x4faa90 emits `mov di,ax` followed by an `and edi,0xffff` when its callee is declared `unsigned short(int)`. Declaring the same callee `int(int)` and explicitly casting the result to unsigned short emits `mov edi,eax` followed by the same mask instead: the body shrinks from85 to84 bytes. The explicit cast preserves the arithmetic value but does not reproduce the return-width hint. In the boolean caller0x4a9000, an explicit unsigned-short result cast does restore the original64 object bytes. The pointer-typed caller0x4ad1c0 also preserves all228 object bytes and typed relocations after using an integer return plus an explicit pointer cast at the use. These are object-to-object experiments, not new native caller promotions; the original callers have accepted RELOC baseline receipts.

The helper itself does not establish its unique original prototype: an int parameter narrowed to an unsigned-short local range emits the same32 native bytes as the existing unsigned-short parameter form for server1001a0d0, TL42e410 and Gold42ec00. Each complete native comparison binds its stock rand operand, disables IAT wildcards, and rejects a wrong+4 binding while retaining the correct-address sentinel. Do not infer a canonical source signature from identical helper bodies alone or globally replace caller declarations. Evidence: `.scratch/goal-random-helper/{caller-type-probes.json,native-intarg-audit.json,caller-type-probe-checkpoint.json}`. No game C/header changes were made by these probes.

### Random-helper return width changes both epilogues (2026-10-04)

Keeping the extracted `gm_RandomMod(unsigned short n)` body and changing only
its return type from `int` to `unsigned short` makes both configured MSVC6
profiles emit34 bytes instead of the native32. The remainder return changes
`mov eax,edx` to `mov ax,dx`, and the zero return changes `xor eax,eax` to
`xor ax,ax`; each adds a66 operand-size prefix. An unsigned-short return with
an int argument narrowed into an unsigned-short local also emits34 bytes.
The int and unsigned-int return variants both match all32 bytes for server
1001a0d0, TL42e410 and Gold42ec00, with the stock-rand operand bound, IAT
wildcards disabled, and all6 matched-variant wrong+4 controls rejected.
These probes support retaining the existing int-return definition; they do
not distinguish signed from unsigned32-bit returns or prove a unique
original prototype. Caller narrowing remains a separate C-shape problem.
Evidence: `.scratch/goal-random-helper/{return-type-probes.json,return-type-instructions.json,return-type-probes-job.json}`. Scratch only; no game-source, header, flags, or managed-identity change.


### Slot byte signedness changes equality promotion (2026-10-04)

At TL 0x005ca560 and Gold 0x005be320, the comparison of the current slot byte at +9 with a char-pointer byte at +9 uses two byte loads and `cmp al,dl`. Changing only the slot declaration from char[] to unsigned char[] emits `xor eax,eax`, a byte load, `movsx edx,byte ptr [ecx+9]`, and `cmp eax,edx`; the complete object body grows from477 to480 bytes. An explicit `(char)` view of the slot byte restores all477 object bytes and typed relocation records in both clients. This equality compares promoted values: the unsigned view alone changes behavior for high-bit bytes as well as the code shape. Three other shared byte-use functions (TL57ff20/5aac20/5aadd0; Gold577950/5a1900/5a1ab0) retain their176/277/253 bytes after the declaration change because their reads narrow into char locals. Evidence: `.scratch/goal-resolver-slot-types/{results,signed-comparison-instructions}.json`. Scratch probes only; no source or verdict promotion.


### Unused named variadic parameter does not establish a prototype (2026-10-04)

The query helper uses &arg_count and advances an int pointer through the filter
arguments; its named first_arg parameter is unused. Removing that third named
parameter preserves all316 SERVER bytes and all300 bytes in each client under
the configured VC6 profiles. The logging statement is enabled only in the SERVER
scratch build; literal bytes and every typed reference independently agree with
the respective native body, and every wrong binding rejects. This demonstrates
body compatibility for two variadic declarations, not a uniquely recovered
original prototype. Callers and declarations still require a separate audit.
Evidence: `.scratch/goal-query-filter-extent/{shared-native-proof,
shared-two-named-native-proof}.json`. Production source and flags are unchanged.

### Empty helper knowledge changes calls, not just register allocation (2026-10-10)

TL CharacterClearSitting406560 has an 87-byte native body. Correcting its C to
retain the seat pointer across a void helper and pass model/name in native order
emits 98 bytes under the processor-pack /O2 /Gd profile, rather than the previous
incorrect 90-byte body. The original retains EAX/ECX across402aa0, whose complete
body is one RET; the standalone caller conservatively preserves the seat/entity
in EDI/EBX. Moving an ordinary empty definition before the caller removes its
call and emits69 bytes, including with /Ob0 or pragma auto_inline(off). Moving
it after the caller retains98. These bounded experiments do not establish the
original declaration/TU/optimization context. No helper body, pragma, inline
assembly or alternate flags were added to production. Behavior and byte identity
remain separate: the corrected body passes16 branch cases and rejects reversed
arguments/wrong-seat-offset controls, but retains SIZE_MISMATCH87 versus98.
Evidence: `.scratch/goal20/clear-sitting-{legal-variants,no-inline-variants,
corrected-test,behavior}.json`. Initial legal-variants `size` is the compared
slice length; full lengths are in its compiler messages and corrected-test
`obj_size`, not the truncated comparison bytes.

### Mode-check ordering shares failure returns (2026-10-10)

TL Buergerrecht starter499a50 is125 bytes. Testing mode1 first, then an
`else if (mode != 0)`, produces145 bytes under default processor-pack /O2:
failure returns are duplicated. Testing `mode != 1` first, rejecting nonzero
modes inside it and validating the output state in the else branch, produces
the native early shared return and complete125-byte body. No goto or flag
override is needed. Explicit shared-failure gotos also produce125 but move
the return to the end and change branch layout; /O1 variants produce119/121.
Only the ordinary inverted /O2 spelling matches. Float literal payloads0.44f
and16000.0f, all operands and negative controls independently match both TL
and GOLD bodies. Evidence `.scratch/goal20/citizenship-{return-layout,
starter-audit,gold-audit,starter-behavior}.json`;640 C89 cases pass.

### Prototype consolidation can change line constants (2026-10-11)

The shared plant lookup's canonical declaration is `char* __cdecl
plt_FindPlantInfo(int key)`. Replacing the client unsigned-return declaration
requires explicit unsigned-char views in the owner-update caller: its comparison
at record+0x44 must keep zero extension. Replacing declarations in place preserves
the parent source's line count. Adding the definition's header include as an
extra line changed real compiled `__LINE__` immediates in rd_AddBKBox/rd_GetBKSize;
using the existing blank line restores the bytes without a `#line` override.
MSVC also renumbers `$L`/`$SG` internal symbol names after declaration changes.
Compare their actual section/value bindings, not just generated spellings:
12 actual target/flag groups preserve complete COFF code/data section payloads,
typed relocation sites and98 function measurements with no missing symbol.
Evidence: `.scratch/goal20/plant-callers-byte-preservation.json` and the earlier
failed section-difference receipt. The matching table and69-byte lookup body
were independently audited against all three native binaries.

## Narrow helper formals control partial-register argument loads (2026-10-11)

The stat formatter at TL4e7600/GOLD4e5af0 calls the slot accumulator with
`gm_WalkEntityChain(*(unsigned short*)entity)`. Declaring that helper's formal
as `unsigned short` emits `mov ax,[esi]; push eax` and matches all90 native
formatter bytes under `/O2 /Gd`. Changing only the formal declaration to
`int` adds `xor eax,eax` before the word load and grows the body to92 bytes.
Every other instruction and typed relocation site is unchanged after that
two-byte shift; resolving the wide variant's operands still fails the native
comparison. The existing numeric helper's `int raw_idx` definition narrows
inside its body and matches the124-byte callee, so a callee byte match alone
does not settle the shared declaration. The caller supplies the missing
width evidence; the existing canonical spiel.c definition already takes an
unsigned short. Evidence: `.scratch/goal20/stat-formatter-width-control.json`
and `stat-helper-declarations.json`. No qualifier, assembly or extra flag
was needed.

## Prototype-only headers preserve MSVC6 translation-unit context (2026-10-11)

Consolidating `gm_WalkEntityChain` into the existing `entity.h` changed the
call order and scratch argument offsets in GOLDTL493ee0, although six initial
representative object probes passed. A small `spiel.h` containing only the
existing unsigned-short prototype preserves all 82 affected target/flag groups
and 108 complete function bodies. Keep the replaced declaration on the same
source line; compiler-generated local labels are compared by section/value.

The declaration's storage-class spelling also matters here. Adding `extern`
to the original bare `int` prototype shrank server `gm_Open` from 861 to 859
bytes. Restoring the original declaration form restores RELOC 861 without a
body or flag change. Both complete shared client objects remain unchanged.
Evidence: `.scratch/goal20/stat-helper-after-final-prototype/`,
`stat-helper-shared-final-prototype.json`, and
`stat-helper-server-bare-prototype-test.json`.


## Shared prototype position preserves commutative integer register roles (2026-10-14)

TL5c95d0 has a complete 639-byte dialog body. Replacing its incorrect void
category declaration with the shared integer-returning prototype at the top
of the file changes three bytes around the st[4]+st[5] sum: ECX/EDX load
roles and LEA base/index order. Moving the owning spiel.h include to the
original declaration position preserves all 639 bytes with the original sum
expressions unchanged. Correct return type and ordinary flags remain in use.

An explicit discarded-result cast leaves the LEA difference. A separately
computed scalar sum can also reproduce the body, but the accepted header
position requires no extra local or expression changes. All 137 surrounding
caller bodies and their typed operand graphs are unchanged, and all 194
placeholder call operands independently resolve to the native helpers.
Evidence: .scratch/goal22/spiel-unification/caller-order-probes*.json,
users-{before,after}.json and matched/unmatched native-call receipts.


The required full corpus exposed a separate implementation-context regression:
importing the broader spiel.h into entity.h shrank server gm_Open from 861 to 859.
The preexisting extern resolver declaration in entity.h and bare category
prototype at its original spiel.c position restore all 861 bytes. Retain these
compatible implementation declarations; caller consolidation still uses the
shared interface. The narrow 137-caller preservation did not prove the whole unit.
Evidence: spiel-unification/server-gm-open-restored.json and the initial/full
corpus reports. No source body, flag or assembly workaround was adopted.


## Six-element array loops reduce to native display-counter address loops (2026-10-14)

Ordinary signed-int index loops over six DISPLAY_COUNTER records reproduce the
complete 27-byte reset and 25-byte count bodies in both clients. VC6 strength
reduces the index to a pointer advancing by 12 bytes, with a signed comparison
against the table plus 72. Reset stores value 0 before ID -1; count increments
for IDs other than -1. Explicit integer address iteration is unnecessary.

The global declaration supplies two DIR32 operands per body, for the base and
end. Complete relocation application gives all 104 native bytes; a table base
shifted by four fails. The final four record bytes stay an uninterpreted byte
region. All 18 affected caller bodies and typed operand graphs remain unchanged.
No flags or assembly are added. Evidence: .scratch/goal23/pool-unification/
production-native-proof.json, index-native-proof.json and users-{before,after}.json.

## Typed scene draw-data cleanup preserves both 137-byte bodies (2026-10-15)

An ordinary signed-int loop over `object->zeichendaten->teile[i]` reproduces
TL439d80 and Gold43cd80. The bound draw-part strides are4a4/198 and the count
bytes are163c/96c. Keep the unconditional cleanup of `teile[3]` after the loop,
then clear the count, free and clear draw data, and finally clear `kontext`.
The context clear also runs when draw data is null. Do not cache the draw-data
pointer or count across cleanup calls, or suppress the final part-three call
when the loop already visited it.

Explicit target guards retain the distinct draw-part destinations439c90/43cc90;
the existing shared `m_FreeTracked` supplies41ddd0/422620. Full relocation
application reproduces all137 bytes per target and all six operand sites.
Four shifted-callee controls reject. Both154-byte unlink helpers and32-byte
destruction wrappers retain their complete bodies and rejecting controls.
No flags, assembly, padding or storage are added. Receipts:
`.scratch/goal41/cleanup/{production-native-proof,object-native-proof}.json`.

## Auxiliary-record cleanup shares one typed 133-byte algorithm (2026-10-15)

TL456b80 / Gold45ccc0 use four records at draw offsets0x1384/0x754 with
strides0x9c/0x80. The full244/292-byte native draw constructors establish those
bounds within allocations0x1640/0x970. These are array stride views, not separate
allocations. Record+8 TL /+4 Gold holds the object compared by the154-byte
cleanup callback; the following pointer is dereferenced by per-record cleanup.
Other exposed words remain inferred access views with unknown semantic types.

A common `zusatz_flag` occupies the bit immediately below `darstellungsflag`.
TL replaces its one-bit rest; Gold reduces rest from3 to2, preserving eight
bits and the existing flag. Native constructor stores and paired cleanup bodies
confirm masks1/4. Both target compilers retain all six prior sizeof/extents and
bound offsets; two new stride bindings assert each record's size and fields.

Keep the four-element signed-int loop, nonzero first-word test, cleanup call,
object-pointer clear and three word clears in that order. Reload draw data after
the call. Explicit guards retain native per-record providers456b10/45cc80.
Full relocation application reproduces all133 bytes per target; wrong-callee,
opposite-layout and wrong-flag controls reject. The existing137-byte draw-data
cleanup,154-byte unlink and32-byte destruction bodies remain complete.
Receipts: .scratch/goal42/{production-native-proof,negative-controls,
draw-cleanup-native-proof,object-native-proof}.json andtype-*.json.


## Full spiel.c context and allocator byte-condition residue (2026-10-15)

TL gm_AllocObjekt502fe0/Gold 0x500190 includes renderer work and embedded two-stage
switch maps; its native extent is2,003, not the discovery extent2,016 that includes
thirteen trailing NOPs. Kuna misses the indirect switch arms. The server-only seed
cannot reconstruct the client body.

The same ordinary C compiled alone matched only 585 bytes; replacing the existing
function in the full spiel.c context matched 1,409. Surrounding definitions affect
VC6 register/global caching. Initial pointer-zero order, universe initialization
before child-field writes, an integer random selector narrowed from unsigned short,
duplicated native parent-choice calls and repeated native model tails increase
agreement to 1,771 TL/1,777 Gold. Preserve actual call/load/store ordering; do not
manufacture a cached global or target-only source shape to tune the isolated body.

Remaining residue starts at byte 1,299. Native uses MOV AL,[owner+54], ADD AL,67,
TEST AL,AL, MOV stack-byte,AL, then JE. Candidate uses CL and ADD's flags, omitting
TEST; its longer ADD encoding leaves the executable stream one byte shorter.
Both total symbol extents stay 2,003 because following tables are aligned. Late
branch displacements/operands and table targets expose the difference.

Measured without improvement: separate versus conditional byte assignment,
implicit narrowing, signed versus unsigned byte, reading/narrowing the DWORD,
compound byte addition and the canonical unsigned-byte pointer view.
Computing/assigning only on the nonzero path changes
frame size and worsens the match; promoting the narrowed local to int also loses
the native frame. Do not repeat these probes or a declaration/qualifier sweep
without new native/compiler evidence. No assembly, padding or flag change adopted.
Receipts: .scratch/goal50/alloc-*.{c,json}, full-unit, native-layout-proof.json and
literal-audit.json. New production source remains honestly NEAR_MATCHING; complete
operand bindings, renderer contracts and raw client providers remain open.


## Character model flag word emits the native high-byte OR (2026-10-15)

In ch_CreateMesh TL 0x403880/Gold 0x403070, `model[0x8d] |=0x10` through signed char*
produces a seven-byte excess from load/OR/store. The native consumer 0x40342a loads
WORD[model+8c]; `*(unsigned short*)(model+0x8c) |=0x1000` emits the native direct
byte OR. This is a supported word-access view, not proof of an original typedef.
The complete ordinary-C bodies then match 777/787 bytes with 61 operands and 45
rejecting symbol controls. Four explicit float zeros and ordinary strcpy/strchr/
strstr preserve native copy loops and branch order. Gold's extra scene call adds
nine bytes; its moved display bit needs SHL rather than TL's ADD, adding one.
No assembly, padding, new flag override or declaration sweep. Production context,
literals and rejecting controls: .scratch/goal51/constructor-proof.json.

## A forwarded stack DWORD does not establish an int parameter (2026-10-15)

The animation wrapper TL `0x44c620` / Gold `0x44e4a0` forwards its third stack slot
with a DWORD load/push. Its consumer TL `0x44e1e0` nevertheless reads only the low
byte at `0x44e309` and stores it into animation `+0x169` at `0x44e32d`. Kuna
independently recovers a char third argument. Caller TL `0x404a00` stores its looping flag as a byte, then
pushes the surrounding stack word; the upper bits are not a full-width contract.
Gold's core at `0x44f8b0` makes the same byte load at `0x44f9d9` and store at
`0x44f9fd`; its Kuna seed also retains a char third argument. The bounded native
flag window validates this access, without claiming a complete core-body match.

Use a canonical char loop flag through the loader, its core declaration and the
`0x418b40` forwarding wrapper. Declaring int changed the ordinary preload caller from
342 to 340 bytes; the reviewed char contract restores all 342 bytes in both clients
and preserves the 207/108-byte wrappers. Animation names and lookup results remain
pointers. This is evidence from the call chain, not a type chosen from match score.
Source spellings remain inferred. The shared 207-byte loader passes eight operand
sites and seven rejecting symbol controls per target; unbound destinations remain
native comparison hypotheses, without a raw-link provider claim. Receipts are in
.scratch/goal52/{loader-core-inventory-native,loader-core-kuna,preloaders-char-loop,
loader-wrapper-char-loop,loader-native-proof}.json.

## Implicit final row in a local string matrix (2026-10-16)

TL406ee0 / Gold406340 initialize 15 rows of 64 bytes, then scan all fifteen.
Fourteen observed string literals initialize the first fourteen rows; ordinary
aggregate zero-initialization supplies the last row. The first C candidate used
an explicit final `""`, which emitted 1,117 bytes and an extra literal operand.
Omitting that initializer emits the native 1,102 bytes in both production
contexts: the final row uses one 16-DWORD clear with no empty-string copy.
All 58 literal operand sites per target validate their complete fourteen literal
extents. Keep the concatenated AUSGANG/LAUFEN1 string as one native entry; splitting
it into two rows changes the filter. No flags, padding, assembly or fabricated
locals are needed. Source spelling is inferred from full native agreement,
not uniquely recovered. .scratch/goal55/{first-tl,implicit-tl,implicit-gold,
native-proof}.json preserve the failed and accepted measurements.

### Character camera script exits and separation probe (2026-10-16)

TL `0x40d980` / Gold `0x40ca60` each contain 218 executable bytes.
The adopted ordinary-C `MoveCharacterCamera` emits 221 bytes in each client;
its mismatch remains recorded. Preserve the null-character diagnostic/return1,
four ordered string cases, selector values0..3, dereferenced mode, and return0
for every valid-character path, including an unrecognized name. Initial,
cached-object and cached-name forms emit221; a positive continuation emits225.
The remaining difference concerns entry/register saves and exit layout; those
observations do not uniquely establish the original source spelling.

Bounded read-only controls on the complete new script unit: `/O1 /Gd` emits
Walk159, camera166 and registration882, losing the established185/1033 shapes;
`/O2 /Gd /G5` is neutral; `/O2 /Gd /G6` emits Walk187 and leaves camera221.
Keep the configured `/O2 /Gd`. No CFLAGS/STATUS promotion comes from these
controls, and no assembly, invented locals or padding is justified. The
registration and walk bodies match in both production contexts, while the
Gold three-byte stub operand remains an explicit comparison hypothesis.

Unadopted TL `0x402d00` separation recon: native744 bytes, first C720,
reloaded/reused-counter C745. Native multiplies in z*z+y*y+x*x order, reads a
word flag and repeats task45 tests, including an unreachable100-radius case.
Kuna's order must not replace those instructions. Register/frame/flag-load
shape and an unexplained16-byte stack allocation remain unresolved. Do not
invent a float[4] view, padding, volatile access or assembly. A signature miss
is inconclusive; Gold's fixed-prefix hit at57f3a0 does not prove a counterpart.
Receipts/seeds live in `.scratch/goal56/separation*` and the native402d00 body.


### Six-participant event validator (2026-10-16)

TL `0x4dc7d0` / Gold `0x4daf80` match one ordinary-C body at 1,920 bytes each
under the configured Processor Pack `/O2 /Gd`. That complete extent includes
the seven-entry indexed switch table: TL code returns at `4dcf33`, table bytes
are `4dcf34..4dcf4f`, and the next function begins at `4dcf50`. Gold's next
function begins at `4db700`. The old discovery extents, 13,264 and 13,616,
swallowed subsequent independent functions; their released bytes remain
unassigned code, with only evidenced NOP alignment counted as padding.

Keep all six participant lookups unconditional. Only the sixth validation is
conditional on count >= 6. Preserve null/type-15/inactive checks, busy/query
ordering, and the native second-participant path's reuse of the FIRST
participant's busy flag and ID. Both fourth and fifth validation failures select
error 4. The success path uses ordinary `strcat` with 64- and 512-byte local
buffers; the seven-case failure dispatch needs no flags, assembly or filler.
Kuna is a useful control-flow seed; native loads and operands decide these
otherwise surprising details. The first isolated C candidate already matched.

The formatter's second word is a tagged ID/address contract. Native code
compares it with signed `0x4800`; smaller values select localization IDs,
otherwise it is a format pointer. Its EBP+0x10 vararg start proves two fixed
arguments. `(int) "%s"` represents that evidenced boundary and produces the
correct per-target three-byte compiler literal (TL `679060`, Gold `5f8318`).
Do not retain a raw TL address or adopt Kuna's inferred six-fixed-argument
prototype from its aligned-frame decompilation.

The paired 630-byte event consumers resolve their two actual registry field
operands to backing+16. Three syntactic field references emit two operands;
the initial load is reused at the indirect call. Complete production proof
covers ten bodies, 6,412 bytes, 306 operand sites, 16 independently checked
local/table operands and 148 wrong-address rejecting controls. Unbound externs
remain explicit comparison hypotheses; this is not client raw-provider proof.

The old TL `4d74b0` transfer callback still emits 799 versus native 801 bytes.
Its declaration reconciliation preserves all 799 old compiled bytes and every
fixup. Do not claim the unchanged weak result as a new match. Receipts and
replays: `.scratch/goal57/{native-proof,transfer-preservation}.json`, native/Kuna
inputs, formatter evidence and the complete production comparison logs.


### Court decision source and stateful sum (2026-10-16)

TL `0x4df1b0` / Gold `0x4dd960` are complete native 2,536-/2,528-byte bodies,
including seven-entry switch tables. Their physical case order is 0,1,2,3,6,4,5.
Numeric source ordering initially emitted2,556 TL bytes and changed shared exits;
following the actual native order removes that mismatch. Moving `i = 0` before
the case-5 text-ID assignment closes six scheduling bytes at2121..2126. No
further scheduling experiment is warranted without new evidence.

The five-byte-near scratch expression is INCORRECT: it evaluates the OTHER
entity query before OWN, whereas native code evaluates OWN then OTHER. Both
queries use gm_WalkEntityChain, which changes shared query/iterator state.
C89 does not sequence the operands of addition. Reversing or parenthesizing the
combined calls did not enforce ordering in the measured compiler. The native
stateful control with IDs17/29 observes native trace17,29 versus candidate29,17
and different final query state. Never adopt that candidate or report its
2531/2536 TL and2523/2528 Gold byte scores as a faithful implementation.

The adopted ordinary C explicitly sequences the queries before division by2000.
Native saves the first result in EBP and adds the second directly into EBP;
current correct C copies the second result to ECX and adds/multiplies there,
adding two executable bytes. Alignment absorbs the size in TL; Gold grows four
bytes overall. The internal compiler cause and original C spelling remain
unproved. Extra temporaries, +=, reversed saved-value sums, combined-call forms,
positive/guarded exits, loop-result locals and one outer-comma control are
measured and retired. No flag/declaration sweep, assembly, padding or speculative
provider readdressing is justified. Original TU context remains open.

All seven action cases retain their different participant tests/defaults, timeout
before input handling, case-3 notification, case-2 unmatched-button waiting and
case-5 unconditional exit-flag store after a valid input. Disabling a case-5
button does not erase its saved handle. Complete native/C x86/VEX traces pass
186 bounded service-mock cases per client, including unsupported tags -1/7,
matching/nonmatching participants, five input selectors, timeout paths and all
three case-5 buttons. This is bounded evidence, not universal equivalence or a
byte verdict. The production compare remains STUB (TL2536) / SIZE_MISMATCH
(Gold2532/native2528). Keep its explicit blocker and correctly ordered source.

Receipts/replays: `.scratch/goal58/{decision-boundaries,decision-traces,
query-order-control,decision-production-*,decision-outer-comma-*}.json` and their
scripts/logs. Complete literal checking on the rejected aligned candidate finds
seven operand sites for two strings. Its relocated code differs at721/729/732/
740/747; that independent control is not proof of production raw-link providers.


### Goal59: participant-reset cursor bias and unreachable runner test

TL `4e4f10` and Gold `4e36a0` have complete 162-byte native bodies, differing only
at three DIR32 table operands. Their preceding 65-byte tail-call bodies and the
15/14-byte alignment gaps delimit them independently. Inventory repair is separate
from source matching and preserves the preceding RELOC identities.

The shared source emits 162 bytes but walks the participant table from +4;
native walks from +8. Both write fields in order 0,8,4,12, then the event's ID and
later flag byte. The compiler's addressing bias changes instruction lengths for
the middle stores and the signed end-pointer operand. With all operands applied,
both targets differ at offsets 9,34,36,37,38,39,42,53,123,130,143. These are not
unresolved external calls: all three COFF fixups refer to the known table backing.
The binding checker correctly refuses promotion. Equal size is insufficient.

Byte/word/address cursor and private typed-record experiments, counted/do loops,
store ordering and chained assignments did not close the residue. Indexed outer
iteration removes an extra two-byte cursor adjustment. Keep the shared ordinary-C
body and explicit blocker; do not invent an alias global, qualifiers or assembly
to force the bias. No original declaration order or record spelling is proved.

Seven bounded native/C VEX cases per target compare all table bytes and canaries,
and preserve the event input. Counts 0/1/2/16, null, mixed/all-active IDs and a
non-type-3 path pass; a four-byte wrong table binding fails. Preserve the repeated
inner reset within each outer pass: IDs for later rows may still have their
previous values. This is bounded evidence, not a universal proof or byte verdict.

For the larger runner, TL `4e5a00` ends at RET `4e61f0` (2033 bytes), Gold
`4e4060` at RET `4e486e` (2063). The earlier 2016-byte TL slice was truncated.
Kuna removes native's unreachable `(flags == 0) & 2` branch. An isolated ordinary
C89 `if (skip && !event[0x26] & 2) return;` under the pinned Processor Pack emits
TEST/SETE/TEST-bit-2/JNE. It is a plausible source-shape explanation, not recovered
spelling; the original source/TU remains unproved. This is not a decompiler bug.

The runner cannot simply reuse TL's layouts in Gold. Native Gold sign-extends
viewport dimensions from adjacent words; TL reads dwords. The scene-table loop
uses Gold stride 0x2ec, count 768 and fields +0x18/+0x38 versus TL stride 0x2f4,
count 1024 and fields +0x20/+0x48. Callback and scene-table contracts need review
before adopting one shared runner. Receipts/replays: `.scratch/goal59/reset-proof.py`,
`reset-effects.json`, `reset-byte-residue.json`, `runner-*-body.asm`, Kuna outputs
and `runner-condition-result.json`. No raw-link client/provider claim is made.


### Goal60: one texture loop, two native backends

The shared object-texture callback matches TL `443270` (89 bytes) and Gold
`447800` (86 bytes). It accepts one object byte pointer, then uses canonical
`D3_OBJECT::kontext`. Both bodies guard the context and its owner, cache the signed
count, and walk a table of texture pointers. Each texture is guarded, as are its
resource pointer and already-processed flag. Null/negative/zero cases do not call
services. Do not turn this into a table of pointer-to-pointer entries.

The native-supported differences are:

| View | TL | Gold |
| --- | --- | --- |
| Context owner / table | +318 / +31c | +10 / +14 |
| Owner count | +1e4 | +1e0 |
| Texture resource / flags | +50 / +54 | +64 / +68 |
| Processed bit | 40 | 80 |
| Resource operation | one-argument stdcall virtual slot 9 | cdecl precache helper |

After the resource call, both natives reload `table[i]` before setting the bit.
The helper can replace the table entry, so caching the original texture for the
final write is incorrect. Eighteen bounded native/C VEX cases include replacement,
null fields, signed counts and already-set flags. The complete TL body has no
fixups; Gold's sole REL32 operand resolves to `4360e0`, with a rejecting +4 control.
These checks do not establish the actual client raw-link provider/placement.

Gold's 117-byte helper is reconstructed as inferred `d3d_PrecacheTexture` in the
attested `d3_d3d.c`. It sets texture stage zero, records the HRESULT and logs
failures, then reloads the device and draws the precache triangle, again recording
and logging the result. A SetTexture failure does not suppress DrawPrimitive.
Preserve the native path, line values 167/168 and complete diagnostic expressions.
All 117 bytes and 11 operands agree after resolution; four literal sites for three
complete strings pass an independent content audit. Wrong bindings and a wrong
literal are rejected. Eight bounded service/error cases include device replacement.
The old 44-byte EndScene body, fixups and literals remain unchanged in this TU.
No buffer storage or raw-data bytes are manufactured.

The runner itself has a complete unadopted C candidate. Default builds emit
2023/2054 bytes against native 2033/2063. An isolated frame-pointer diagnostic emits
2007/2034; it does not justify a production pragma or recover the original TU
options. The runner still has provisional/incompatible service declarations,
including callback/packet pointer transport and lighting views. Do not promote it
from a size comparison or the decompiler seed. Its native branch/layout facts from
Goal59 remain authoritative; preserve both participant scans and stateful effects.

The first registry slot now uses `EVENT_RUN` consistently. Existing 674/165-byte
providers and registrar/setter match in both targets. The 165-byte provider retains a private word view of the event pointer, with no
integer transport. TL's refresh provider now declares its natively supplied, unused int
argument; all existing callers use the canonical header. Gold's different refresh
body remains unadopted.

Replays/receipts are in `.scratch/goal60`: texture-proof.py/json, precache-proof.py/
json, event-abi.py/json, guarded inventory repair, scope, contracts, data/lint/types,
current server gate and old court/reset traces. Failed scratch drafts/setup errors
are retained separately. `types bind` currently supports records, so callback
pointer-width assertions do not create a managed type identity. The feature gap is
recorded upstream in `docs/IDEAS-GUILD.md` (4d52a5b4), without a wrapper struct.

### Goal61 — typed periodic callbacks without changing timer behavior

The five timer functions share a 32-slot table with a 12-byte stride. A slot
contains a no-argument cdecl function pointer, an unsigned period and a pause
integer at offsets 0/4/8. The timer dispatcher uses unsigned division and calls
the selected function without arguments. Registry control APIs return a full
integer Boolean. Do not transport callbacks through integers, object pointers,
or data arrays. Their existing providers and callers now share `client_timer.h`.

Removal, pause and query retain pointer cursors. Native compares table addresses
as signed integers. An ordinary pointer comparison changes `jl` to `jb`; a signed
byte-distance condition expands these bodies from 49 to 57 bytes, and an indexed
count condition emits 47 bytes with a different allocation. The chosen explicit
signed comparison preserves all 49 bytes while keeping the cursor and callback
storage typed. This is a reconstructed expression, not recovered source spelling.
No compiler flags or assembly were added. These isolated probes are closed unless
new source/TU evidence appears.

Preserve the native registry's edge behavior. Its `i > 32` failure is unreachable
under the bounded scan; a full table overwrites the last slot and returns 1.
Registration permits a null callback and a zero period. Removal/pause/query with
a null callback select the first empty slot. Do not silently repair these game
semantics while reconstructing types. Fifty bounded native/compiled VEX cases
cover the controls and signed cutscene clock, including full/duplicate/empty
tables and comparison before increment. They are not universal semantic proofs.

Four control bodies (88/49/49/49) and the 31-byte clock callback match complete
native bytes with all 20 operand sites per target resolved. Eighteen rejecting
wrong-binding controls pass across both targets. The existing 262-byte dispatcher
and all 28 fixups remain identical to the previous object; its older unresolved
operands and IAT policy remain separate from complete bound evidence.

Discovery previously folded the clock and one NOP into its 336-byte predecessor.
The two inventories are repaired through digest-guarded CLI previews, preserving
the old matched predecessor and admitting the separate 31-byte body. The clock
sets its flag from the signed pre-increment comparison, then increments the count.
Kuna independently confirms the operation order; native `setg` establishes the
comparison signedness. No storage, initialized-data verdict or raw-link proof is
created by the new scalar declarations.

The runner candidate now includes the canonical timer/clock headers but remains
2023/2054 bytes against native 2033/2063. It is not adopted. Operand conflict
counts on these differently sized bodies are not reliable callee diagnoses;
continue from actual native operands and providers. Packet-base, resource and
lighting contracts remain open. Receipts/replays: `.scratch/goal61/timer-proof.py`,
`timer-proof.json`, inventory plans, scoped verification and `runner-measure.py`.

### Goal62 — resolver output locals can reuse a dead ID argument

TL `4c4510` / Gold `4c3ba0` initialize the 0x7c-byte packet view, reset its byte
count, call `gm_ResolveEntityById` and store the original base argument only on
nonzero return. Both native bodies are 90 bytes. The previous reconstruction
passed three pointer outputs through integer variables, including the address of
the integer ID argument. Do not infer that this alias cast was original source.

Ordinary C with a byte-pointer base and three `void*` output locals emits all 90
native bytes and six operands in both targets.
MSVC6 reuses the dead ID argument's stack slot for that third local itself.
The source does not need to write a pointer through the address of an integer.
Resolver destinations are independently checked: TL `5015e0`, Gold `4fea50`.
The initial scratch Gold destination guess was wrong and remains a failed receipt;
the strict proof uses the native call and existing matched resolver identity.

Keep packet clearing and count reset before resolution, including on failure.
Do not replace the retained base with one of the resolver's returned pointers.
Sixteen bounded native/compiled cases cover returns 0/1/2/3, a full-width nonzero
result, output writes, negative/zero IDs and resolver side effects. Failure keeps
any resolver mutations; success overwrites only the base with the original argument.
Eight wrong-binding controls reject. These are bounded effects, not universal
semantic proofs or client raw-link/data-owner evidence.

The canonical byte-access interface reaches all 42 provider/caller source files
and the additional base-pointer consumer. Existing private object layouts remain
private; offsets are byte-pointer differences with their existing narrowing.
The pointer-valued `fcn_004ce740` consumer preserves its complete 366-byte object
and fixups per client. All 68 old strong target contexts still match. All six
existing weak contexts retain their previous compiled bytes, fixups and literals;
their weak verdicts are not promoted. No flags, assembly, new storage or source
reorganization was introduced. Replays: `.scratch/goal62/packet-proof.py`,
`weak-preservation.py` and `verify-scope.py` with their JSON receipts.

## Method registration's explicit memcpy (Goal66, 2026-10-16)

TL494ed0 / Gold495510 share579 executable bytes. The native body calls memcpy
for32 bytes from method+0x30 to+0x50, then uses a37-DWORD REP MOVSD for the final
0x94-byte registry assignment. Default Processor Pack `/O2 /Gd` plus the narrow
`#pragma function(memcpy)` preserves both operations. `/Oi-` also matches, but
is broader than the evidenced requirement and is not adopted. The exact pragma
spelling is inferred; the explicit native call is established. Both production
contexts pass complete resolved-byte/literal proofs and rejecting controls.

The effect type is an unsigned byte. Native loads it into a cleared full-width
register before comparing with-1; do not change its signedness, compare with0xff
or remove the apparent defective test. Four prior callers now use the inferred
shared AM_METHOD layout without changing their compiled bytes, fixups or literals.
Both effect and method sizes are native strides, not allocation claims.

The cutscene allocation helper TL4e6ae0 / Gold4e5150 returns its allocated pointer.
A positive `if (p != 0)` copy/store region followed by `return p` preserves its
46-byte body. Early null return and returning memcpy's result emit47 bytes;
those two shapes are rejected. No extra flags, volatile or assembly are needed.
See `.scratch/goal66/method-production-proof.json`, `commands-production-proof.json`
and the independent method/command preservation reports.

## Script animation options ordering (Goal67, 2026-10-16)

TL40eff0 / Gold40e0e0 (`AttachAnimLooped`) match 454 complete executable bytes
under default Processor Pack flags. The twelve-byte by-value options record
uses the existing D3_ANIMATION_OPTIONS type. Measured source order is:

```c
memset(&options, 0, sizeof(options));
*(int*) &options = 0;
options.queue = 1;
options.layer = *kind == 1 ? 0x10 : 0;
options.mode = (unsigned char) *kind;
options.reverse = 0;
options.loop = 1;
```

Moving the repeated first-word zero after queue delayed its store and selected
EAX instead of ECX. Putting mode before layer swapped the kind-byte/mask register
lifetimes. Early reverse/loop writes added two bytes; the final order matches
all native instructions and operands. These spellings are inferred, not recovered
original text. Do not add flags, volatile, assembly or arbitrary local-order sweeps.

The indexed name copy must preserve the cached byte through increment/test.
An explicit do-loop with a byte temporary matches; testing source[i-1] after
increment forces a redundant reload, while the initial for-condition assignment
places its updates differently. The otherwise unused resolved-name buffer and
copy are native and must remain. All bounded shapes/results are retained under
`.scratch/goal67/attach-loop`; both production targets pass complete operand and
literal proofs. Wider callback/context/storage contracts remain separate.
