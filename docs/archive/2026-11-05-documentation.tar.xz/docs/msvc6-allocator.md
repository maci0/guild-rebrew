# MSVC 6.0 register allocation

Empirical findings from complete native/object comparisons. Early Findings 1–8e
are `gm_ff_Objekt` lab notes, not a general guarantee that C controls register
homes. Read [walls §1](codegen-walls.md) and Findings 52–65 before reopening
callee-saved or slot-map probes.

Scores and "SOLVED" or "FENCED" headings are checkpoints. Current proof and
status stay in managed metadata. A fenced naked body or a failed search here
is historical, not assembly permission; see
[the assembly audit](assembly-audit.md#what-qualifies). "Not reproducible"
means the spellings listed in that note. Historical flag probes do not authorize
per-function optimization overrides in production game code; use canonical game
TU/target flags, with separate contexts only for independently built libraries
or natively evidenced original TUs.

## Index

Original finding numbers are stable; 9–11 are absent. Per-function notes are
address-keyed. Query `rebrew source findings` and inspect the source header.

| Topic | Findings |
|---|---|
| Current policy: callee-saved homes and slot maps are not a C knob | 20, 22, 27, 52, 53, 62, 63, 64, 65, 68, 69, 70 |
| The zero register and constants held in registers | 1, 4, 17, 51 |
| Live ranges across loops, loop counters and induction variables | 2, 31, 38, 43, 47, 49, 50, 54 |
| Flag variables and `?:` chains | 3, 21, 32 |
| Callee-saved push/pop placement, prologue scheduling | 5, 41, 48, 66, 67 |
| Parameters: address-taken, slot reuse, reload against preserve, argument order | 7, 18, 25, 26, 28, 33, 44 |
| Shared tails, multi-branch dispatch, block splits | 6, 8, 8b, 8c, 8d, 8e, 23, 45, 46 |
| `eax`/`ecx` choice from a named local against a CSE'd load, allocator internals from `c2.dll` | 12, 74 |
| Byte operations and zero-extension (see also the and-idiom deep-dive) | 14, 17, 18 |
| Frame and stack-slot maps, the sentinel instrument | 19, 55, 60, 61 |
| x87 return and clamp blocks | 24, 35, 40 |
| Field-store materialisation in the `cm_*` family | 16, 36, 37, 39, 40, 42 |
| Addressing-mode base/index roles | 13, 29, 30, 34 |
| Object size, COMDAT placement, relocation accounting (not allocation, kept here for history) | 15, 56, 57, 58, 59 |

## Methodology

Use `uv run rebrew source findings 0x<VA> --json`, then native assembly,
`diff` and `test --no-promote`. Keep isolated probes in `.scratch/` and
compile with the project `unshare` backend on the pinned image. Use the
normal project `uv` environment; `--frozen` and a sibling checkout are not
required. The current server is plain SP5; clients use Processor Pack and
their builds are comparison scaffolds, not identical or playable images.
Earlier SP6 and Docker runs keep that compiler context. Measure the complete
raw image for layout claims; [tooling](tooling-upstream.md) replaces retired
probe wrappers. Full original notes are [archived](goal-history.md#full-notebooks).

## Register set & baseline (from rebrew docs)

- Volatile: `eax ecx edx` (caller-saved); callee-saved: `ebx esi edi`.
- In this baseline, loop-invariant constants stay as immediate stores
  (`c7 05 ...`) rather than being hoisted into a callee-saved register; the
  earlier 4.x/5.0 comparison reported hoisting. This is not a general absence
  of constant caching: Finding 72 traces a multi-use constant as a register
  colouring candidate in VC6.
- The zero-comparison era marker (5.0–7.1): `a == 0` = load + `test`/
  `cmp` + branch against a materialized zero register.
- The target function is fully register-resident: `flag1`→`dl`, `flag2`→`bl`,
  loop counter `i`→`esi`, arg walker→`eax`. No stack locals.

## Finding 1: the "zero register" is allocated once and reused

For `if (g_item_def_table == 0) return 0;` followed by
`g_query_count = 0; g_query_match_count = 0;` and an `arg_count == 0`
compare, MSVC 6.0 materializes the constant `0` **once** and reuses it:

```asm
; reference (0x10016460)
mov  ecx, [g_item_def_table]   ; 8b 0d ...
xor  eax, eax                  ; 33 c0   <-- the zero
cmp  ecx, eax                  ; 3b c8
push ebx                       ; 53
jne  Lmain                     ; 75 02
pop  ebx                       ; 5b        ; inline early return
ret                            ; c3        ; reuses eax == 0
Lmain:
mov  ecx, [esp + 0xc]          ; arg_count -> ecx
xor  dl, dl                    ; flag2 = 0
xor  bl, bl                    ; flag1 = 0
cmp  ecx, eax                  ; 3b c8     ; arg_count vs the SAME zero
...
mov  [g_query_count], eax      ; a3 ...    ; eax-specific moffs encoding!
mov  [g_query_match_count], eax; a3 ...
jle  Lcheck_container
```

Notes:

- The `a3`/`a2`/`a1` opcodes are **EAX-specific** encodings
  (`mov moffs, eax`). Their presence is a reliable fingerprint that the
  value lived in `eax`, not just "a register".
- The early `return 0` is **inline** (`pop ebx; ret`) and reuses the zero
  register: no `xor eax,eax` on that path. The zero doubles as the
  return value, which is what anchors it to `eax`.
- The same zero register is used for the `arg_count` compare *and* both
  count stores, then it dies before the loop (`eax` becomes the arg
  pointer walker).

## Finding 2: the LIVE-RANGE-ACROSS-LOOP flip (the big one)

Add a second literal `return 0` that is reachable after the loop
**without an intervening call** (a flag test like
`if (flag2 == 0) return 0;`), and the whole entry allocation flips:

```asm
; probe26a: probe26 + "if (flag2 == 0) return 0;" after the loop
mov  eax, [g_item_def_table]   ; a1 00 00 00 00  <-- table now in eax!
push ebx                       ; 53
push esi                       ; 56            <-- esi pushed at ENTRY
xor  esi, esi                  ; 33 f6         <-- zero now in esi!
cmp  esi, eax                  ; 3b c6
je   Lshared_tail              ; 0f 84 ...     <-- far je to a merged tail
...
mov  [g_query_count], esi      ; 89 35 ...     <-- count stores from esi
mov  [g_query_match_count], esi; 89 35 ...
```

The cascade:

1. The post-loop `return 0` (no call between entry and it) is **constant-
   commoned** with the entry `return 0` → MSVC merges them into one shared
   return tail at the end of the function (a far `je`).
2. The shared tail is reached both with and without the loop having run →
   the stack states must match → `esi` gets pushed at **function entry**
   (before the table check).
3. With `esi` pushed from the start, the allocator parks the zero in `esi`
   (volatile regs are all busy: `eax`=table, `ecx`=arg_count, `edx`=flag1,
   `ebx`=flag2), the table lands in `eax`, `-1` is materialized in the dead
   table register (`or eax,-1`), and the count stores become `89 35` (esi)
   instead of `a3` (eax).

Everything in Finding 1 that anchored the zero to `eax` is defeated by the
single extra post-loop `return 0`.

### What does NOT trigger or fix the flip (all tested, byte-compared)

Tried: allocation stayed flipped (zero in `esi`, table in `eax`):

- Changing the post-loop flag logic: `goto check_container` vs duplicated
  block vs `if (flag2 != 0) { error }` vs `if (flag2 == 0) goto query`.
- Making the final return a *variable* (`return container_id;`) instead of
  a literal: MSVC folds `container_id == 0` on that path and merges the
  tail anyway.
- Removing the final return entirely (fall off the end, C4715): the entry
  return becomes inline again, **but** the zero is still parked in `esi`
  and the entry return still re-materializes (`pop esi; xor eax,eax; ...`).
- Comparison operand order (`0 == g_item_def_table`), variable declaration
  order (flags first / `i` before `arg_ptr`), store ordering (count stores
  before flag stores), explicit `int zero = 0;` variable threaded through
  the entry check and stores, `i = arg_count;` hoisted before the stores.
- Every `/O` variant and the pragma family from the summary (`optimize`,
  `intrinsic`, `check_stack`, `auto_inline`, `inline_depth`, `volatile`,
  `default_char_unsigned`), SP1–SP6 toolchains, `rebrew match run
  --flag-sweep-only --tier quick` (produced no better result).

Conclusion so far: the flip is driven by the **presence of a post-loop
literal-0 return with no intervening call**, and the merge it causes. The
remaining unsolved piece is that in the reference the *error-path* `return 0`
(after the `LogMessageInternal` call) does **not** merge with the entry
return, while our probes' equivalent paths always do. The reference keeps
three separate return sites (entry inline, error separate, check returns
`container_id`).

## Finding 3: flag variables: first-tested flag gets `dl`, second gets `bl`

`gm_ff_Objekt` keeps two byte flags in registers. The assignment
tracks the *dispatch order*, not declaration order:

- case 7 handler: `mov dl, 1` → flag tested **first** (`test dl,dl;
  je check_container`).
- case 6 handler: `mov bl, 1` → flag tested **second** (`test bl,bl;
  je query_path`).

So the flag that the code tests first ends up in `dl`, the second in `bl`.
Writing the dispatch in the wrong order (`if (flag2 == 0)` before
`if (flag1 == 0)`) swaps them and produces `88 1d` where the reference has
`88 15` and vice versa (a 1-byte diff per store).

## Finding 4: `-1` stores: immediate vs register is a *consequence*

`g_query_filter_owner = -1` etc. compile either to `c7 05 <addr> ffffffff`
(10B immediate) or `or reg,-1` + `mov [addr],reg` (8B, register form).
MSVC 6.0 picks the register form whenever a volatile register is free at
that point. In the reference it is **never** free (`eax`=zero,
`ecx`=arg_count, `edx`/`ebx`=flags) → all immediates. In the flipped
probes, `eax` is free (dead table) → `or eax,-1` → 1-byte-size stores
(`a3`/`66 a3`/`a2`). So immediate-`-1` stores are a downstream symptom of
Finding 1, not a separate knob.

## Finding 5: `esi` push/pop placement tracks its live range

- Reference: `push esi` at loop entry (after the `jle`), `pop esi` right
  after the loop (before the flag dispatch). All post-loop blocks run with
  `ebx`-only frames → `[esp+8]` addressing for `container_id`.
- Flipped probes: `push esi` at function entry, `pop esi` in each exit
  path (three pops), and the post-loop blocks keep `esi` pushed →
  `[esp+0xc]` addressing.

The `[esp+8]` vs `[esp+0xc]` difference in the `container_id` load is a
direct consequence of when `esi` is pushed. You cannot mix: matching the
reference's `mov eax,[esp+8]` requires the whole "esi only in the loop"
scheme (Finding 1 intact).

## Finding 6: shared store+call tail needs both values in the same register

The reference merges the query path and the check_container path into one
tail:

```asm
query: mov eax, [g_query_base]       ; 0x10016561
shared: mov [g_query_cursor], eax    ; 0x10016566
        call gm_NextEntityQueryMatch
        pop ebx
        ret
check: mov eax, [esp+8]              ; container_id
       test eax, eax
       jne shared                    ; 75 ec
       pop ebx
       ret
```

For the tails to merge, both paths must load their value into the **same**
register (`eax` here). In the probes, the query value consistently lands in
`edx` (reusing the just-dead `dl` flag register) while the check value is
in `eax`, so no merge happens and the check path emits its own
store+call. The query value landing in `edx` vs `eax` appears tied to
which block is emitted first (error block before query → eax is "fresh"
from the error's `xor eax,eax`; query before error → `edx` reuse).

## Practical recipe for writing matching C

Scoped to `gm_ff_Objekt` (0x10016460), which is RELOC in toml. Do not
treat flag `dl`/`bl` or post-loop `return 0` merge as GRA law. For
homes, stop at walls §1 / Findings 62–64.

1. Identify every literal `return 0` in the original and their *paths*.
   Any post-loop literal-0 return reachable without a call in between will
   merge with the entry return and flip the whole allocation. Restructure
   so post-loop "zero" returns either (a) come after a call, or (b) return
   a variable value the compiler cannot fold to 0 (e.g. the compared
   variable itself), or (c) fall off the end.
2. Keep the entry `return 0` inline (short `jne` + `pop ebx; ret`) so the
   zero doubles as the return value and anchors to `eax`.
3. Match the flag dispatch order exactly (Finding 3): the first-tested
   flag is `dl`, the second `bl`.
4. Expect `-1`/`0` constant stores to be immediates **only when** no
   volatile register is free at that point; if your output shows
   `or reg,-1` + register stores, a register that should be busy (zero /
   arg_count) is free: the allocation upstream is wrong.
5. For byte-matching, `a3`/`a2` (eax-moffs) stores are the fingerprint
   that the zero is in `eax`; `89 35`/`89 0d` mean the zero moved.

## Finding 7: address-taken parameter kills the callee-save base

The `cm_*` command handlers share a shape: the command pointer is kept in
a callee-save register (`push esi; mov esi,[esp+0x10]`) across a
`gm_GetFieldByType` call, then its address is passed to
`gm_ResolveEntityById((void**)&cmd, ...)` (the callee writes the resolved
entity back into the parameter slot). Reproducing this in C fails:

- With a plain `iVar1 = cmd;` copy (Ghidra's structure) MSVC **unifies**
  the copy with the parameter via copy propagation. Once `&cmd` is taken
  the unified value is memory-resident → the base lands in a volatile
  register (`mov eax,[esp+4]` emitted *before* the frame), the store
  address is CSE-hoisted (`lea esi,[eax+0x10]`), and the post-resolve
  uses get a second callee-save (`mov edi,eax`), three registers where
  the reference uses one (`esi`).
- The reference loads the base into `esi` *after* the frame
  (`sub esp,N; push esi; mov esi,[esp+0x10]`) and never hoists the
  displacement.
- Tried and failed (all produce the split): copy via `char* p`, read via
  param / store via copy and vice versa, struct member access, single
  combined statements, `int` vs `unsigned short` field types, explicit
  result variables, /O1 /Og- /Oy- /G5 /arch:SSE, all declaration orders.
- A minimal head with **no** address-taken (`gm_GetFieldByType(cmd, ...)`
  twice, no resolve) DOES keep the base in `esi`: the address-taken is
  the trigger, not the call count.
- Affected: `cm_ExFree` (0x1000d730), `cm_ChkChangeBits` (0x1000cf30) and
  the other handlers that pass `&cmd` to `gm_ResolveEntityById`. These
  stay readable-`__asm` (byte-identical, RELOC) pending a C formulation
  that defeats the copy propagation.

## Finding 8b: multi-branch dispatch register cascade

`cm_ExCopyEntityData` (0x1000ec00, 901B) converts at the head (first 34
bytes byte-identical: frame, `mov edi,cmd`, two deferred-cleanup
`gm_GetFieldByType` calls, `mov [edi+0x14],eax`) and then diverges on the
dispatch register allocation:

- Reference: `mov ebx,[edi+0x1c]`, the field/type value (`fld`) lives in
  **ebx**, and the `cnt >= fld` dispatch emits `cmp edi,ebx; jae case 4`
  with a duplicated `test edi,edi; jbe default` guard pair (a comparison
  chain, *not* a jump table, so the original was not a `switch`).
- Mine (current): `fld` also lands in **ebx** (fixed since this finding was
  written), but MSVC still eliminates one of the two guards: the separate-if
  form drops the `cnt>=fld` branch as dead (its stores are provably
  overwritten by the else-if chain), and the else-if-chained form drops the
  `cnt==fld` branch as subsumed.  `volatile` locals keep both guards but
  hoist the constants into registers and duplicate the store block, so the
  reference's shared immediate-store block is not reproducible either.  ~20
  chain/switch formulations tested; every `switch` form compiles to a jump
  table (`lea eax,[cnt-1]; cmp eax,3; ja; jmp [eax*4]`), and every if/else
  chain either inverts or removes the dead checks.  The exact reference
  chain (jumped-to case 4 + kept redundant guards) is not reproducible.
- The chained else-if form is used in the source because it preserves the
  reference behaviour for `level >= 4` (the separate-if form changes
  `level >= 5` to the default set).  Best-effort is 206/901 bytes (obj 898;
  the stale 912 in functions.txt/toml includes 11 bytes of linker padding)
  with the dispatch store order (`decay_low` before `decay_high`) and
  do-while scan loops tuned to the reference layout.  A `while(1)+break`
  variant matches a few more bytes (212) but is 36 bytes smaller.
- The register cascade (fld → ebx vs esi) is the same class of GRA
  sensitivity as Finding 7: the reference's allocation is "better"
  (single callee-save for fld, reused later) and cannot be steered from C.
  The matrix-loop registers (outer_idx/outer_ent/mat_row/inner_ent/delta =
  edi/ebx/edx/esi/ebp vs ebx/ebp/esi/edi/edx) are likewise unaffected by
  declaration order (tested 4 orderings).

## Finding 8d: value propagation splits shared blocks

`gm_SetBuildingWorkerLimits` (0x10017400, 202B) converts at the head
(the `push esi; push edi; mov edi,[esp+0xc]` base + interleaved
`gm_ff_Objekt` arg pushes + table `lea` chain match byte-for-byte)
and then diverges in the field chain:

```c
if (t23d == 0 && t23e == 0 && t23f != 0) { result[0x1c] = t23f; }
else { if (t23d < 2) t23d = 2; result[0x1c] = t23d; ... }
```

- Reference: keeps `t23d` in `cl` across the whole chain (reads
  `t23e`/`t23f` into `dl`) and emits **one** shared clamp block
  (`cmp cl,2; jae; mov ecx,2; ...`) for all three failure paths.
- Ours: MSVC6's value propagation proves `t23d == 0` on the
  `t23e != 0`/`t23f == 0` paths and **splits** the clamp: those paths
  jump straight to `mov cl,2` while only the `t23d != 0` path keeps the
  `cmp cl,2`. The result is semantically correct but a different block
  layout (5–20 bytes shorter). ~6 formulations (`&&` chain, nested ifs,
  duplicated else, ternary clamp, goto dispatch, inverted conditions)
  all trigger the propagation; none reproduce the single shared block.
- Same class as Findings 7/8b: the reference was compiled from a source
  shape that hides the value from the optimizer's path analysis, and
  that shape has not been found.

## Finding 8c: the convertible head pattern (summary)

The *only* shape verified to convert byte-identically so far: a base
pointer passed **by value** across two or more calls with no address-taken
and no multi-branch dispatch on its fields (`ls_LoadEntities` 0x10013230
RELOC 2268/2268; synthetic head with two `gm_GetFieldByType` calls). The
moment the function takes `&param`, dispatches on a field read into a
callee-save, or keeps a single-use value across a call, MSVC6's GRA picks
a different (split/reloaded) allocation than the reference.

## Finding 8: multi-call value base converts cleanly

When the base is passed *by value* across two or more calls and its
address is never taken, MSVC 6.0 keeps it in a callee-save register
naturally. A minimal head compiles to the reference shape:

```c
/* head: two gm_GetFieldByType calls, base by value */
*(int*)((char*)cmd + 0x10) = gm_GetFieldByType((char*)cmd, *(int*)((char*)cmd + 0x10));
*(int*)((char*)cmd + 0x14) = gm_GetFieldByType((char*)cmd, *(int*)((char*)cmd + 0x14));
ebx = *(int*)((char*)cmd + 0x1c);
```
→
```asm
push esi
mov  esi, [esp + 8]      ; base -> esi
mov  eax, [esi + 0x10]   ; arg2 read via esi
push eax
push esi                 ; arg1 = base
call gm_GetFieldByType
...
```
This is the `ls_LoadEntities` (0x10013230, RELOC 2268/2268) class: the
large conversions that already match were all of this shape. The recipe:
never take the address of a base you also keep across a call; pass the
value.

## Finding 8e: a CONVERTIBLE recipe (verified)

(No Findings 9, 10, or 11. Next numbered finding is 12.)

`amt_ValidateOfficeCandidate` (0x1000b1c0, 205B) converted to C with a
**RELOC 205/205** match. The winning recipe, in order:

1. Base pointer used *by value* across a call, then dead (multi-use across
   the call is fine; address-taking is fatal).
2. Table scans written as `for (i = 0; i < 30; i++) { if (table[i] == x)
   break; }`: MSVC6 emits the do-while shape (`xor edx,edx; mov ecx,base;
   cmp; je; add; inc; cmp; jl`) byte-identically.
3. Post-scan table checks must use a **shared offset variable**
   (`off = i * 0x18;` then `*(int*)(0x101de5a4 + off)`), NOT the raw
   `i * 0x18` expression: MSVC6's linear-function factoring otherwise
   re-derives the address from the loop counter (`lea edx,[eax+eax*2+
   0x203bcb6]; cmp [edx*8],3`) when the displacement divides evenly by 8
   (0xb0 and 0xa8 fold; 0xa4/0xac do not, inconsistent per-expression).
4. Shared return tails: write `if (cond) { ... } return 1;` (return at the
   function tail) instead of `if (cond) return 1; ...; return 1;`: the
   former lets MSVC lay the shared return-1 out as the tail block with
   short forward `je`s, matching the reference.
5. `if (cond) goto L_ret0;`-style early returns merge into one shared
   return-0 block naturally.

Also verified: `memcpy(buf, (void*)(base + n*0x18), 24)` with
`#pragma intrinsic(memcpy)` emits `mov ecx,6; rep movsd` (per the
msvc-6.md docs).

**CRITICAL for the byte-identity guard:** converted functions must use
**absolute addresses** for every string constant (`(char*)0x1002a0a0`),
never C string literals. The byte-identity build (sha `c7ac331f…`)
reproduces the original `.rdata` layout exactly; a literal in a converted
`.c` adds new `.rdata` bytes, shifting the section and breaking ~150
bytes of absolute references in *unrelated* functions (observed:
m_alloc at 0x10006cc0). The rebrew test still reports RELOC (reloc
masking hides the shift), so only the final `sha256sum` comparison
catches it. `amt_fio_LoadAemter` (0x1000baf0, 606B) converted to RELOC
606/606 with this rule; also confirms the signed/unsigned branch rule
(loop bound as `unsigned int` → `jbe`/`jb`, matching the reference).

`amt_ValidateAndAssignOffice` (0x1000b290, 425B, same family) is a documented
near-miss: the identical recipe gets 41/425 with the head matching, then
MSVC6 assigns `result` to `edi`+spill (frame grows to 0x1c, `buf` shifts
to [esp+0x14]) instead of the reference's `ebp`-resident `result` (frame
0x18, `buf` at [esp+0x10]). The cascade root is the byte-register choice
for `type4` (`dl` in ours vs `al` in the reference), which shifts the
scan counter register and everything downstream. ~8 formulations
(declaration orders A–D, inlined reads, off-variables) did not steer it.

## Open questions

- Why does the reference's error-path `return 0` (after the
  `LogMessageInternal` call) stay a separate block instead of merging with
  the entry return? The merge of *that* pair is what forces `esi` at
  entry in every probe tried. The call itself should make the zero's live
  range end before it (volatile clobber), so MSVC *could* re-materialize:
  it does, in the reference; it doesn't, in our probes. The deciding
  factor is still unknown.
- The query-value register (`eax` vs `edx`) and the `esi` pop placement
  are correlated with block emission order, but the ordering heuristic
  (why the error block precedes the query block in the reference but not
  in our C) is not yet pinned down.
- How the reference `cm_*` handlers keep the base in `esi` *despite*
  passing `&cmd` (Finding 7): some C structure defeats MSVC6's copy
  propagation of `iVar1 = cmd`; it has not been found after ~25 variants.

Probe corpus: `/tmp/probe26.c` (correct allocation, no flag tests),
`/tmp/probe26a.c` (minimal flip trigger), `/tmp/probe27/31/32/33/34/35/
36/37/38.c` (structural variants, all flipped), `/tmp/probeA..D.c`
(declaration/order variants). All compiled with the command in
"Methodology".

## gm_CalculateProductionValue (0x10019720): recursion + FPU

Recursive FPU cache function; C reconstruction in `spiel622.c` (#else of the
fence) is **semantically correct** (verified statement-by-statement against
the naked asm), but byte-matching stalls at 87/420 with four distinct
allocator/codegen divergences:

1. **Register choice for the live index**: reference keeps `entity_index`
   in `ecx` from entry (`mov ecx,[esp+4]` → later `mov eax,[ecx*4+table]`);
   every C formulation puts it in `eax` (indexing `[eax*4+table]` instead).
   This cascades: with `eax` occupied, the reference's `mov eax,[esi+0x38]`
   (cache) becomes `mov ecx,[esi+0x38]` in ours.
2. **`push edi` placement**: reference pushes `edi` only inside the recurse
   branch (`L_recurse: push ebp; push edi; lea edi,[esi+0x2e]`), cold-path
   region allocation. Ours pushes `edi` in the prologue unconditionally,
   shifting every stack offset by 4 (`[esp+0x1c]` vs `[esp+0x18]` for arg2).
3. **`fidiv` vs `fild`+`fdivp`**: reference divides a double by a memory
   int with `fidiv dword`; ours converts the int to double first
   (`fild dword` + `fdivp st(1)`), even with the divisor as a named `int`
   or `unsigned int` local and with the division split across two
   statements. MSVC6's `fidiv` emission trigger here is not reproduced.
4. **`fimul` fusion**: reference multiplies `(double)v * int` as a fused
   `fimul dword`; ours emits `fild`+`fmulp` and reorders the constant
   multiply (`fmul 5fb8` before the `fild` of the int). A named int local
   for the masked param (`p = (unsigned char)param2; (double)v * p`)
   does not change this: the fusion peephole is suppressed in our shape.

Also confirmed while reconstructing: `0x101de450` is a **pointer global**
(`mov edx,[0x101de450]`), i.e. `g_item_def_table`: the reference never uses
`0x101de450` as a literal base; `(double)` of the unsigned dword at
`ent+0x22` zero-extends via the `fild qword` pair (`[esp+8]=val,[esp+0xc]=0`),
so the source type is `unsigned int` → double.

## gm_eval_SlotVoll (0x10019d30): CONVERTED, patterns that mattered

Byte-identical C achieved (RELOC 407/407) after ~8 iterations. Each of these
was the deciding factor for one divergence class:

1. **Extra ignored call argument**: the reference calls `compute_size` with
   TWO pushed args (`push esi; push edi; call`), the callee reading only the
   first. The C form
   `((int (__cdecl *)(char*, int)) compute_size)(obj, entity_index)` (cast
   call) reproduces it, and the early `mov esi,[esp+0x1c]` (entity_index →
   callee-saved esi) follows from the arg materialization. A 1-arg call
   drops both the junk push and the early esi load.
2. **`count = 0` before the call**: the reference zeroes `esi` between the
   arg pushes and `call gm_ff_Objekt`; the C must be
   `count = 0; q = gm_ff_Objekt(...)` (assignment textually first),
   not `q = ...; count = 0;`.
3. **Signed limit type**: `int limit` (not `unsigned int`): the reference
   compares with `jl` (signed). The zero-extended byte load
   (`xor ecx,ecx; mov cl,[edi+0x1c]`) is unchanged either way.
4. **Inverted tail conditions prevent epilogue merging**: with
   `if (count < limit) goto use_max; return 0;` MSVC6 *merges* the three
   return-0 blocks into a shared split epilogue (`xor eax,eax` then
   `pop`-chain entered at two offsets) and shares one `jl` via `jmp`.
   Writing `if (count >= limit) return 0;` with the use_max code as the
   fall-through reproduces the reference's three separate return-0 blocks
   (`pop edi; pop esi; pop ebp; xor eax,eax; pop ebx; ret`) exactly.
5. **`avail` must be a temp, not a named variable**:
   `avail = gm_GetMsgField(obj, q); if (size - avail > requested) ...`
   with the subtraction written twice (CSE'd). A named `avail` gets
   allocated to ebp (reusing/destroying `size`); the inline temp form lands
   in ecx (`mov ecx, ebp; sub ecx, eax`), preserving size in ebp, which
   the reference does.
6. **use_max = min(size, requested)**: the reference spills `size` into the
   dead `obj` arg slot (`mov [esp+0x30], ebp` before the call) and reads it
   back at use_max (`mov ecx, [esp+0x14]`). The long live-range of `size`
   (through use_max) is what gives it ebp; entity_index gets esi.

## gm_CheckInventoryCapacity (0x10019ed0): blocked (GRA/peephole)

Semantically correct C reconstruction preserved as a comment above the naked
function in `spiel622.c` (best result 35/395 after ~7 formulations). The
cap/goto CFG shape (single `cap` variable, shared clamp epilogue reached via
`goto clamp`) DOES reproduce the reference's prologue register set (4
callee-saved pushes, `edi`=entity_index). That part was the decisive change.
Still blocked on three allocation/peephole details:

1. **Ent-address shape**: reference emits `mov ecx,[g_item_def_table]; mov
   eax,edi; shl eax,6; add ecx,eax; mov eax,edi; add eax,ecx` (separate
   adds) then `mov al,[eax]`. Ours folds the `+idx` term into the load
   addressing mode (`mov cl,[edi+edx]`) and assigns the base to edx. Writing
   `ent = base + idx*0x40; ent += idx;` is strength-reduced right back.
2. **Base register**: `mov ecx,[g_item_def_table]` (ref) vs `mov edx,[...]`
   (ours): cascades into the idx*64 register (eax vs ecx).
3. **Clamp peephole**: ref emits `test ebp,ebp; setl al` (after the sub and
   a `pop edi` in between); ours emits `sets dl` directly on the sub flags
   (no re-test), plus `mov edx,0` instead of `xor eax,eax`.

Also notable: the return-clamp idiom `xor eax,eax; test ebp,ebp; setl al;
dec eax; and eax, ebp` == `(x < 0) ? 0 : x` (mask select); the reference
returns the RAW `requested` on the `t == 9` early path (no clamp).

## sim_PriorityUpdate (0x10015400): CONVERTED (frame-size oracle)

Byte-identical (RELOC 83/83). The blocking divergence was the frame layout:
the reference does `sub esp,8` + `lea eax,[esp]` with the 2-byte compare
operand at `[esp+4]`; every `unsigned short local` formulation reused the
dead arg2 slot instead (`lea eax,[esp+0xc]`, no sub). The **sub esp,8 gave
away the original's local type**: an 8-byte `char local[8]` buffer (the
compare reads its first two bytes as `*(unsigned short*)local`). With that
type the arg-slot reuse is impossible (8 bytes don't fit the 4-byte slot)
and the frame matches exactly.

Lesson: when the reference frame size (sub esp,N) is larger than the
smallest local you're modeling, the original local is likely a bigger
buffer/array: the frame size is an oracle for the declared local types.
Also note the arg-slot reuse rule implied here: MSVC6 reuses a dead
argument slot for a small address-taken local (as in gm_CalculateProductionValue)
but a fresh frame slot when the local doesn't fit.

## sim_StartEntityQueryByType (0x10015460): blocked (GRA)

Semantically correct C preserved in sim.c above the naked function (best
12/145 after ~6 formulations). The reference's register picture:
`esi`=arg1 (first callee-saved, loaded immediately), `edx`=type,
`edi`=table base (second callee-saved), `eax`=0 materialized at the top
(the 0-arg of every query call, pushed as `push eax`), `ecx`=the 589x lea
chain and the rec[0] dispatch byte (`cl`). Ours: arg1 in `edx` (scratch,
valid per-path since each branch reads `[arg1+0x5d]` before its call),
type in `ecx`, table in `esi`, 0-arg as `push 0` (no early materialization),
rec[0] in `al`. A `z=0` variable did not produce the early `xor eax,eax`;
a switch form ballooned to 189 bytes (not the if/else chain). The
pre-materialized 0 constant appears to be the linchpin of the reference's
register allocation, and no C shape reproduced it.

## sim_AdvanceGameClock (0x100155c0): blocked (arg4 live-range split)

Semantically correct C preserved in sim.c (best 19/200, ref 197). The
function's /60 and /24 magic-multiply idioms (`0x88888889` = ÷60 signed,
`0xaaaaaaab` = ÷24) and the negative-hours floored-modulo trick
(`q = (23-t)/24; t += q*24`) all reproduced once the day-loops were written
as do-while (`do { days++; } while (--q != 0)`); a `while (q-- != 0)` adds
an unwanted pre-check.

Blocked solely on arg4's allocation: the reference keeps ONLY `esi` saved
and RELOADS arg4 from `[esp+0x10]` per section (live-range split, its uses
die at each `lea esi,[edx+eax]`), which forces the sequential store order
(memory operands serialize). Ours keeps arg4 in `edi` across the sections
(+2 push/pop) which lets the scheduler hoist section-2's `t` computation
before the section-1 stores and defers the minutes store past the idiv.
~9 formulations (single/shared/scoped temps, inline CSE, struct pointer,
do-while, zero-var) could not trigger the split. The clock struct is
`{int days; short hours; int minutes; int seconds;}` packed (SIZE 0xe);
the caller is `sim_AdvanceGameClock((int*)0x10035880, 0, 1, 0)`.

## ReceivePacketHeader (0x1000a340): SOLVED (RELOC, delta 0)
Checkpoint: the heading's old status is not current. Verdicts stay in metadata. The mechanism below is that pass's observation.


Semantically complete C preserved in server2.c (best 104/336; the remaining
232 bytes of divergence are offset shifts caused by one 23-byte difference).
All instructions match the reference except:

1. **Cross-jumping of the two identical error paths**: the reference emits
   the timeout error block (`gettick; cmp; jae; push 1/msg/line/file; call
   LogMessageInternal; push conn; call cm_ClosePlayerConnection; add esp,
   0x14; or eax,-1; pop; pop; ret`) INLINE at both recv sites (lines 0x52a
   and 0x552). MSVC6 merges our two tails into one shared block
(`push 0x52a; jmp shared`), saving 23 bytes. No C shape (inline,
   goto-add, nested-if, gettick-temp vs inline call) prevented the merge.
2. **merge1 branch polarity**: reference `cmp eax,-1; jne add; jmp wsa`
   (conditional to the near add block); ours `je wsa; jmp add` regardless
   of how the `r == -1` check is written.

Notable reproductions: the recv function pointer is stdcall (no caller
cleanup: `call edi` then straight on), the >=3 path reads the *dead arg
slot* for the never-set `r` (`mov eax,[esp+0xc]`: an uninitialized-read
reproduced naturally by reusing `r` after the conditional recv), and the
header-complete flag is a dword OR (`mov eax,[esi]; or al,0x80; mov
[esi],eax`) not a byte OR.

## gm_RandomStatModifier (0x10018450): blocked (byte vs dword load)

Semantically correct C preserved in spiel62.c (best 29/78 after ~12
formulations). Everything matches except the char-param load width: the
reference does `mov bl, byte ptr [esp+8]` (partial-register load), which
forces the FPU conversion to re-read the param slot
(`mov eax,[esp+8]; and eax,0xff; mov [esp+8],eax; fild`) and the final
addition to be byte-sized (`add bl,al; mov al,bl`). Ours does
`mov ebx, dword ptr [esp+8]` and derives everything from the register
(`mov eax,ebx; ...; add eax,ebx`), 5 bytes shorter. No C shape (param
direct, `char`/`unsigned char` locals, `==0`/`!x`/truthiness tests, inner
casts vs return-type truncation, ternary n shared across the merged call
block, `if` branch orders) nor any flag (/O1, /Ox, /O2 variants) flipped
the load width. What DID reproduce: the float comparison (`(float)x >=
const` → `fcomp dword ptr [const]; test ah,1; je`: C0-only, no unordered
bit) and MSVC6 merging the two gm_RandomMod calls into one shared block
via a ternary variable (`mov eax,0xb; je; mov eax,6; push eax; call`).

## Loop-form finding (gm_FindSlotById 0x10016240, ahm_QueryEntityBuildingType 0x1000c6a0)

Two more successful conversions, each with a decisive code-shape lesson:

1. **gm_FindSlotById (EXACT 72/72)**: a 589-entry table scan. Three keys:
   `int i = 0` BEFORE the base computation (the counter's `xor ecx` must
   land right after the arg1 load), the found-return recomputed from the
   counter (`return base + arg1*10896 + i*0x80`, not the induction
   pointer), and the increments BOTH in the for-clause (`for (; i < 0x55;
   i++, p += 0x80)`: the reference emits `inc ecx` before `add eax,0x80`).
2. **ahm_QueryEntityBuildingType (RELOC 102/102)**: a query loop with a
   mid-loop return. The `do { ... } while (q != 0)` form made MSVC6 PEEL
   the first iteration and rotate the loop so the next-match call sits at
   the loop top, duplicating the body with different registers. The plain
   `while (q != 0)` form emits the reference's non-peeled layout exactly
   (body once, next-match at the bottom, back-edge to the body).

## ahm_InitRandomEntity (0x1000c600): RELOC 109/109

Fixed by qualifying the float-copy loop's store target as `volatile`
(c-shapes section 22), which pins `fstp [eax]` immediately after the
multiply instead of letting MSVC6 sink it past the pointer bump to
`fstp [eax-0xc]`. No loop shape, induction form, or CPU flag moves the
store; only the destination qualifier does. What also reproduced: the
scan loop EXACTLY (EXACT bytes) once written as
`for (i = 0x20; i != 0; idx = (idx + 1) & 0x1f) { if (used == 0) goto
found; i--; }`: the idx-update as the for-increment and the counter
decrement in the body gives the reference's `dec; inc; and; test; jne`
order. A do-while peels (body duplicated, registers differ); a plain for
with `i--` as the increment emits `inc; and; dec` (wrong order).

The reference's dScaleFactor is a `double` (fmul qword).

## gm_CleanupObjectEntities (0x10015cf0): blocked (addressing-mode roles)

Semantically correct C preserved in spiel.c (best 139/194; the remaining 55
bytes are pure encoding-role differences). The full structure reproduces:
the ptr-variable pattern (the reference computes `ptr = dy+0x5d /
ex+0x14 / st+0x178` in three branches that fall/jmp into ONE shared
`gm_RemoveObjectByType` call block, with a re-check `test eax,eax; je
cleanup`), and the `rep stosd` memset tail (EXACT).

Blocked on the base/index register ROLES in every `g_query_base + i`
addressing: the reference emits `[esi+eax]` / `[esi+edx]` (the loop counter
esi as the BASE), ours `[eax+esi]` / `[edx+esi]` (the base pointer as the
base), same registers, different ModRM (`0x06` vs `0x30`). Swapping the C
operand order (`i + g_query_base`) and the /G5//G6 CPU-scheduling flags do
not change the roles. Also the NoopRet2 arg materializes in `ecx` via
`lea` (reference) vs `eax` via `add` (ours). ~6 formulations.

## cm_ExChangeFloat (0x1000eb70): RELOC 135/135

Two fixes, both in cm_ExChangeFloat.c:

1. **Out-param slot order.** The reference passes the resolve out-params as
   `gm_ResolveEntityById(&pvStack_4, &pvStack_8, (void**) &resolved, ...)`,
   reusing dead incoming slots of the 3-arg frame; the check order in the
   fallback chain is unchanged. 130 → 132.
2. **Offset temp register.** Folding the field offset into the entity
   pointer in its own statement (`p = p + *(int*)(iVar1 + 0x14);`) moved the
   temp from ecx to edx and gave the reference's `add eax,edx`. 132 → 135.
   See c-shapes section 21.

Taking the address of `param_1` itself (rather than a separate `resolved`
local) forces slot re-reads and drops the score to 33/139; the earlier note
that the Ghidra `&param_1` shape was required was wrong.

## AnalyzeInstruction (0x10003260): SOLVED (EXACT)
Checkpoint: the heading's old status is not current. Verdicts stay in metadata. The mechanism below is that pass's observation.


Opcode-length checker (183B); semantically correct C preserved in
ErrorModule.c (best 104/183: the 1st/2nd/3rd/5th/6th checks are EXACT,
including the `or bl,0xff` 0xff-materialization from the signed `== -1`
compares). Blocked ONLY on the 4th check: the reference loads `[eax-2]`
into `cl` once (`mov cl,[eax-2]; cmp cl,bl`) and re-checks it at the
`L_chk_d0` block (`cmp cl,bl` after the `[eax-1] >= 0x40` branch), with
`[eax-1]` re-read fresh for the d0 mask. Ours compares `[eax-2]` directly
and keeps `[eax-1]` in cl, 10 bytes shorter. ~9 formulations (nested vs
two separate ifs, c/b2 locals in conditions, comma-operator assignments,
re-reads) could not make MSVC6 materialize `[eax-2]` into cl across the
branch; the second `[eax-2]` check is always eliminated (dataflow knows it
is unchanged).

## cm_ChkMoveCredits (0x1000cb20): CONVERTED (call-site byte view)

Byte-identical (RELOC 171/171). The final 2-byte blocker was the second
`gm_QueryEntitySum` argument: the reference emits the RAW byte load
`mov cl, byte ptr [esi+0x1c]; push ecx` (register upper bits garbage:
Ghidra shows the CONCAT31 of `extraout_ECX`). A `(unsigned char)` cast
forces `xor ecx,ecx`; a `(char)` cast forces `movsx`. The raw byte appears
when the CALLER's view of the callee prototype has `unsigned char` for the
param. Since the callee's actual definition is `unsigned int`, the
conversion uses a fn-ptr cast call
`((int (__cdecl *)(int, unsigned char)) gm_QueryEntitySum)(...)`. Same
pattern as the compute_size (extra arg) and ShutdownLogAndErrorHandler
(int mask) casts: the reference's caller-side prototype view differs from
the current definition, and the cast-call reproduces it.

## gm_ResolveEntityById (0x10015e90): blocked (existing-loop counter register)

Entity resolution (static/dynamic/existing table scans); semantically
correct C preserved in spiel.c (best 193/211). The static and dynamic scans
are EXACT (the counter in `ecx`, matching both sides). Blocked on the
existing scan: the reference loads the count into `edx` and keeps the loop
counter in `ecx` (`mov edx,[count]; xor ecx,ecx; ...; inc ecx; cmp ecx,edx`);
ours puts the count in `ecx` and the counter in `edx`. Also reproduced:
the existing-loop counter increments ONLY on non-zero entries (the `je`
skips the `inc`: the counter must live inside the `if (*p != 0)` branch,
not the for-increment), and the query base must be read via the
`g_query_base` pointer variable (a load), not the literal. ~8 formulations
(declaration orders, inline count vs local, explicit `n <= 0` check, named
global vs raw address) could not move the count to edx.

## cm_ExModifyStat (0x100100a0): blocked (FPU clamp compare forms)

Stat-modify with float min/max clamping; semantically correct C preserved
in cm_ExModifyStat.c (best 107/159: the head, the `fild`+`fcom dword`
float-compare from the `(float)(int)(...)` sum cast, and the first
`sum < max` check are EXACT). Blocked on the clamp region's FPU compare
forms: the reference emits `fcom min; fnstsw; test ah,0x41; jne` (C0|C2)
for the second comparison while using `test ah,1` (C0) for the first;
ours emits `test ah,1; je` (inverted polarity) for the second regardless
of the C form (`sum < min`, `g_stat_min > sum` [loads the const →
`fcomp st(1)`], `!(sum >= min)`, `!(g_stat_min <= sum)`). ~6 formulations
plus the Ghidra-decomp condition shape `((max <= f) || (min < f)) && (max
<= f)`. The register-layout of the clamp block (fstp/fld swap, __ftol
call) follows once the tests match.

## plt_CheckZoneAvailability (0x10014ff0): DONE (induction-base folding)

Converted to C, RELOC 175/175. Finding: **MSVC6 folds the largest
positive address constant into the induction pointer's base when the
pointer is re-derived each iteration** (`e = base + i*0x18` → init
`add eax, base+1`, accesses `[eax+4]/[eax-1]/[eax]`). Writing the loop
in pointer-increment form (`e = base + 8;` before the loop, `e += 0x18;`
at the loop tail, the same shape as the neighboring `find_zone_record`)
keeps the base at `zone_table+8` with the reference's `[eax+5]/[eax]/[eax+1]`
displacements. Struct-field access (`struct zone_record` sized 0x18) does
NOT prevent the fold: only the increment-form source does. Contrast with
`plt_FindRecord` (0x10014f30) / `plt_SetPlantMap` scan1 (0x100150a0): there the
reference itself has the +1 folded (`lea esi,[edi+9]`, `[esi-1]/[esi]/[esi+4]`),
so per-iteration recompute or `p = base+9` is the matching form. Rule of
thumb: **read the reference's folded base constant from the init `lea`/`add`
and pick the C pointer form that reproduces it**: recompute-for-each-iteration
yields the compiler's own folding, increment-form preserves the source base.

## plt_SetPlantMap (0x100150a0): DONE (constant coalescing + byte-reg pairing)

Converted to C, RELOC 257/257. Findings:
- **Explicit marker variable forces constant materialization.** The reference
  pre-loads `0xffffffff` into edx once (`or edx,0xffffffff`), then uses `dl`
  for the two byte marker compares and `edx` for the dword `-1` store. This
  appears only when C keeps a named `unsigned char marker = 0xff` (as in the
  neighboring `plt_FindRecord`); literal `0xff` compares compile to
  `cmp byte[mem],0xff` immediates and lose the `or`/`dl` form.
- **Dead param-slot reuse:** the SearchRecordTable result lands in
  `zone_type`'s stack slot (`mov [esp+0x20],eax`) because zone_type's value
  was hoisted into ebp early (used as the call arg AND after the loops).
  If the C uses the wrong variable there (e.g. `extra`), the local gets a
  fresh slot and every `[esp+N]` offsets shift by 4.
- **The `if (A) goto; ...; if (B) x; else y;` two-test idiom reproduces
  exactly when A and B are DIFFERENT variables**: here first test is
  `extra`, second `zone_type`; both values live in different registers
  (fresh load vs ebp copy) so MSVC6 emits both tests.
- **Byte-store/load pairing:** the two `(char)` field stores compile with the
  y-value in cl and x in dl (loads emitted y-first, x-second, store y at +9,
  x at +8 AFTER the interleaved map test). Source order that reproduces it is
  x-store THEN y-store (`rec+8 = x; rec+9 = y;`): MSVC6 reorders to the
  y-first/cl form. The naive source order (y then x) swaps the pairing.

## ProcessSendData (0x1000a860): SOLVED (RELOC, delta 0)
Checkpoint: the heading's old status is not current. Verdicts stay in metadata. The mechanism below is that pass's observation.


Connection loop iterating 8 slots (`0x101deb00` + `0x264264` stride to
`0x114ffe20`, signed `jge` end compare: cast to int, else `jae`); per
slot: flag bit 1 gate, `srv_SendPlayerData`, inner packet loop
(pkt at `+0x2641f4`, flag bit 0x100, `memcpy(dst +0xb1, pkt, 0x99)`
via rep movsd/movsb, `FreeCommandBuffer(conn, pkt)`, clear flag bit,
re-send). Semantically correct C preserved in server3.c (best 18/132).
Blocked on two coupled allocation choices: (1) the reference loads the
packet ONCE into esi (the rep movsd src register) at the loop top and the
`mov eax,[ebx+0x2641f4]` reload for the FreeCommandBuffer arg comes AFTER
the rep (esi was consumed); our compile keeps the packet in edx (rep does
not clobber edx) and pre-pushes it before the rep, no reload. (2) the
reference computes the memcpy dest with `lea edi,[ebx+0xb1]` in-loop; our
compile LICM-hoists `conn+0xb1` into ebp (a 4th saved register, +1 byte
prologue) and re-expresses the pkt load through it (`mov edx,[ebp+0x264143]`).
~4 formulations (inline vs named pkt, int vs char* pkt, while-cond
assignment, unsigned char* conn) could not move the packet to esi or keep
the dest lea in-loop.

## m_PoolAlloc (0x10006d20) / srv_InitBuildingTypeTable (0x1000b040): blocked (alignment-prefixed memset)

Both functions otherwise convert cleanly (m_PoolAlloc 234/270 with msvc6
`/O2 /Gd /Oy-`; srv_InitBuildingTypeTable 261/372 with explicit-store C) but share
a block-fill prelude the spellings tried here did not emit. The later heading
records a likelihood inference, not a proof that C cannot emit it and not
assembly permission. The reference runs
this **alignment prelude** before the dword stores:

    xor eax,eax
    lea ecx,[edi+edi*2]   ; (3*dest)&3 = alignment offset
    and ecx,3
    sub ebx,ecx           ; len -= prefix
    jle L_after
    rep stosb             ; prefix bytes (aligns dest to 4)
    mov ecx,ebx
    and ebx,3
    shr ecx,2
    rep stosd             ; dwords
    add ecx,ebx
    rep stosb             ; tail

Every msvc 4.0/4.2/5.0/6.0/7.0 / VC7 compile of ~25 probe shapes emits the
plain dword+tail form (`shr ecx,2; rep stosd; and ecx,3; rep stosb`)
instead. Probed: constant/runtime/local/unsigned/size_t lengths, escaping
locals (`&n` taken), global vs param dests, explicit `for`/`while(n--)`
zero loops, the CRT `memset` loop source, `/O1 /O2 /Ox /Os /Ot /Og`, codegen
`/G3 /G4 /G5 /G6 /GB`, `/Zp1`, `/Oy-`, `/Ob0/1/2`, msvc5 SP1-3 / msvc6
SP3/SP6. `/Og-` (`/Oi /Ot /Oy`) keeps the length in a local (matching the
reference's `mov [ebp-4],0x3f0; mov ebx,[ebp-4]`) but expands the memset
without the prelude; `/Ot`/`/O1` emit a real `call memset`. The reference
also spills payload+len to dead param slots (`[ebp+0xc]`/`[ebp+8]`) around
the memset: a consequence of the prelude's extra register pressure. Suspect
a service-pack or custom-build codegen difference; preserved C is in
m_alloc2.c / server4.c. The rest of both functions (alignment calc, node
search, slot scan, and srv_InitBuildingTypeTable's loop + 42 unrolled constant
stores with their `mov al,N` value grouping) matches msvc6 `/O2` exactly.

Additional probes (2026-08, srv_InitBuildingTypeTable specifically): msvc600sp4
and msvc600sp5 also emit the plain dword+tail form (SP1-SP6 now all ruled
out); a 96-combination flag sweep on the full function body (`/O1 /O2 /Ox
/Od` × `/G5 /G6` × `/Oy-` × `/Oi` × `/Og-`) produced zero alignment-prelude
hits; ~45 C formulations total were compiled, adding dest-copy locals
(`char *d = g; memset(d,0,0x3f0)`), pointer-difference counts (`end-start`
through locals), `sizeof` through pointer-to-array casts, volatile and
address-taken counts inside the full loop+stores body, inlined-wrapper
passes (the wrapper inlines but `memset` becomes a `call`), and count
variables shared with the loop bound, all still `mov ecx,0xfc; rep stosd`
or `call memset`. The aligned prelude only ever appears in the target when
the count is a memory-resident runtime value in an ebp-framed function
(e.g. 0x10006728, 0x10017611), and no leaf-function probe with a constant
count reproduces either the frame or the prelude. Confirmed: the target's
`mov [ebp-4],0x3f0; mov ebx,[ebp-4]` spill is the only frame local, and the
function is a leaf (no calls), so a proper-C match cannot reach 372 bytes
(ceiling 334B / 261 matched bytes).

Re-verified 2026-08-27 (srv_InitBuildingTypeTable, full body, end-to-end via
`rebrew test`): 7 whole-function variants (constant / `int n` / dest-copy
`char *d` / volatile / address-taken counts × dests) × `/O2 /Gd` and
`/O2 /Gd /Oy-`: best is still 261/372 (334B), every other variant is
worse (volatile: 355-358B but 192-256 matched: the spill breaks the
loop/store register allocation). Additional compiler builds: base 6.0
(12.00.8168) and 6.0-SP6 (12.00.8804, /G6-capable i.e. Processor-Pack
codegen) both emit the plain form for variable/volatile/param-operand
counts; a 16-variant × 7-flag matrix (volatile, address-taken, struct
member, register/const/unsigned/size_t counts, dest-copy locals,
struct-copy `memcpy` forms, `/Og- /Oi /Oy- /O1 /Ox /G6`) produced zero
prelude hits; two-arg param probes `memset(p, n)` / `memset(slot+4, 0,
asize-4)` (the m_PoolAlloc shape) also plain. The prelude template
(`lea r,[edi+edi*2]; and r,3; sub ebx,ecx; jle; rep stosb; rep stosd;
rep stosb`) occurs at exactly 6 target sites: m_AllocTracked 0x10006730,
m_init 0x10006929, m_PoolAlloc 0x10006e0d, srv_InitBuildingTypeTable
0x1000b057, gm_AllocGebaeude 0x10017611, plus a memcpy twin (rep movs)
at ReadVfsData 0x10008f0c: every one in a function that has never
byte-matched (SIZE_MISMATCH or only PROVEN).

### The prelude is hand-written asm, not a compiler expansion (2026-09-04)

The title records a likelihood inference, not a proof that C cannot emit the
shape. Native register invariance across contexts and operand homing are the
positive structural evidence; unsuccessful C searches and library exclusions
only corroborate it. Goal108 rechecked209 distinct target/core sites from the
current receipts and the stored/reloaded literal count in both client
building-table initializers. It did not recount all 725 historical sites or
reproduce their original source text. Current target-scoped receipts state the
inference explicitly; see [the assembly audit](assembly-audit.md#what-qualifies).

#### Reviewed GOLDTL inline helpers (2026-10-09)

Three file-local helpers have no standalone target VA. Their original
callers contain the same operand-homed assembly macro described below:
`fill0` and `copy0` are inferred reconstruction names; the evidence attests
the original macro, not those helper names or a standalone allocation.

| Source definition | Original caller | Prelude site | Operation |
|---|---|---|---|
| `src/GOLDTL.fcn_0043f6b0.c:fill0` | `0x0043f6b0` (297 bytes) | `0x0043f76b` | Fill |
| `src/GOLDTL.fcn_00449ba0.c:copy0` | `0x00449ba0` (528 bytes) | `0x00449c6f` | Copy |
| `src/GOLDTL.fcn_00469140.c:fill0` | `0x00469140` (378 bytes) | `0x004691f8` | Fill |

The complete prelude is **26 bytes**, starting at `lea ecx,[edi+edi*2]`
and ending after the final `rep stosb` / `rep movsb`; the older 24-byte label
is imprecise. The fill pattern
is `8d0c7f83e1032bd97e0cf3aa8bcb83e303c1e902f3ab03cbf3aa` and the copy
pattern is `8d0c7f83e1032bd97e0cf3a48bcb83e303c1e902f3a503cbf3a4`.
Each caller contains exactly one corresponding pattern. Direct checks
exclude both patterns from the stock `msvc-6.0-sp5-pp` `LIBC.LIB` and
`LIBCMT.LIB`; whole-caller library matching also returns a miss for each.
These exclusions corroborate the compiler/operand evidence below rather
than using a signature miss alone to establish provenance.

`.scratch/goal20/helper-assembly-evidence.json` records instruction contexts,
reference and archive hashes; `check_helper_assembly.py` asserts the sites,
lengths and archive exclusions from the saved CLI disassembly/probe receipts.
The helpers' evidence now lives in format-3 `rebrew-functions.toml` under
`[source.definitions]`, keyed by file, C symbol and target, with
`[source.files]` for support purposes. The separate source store is retired.
Data rows stay format-2 `rebrew-data.toml`. No helper VA or byte verdict is
invented, and a caller's blocker is not inherited by its helper. Current
body/target evidence must be reviewed again after changes; the historical
caller matches are not fresh measurements.

Fresh `rebrew test --no-promote` measurements with the provenance-support
checkout reproduce all three callers as RELOC: 297/297, 528/528 and 378/378
bytes respectively, with no mismatches after relocation masking. Receipts
are `.scratch/goal20/helper-client-test-0043f6b0.json`,
`helper-client-test-00449ba0.json` and `helper-client-test-00469140.json`.
These are object comparisons; they do not establish a byte-identical client
link or promote the helpers to standalone functions.

#### Reviewed GOLDTL building-table initializer (2026-10-10)

`src/Develop/DieGildeAddOnServer/server.c:srv_InitBuildingTypeTable`
corresponds to the complete 372-byte GOLDTL body at `0x004e7810`. Its fill
macro starts at `0x004e7827` and contains the same complete 26-byte fill
pattern above. The leaf function stores literal `0x3f0` at `[ebp-4]` and
reloads it into EBX before the macro; the destination is loaded into EDI.
This operand homing, invariant alignment arithmetic and three REP passes
agree with the original assembly evidence and compiler controls above.
Stock PP LIBC and LIBCMT exclude the pattern, and the whole-body probe misses.

`check_building_table_assembly.py` checks the complete body, operand setup,
pattern and archive exclusions and writes `building-table-assembly-evidence.json`
under `.scratch/goal20`. Fresh object comparison is RELOC, 372/372 bytes with
45 relocations; this is corroboration and does not establish a client link.
The reviewed source evidence is recorded through `source document-assembly`
for GOLDTL only. The source body and other targets' records are unchanged.

Measured with `.scratch/mp2/tmpl.py`, `scratch.py`, `libscan.py`:

- **Byte-invariant.** All 725 prelude sites across `server.dll`,
  `server.exe`, `Europa1400Gold.exe` and `Europa1400Gold_TL.exe` are one of
  exactly two 24-byte sequences, differing only in `stos` (fill) vs `movs`
  (copy). The scratch register is `ebx` at all 725.
- **The plain form is not invariant.** Its `mov <scratch>,ecx` register over
  the same binaries splits eax 161 / edx 134 / ebx 21 / ebp 14 / esi 1. A
  register-allocated expansion varies with context; this one never does.
- **`lea` is not msvc6's idiom.** The prelude computes the head pad as
  `lea ecx,[edi+edi*2]; and ecx,3`, using 3 == -1 (mod 4) to save a byte.
  msvc6 compiles every C spelling of that pad (`-(int)p`, `4-(p&3)`, `p*3`,
  `~p+1`) to `neg`, including when the pointer stays live.
- **Not a CRT routine.** Neither template appears in msvc6 `LIBC.LIB` or
  `LIBCMT.LIB`, so the linker did not pull it in.
- **Constant operands are spilled anyway.** At 0x1000b046 a literal `0x3f0`
  is stored to `[ebp-4]` and reloaded into `ebx` before the fill. No
  compiler homes a constant to the stack to feed its own inlined memset;
  an `__asm` block naming a C variable does exactly that. All six sites
  home both operands, which is the asm-operand signature.

An `__asm` block naming the two operands as C variables reproduces
m_init byte-for-byte (`.scratch/memset_probe/a3.c`). The original
sources used an asm zero-fill/copy macro here, so the prelude cannot be
reached from C and the six sites split two ways:

| Sites | Spelling | Result |
|-------|----------|--------|
| m_init 0x10006929, m_PoolAlloc 0x10006e0d, srv_InitBuildingTypeTable 0x1000b057 | minimal `__asm` block | byte-exact: m_init and srv_InitBuildingTypeTable RELOC 100%, m_PoolAlloc 4 bytes off |
| m_AllocTracked 0x10006730, vfs_ReadData 0x10008f0c, gm_AllocGebaeude 0x10017611 | plain C | PROVEN, with the prelude's bytes missing (m_AllocTracked 608 vs 658, vfs_ReadData 446 vs 472) |

Removing the remaining three blocks is possible but costs byte identity:
m_init measured 97/162 with the object 143 bytes against the target's 162
when the block is replaced by `memset` (`.scratch/memsetprobe/m_alloc_noasm.c`),
and it would then need `rebrew prove` to stay green. Kept as asm for now.

Re-checked 2026-09-12, independently of the 20-image sweep below:
msvc600sp5pp, msvc7, msvc700, msvc700sp1, msvc710 and msvc710sp1 with
/O1 and /O2 never emit the prelude for `memset`/`memcpy`; MSVC6's STL
(`std::fill`, `std::fill_n`, `std::copy`) does not either; and every C
spelling of the head pad (`d*3`, `(d<<1)+d`, `d+d+d`, `-d`, `4-(d&3)`)
compiles to `neg`, never to `lea ecx,[edi+edi*2]`.

Two earlier claims in this file are corrected by the above: the prelude is
not a "dest-alignment" expansion (0x1000b046's dest is link-time constant
and dword-aligned with a constant length), and it is not a service-pack
codegen difference (a 20-image × 10-flag sweep over msvc 2.0 through 7.1,
including both 12.00.8168 and 12.00.8804 backends, is plain in all 200
runs; `.scratch/mp2/sweep.sh`).

`rebrew prove` can rescue this one, and now does (2026-08-27): the two
prove-tool bugs noted below were fixed in prove.py: (1) DIR32 watched
patches preserve operand addends (`symbol_va + addend`, so the
`cmp eax, g_office_slots+0x3f4` bound links to `0x101de994`, not the
bare base), and the original blob is no longer patched at compiled
offsets (its linked operands are already correct; writing compiled
offsets into it corrupted the different-layout instruction stream);
(2) void functions now skip the EAX/EDX comparison entirely (EAX at
`ret` is unspecified junk for a void cdecl function) and prove by
memory side effects only. srv_InitBuildingTypeTable is therefore PROVEN:
`rebrew prove 0x1000b040 --loop-bound 400 --watch-va <252 table dwords>`
compares every dword of the 0x3f0-byte table (1×1 terminal state
pairs). Note the high `--loop-bound`: angr's LoopSeer counts each
rep-stosd iteration, and the memset alone is 252. Pointer-returning
siblings (m_PoolAlloc 0x10006d20, AllocateTrackedHeapBlock 0x10006580)
prove via EAX equivalence once the original-blob corruption is fixed:
m_PoolAlloc is now PROVEN too.
Since the original writeup, m_PoolAlloc's C was rebuilt and now matches
234/270 (from 223): the two allocation sites with their distinct literals
(`m:pool_get_free(tp_m_pool)` for the empty-head path with `*head=block`
stored first, `m:pool_alloc(tp_m_pool)` for the search-miss path with
`next=*head`/`*head=block` last), the `while (block && ...)` search loop,
`slot += block->size` in the for-increment, and the back-pointer write
`*(int*)slot = (int)block` before `count++`/`memset(slot+4, 0, asize-4)`.
The only remaining delta is the found-path memset block (offset 0x10006df7
on), still the unreproducible alignment-prelude expansion. m_ShutdownAllocator
(0x10006c00) is no longer blocked: see its section below.

Re-verified 2026-08-27 on the full m_PoolAlloc body (runtime count `asize-4`,
not a constant):
- Compiled the identical body with every available image (msvc 4.0/4.1/4.2,
  5.0/SP1/SP3, 6.0/base+SP1-SP6, 7.0), all emit byte-identical 248-byte code,
  zero prelude hits. Same for a /G3 /G4 /G5 /G6 /G7 /GB sweep and a residual
  flag sweep (/Os /Ot /Oz /Oa /Ow /Og- combinations) on the runtime-count body.
- ~15 additional C formulations added to the prior ~45: address-taken locals
  that survive DCE, memory-residency forced via opaque global stores,
  `volatile` count, `unsigned` count, byte and dword zero loops
  (`for(j...) slot[j]=0`, `while(n--)`, `while(n>=4){*(int*)p=0;...}`),
  `block->size-4` field count, inlined static wrapper, all still the plain
  `shr ecx,2; rep stosd; and ecx,3; rep stosb` form (or `call memset`).
- Target-wide scan: the prelude template (`lea r,[edi+edi*2]; and r,3;
  sub ebx,ecx; jle; rep stosb; ...; rep stosd; ...; rep stosb`) occurs at
  exactly 6 sites: m_AllocTracked 0x10006730, m_init 0x10006929,
  m_PoolAlloc 0x10006e0d, ReadVfsData 0x10008f0c (a **memcpy** variant:
  `rep movsb/movsd`, src in esi), srv_InitBuildingTypeTable 0x1000b057,
  gm_AllocGebaeude 0x10017611: all in Finding-19-blocked functions. The
  plain form occurs at independent sites (zlib deflate/lm_init,
  gv_AllocGraveyardField, setSBUpLow). Both forms coexist in ONE binary.
- Structural discriminator: plain-form sites materialize the count freshly
  into the volatile ecx (`mov eax,[g]; lea ecx,[eax+eax*4]; ...` in
  gv_AllocGraveyardField); aligned-form sites load the count from a stack slot
  into ebx with dest in edi. msvc6 SP6 always keeps runtime counts in ecx,
  fresh or reloaded, so no C shape can steer it onto the ebx/memory path.
  The original build's compiler variant (service-pack/custom-build codegen)
  remains the suspect. Ceiling for proper C confirmed at 234/270.

### m_init (0x100068e0): re-verified 2026-08-27, same conclusion

Non-leaf runtime-count site (count `n*16` kept in ebx across the `malloc`
call at 0x1001a7f7; 143B compiled vs 162B target, the 19B delta being the
prelude + the count-register choice edi-vs-ebx that precedes it). Probed for
this exact body: 15 C formulations (inline `n*16`, `int`/`unsigned` locals,
`volatile` count, memory-resident count via the `g_flag_3c` global store,
dest-copy locals (`char* d`/`void* pool`), `n<<4`, store-to-global after the
call (`memset` count reloaded), address-taken local, reordered statements,
named vs absolute-address globals) × `/O2 /Gd /Oy-`, plus an `/O1 /Ox /O2
/G5 /G6 /GB /Oi /Og-` flag sweep: zero prelude hits, count always
re-materialized into volatile ecx. The rest of the function is byte-faithful:
prologue, four zero stores (`0x28,0x30,0x2c,0x34` order, source order, not
address order), malloc call, and the tail. The tail is the discriminator for
source shape: the reference hoists the two `g_alloc_root_name/_4` loads
above the six zero stores (`mov eax,[g_default_group_name]` right after the
memset, stores at the end after `pop edi/esi`): only reproducible with the
assignments written FIRST and named externs (absolute-address derefs keep
source order and emit the loads after the stores). Final state: SIZE_MISMATCH
110/162 (object 146), C in m_alloc.c: see the Finding 19 correction for the
volatile-aliased dest read that closed the call region.

`rebrew prove` cannot reach a verdict on this body, and the failure is
structural rather than a budget problem. The target's prelude carries a `jle`
that skips the fill, so the original terminates; the compiled body fills
unconditionally, so every state dies inside `rep stos` with a symbolic count
and angr reports "no terminal states for compiled code". Confirmed at timeouts
up to 1800s and loop bounds 0, 1, 2, 3, 4, 6, 8, 10, 12, 16, 32, 64, 80, 128,
and unchanged by a 0/68 slice. Deleting the memset proves in seconds, which
isolates the fill as the sole cause. Bounding arg0 through
`prove_constraints` moves the stall to the original instead of removing it.

**A guarded memset must not be used to obtain PROVEN here.** Wrapping the fill
in `if (g_array_ptr != 0)` or an early `return` does make the tool print
PROVEN, but the proof is vacuous: with the guard present, a body whose tail
writes `g_list_head = 12345` instead of `0` is also reported "proven
equivalent", while the same wrong tail without the guard is correctly rejected
with a counterexample (`mem[0x117640c4]=0 vs 959447040`). The guard gives angr
a fill-free path, it explores only that path, and everything the fill path
would have contradicted goes unchecked. Probes in `.scratch/ipp-l3/bodies/`
(`f2_wrongtail.c`, `f3_nofill_wrongtail.c`, `f4_inlineguard_wrongtail.c`).

## lb_ExPlayerlist (0x100145e0): DONE (struct-for-layout + auto-zero + tail layout)

Converted to C, RELOC 209/209. Findings:
- **A struct `{int count; int ids[8];}` (36 bytes) reproduces the contiguous
  count+ids frame** that a separate `int count; int ids[8];` does not: the
  compiler parked `count` in a dead param slot and the `memcpy(&count, 0x24)`
  became a garbage read. The struct forces adjacency; `memcpy(msg+0x14,
  &list, sizeof(list))` then reads the intended 9 dwords.
- **The reference's `rep stosd` (9 dwords) + redundant `mov [esp+0xc],eax`
  (count=0) requires an EXPLICIT `memset(&list, 0, sizeof(list))` before
  `list.count = 0;`**: MSVC6's auto-init of fully-copied partially-written
  locals did not fire; the explicit memset places the rep-stosd first and the
  count store after, byte-identical to the reference.
- **Tail layout:** the final `if (result != -1) { log; return 0; } return -1;`
  puts the -1 path at the end (`je`, `or eax,0xffffffff`); the reference has
  the -1 path in fall-through with `jne L_queued_ok` and a no-op `or eax,eax`:
  produced by `if (result == -1) { return result; } log; return 0;`
  (`return result` keeps eax untouched; `return -1` forces `or eax,0xffffffff`).
- Same-function idioms reconfirmed: `(result + 1 == 0) ? -1 : 0` for the
  sbb chain; dword flag loads (`*(unsigned int*)conn & 0x200`, a byte load
  here constant-folds to `test cl,0`, a no-op).

## amt_SwapOfficeHolders (0x1000b880): SOLVED (RELOC, delta 0)
Checkpoint: the heading's old status is not current. Verdicts stay in metadata. The mechanism below is that pass's observation.


Semantically correct C preserved in aemter2.c (best 10/263 with msvc6
`/O2 /Gd`: the same ratio as other blocker-class functions, i.e. the CFG
matches and the frame/allocation diverges). Two coupled allocator choices
differ from the reference: (1) the reference INLINES each error epilogue at
its site: the call-result paths (`req==0`, `ent_a_rec==0`, `ent_b_rec==0`)
emit plain `pop;pop;pop;pop;ret` with NO `xor eax,eax` (eax already 0 from
the test), the other error paths emit `xor eax,eax`, while our compile
tail-merges all six into one shared xor block; (2) the reference uses zero
stack locals (req lives in the dead arg1 param slot, `ent_a_rec` in ebp,
ent_a/ent_b in edi/esi, swap temps in ecx/edx/eax) while our compile spills
8 bytes (`sub esp,8`, req + a swap temp), shifting every `[esp+N]` offset
and breaking the byte identity. Note the reference's `if (req == 0)` compiles
to `jne L_have_req` (error in fall-through, inline epilogue) vs ours
`je L_return0` (shared block): epilogue-merging is the culprit. Also
confirmed: `lea edx,[ecx+ecx*2]; lea edi,[edx*8+base]` for `base + i*24`,
`test edi,edi; jne` kept even though `base+i*24` is never 0.

## gm_KillSpieler (0x10017fb0): FENCED + PROVEN (267/278, scheduling swap)

Entity deallocation; C in the #else fence of spiel62.c, PROVEN via
`rebrew prove` (symbolic equivalence). Findings:
- **The `_emit` byte sequences in the naked body are 16-bit ops the inline
  asm parser can't spell**: `66 A1 moffs` = `mov ax,[abs]`, `66 81 3E FF FF`
  = `cmp word [esi],0xffff`, `FF 0D moffs` = `dec dword [abs]`. All three
  express directly in C (`*(unsigned short*)0x10035880`,
  `*(unsigned short*)entity == 0xffff`, `g_citizen_count--`).
- **`dec [g_citizen_count]` (the FF 0D memory form) requires the NAMED
  symbol**: a raw `*(int*)0x10035434 -= 1` compiles to load/dec/store.
- **`mov [ebp+0x100358a4],eax` (index-based address) requires the raw
  expression `*(int*)(0x100358a4 + index * 0x21c) = -1`**: writing
  `*(int*)(entity + 4)` emits the 3-byte `mov [esi+4],eax` instead of the
  reference's 6-byte ebp+disp form, cascading into a different store order.
- **Branch layout:** `if (arg2 != 0) { big } else { sprintf }` (sprintf in
  the else, emitted as the jump target at the end) reproduces the
  reference's `je L_param2_zero`; the inverted if put the sprintf in
  fall-through.
- **Persistent blocker (15 bytes, best 263/278):** two coupled spots. The
  ref-clear compare wants `mov edi,[ref]; cmp edi,[esi+4]` (table cell in a
  register, `*eid` as the cmp memory operand); the refs-fill `memset(...0x20)`
  setup wants `lea edi,[ebp+0x100358fc]` before `mov ecx,8`. Each is
  individually reachable but not together: `volatile` on the ref cells gives
  the target's load direction and drops to 248/278; `*(volatile int*)&ref[j]`
  also 248; a `cur = ref[j]` temp gives 259; re-deriving `*eid` as
  `*(volatile int*)(entity + 4)` holds 263 but flips the cmp direction. A
  `char* volatile` dest local delays the count as wanted in isolation but
  collapses the function to 180/278 in-tree. ~6 further C/flag variations
  (operand order, parenthesization, /G3 /G5 /GB /G6 /O1 /Ox) did not move the
  memset setup. The function is semantically PROVEN.

## ls_LoadExistingEntities (0x100127d0): FENCED + PROVEN (271/282)

Record loader; C fenced in loadsave2.c's #else, PROVEN via `rebrew prove`.
Blocked on two coupled register-role choices: (1) the reference sinks the
`offset = 0` store into the loop preheader (after the `count <= 0` guard:
`xor ebp; test; jle; xor ebx`) while our compile emits it before the guard;
(2) the reference's `lea esi,[offset+base]` puts the offset in the ModRM
base slot, ours `[base+offset]`, despite the same `offset + base` C
expression. Declaration order, for-increment forms, guard+do-while, and
/O1 /G5 /GB did not move either. Everything else matches: the `_emit`
`mov ecx,[0x100a8c34]` / `mov [0x10035450],eax` = plain global reads/writes
(`g_100a8c34`, `g_query_limit`), the record field reads at +0/+2/+6/+0xa/
+0xe/+0x12/+0x13/+0x1c with the 0x43 stride, and the shared `L_ret0` epilogue.
Historical proof procedure: that checkpoint first compiled the C path to set
NEAR_MATCHING, then ran `rebrew prove`. Use current CLI help for proof behavior;
the old flag override is not a production recommendation.

## srv_Init (0x10009d30): SOLVED (RELOC, delta 0)
Checkpoint: the heading's old status is not current. Verdicts stay in metadata. The mechanism below is that pass's observation.


Server init; C fenced in server2.c's #else, PROVEN via `rebrew prove`.
Blocked on two allocator choices: (1) **MSVC6 lays the four string buffers
by size** (b2@[esp+0], b0@[esp+0xc], b1@[esp+0x48], b3@[esp+0x110]) while
the reference keeps them contiguous in declaration order
(b0@0xc, b1@0x20, b2@0x104, b3@0x110): sizes b0[0x14], b1[0xe4], b2[0xc],
b3[0x3f4]; (2) `SetThreadPriority(GetCurrentThread(), 2)` hoists the
`push 2` before the GetCurrentThread call (a temp handle fixes the order
but re-introduces a stack local that shifts the buffers). Other findings:
- **Deferred cleanup across 4 calls**: `InitializeLogAndErrorHandler`
  (4 args, via a cast-call against the 1-arg prototype), `m_init`,
  `gm_Open` all pop their cdecl args in ONE `add esp,0x18` after gm_Open.
- **The `0x7fa6` stack-arg reuse**: `m_init(0x7fa6)`'s push doubles
  as gm_Open's 2nd param: only reproducible by calling gm_Open as a 1-arg
  cast-call (`((int(__cdecl*)(char*))gm_Open)(b1)`); a literal 2-arg call
  emits a second push (+4 bytes).
- The `_emit` sequences decode as `call [GetCurrentThread]` /
  `call [SetThreadPriority]` (IAT entries at 0x1002406c/0x10024068),
  `mov ecx,[0x10117688]`, `mov [0x101176ec],eax`, `mov dword[0x10117690],0`,
  `lea ecx,[esp+0]` (the sprintf's 3rd arg = &b0).
- strcpy/strcat inline as the repne-scasb strlen + rep-movsd/movsb copies
  when written as plain `strcpy`/`strcat` on the char buffers.

## cm_ExChangeBits (0x1000eaa0): SOLVED (RELOC, delta 0)
Checkpoint: the heading's old status is not current. Verdicts stay in metadata. The mechanism below is that pass's observation.


Bitmask edit handler; C preserved as a comment in cm_ExChangeBits.c (best
18/213: the Ghidra decomp at the top of the file matches the asm exactly).
Blocked on: MSVC6 materializes `base + 0x10` into a callee-saved edi across
the `gm_GetFieldByType` call (`lea edi,[esi+0x10]; ...; mov [edi],eax`) while
the reference emits `mov [esi+0x10],eax` inline; the `gm_ResolveEntityById`
arg pushes are also scheduled differently (~7 C formulations: iVar1/orig
copies, char* base, target-variable selection, comma-form, switch vs if-else,
declaration orders; none moved the materialization). Additionally
`rebrew prove` cannot mark it PROVEN (symbolic-execution state explosion even
with --loop-bound 30 / slice offsets), so the #else fence cannot be used
(SIZE_MISMATCH would fail `rebrew verify`): the function remains plain
naked with the C as a comment.

## ls_ID2Ptr (0x10014070): blocked (lazy ebp save, first draft)

491-byte savegame/entity-link fixup; first-draft C preserved in /tmp/lsid.c
(best 103/491). The reference pushes ebp/esi/edi together in the prologue
(ebp = the outer g_query_limit-loop counter) while MSVC6 pushes ebp lazily
at the outer loop's preheader (shifting every [esp+N] offset). Other
first-pass deltas: the resolve out-param locals and the lookup-array pass.
The decode is complete (see the file comment): g_entity_table_end player lookup,
gm_StartFilteredEntitySearch(1,5,0xa), the g_file_version-gated lookup
array, the 0x21c-stride entity pass with the word@-0x170 gate and
resolve/replace of ids at -4/0, and the outer loop's linked-list attaches
(pv1->5d / pv2->14 / pv3->178 with the 0x3f tail walk).

## cm_ExAllocThemaPredigt (0x1000f2f0): SOLVED (RELOC 172/172)

Checkpoint: the old "FENCED + PROVEN (76/172)" heading was already wrong by round 859.
The `obj[0x22] = 0` store at `0x1000f379` is `c6462200` on both sides, and `esi` holds `obj`.
The distinct-expression explanation below is the one that failed; the residence table is the correction.
The `type * 0x264264` index still matches the reference lea chain (`shl` ×0x11011, `lea [eax+eax*8]`, ModRM ×4).

**The condition is the base pointer's *residence*, not the expressions' distinctness (round 859,
isolated).** Swept the spellings with `payload[6]` then `= 0`:

| spelling | `obj` loads | surviving stores |
|---|---|---|
| `*(char*)(obj+0x22)` twice | 3 | **2** |
| `*(char*)(d+6)` then `*(char*)(obj+0x22)` (the doc's example) | 3 | **2** |
| `*(char*)(d+6)` twice | 3 | **2** |
| `p = obj; *(char*)(p+0x22)` twice | **1** | **1** (eliminated) |

Row 1 is the one that breaks the doc's framing: writing the **same** expression text twice also
survives, so "distinctness" is not the discriminator. What separates rows 1-3 from row 4 is
whether MSVC6 **reloads `obj` between the stores**: when the base is re-read from memory it
cannot prove the second store aliases the first, so both survive; when a named pointer holds it
in a register it can, and the dead store goes. The doc's example worked because
`d = obj + 0x1c` left `obj` reloadable, not because the expressions differed.

Practical form: to keep a redundant store, make the base pointer **reloadable** (spell it as the
global/parameter each time, or take the address in more than one expression); to let it be
eliminated, hold the base in a named local.

## cm_ExClearLagerslot (0x1000e690): SOLVED (RELOC, delta 0)
Checkpoint: the heading's old status is not current. Verdicts stay in metadata. The mechanism below is that pass's observation.


Storage-slot clear; C preserved as a comment in cm_ExClearLagerslot.c (best
28/191; the Ghidra decomp at the top matches the asm). Blocked on: the
reference keeps the ORIGINAL cmd in esi across the GetField/Resolve calls
(`mov esi,[esp+8]` in the prologue; `mov [esi+0x10],eax` field store;
`mov dx,[esi+0x14]` word reads) while MSVC6 reloads the param slot after
each call: ~8 C forms (msg/line variables, duplicated log calls for the
tail-merge, psVar1/c original copies, Ghidra short* arithmetic) could not
force the esi allocation. Also `rebrew prove` state-explodes on the
gm_ResolveEntityById path (like cm_ExChangeBits) so the #else fence cannot
be used: remains plain naked. Note the resolve-heavy functions
(cm_* with gm_ResolveEntityById) are systematically unprovable by the
current symbolic engine; the fence+PROVEN pattern only works for
resolve-free functions.

## m_pool_free (0x10006e30): SOLVED (RELOC, delta 0)
Checkpoint: the heading's old status is not current. Verdicts stay in metadata. The mechanism below is that pass's observation.


Block return to the pool free list; C preserved as a comment in m_alloc2.c
(best 23/137 with /O2: size matches). Blocked on: MSVC6 keeps the pool
pointer in esi (callee-saved) and places the fatal block between the checks
and the main body, while the reference uses edx (the value dies before the
m_FreeTracked calls) with the fatal after the main. /O1 swaps the register
(pool in edx ✓) but changes the encodings (`andl $0,mem` / `decl mem` vs the
reference's `mov [mem],0` + load-dec-store) and the walk's back-edge shape.
`rebrew prove` state-explodes on the walk loop → no fence. The decode:
slot = pool-1, node = *slot, bounds (node+0x10 .. node+0x10+size*max,
unsigned jb/jae), *slot = 0, count--, and when empty unlink from *pool
(head case or prev->next walk) + m_FreeTracked; fatal =
ReportFatalError(0x10028888, 0x279, 0x10028b94).

## m_ShutdownAllocator (0x10006c00): DONE (RELOC 283/283)

Memory-allocator teardown; C in m_alloc2.c, RELOC 283/283. Reproducing the
reference needed three fixes over the old /tmp/sma.c shape: (1) a single
`char buf[0x400]` reused by both sprintf sites (the reference lays the loop
"-> Pointer not freed:%s" buffer at the SAME frame offset as the anomaly
buffer: the old `buf[0x3f0]+buf2[0xc]` pair gave a 0x3fc frame and a
separate buf2 at 0x3f0); (2) the array loop as `i = 0; if (g_array_count
<= 0) goto cleanup; item = g_array_ptr + 8; do {...} while (i < g_array_count)`
with `i++; item += 0x10;` at the body end: this reproduces the reference's
guard-then-pointer-load preheader (`mov eax,[g_array_count]; xor edi,edi;
cmp eax,ebx; jle; mov ecx,[g_array_ptr]; lea esi,[ecx+8]`) and the
`inc edi; add esi,0x10` loop-back order; (3) `/O2 /Gd` (frame-pointer
omission: the reference uses esp-relative addressing throughout).

## gm_RandomStatModifier (0x10018450): blocked (char value representation)

Random stat modifier; C preserved in /tmp/grsm.c (best 29/78). Blocked on
MSVC6's char-value representation: the reference loads the char param as a
BYTE (`mov bl,[esp+8]`), reloads the param slot for the fild zero-extension
(`mov eax,[esp+8]; and eax,0xff`), and does the sums in byte registers
(`add al,0x15`; `add bl,al; mov al,bl`); MSVC6 loads the dword and sums in
eax/ebx regardless of the cast form. `rebrew prove` additionally flags a
char-sign EAX difference (4294967040 vs 0) → no fence; remains plain naked.
The Ghidra reference (in the file) matches the decode exactly.

## CloseVfsStream (0x10008d10): SOLVED (RELOC, delta 0)
Checkpoint: the heading's old status is not current. Verdicts stay in metadata. The mechanism below is that pass's observation.


VFS stream close; C preserved in /tmp/cvs.c (best ~62/301 with /O2; the
byte-loop crc/size writes, the unsigned `>= 8` bounds (cast to unsigned, or
`jb` appears instead of `jl`), the flags reload for the final check (read
the memory, not a register copy, else an extra `push ebx` appears), and the
flags-in-al register all match). Blocked on: the reference places the
stream==0 return at the END (`je 0x128` long jump, `mov eax,ebp`) while
MSVC6 inlines it (`jne` short, `xor eax`); `return result` still folds to
xor. The diff ratio classifies as STUB, which `rebrew prove` rejects →
no fence. Also note: the STUB/SIZE_MISMATCH/NEAR_MATCHING class comes from
the byte-diff ratio, and prove only accepts the latter two.

## ahm_InitRandomEntity (0x1000c600): DONE (RELOC 109/109)

Random alchemy-entity initializer; converted to C, RELOC 109/109. Findings:
- **The scan-loop tail order (`dec count; inc idx; and; test; jne`) requires a
  WHILE loop with `count--; idx = (idx+1)&0x1f;` in that order in the body**:
  the equivalent for-loop (`for (count=0x20; count; count--)`) emits
  `inc/and` before `dec`, and a do-while PEELS the first iteration.
- **The float-store scheduling (`fstp [eax]` before `add eax,0xc`) needs an
  explicit `(float)` cast on the store**: `((float*)p)[0] = (float)(*(p-1)
  * dScaleFactor)` (double multiply via `fmul qword`, single store) vs the
  uncast form which defers the fstp after the pointer add.
- The `idx*244` lea chain (`idx*3 → *15 → idx*61` then `shl 2`) and the
  `[ecx*4 + base]` marker check reproduce from plain `idx * 244` arithmetic.

## sim_StartEntityQueryByType (0x10015460): blocked (arg/table register roles)

Type-dispatched entity query; C preserved as a comment in sim.c (best
10/145: the size matches; the register roles shift everything). The
reference keeps arg1 in esi and the entity-type table in edi (both
callee-saved, restored per branch epilogue); MSVC6 allocates edx/esi
instead. The `type * 0x24d` (589) record index reproduces via the reference's
lea chain (×3 → shl 4 → +type → ×3 → ModRM ×4). `rebrew prove` rejects the
STUB-class ratio → no fence.

## amt_UpdateEntityLinks (0x1000ba30): SOLVED (RELOC, delta 0)
Checkpoint: the heading's old status is not current. Verdicts stay in metadata. The mechanism below is that pass's observation.


Office-entity link fixup; C preserved as a comment in aemter2.c (best
~49/179). The reference keeps arg1 in ebp at the start (for the `[ebp+4]`
field reads) and REASSIGNS ebp = arg2 inside loop1 (for the later
`[ebp+0x168]` uses), checking the arg2 condition directly against the param
slot; MSVC6 hoists arg2 into ebp from the start and adds an extra
callee-saved edi. ~5 forms (rec-based vs eax-style loop pointers, arg1+4 vs
arg2+4 in the field compare, byte vs dword `+3`) did not move it. The
`(def > 0xb) + 3` (seta; add) and the two-loop structure decode cleanly.

## gm_FindEntityByOwner (0x10019c60): blocked (loop register roles)

Owner lookup; C preserved as a comment in spiel622.c (best 13/98). The
reference keeps arg1 in edi, the loop pointer in ecx, the counter in esi
and inlines the arg1==0 return-0; MSVC6 allocates esi/eax/edx with the
return at the end. The owner/type checks and the `i * 0x21c` lea-chain
return decode cleanly.

## cm_ExChangeDesire (0x1000e9c0): SOLVED (RELOC, delta 0)
Checkpoint: the heading's old status is not current. Verdicts stay in metadata. The mechanism below is that pass's observation.


Desire-stat update; C preserved as a comment in cm_ExChangeDesire.c (best
37/214: the size matches). The reference keeps cmd in edi (callee-saved)
with the loop counter in ebx; MSVC6 reloads the param slot. Interesting
decode: the clamp is the ternary `*slot = (*slot >= _g_stat_max_d) ?
_g_stat_min_d : _g_stat_max_d;`: the reference's redundant middle
slot-vs-min check is the compiler's ternary expansion.

## cm_ExSetAttribute (0x1000e8d0): SOLVED (RELOC, delta 0)
Checkpoint: the heading's old status is not current. Verdicts stay in metadata. The mechanism below is that pass's observation.


Attribute-set handler; C preserved in cm_ExSetAttribute.c
(best 15/243). The reference keeps cmd in ebp across the
GetField/Resolve calls; MSVC6 reloads the param slot and schedules the
resolve arg pushes differently. The descriptor decode is clean: signed
size/count bytes + 16-bit offset, three size-dispatched copy loops
(1/2/4 bytes) with the `movsx`+`jbe`/dec-jne pattern.

## cm_ExRemoveLinkedObject (0x1000f0d0): SOLVED (RELOC, delta 0)
Checkpoint: the heading's old status is not current. Verdicts stay in metadata. The mechanism below is that pass's observation.


Linked-node removal; C preserved in cm_ExRemoveLinkedObject.c
(best 22/197). The reference keeps result in edi and the original cmd in esi
across the resolve/query calls (with the resolve's 2nd out writing into the
result param slot); MSVC6 keeps both in volatile registers. The decode is
clean: pre-mark `*result = 2`, the resolve with the result-slot out, the
three removal paths (cmd+0x5d direct, q+0x14 query, local0+0x178,
result+0x14) with the -2/-1/0/eax return conventions.

## cm_ExChangeAttribute (0x1000e7d0): SOLVED (RELOC, delta 0)
Checkpoint: the heading's old status is not current. Verdicts stay in metadata. The mechanism below is that pass's observation.


Attribute accumulator (the `*dst += src` sibling of cm_ExSetAttribute); C
preserved in cm_ExChangeAttribute.c (best 18/261). Same
blocker class: the reference keeps the original cmd in ebp and dst_base in
edi across the descriptor loop; MSVC6 reloads the param slots. The Ghidra
reference at the top of the file matches the decode exactly.

---

## Session findings: five more conversions + two register-role blockers

### Converted to byte-identical C (all RELOC, verified via `rebrew verify` 245/245, build hash c7ac331f)

**sim_FindAndMatchParents (0x100151e0, 535B)**: `gm_RandomMod` parent scan.
- The loop values are `unsigned short`: the compares compile to 16-bit
  `cmp bp/si, 0xffff` and the return-0 epilogue to `xor ax,ax`: the return
  type is `unsigned short` (the whole-register `mov ebp,eax` after the call
  leaves garbage in bits 16-31; only the low half is meaningful).
`(range * 3) / 4` is SIGNED division: `lea;cdq;and edx,3;add;sar`; writing
  `>> 2` produces a plain `sar` (3 bytes shorter, mismatches).
- The three check-fails share one `mov ebp,0xffff` tail block. MSVC6 only
  produces the shared tail when the checks are an `else if` chain ending in
  `goto done1; continue;`: a plain `goto fail1` label anywhere else gets
  placed mid-loop (after the last check) and inverts the final test.

**cm_ChkChangeAttribute (0x1000cde0, 331B)**: descriptor walker.
- Declaring `kind`/`n` as `signed char` makes MSVC6 allocate BYTE registers
  (`mov cl/bl`) and spill the call-crossing one to the freed param slot;
  declaring them `int` forces `movsx ebx/edi` (full registers, no spill).
- The switch cases are **1, 2, 4**, not 1,2,3: MSVC6's dense-switch test
  chain is `dec;je;dec;je;sub eax,2;jne default` (kind==3 would hit the
  default; the `p += 4*n` arm is case 4).
- `p++; p++` with a load between them (`n = *p` after the first increment)
  survives as `inc esi; inc esi`: adjacent increments merge into `add esi,2`.
- The record-sum expression needs a temp variable (`s = a + b; call(s)`) to
  get `mov eax,[esi]; mov edx,[ecx]; add eax,edx; push eax` instead of an
  edx-first load order.

**cm_ChkJoinLeaveElection (0x1000d110, 333B) / cm_ExJoinLeaveElection
(0x1000fd50, 445B)**: election validation/execution.
- `do { if (c) return 1; i++; } while (i < 4)` PEELS the first iteration
  (extra `mov edx,[q+0x1c]; lea edi,...` + a jge/jne loop reshape). The plain
  `for (i = 0; i < 4; i++)` with `break` + `if (i >= 4) return 1; return 0;`
  compiles to the reference's bottom-tested walk (`cmp [p],x; je; inc; add
  p,4; cmp i,4; jl`) with the loop-complete falling into the shared fail.
- `if (c) return 1; return 0;` (adjacent returns) triggers MSVC6's boolean
  idiom: `xor eax,eax; cmp; setge al`, 2 bytes longer and different layout
  from the reference's `cmp; jge shared_fail; xor eax,eax; ret`. Only the
  break+post-check shape (where the loop-complete path falls into `return 1`)
  avoids the idiom.
- In the Ex variant, writing the slot as `*(int*)(q+0x1c+i*4) =
  *(int*)(cmd+0x14)` (re-reading cmd+0x14 at the write) instead of a cached
  `player` variable lets the allocator reuse the register for the scan value
  and reload cmd+0x14, matching the reference byte-for-byte.
- The cler branch returns the INVERTED boolean: `result == 0` compiles to
  `neg eax; sbb eax,eax; inc eax`, while `!= 0` gives `neg;sbb;neg`. Both are
  valid 0/1 booleanizations; MSVC6 picks `inc` for `== 0` and `neg` for
  `!= 0` on call results (pointer comparisons give `neg;sbb;neg`).

**cm_ChkSellObjekt (0x1000cbd0, 517B)**: two-phase sell validation.
- The `w == 0xffff ? 0 : rec` ternary inverts to `jne` with the rec-chain
  inline; the reference has `je` with the zero inline: write
  `if (w != 0xffff) { p = rec; } else { p = 0; }` (the reference's then-arm
  is the rec computation).
- `gm_QueryEntitySum` takes a raw `char` second param: the reference pushes
  `mov dl, byte[...]` with garbage upper bits. The project-wide `(int, int)`
  declaration would sign-extend; use the cast idiom
  `((int (__cdecl *)(int, unsigned char)) gm_QueryEntitySum)(...)`.

### Blocked (documented with preserved C, see file comments)

**lb_SendLobbyConfig (0x100146c0): CONVERTED 236/236 RELOC** (was 225/236).
The reference loads `*player` flags into eax and keeps it there across the
value_ok path, doing `test ah,0x60`, `or/and ah,8`, `mov [esi],eax`; the
former C (with a `flags` local) made MSVC6 put the flags value in ecx and
the short-lived msg+0x18 value in eax.  **The fix: drop the `flags` local
entirely and read/write `*player` directly** (`if ((*player & 0x6000) != 0)
...; *player |= 0x800 / *player &= ~0x800;`).  The optimizer CSEs the two
`*player` reads into one value either way, but a *named* local is a distinct
IR node created at the assignment statement, while the anonymous CSE'd
load is created at its first use, and that creation point changes the
value's position in the allocator's priority list, flipping eax↔ecx (see
Finding 12 for the allocator-internal mechanism).  ~50 other formulations
(declaration order, signed/unsigned, `v` temp placement, `if (v != 0)`
polarity, ternary forms, goto structure, removing the `result` local, all
/O-flag axes) did not move it; removing the *flags* local did.

**cm_ExAllocClientSpieler (0x1000d570): 142/361 (result-register role).**
The reference keeps `result` in ebx (loaded at the `result ? 6 : 7` arg
computation, with the pending srand arg shifting esp so `[esp+0x18]` is the
arg2 slot) and cmd in edi, with rec pushed into ebp only at L_ok; MSVC6
allocates result→ebp and cmd→esi, and the arg-load scheduling diverges.
Flag sweep (/O2 /G5 /G6 /Og /Gy) and the GA matcher (10-min timeout, no
improvement) did not help. The `g_slot_table` symbol form
(over the 0x100358a0 literal) gained 4 matches; the rest is the register
roles.

**ls_LoadEntities (0x10013230): 2239/2268 (frame layout).** The C in the
fence's #else is structurally byte-identical (the body matches instruction
for instruction; 89 relocs) except for the frame: the reference keeps
`sub esp, 0xc` (3 dwords: record_count, i, id) and REUSES the ctx arg slot
(`lea ecx,[esp+0x28]` with two args pushed) for header_field; MSVC6
allocates a 4th frame dword (`sub esp, 0x10`), shifting every [esp+N]
operand by 4. ~14 formulations (declaration orders, for/while loop forms,
merging id/rec_id, removing the slot_ext_ptr variable) could not shrink the
frame; the arg-slot reuse for a late address-taken local is a GRA slot-
allocation decision that resisted steering.

**gm_StartFilteredEntitySearch (0x100170e0): 269/296 (setup register/CSE).**
The fence's #else C is complete and matches from the switch dispatch onward;
the divergence is the 9-global setup block.  The reference parks the zero in
`edx` (`xor edx,edx` reused for the null-check `cmp` and the three zero
stores) and CSEs the repeated `0xff` byte constants into `cl` (one hoisted
`mov cl,0xff`, two `mov [addr],cl` stores), emitting the stores in source
order.  MSVC6 picks `ecx` for the zero, emits per-store immediates
(`c6 05 addr,0xff`), and schedules the extra5 byte store ahead of the
extra2/extra3 word stores.  Cast removal, statement reordering, and the
/O1 /Ox /Og /Oy sweep did not change it.

Two later rounds moved the score without touching that register split, both
by fixing where `add edx,4` lands in the case-2 (strcpy) arm.  241 -> 262
came from advancing `arg_ptr` before the call; 262 -> 269 (2026-09-06) came
from dropping the `src` local as well and passing the post-increment slot
straight to strcpy.  The local delayed `add edx,4` by one slot versus the
reference's 0x10017176; without it the whole case-2 handler lines up and
every byte from the switch dispatch to the tail matches, leaving all
mismatches inside the setup head at offsets 6-81.  The same increment-first
spelling in cases 0/1/3/4/5 is neutral: the reference keeps `add edx,4`
after the value read in those arms.

**gm_Open (0x10015950): 856/861, PROVEN via 1-byte slice prove [91..92]
(pointer-base + register roles).** The C is a full reconstruction; restored
2026-08-26: the original calls `srand(timeGetTime())` (thunk fcn.1001a140)
between the producible-count loop and the exit log: the reversed CRT used to
provide it as `getpid` (run_000.c) until c77489a dropped run_000 and the call
with it; the C now calls it via an extern symbol. Two regions still diverge.
(1) The player-slot init loop: the reference bases dst_player_ptr at dst[0]
(`lea edi,[eax+0xc]` for the memcpy, stores at [eax-4]/[eax]/[eax+4]/
[eax+8]) while MSVC6 normalizes the base to dst[1] (stores at
[eax-8]/[eax-4]/[eax]/[eax+4], `lea edi,[eax+8]`): the [-1] index in the
source drives the base normalization. (2) The producible-count tail loop:
with `table_offset += 0x24d` driving the outer while and a hoisted
`slot_idx`, the inner loop now matches byte-for-byte except the item-category
load: the reference materializes `item + idx*65` in a register
(`mov ecx,eax; add ecx,ebx; mov cl,[ecx]`, 6B) while SP6 folds it into
`mov cl,[eax+ebx]` (3B); and the outer store: the reference uses index
addressing with a compensated displacement (`mov [esi+eax-0x22c],bl`, 7B)
after hoisting `add esi,0x24d` between load and store, while SP6 materializes
the address (`lea eax,[edx+esi+0x21]; mov [eax],dl`). Those two decisions
account for the remaining 5B (856 vs 861); ~10 C expression variants
(`*0x41` vs `*0x40+idx`, named address vars, struct indexing, double-use CSE,
outer-tail temps) and a /G3 /G5 /G6 /GB /O1 flag sweep all compile to the
same fold. Semantics match throughout (slice-proven).

**ahm_GetCommandPayloadSize (0x1000c710): 494/752 (switch preamble + case split).**
The fence's #else C is a partial reconstruction of the 103-case payload-size
switch.  Two blockers: (1) the switch preamble: the reference emits
`mov dl,[eax]; mov ecx,edx; and ecx,0xff; add ecx,-3; cmp ecx,0x66; ja;
jmp [ecx*4+0x1000c864]` (10-byte index prep that keeps the byte in dl for a
later `cmp dl,0x16`), MSVC6 emits `xor ecx,ecx; mov cl,[eax]` (4 bytes) and
folds the `(*cmd_payload == 0x16 ? 0x15 : 0x15)` ternary away: the 6-byte
delta shifts every subsequent case body; (2) case 0x16's entry-count loop is
misplaced in the reconstruction (the reference has the loop inline in case
0x16; the C sets cursor/total and breaks, with the loop in a different
case).  Switch-expression casts (`unsigned char`, `(int)`, `& 0xff`,
explicit variable) and the /O1 /Ox /Og sweep did not change the preamble.

---

## Deep-dive: the unsigned-char zero-extension form (and-idiom): resolved

The rebrew codegen docs (`docs/codegen/msvc/msvc-6.md`) claim the /O2
unsigned-char form is `and eax,0xff` (`25 ff 00 00 00` / `81 e1 ff 00 00 00`):
the 5.0/6.0 marker.  The ahm_GetCommandPayloadSize (0x1000c710) target shows
exactly this in its switch preamble, yet every probe of a bare byte load
produced `xor reg,reg; mov reg_low,[mem]`, and the file's own investigation
comment claimed no available MSVC build reproduces the and-idiom.  The
deep-dive resolved the contradiction: the form is selected by **whether the
byte value stays live after the load**:

### The three forms and when each appears

| Context | Codegen | Notes |
|---|---|---|
| unsigned char PARAMETER (32-bit stack slot, garbage high bits) | `mov eax,[esp+4]; and eax,0xff` | always masked: the slot's upper bits are unknown |
| byte from pointer-deref, value DEAD after | `xor reg,reg; mov reg_low,[mem]` | the "clean" zero-extend |
| byte from pointer-deref, value LIVE after (used later) | `mov reg_low,[mem]; mov reg2,reg; and reg2,0xff` | byte kept in a byte register, masked copy for the consuming op |

Probes (MSVC 12.00.8168, /O2; that run used Docker, current runs use project `unshare` on the pinned image):
- `uc_add(unsigned char a, unsigned char b) { return a+b; }` →
  `mov eax,[esp+4]; mov ecx,[esp+8]; and eax,0xff; and ecx,0xff; add eax,ecx`
  (the docs' claim: param values).
- `switch (*p) { ... }` with the byte dead → `xor ecx,ecx; mov cl,[eax]`.
- `switch (*p)` where a case uses `*p` again (e.g. `return (*p==0x16) ? total : total;`)
  → `mov al,[eax]; and eax,0xff`: the and-form, byte kept in al.

### The liveness lever (what keeps the byte live)

The fold of `(cond ? CONST : CONST)` with equal constant arms REMOVES the
comparison and kills the byte's liveness → xor-form.  A ternary with
VARIABLE or POINTER arms does NOT fold (MSVC6 evaluates the condition, then
selects) → byte stays live → and-form.  For ahm_GetCommandPayloadSize the
decisive change was the cursor expression:

```c
/* before: folds, byte dead, xor-form preamble (494/752): */
cursor = cmd_payload + (*cmd_payload == 0x16 ? 0x15 : 0x15);
/* after: byte live, and-form preamble (623/760): */
cursor = (*cmd_payload == 0x16) ? (cmd_payload + 0x15) : (cmd_payload + 0x15);
```

This raised ahm_GetCommandPayloadSize from 494 to 623 matches and produced the
target's exact preamble shape (`mov reg_low,[eax]; mov reg2,reg; and
reg2,0xff; add reg2,-3; cmp reg2,0x66; ja; jmp [reg2*4+table]`): the
previous "needs the original's exact CL.EXE build" conclusion in the file
header is OUTDATED; the remaining delta is the register roles (target keeps
the byte in dl and the index in ecx; MSVC6 picks cl/edx) and the case-0x20
negation idiom (below).

### Related: `-(x != c)` negation idiom

The target's case 0x20 (`(-(cmd_payload[0x10] != 0xe) & 0x7c) + 0x11`)
compiles to `sub al,0xe; neg al; sbb eax,eax; and eax,0x7c; add eax,0x11`
(the fused compare-and-negate producing -1/0).  MSVC6's alternative is
`cmp cl,0xe; setne dl; neg edx; and edx,0x7c; add edx,0x11` (setne then
  negate): 7 bytes larger.  The choice follows the same register-role/
context rule; `0 - (x != c)` and `x == c ? 0 : -1` forms were tested and did
not flip it.

### Refines the CODEGEN_PATTERNS.md "NOT controllable" row

`CODEGEN_PATTERNS.md` lists "Byte param zero-extend: `mov dl,[reg+off]` vs
`xor edx,edx; mov dl,[reg+off]`: compiler decides based on register
liveness: NOT controllable from C; accept as NEAR_MATCHING blocker".  The
liveness IS controllable via the fold lever above: a byte value kept live
across the switch (variable/pointer-arm ternary, or any later use of the
value) forces the and-form.  The remaining register-role choice (dl vs cl
for the kept byte) is still not steerable.

## Deep-dive: the rebrew flag-sweep tiers (never fully swept)

The earlier sweeps tried only the /O and /G axes by hand (~6 combos).
`rebrew match flags` exposes the full tiered grid
(`docs/FLAG_SWEEP_TIERS.md`): quick 192, targeted 1,152 (default), normal
5,376, thorough ~86k sampled, full ~100k sampled.  The axes include
`/Ob0..2` (inlining), `/ML /MT /MD /MLd /MTd /MDd` (runtime library),
`/Zp1..16` (alignment), `/GX` (EH), `/Gs` (stack checking), `/GZ` (debug
checks), `/GR` (RTTI), `/TP` (C++ mode).  A targeted-tier run on the
ahm_GetCommandPayloadSize reconstruction produced no improvement (the register
roles are not flag-selectable); the run confirmed the register-role blockers
are structural, not flag-fixable.

### ahm_GetCommandPayloadSize follow-up: 494 → 742 (three more levers found)

Continuing from the and-idiom resolution, three further levers took the
reconstruction from 623 to 742/752 (sizes match):

1. **Case body ORDER is the original source order, not numeric.**  The
   generated case bodies follow the switch's source order.  The Ghidra
   reconstruction had the cases grouped non-numerically (the 0xd-group
   returning 0x18 placed early; the `default` in the middle), producing a
   different body layout.  Reordering the switch to the target's exact
   generated order (read from the jump-table targets:
   `{3,...}→0x1c, {4}→0x11, {8,...}→0x14, {0xa}→0x50, {0xb}→0x2a,
   {0xc}→0x49, {0xf,0x2c}→0x21, {0x11,0x3d}→0x27, {0x12,0x1e}→0x1e,
   {0x14}→0x16, {0x15}→0x39, {0x16,0x17}→loop, {0x18}→computed,
   {0x19,0x53}→0x24, {0x1b,0x64}→0x28, {0x1d}→0x5f, {0x20}→code,
   {0x22}→0x3d, {0xd,...}→0x18, ...`) aligned the bodies (644 → 742).

2. **The `-(x != c)` negation idiom.**  `-(x != 0xe)` compiles to
   `cmp cl,0xe; setne al; neg eax` (setne form); `(x != c ? -1 : 0)` (or
   `(x == c ? 0 : -1)`) compiles to `sub al,0xe; neg al; sbb eax,eax`:
   the target's form.  The setne variant is 7 bytes larger; switching the
   case-0x20 expression to the ternary-? -1 : 0 form removed the size
   excess (760 → 752) and added matches (623 → 644).

3. **Register roles remain** (byte dl vs cl, index ecx vs edx, count cl vs
   dl): the last 10 bytes.  Declaration order of the four locals, an
   explicit `unsigned char sw` switch-value variable (which regressed to
   599), and the flag sweep (targeted tier) did not move them.

### Register-role residue confirmed for ahm_GetCommandPayloadSize (742/752)

The final 10 bytes are exclusively register-role encodings in the switch
preamble and the case-0x16 count setup: the reference uses `dl` for the
kept switch byte (`8a 10`), `ecx` for the masked index (`8b ca; 81 e1 ff 00
00 00; 83 c1 fd; 83 f9 66; ff 24 8d`) and `cl` for the loop count; MSVC6
picks `cl`/`edx`/`dl`.  Levers tried and rejected: four declaration orders,
an explicit `unsigned char sw` switch-value variable (regressed 742→599),
hoisting `count = cmd_payload[0x14]` before the switch (regressed →461),
count types `unsigned char`/`short` (regressed), and the targeted-tier flag
sweep.  The `rebrew diff -r` register-aware path crashes (Capstone
CS_ERR_DETAIL) so the residue cannot be machine-normalized either.

## Finding 12: named local vs anonymous CSE'd load (the eax↔ecx lever)

**Rule:** for a value loaded from memory once and reused across a branchy
fall-through, whether MSVC6 gives it eax or ecx can depend on whether the C
source names it as a local variable or reads the memory location directly.

- **Named local** (`flags = *player; ... *player = flags;`): the value is a
  distinct IR node created at the assignment.  In the lb_SendLobbyConfig
  shape it landed **ecx** (short-lived msg+0x18 value took eax).
- **Direct memory** (`if ((*player & 0x6000) != 0) ...; *player |= 0x800;`):
  the optimizer CSEs the two reads into one anonymous value created at its
  first use: it landed **eax**, byte-matching the original binary.

The final code is *identical* modulo the register roles, so this is purely
an allocator input-ordering effect, not a codegen difference.

### Allocator internals (from reversing c2.dll, p2 backend)

The register allocator is a priority-based graph-coloring pass in c2.dll,
source `P2\color.c` (`E:\8168\vc98\p2\src\P2\color.c` in the string table):

- **Priority computation** (FUN_1071431d @ 0x1071431d): per use,
  `node+0x3c += use_weight × loop_weight`.  `node+0x18` accumulates the
  plain use count, `node+0x24` the def count.  `loop_weight` is `1` by
  default, or `1 << depth` when optimizing for speed (`DAT_107ac0b0`).
- **Use weights** (FUN_10714c76/10714eeb/10714c90): default **6** per use;
  class 3/4/5/6 (ebx/esp/ebp/esi) operands ≈ 3; the special register class
  `0xd` ('\r') gets 2/3/5 depending on the referencing instruction.  So a
  `test`/`or`/`and`/`cmp`/store chain of 3 uses ≈ priority 18 each.
- **Priority list** (FUN_10717220/10717260): nodes sorted **ascending** by
  `node+0x3c` (head = lowest priority); class-0xd nodes are always appended
  at the tail (highest priority slot); equal-priority inserts go **before**
  the equal group (reverse insertion order).  The simplify driver
  (FUN_1071700b) consumes the head (lowest) first; nodes with priority < 1
  go down the cheap-spill path.
- **Node layout** (from the use/def loops): +0x14 prev, +0x18 next,
  +0x1c id, +0x28..+0x30 neighbor lists, +0x3c priority, +0x40 order
  number, +4 register class of the referencing instruction.

**Register choice in c2 12.00.9782 (the SP6 image), traced under a debugger.** The addresses
in the paragraphs above come from build 8168 and do not apply to this image. Method: run
`CL.EXE` under `winedbg --gdb` in the toolchain container (host networking) and attach host
`gdb`; `catch load c2`, then break on the addresses below.

- Interference nodes live in a 1024-bucket hash at `0x1079d88c` (`fcn.1071e7ae` looks one up:
  id at `+0x1c`, chain at `+0x2c`). `+0x0` is the symbol, `+0xc` the priority, `+0x10` the
  assigned register as a pointer into the descriptor table `0x107ac730 + reg * 0x54`, with
  `reg` = x86 encoding + 1 (1 `eax`, 2 `ecx`, 3 `edx`, 4 `ebx`, 6 `ebp`, 7 `esi`, 8 `edi`),
  `+0x24` the use count, `+0x34` the preference list, `+0x3c` a weight.
- Nodes are coloured in descending priority order (observed on `gm_AllocSpieler`: 232, 205,
  162, 150, ...). The priority accumulates along the program (around `0x1071e238`): each
  reference adds `weight * count`, each position where the node is live subtracts the
  weight, so a longer live range lowers the priority.
- Select is `fcn.1071f7b3` (writes `+0x10` at `0x1071f94e`). It zeroes a cost per register,
  subtracts each preference's weight at the register of the node it points to, adds
  `100 * weight` for a register that a neighbouring node can only take, then walks the
  class's register list and keeps the first allowed register with a strictly lower cost.
  The list for class 0 (`0x107a04dc`) is `eax, ecx, edx, esi, edi, ebx, ebp`, so with equal
  costs a value live across a call takes `esi`, then `edi`, then `ebx`.

Consequence: a register permutation between two builds of the same function (for
`gm_AllocSpieler`'s 14-trait loop, `esi/edi/ebx` = pointer/offset/counter in the reference
and counter/pointer/offset in ours) is a difference in colouring order, i.e. priority, in
preferences, or in the single-register penalty below; it is not a different default order.

The single-register penalty decides whole regions. In our `gm_AllocSpieler` build the first
sympathy loop's `j*0x300` induction (node 154, priority 145) is coloured while `esi` is still
free, yet it takes `edi`: its cost for `esi` is 8800, from three not-yet-coloured neighbours
whose allowed set has shrunk to `esi` alone (weights 58, 26 and 4; the 26 is `idx`, live over
the whole function). Those neighbours have priority below 1 and end up in stack slots
anyway, but while uncoloured they push every higher-priority neighbour off `esi`. Every
sympathy and trait loop in the parent path shows the same `esi` -> `edi` -> `ebx` rotation
against the reference, so the reference reached those loops without such a penalty on `esi`.

How select reads a neighbour (`0x1071f87a..0x1071f8de`): it looks the neighbour up by id
(`fcn.1071e7ae`, bucket `id & 0x3ff` of the table at `0x1079d88c`), skips it when its weight
`+0x3c` is 0 or less, counts its allowed registers (`+0x20` points to a sparse bitset: first
chunk `{base, ?, bits}`, bit `n` = register `n`, so `0x80` is `esi` and `0x190` is
`ebx`/`esi`/`edi`), and adds `100 * weight` to that register's cost only when exactly one
bit is left. A second loop adds the weight of each neighbour preference that names an
allowed register. Allowed sets start without the registers clobbered inside the node's
range (a live-across `rep stos` removes `edi`) and lose each register a coloured neighbour
takes. A node left with no register is split: node ids are reused, and a piece of the old
range comes back with a fresh allowed set. In the current `gm_AllocSpieler` build `idx`
starts with `ebx`/`ebp`/`esi`, loses `ebp` to `slot` and `ebx` to `ent`, is split when the
no-parent loop's pointer takes `esi`, and the parent-path piece (weight 20) comes back
allowed only `esi`. That piece is what sends the 14-trait loop's pointer to `edi`. To watch a
node, break at `0x1071f895` (neighbour in `ebp`, bitset pointer at `[ebp+0x20]`) or read
`*(0x1079d88c + id*4)` at each entry to select.

**Scratch picker, traced (round 1145, c2 12.00.9782 loaded at 0x10700000).** Temporaries outside
the colourer get their register from `fcn.10721c0f`, called by the local assignment pass
`fcn.10720798`, which walks the function's items in order (`10720c1f` release, `10720cba` assign).
The cursor is the global `0x1079d710` into the list `0x107adff4` (eax, ecx, edx, esi, edi, ebx, ebp),
reset once per FUNCTION at `0x10720802`, not per block. With `[0x107ac0b4]` set it scans only eax,
ecx, edx from the cursor, wrapping; it skips a register whose contents slot (`0x1079d6ec + reg*4`)
is non-zero or that `fcn.107032e3` reports as conflicting; on a hit it advances the cursor past the
chosen register and assigns through `fcn.10721f07`. A preferred register (tuple +0x2c, set when the
value is copied into a register) and the fallbacks (`0x10721daa`, `fcn.10757806`, `fcn.10757a63`,
`fcn.10757e50`) bypass the scan and leave the cursor. Coloured candidates never go through it: a
named local becomes a rotation temporary only when c2 folds it away. A second picker, `fcn.10721995`
(from `fcn.10720890`, cursor `0x107ac2dc` reset per block at `0x1072090e`, never re-picks its last
register), has no established role yet. Tracers: `.scratch/c2trace-scratchpick/` (gitignored).

**Scratch temporaries rotate.** Short-lived temporaries outside the colourer take `eax`,
`ecx`, `edx` in turn rather than the first free one: `ga = gb; gc = gd; ge = gf; gg = gh;`
compiles to loads into `eax`, `ecx`, `edx`, `eax`. One extra or missing temporary therefore
shifts every later scratch choice by one register until something resynchronises it. In
`gm_AllocSpieler` the ref and our build agree up to the no-parent draw block; there our
`slot[0x18] = slot[0x1c]` copy loads while the draw still holds `eax`, takes `ecx`, and every
scratch register from the aging block to the final `sprintf` is rotated (`edx/eax/ecx` for
the reference's `ecx/edx/eax`). Writing the copy after the `+0x10` blend frees `eax` first
and puts the whole tail back in step. When a diff shows the same register substitution
over a long stretch, look for the first temporary allocated in a different order, not at
the stretch itself.

**Priority multiplies uses by block pressure.** At each block the priority walk adds, for
every candidate referenced there, its pending weighted uses times the number of candidates
referenced in that block (times `1 << loop depth`); live-through positions subtract
(`0x1071da32..0x1071e25e`). A variable's rank therefore depends on what else is named in
the blocks where it is used: in `gm_AllocSpieler` the citizen block referenced 12
candidates, giving `ent` 16 + 12 * 18 = 232 and colouring it before the parent loops;
folding the `n` and `draw` locals into their expressions brought it to 10 and the parent
loops to the reference's registers.

**Node ids are recycled.** (Round 1145: the reload order below was flipped from source by giving the dead parameter `location` three more webs; see codegen-walls section 49.) New nodes (`fcn.107119e1`) pop a LIFO free list at `0x107ae038`
and keep the popped node's old id; only an empty list takes the counter at `0x1079d74c`.
Split pieces therefore get ids from whatever was freed last. The reload order in
`gm_AllocSpieler`'s two edge blocks (0x10018c28/0x10018c38) fits ascending piece id,
appended on one edge and prepended on the other; the insertion code itself has not been
traced. Swapping the two parameter nodes' ids at creation (under the debugger) reverses
that reload order and nothing else, so the id order does decide it. The parameters take
their ids from the free list right after the constant candidates are released: the release
walks a 64-bucket hash (`0x1079d750`, bucket = `value & 63`, ascending, newest first within
a bucket; `0x1071b8c0..0x1071b94b`) and frees every constant whose use count (`+0x14` of the
record at symbol `+0x30`) is 0. The count rises at `0x107169f2` only for a tuple whose
descriptor (`+0x18`) is `0x107ae040`: each `mov cl,0x7f` of the mutual-sympathy stores
counts, a direct `mov byte [ebp+0x217],0x3e` does not. The parameters are then created in
reverse declaration order (`arg8` first) and pop those ids.

Constant candidates are numbered in final code-layout order, not source order (`0x7fff`,
stored at +0xc5c, gets 56; `0x27f0`, pushed at +0xc86, gets 58), so a constant the
reference emits has a fixed id. A `c ? A : B` that c2 turns into setcc arithmetic also
creates candidates for both arms and for `A - B` (`-8` from `rnd < 4 ? 0x4e : 0x56`).

The parameter ids are only the input. A later pass recreates the candidates still live, in
ascending first-pass id, and pops a new id for each; the split pieces then pop theirs in
the order of those second ids, so the parameter recreated at the lower second id is split
first and gets the higher piece ids. Traced in `gm_AllocSpieler`:

| Source | First pass `arg6`/`type` | Second pass | Pieces (`arg6` / `type`) | Reload order |
|--------|--------------------------|-------------|--------------------------|--------------|
| current | 49 / 61 | 109 / 107 | 5 / 27, 14 | ours |
| `-8` candidate removed | 49 / 26 | 108 / 116 | 28 / 9, 5 | reference's |
| `-4` and `-0x86` candidates added | 34 / 18 | 116 / 62 | 5 / 45, 19 | ours |

The second pass pops a free list that is not monotonic, so a lower first-pass id for
`type` does not guarantee the flip.

**Block layout, traced (round 1145).** Three passes decide block order and jump shape:
- **Layout** is the reverse postorder of a depth-first walk that visits a conditional block's TAKEN
  target before its fallthrough: `0x10703558` builds the postorder (chained through block
  +0x10/+0x14), `0x107351b7` relinks the blocks in reverse; the pass runs from `0x10705166`, called
  by the driver at `0x107603b2`.
- **Jump inversion** (`0x10705507`, from `0x107053c9` in the jump optimiser `0x10705193`) turns
  `jcc L1; jmp L2; L1:` into `jncc L2` only when the jmp block holds nothing but the jmp
  (`0x10703ed5`). A dead store in that block (cm_ProcessCommandQueue's `ok = 0`) keeps it non-empty
  and so keeps the reference's `jcc; jmp` pair.
- **Late block move** is loop 1 of `0x10724a49`: a block nothing falls into, up to its first
  unconditional jmp or ret, moves behind the forward jmp that targets it. Loop 2 of the same
  function duplicates jump targets of 20 bytes or less.
Scheduler candidate/issue points: `0x107279c2` and `0x10727a51` (node +0x1c tuple, +0x2c priority,
+0x36 sequence, +0x30 earliest cycle). Tracers: `.scratch/c2trace-layout/` (gitignored).

**Scheduler hold and priority, traced (round 1145).** The hold at `0x10727d01` fires when the previous
issue is opcode 95 (the x87 fetch that becomes `fxch`), or opcode 354 (a copy) whose source is a 95,
AND the pipe mode is P5 (`[0x10799218]==2`), AND the candidate is an integer instruction, AND an x87
node in the ready list has earliest cycle <= current+1. Priority (+0x2c) is set in `0x10726e85` as
the node height (+0x34) plus weighted terms from the table at `[0x10799204]`; at the issue point
`0x10727a51`, +0x34 packs the sequence number (high word) and priority (low word). Source lever: a
float-rounded temporary (`quot_f = (float) quot; quot_f = (float) (quot_f * ...)`) removes the copy
node after the fetch, so integer work issues between `fxch` and `fmulp` (gm_CalculateProductionValue,
byte-exact).

**Scheduler priority and edges, traced (round 1145, CrashDump).** The weight table at
`[0x10799204]` is `-1 13 -5 -1 -2 16 16` and `0x10727781` computes `x << w`, so priority is in
effect height x 8192, plus 65536 when the node reads memory (+0x3a bit 0); the other terms shift to
zero. Height is 1 + the maximum over successors of (successor height + edge latency); ties go to the
lower sequence number, i.e. IL order. Registers are chosen before scheduling, so register reuse
(an eax freed by one store and loaded by the next instruction) is a scheduling edge. Calls do not
split scheduling blocks; `rep movs` has a 13-cycle latency with nothing issued under it. A load
through a pointer gets memory edges to stores into address-taken locals of an enclosing scope (a
`memcpy` or an assignment) but none to initialiser stores of block-local arrays: declaring
`szLine`/`szSep` as initialised locals of an inner block removed those edges and closed a 45-byte
block. Each label left after tail merging leaves an op-444 node (priority 2) that takes a cycle.

**The instruction scheduler** is the cycle loop at `0x10727977`: per cycle and pipe it walks
a ready list ordered by priority (`+0x2c`, descending, ties by sequence `+0x36`), checks
pairing (`[0x10799214]`), two hazard routines (`0x10727ca9`, `0x10727d01`) and the earliest
cycle `+0x30`. `0x10727d01` holds back an integer instruction when the previously issued
tuple is opcode 95 (0x5f, the x87 value feeding the second multiply of a blend) and an FP
instruction becomes ready in the next cycle, so the FPU can keep pairing. That rule places
`push 0xa` after the second `fmul` in `gm_AllocSpieler`'s parent blend, where the reference
has it after `fsubr`.

**Frame slots** (read from c2.dll 12.00.9782 in rizin; addresses are in that image):

- `fcn.10722246` walks every block, instruction and operand; each operand that names a
  stack symbol (kind 3, 4 or 5 at `sym+4`) calls `fcn.1073a9c4(sym, 1)`. The weight is 1
  per referencing operand, not scaled by loop depth.
- `fcn.1073a9c4` keeps the list at `0x1079f220` sorted by symbol size (`sym+0x20`)
  ascending, then by accumulated weight (`sym+0x34`) descending. A symbol's first
  reference appends it to the end of its size group; later references move it ahead of
  strictly lighter entries, so equal weights stay in first-reference order.
- `fcn.107400e7` packs the list: each kind-5 symbol opens a group, every other symbol
  joins the first group that is at least its size and that it does not interfere with,
  or opens a new one.
- When the packed frame exceeds 0x80 bytes, `fcn.10757404` quicksorts the groups after
  the kind-5 ones by `weight * 1000 / size`, descending. Quicksort is not stable, so equal
  densities can come out in either order.
- Offsets are then handed out group by group by the bump allocator `fcn.1070f914`, which
  lowers the frame offset by the aligned size.

Not verified: that the densest group lands nearest `esp`. It fits `gm_AllocSpieler`
(`0x10018850`, frame 0x41c), where `[esp+0x10]` holds the most referenced slot and the
0x400-byte buffer is at the top. The consequence for matching: a local's slot follows how
many instructions reference it relative to the others, so a slot permutation is usually
a symptom of code that still differs, not a lever of its own.

**Processor Pack c2 and `__asm` (GOLDTL 0x4af800).** The client c2.dll has the same insert at
`0x10713312` (list head `0x107b15fc`, size `+0x20`, weight `+0x34`), called from the operand walk at
`0x1070de4c`; to trace, break there and print `$ecx` (the symbol), `*(int*)($ecx+0x20)` and the
return address. The `__asm` tuple adds operand lists that name the locals it references and every
address-taken local: for the prelude `mov edi, p; mov ebx, n` the fill pointer `p` (also passed as
`&p`) counts three times, `buf` twice and `n` once, so `p` reaches 6 references against 4 in the
code and outweighs the 10-byte `ids` array with 11. In the 0x22c frame the groups sort by density
and the densest takes the top slot (`[ebp-0xc]`, `ids` in the reference).
The source fix is in `msvc6-c-shapes.md` section 202.

**Practical consequence:** when two memory-derived values have equal
weighted priority (the common 3-use case), the register they receive is
decided by their relative creation order in the value table: which the C
source can steer by choosing *which* memory reads are named locals and
which are left as implicit CSE'd loads.  If a register role won't budge,
try deleting the local and writing the memory operand directly (or vice
versa), then re-test.

**The lever scales to a whole callee-saved web, not just eax/ecx.**
gm_NextEntityQueryMatch (0x10016290) sat at 439/464 with the size and block
layout already exact: two webs compete for esi/edi, one long (the query depth,
live across the entire loop) and one a coalesced set of short ranges
(g_query_limit at the loop top, g_query_count at the bottom, g_item_def_table
in the state block, `[current+0x14]` in the tail).  The reference gives edi to
the long web; every shape with a named `int stack_depth` local got esi, across
loop forms, declaration-order rotations, `register`, width changes,
live-range splits and the whole CFLAGS grid.  Deleting the local and reading
`g_query_match_count` directly at all seven sites converted it to RELOC
464/464 in one edit.  Partial conversion does not pay (tail-store-only and
pop-arm-only both stay at 439, entry-arm-only falls to 191/466): the local has
to disappear completely, so the value is an anonymous load born at its first
use.  Try this whenever the residual is a pure register transposition against
a value that shadows a global.

## Finding 13: lb_ExPlayerlist (0x100145e0): struct-fields beat array-index counters

Converted 209/209 RELOC with two extra rules on top of Finding 12:

1. **Statement order drives load placement.**  The target loads `*player`
   into eax *immediately* after the prologue (before zeroing the local
   array).  The C must therefore put the `if ((*player & 0x6000) != 0)`
   check **before** the `memset`/count-init statements: putting the
   zeroing first moved the flags load after the `rep stosd` and shifted
   every byte.  (This is the same "value created at first use" effect as
   Finding 12: the memory-load value is born at the check, which is where
   the reference wants it.)

2. **A plain `int list[9]` with `list[++list[0]]` gets scalarized.**  The
   optimizer recognizes `list[0]` is only ever used as a counter, extracts
   it into its own frame slot, and shrinks the zeroed array to 8 dwords,
   so the `rep stosd` count, the index arithmetic and the final `rep movsd`
   source all shift.  Wrapping the array in a struct
   (`typedef struct { int count; int ids[8]; } PlayerList9;`) makes the
   counter a *field*: struct fields are never scalarized, `memset(&list,
   0, 36)` stays `mov ecx,9; rep stosd`, and the trailing
   `memcpy(msg+0x14, &list, 36)` copies count+ids as the reference does.

Both rules are the same underlying lever as Finding 12: **what the
optimizer/allocator sees is not the C statements but the value graph, and
anonymous loads, statement order, and struct-field access all change that
graph's shape.**

## Finding 14: AH-relative masks (read the byte before the mask)

`lb_BroadcastStateChange (0x10014a50): 157/157 RELOC` and its lobby
siblings use `test ah,0x60` / `or ah,0x30` / `test ah,0x4` on the
`*player` flags.  The `ah` prefix means the mask must be read **8 bits
high**: `test ah,0x60` = `*player & 0x6000`, `or ah,0x30` = `|= 0x3000`,
`test ah,0x4` = `& 0x400`.  Writing the literal low-byte masks (`0x30`,
`4`) made the compiler emit the AL forms (`or al,0x30`, `mov al,[esi];
test al,4`): a 2-byte size regression and shifted bytes.  Once the masks
were shifted to the AH-relative values the function matched 157/157 on
the first try with the Finding-12 direct-memory style (`*player` reads,
no `flags` local).

General rule: **when a flag value's tests appear as `test ah/…` in the
reference, every constant in the byte-ops must be `(value << 8)`**: the
compiler commits the value to the AH byte-slot and will not mix AL and AH
ops on the same value.

## Finding 15: COMDAT placement: functions in a file must be VA-contiguous

Historical split-link placement. Each ``.c`` file compiled to one object whose
functions the linker placed as a contiguous run (each function padded to 0x10
alignment) starting at the file's first ``// FUNCTION:`` VA. Current identity
is managed metadata plus optional ``/* ADDRESS: MODULE 0xVA */`` comments.
Consequences measured in that layout:

- **A contiguous VA run could not be split across files in that layout.**
  Moving one function (e.g. lb_HandleEntitySync 0x10014bf0) into its own
  ``.c`` reordered the object: the remaining functions shifted onto the
  vacated VAs and the whole ``.text`` after that point drifted. VA-adjacent
  functions (gap equal to the predecessor's padded size) stayed in one file.
- **Uncovered holes were filled in that layout.**  The original may have had
  functions the project had not reversed (e.g. 0x10014ee0 between
  lb_ExLobbyServerCommand and plant.c's find_zone_record).  A naked ``_emit``
  placeholder was how that link held the hole. It is not a current remedy and
  not an assembly exception.
- Duplicate VA coverage across files (e.g. defining 0x10014f80 in two files)
  breaks the layout silently: check dedicated metadata bindings before adding.

**Amended (2026 campaign): the 16-byte pad hides the real body length.**  A
COMDAT is padded to a 16-byte multiple, so several different real body lengths
report the *same* object size: every real length from 3681 to 3696 in
`gm_AllocSpieler` (0x10018850) reports "object size 3696".  A candidate can
therefore change the linked section size, and move every symbol after it,
while every tool reports the size as unchanged.  Always compare the *real* body
length (COMDAT minus its trailing pad) as well as the reported object size.
Caveat: not every function pads with `0x90`; `CrashDumpUnhandledExceptionFilter`
(0x10002770) pads with `0x09`, so a naive strip gives a wrong real length there.

> **The conclusion above is inverted: see Finding 58, and read it before acting
> on this paragraph.**  The premise holds (the aligned object size does not reveal
> the real body length) but the inference does not: `have` is
> `16*ceil(real_code/16)`, so an *unchanged* reported size means an unchanged span
> and **no** symbol movement.  Every real length from 3681 to 3696 in
> `gm_AllocSpieler` is layout-identical against `want` 3689.  The real length does
> still matter: for *intra-object* table placement (Finding 56) and for the
> upward bucket test, but it is not evidence that a layout moved when the number
> did not.

### 0x10014ee0: word-table search (naked placeholder kept)

The 80-byte helper searches a word table at 0x1002d878 (0x46-byte records,
word id at offset 0) and returns ``table + i*0x46``.  The C conversion is
blocked on two codegen patterns the optimizer will not reproduce:

1. **Dword-first / word-rest loads.**  The reference loads the first record
   id with ``mov eax,[0x1002d878]`` (a1: DWORD) and the loop ids with
   ``mov ax,[ecx+0x46]`` (WORD), masking with ``and eax,0xffff`` at the loop
   top.  Every C formulation (word-typed v, dword-typed v, explicit casts,
   do-while/for shapes) yields either a word first-load (``66 a1``) or a
   ``xor eax,eax`` zero-extend instead of the mask-at-loop-top form.
2. **Induction-variable setup.**  The reference keeps the scan pointer at
   0x1002d878 and loads ``[ecx+0x46]``; the compiler instead folds the first
   stride into the pointer (``mov ecx,0x1002d8be``) and loads ``[ecx]``.

Historical fence, EXACT 69/69 at that checkpoint; not current assembly permission
([assembly audit](assembly-audit.md#what-qualifies)). The two load patterns above
are the observation to retest.

## Finding 16: three new blocker patterns (cm_* family)

- **cm_ExChangeFloat (0x1000eb70) / cm_ChkMoveCredits (0x1000cb20): prologue
  scheduling.**  The reference's prologue is `sub esp,8; push esi; mov
  esi,[esp+0x10]`: the frame is set up and the param loaded *into esi*
  (callee-saved) only after the `push esi`.  Every C formulation (with/without
  an iVar1 alias, pointer-typed, indexed stores, `&param` in the
  gm_ResolveEntityById call) makes MSVC6 hoist a *volatile* load
  (`mov eax,[esp+4]`) before the frame setup and materialize `cmd+0x10` into a
  second callee-saved register.  The flag sweep cannot help: `rebrew match run
  --flag-sweep-only` crashes on the Capstone CS_ERR_DETAIL bug (same as
  `rebrew diff -r`).  Historical fence only; not current permission.

- **cm_ExModifyStat (0x100100a0): FPU re-compare.**  The reference clamps a
  float with a convoluted FPU sequence that *re-compares* `_g_stat_max` at the
  join (`fcom max; test ah,1; je L_chk_max; fcom min; test ah,0x41; jne
  USE_MIN; L_chk_max: fcom max; test ah,1; jne USE_X; …`).  All five C shapes
  (simple clamps, nested ifs, empty else, `else if (x >= max)`) make MSVC6
  reuse the first compare's flags instead of re-comparing.  The FPU flag
  decode (`test ah,1` = C0 = ST0<op; `test ah,0x41` = C0|C3 = ST0<=op) is
  standard, but those five shapes did not reproduce the re-compare.  Historical fence only; not current permission.

- **cm_GetBuildingStatCount (0x100104a0): arg-register + zero-extend order.**
  The reference's prologue is `mov edx,[esp+4]; xor ecx,ecx; push ebx; push
  esi; mov cl,[edx]`: the arg lands in edx and the byte index is
  zero-extended by clearing ecx *before* the `mov cl` load, all before the
  callee-saved pushes.  Every C shape puts the arg in eax and emits the
  byte load without the pre-clear (later movzx/mask), and the if/else
  result chains compile to branchless `dec/neg/sbb/and/add` selects instead
  of the reference's explicit `mov eax,imm; cmp; jne` branches.  The
  zero-extend-timing and select-vs-branch choices are both allocator
  liveness decisions (see Finding 12's mechanism).  Historical fence only; not current permission.

- **gm_FindEntityByOwner (0x10019c60): callee-saved pair order.**  The
  reference keeps `owner` in edi and the loop counter in esi (`push edi;
  mov edi,[esp+8]; xor eax,eax; test edi,edi; jne L_search; [inline return
  0]; L_search: push esi; xor esi,esi`).  Every C shape (for/do-while,
  result-variable init, signed/unsigned casts) puts `owner` in esi and the
  counter in a volatile register, one callee-saved fewer, and the
  `owner==0` return becomes a jump-to-tail instead of the reference's inline
  fall-through.  Historical fence only; not current permission.

- **cm_ExClearLagerslot (0x1000e690): address-taken param value-copy.**
  The reference passes `&cmd` (the param slot) to gm_ResolveEntityById yet
  keeps a callee-saved *value* copy (esi) for the pre-resolve uses: simple
  `push esi; mov esi,[esp+8]` prologue.  Any C with `&cmd` makes MSVC6 treat
  the param as memory-only: it hoists a volatile load to offset 0, drops the
  esi copy, and reloads the slot after the resolve.  Passing a *different*
  param's address (&result) keeps the simple prologue but the arg order then
  mismatches the reference (the resolve genuinely targets the cmd slot).
  Historical fence only; not current permission.

## Finding 17: signed `-1` byte compares materialize 0xff via `or reg,0xff`

`AnalyzeInstruction (0x10003260): EXACT 183/183`.  The reference compares
bytes against 0xff by keeping the constant in `bl` and materializing it as
`or bl,0xff` (80 cb ff) *before* the length check of the block that first
uses it.  Writing the compares as `== -1` against `*(char*)` (signed) makes
MSVC6 emit exactly this `or bl,0xff` + hoisted placement; writing `== 0xff`
against `*(unsigned char*)` emits `mov bl,0xff` (2B) *after* the length
check instead.  The split `if (len>=2 && p[-2]==-1 && p[-1]<0x40) return 2;
if (len>=2 && p[-2]==-1 && (p[-1]&0xf8)==0xd0) return 2;` (two separate
ifs) also reproduces the reference's `cl` load + redundant re-compare at
  the second block: a single `||` condition merges the return-2 paths and
loses the re-check.

## Finding 18: memory-operand byte params: local vs global load form

`ShutdownLogAndErrorHandler (0x100034c0): RELOC 83/83`.  Passing a
*global* (`g_log_mode_flags`) to a callee whose param is declared
`unsigned char` makes MSVC6 load only the byte (`mov cl,[mem]`, 3B);
passing a *local* makes it push the full register (no truncation).  The
reference loads the full dword (`mov ecx,[mem]`) from the global in *both*
callers, so the original declaration was `int`.  The rebrew declaration
was `unsigned char`, which the other caller (ReportFatalError) matched
only because its explicit `(unsigned char)` cast then became a no-op.
**Fixing both**: declare the callee param `int` AND drop the caller's
byte cast (the reference passes the untruncated value), both call sites
then byte-match.  (Also: `__declspec(dllimport)` on FreeConsole is needed
to get the reference's `call dword ptr [__imp__FreeConsole]` IAT form
instead of a direct `call`.)

## Finding 19: m_init (0x100068e0): memset alignment-pass + param-slot spill

The reference memsets the pool with the *alignment-aware* inline form
(`lea ecx,[edi+edi*2]; and ecx,3; sub ebx,ecx; jle; rep stosb; rep stosd;
add ecx,ebx; rep stosb`): an ebp frame appears because the size*16 value is
spilled to the param slot (`mov [ebp+8],edi`) so edi can be reused for the
pool, then reloaded (`mov ebx,[ebp+8]`).  Every C shape (memset of the fresh
`_callnewh` result, of the stored global, with a global-read size) makes
MSVC6 emit the simpler `rep stosd; rep stosb` form without the alignment
pass, keep the size in a register, and skip the frame.  The alignment pass
is the compiler's response to an *opaque* destination+size pair with a
potentially large size; the register-reuse that forces the spill is an
allocator scheduling choice.  Historical fence only; not current permission.

Correction (2026-09-09): "every C shape ... keeps the size in a register" is
too strong for the destination half.  Reading the stored global back through a
volatile alias into a local (`d = *(char* volatile*) &g_array_ptr;`) while the
count is read **plain** does emit the target's `mov edi,[g_array_ptr]` reload,
and with it the whole call region matches: `add esp,4` and the `a3`
g_array_ptr store land byte-identical (105 → 110 matched, object 147 → 146).
The pairing is exclusive: a volatile count read alongside the aliased dest
scores 90, and re-homing the length into `[ebp+8]` on top of the reload scores
90-92, so the two spill levers cannot be combined.  What remains of the size
delta is 12 bytes of prelude plus 4 bytes for the length's register (target
`push edi; mov edi,eax`, msvc6 `mov ebx,eax; push edi`), which follows from the
prelude claiming ebx as scratch.  Everything after the fill is
instruction-for-instruction identical, displaced by 16 bytes.

The same prelude also blocks the *memcpy* variant in `ReadVfsData`
(0x10008e40, vfs TU): the target expands `memcpy(buf, *zstrm, total)` with
the dest-aligned prelude (flags&0x20 hoisted to dl, zstrm ptr spilled to
[ebp-0xc], frame 0x10c), while msvc6 SP6 emits only the plain
`shr ecx,2; rep movsd; and ecx,3; rep movsb` from any C shape (~60 whole-
function variants; template absent from the SP6 C1/C1XX/C2 binaries).
Resolved via `rebrew prove` (2026-08-27): SIZE_MISMATCH → PROVEN (EAX
equivalence, 2+2 states).  The earlier exact-bytes `_emit` fence that
reached EXACT 472/472 was reverted (goal constraint: inline asm only for
1-5 byte padding), so the symbolic-proof path stands.

## Client tracked-free CRT binding (2026-10-11)

The shared client tracked-free helper at TL `0x0041ddd0` / Gold `0x00422620`
calls stock CRT `free`, not a game helper. Complete stock archive bodies identify
TL `0x0064dfda` as the 233-byte multithreaded `LIBCMT.LIB:free.obj` body and
Gold `0x005dec24` as the 105-byte single-threaded `LIBC.LIB:free.obj` body. Both
matches are unique over the complete archive body, with rejecting fixed-byte
controls. TL's old `___RTCastToVoid` annotation came from an ambiguous short
comparison and is corrected. Gold's corresponding library identity is added.
These are library-origin findings; the actual archive provider still requires
each client's future raw link map. Gold's provisional `LIBCMT` link list needs
review against the other CRT members before selecting its complete runtime.

The three shared client sources for tracked-free, octree cleanup and list-node
removal now call `free` directly. Six complete native caller comparisons cover
734 bytes and 62 typed relocation operands, including 26 CRT calls. Binding
`free` four bytes away rejects every caller. Before/after complete COFF contexts
preserve function bytes, relocation identities and literal contents. All six
identities freshly verify without changing their byte-match status. No CRT C
implementation, storage allocation or archive patch is introduced.

The server's 188-byte tracked-free helper includes invalid-pointer logging and
underflow reporting; the clients' 117-byte helper does not. Evidence for this
stock-library binding prerequisite:
`.scratch/goal21/stock-free-binding/{stock-free-proof.json,caller-before.json,caller-after.json,client-verification.json}`.

## Shared tracked-free implementation (2026-10-11)

One `m_FreeTracked` definition in `Develop/Units/m_alloc/m_alloc.c` now serves
SERVER `0x10006820`, TL `0x0041ddd0` and Gold `0x00422620`. `REBREW_SERVER`
selects the existing server body; the client branch retains the typed tracking
loop and silently returns when the pointer is absent. Both branches call stock
CRT `free`. The server-only invalid-pointer log and fatal underflow report are
preserved, including when the temporary historical-layout define is disabled.
The shared implementation name is inferred, not an attested original spelling.

Both client bodies equal all 117 native bytes with actual bindings, including
18 typed operands. Moving each of their six distinct bindings by four bytes
rejects the comparison (12 negative controls). All 14 allocator functions are
checked under four distinct compiler/define contexts: server with the temporary
layout flag, server without it, TL and Gold. There is only one original server
binary. Both server compilation results and the other 13 allocator
functions retain their complete bytes, typed operands and literal contents.

The public rehome writer binds the two client identities to this definition.
Reference binding changes only the identifier in 85 caller files, preserving
their compiler-sensitive prototypes. All 115 native caller contexts preserve
26,641 bytes and 1,535 typed operands. All 115 affected client identities
freshly verify (88 TL, 27 Gold), retaining every existing byte-match status.
The old standalone tracked-free source
is retired. No global storage, CRT source, archive, compiler flag, layout or
link rule is changed; the existing numeric client declarations remain views
whose storage ownership and original spellings need separate recovery.

The full server gate passes 316/316 functions and 652/652 data comparisons.
Its 286,720 raw bytes remain reference-identical, SHA-256
`3cc2ce9049e41ab6d0eea042df4966fbf57e5e27c67fb923e81709d2683609d1`.
Full client image identity and faithful discarded server inputs remain open.
Evidence: `.scratch/goal21/shared-tracked-free/` (whole-object comparisons,
native operand controls, public binding previews and final gate).

## Finding 20: m_FreeTracked (0x10006820): transient-register alternation (185/188)

The reference's post-`free` block alternates edx/ecx for the four global
decrements (`g_count3`→edx, `data[0x14]`→ecx, `g_count2`→edx,
  `data[0x10]`→ecx): the first transient *reuses the just-freed block
register* (edx).  Every C shape (with/without a `g3` temp, `b` block copy,
`int`-returning `free`, statement reordering, /G5/G6) makes MSVC6 keep the
  first transient in ecx (two consecutive ecx transients): a 3-byte
register-role residue (`8b 0d` vs `8b 15`, `49` vs `4a`).  All other 185
bytes match, including the `while`-loop form (a `do/break` loop was
rotated with a duplicated compare; the combined `while (i < count &&
p[i].block != b)` condition reproduces the reference's straight
`cmp/jl` back-edge) and the global-load hoisting (reading g_count1 into a
temp before the count/pool loads, then storing g_count1-1 last, matches
the reference's three-hoisted-loads order).  Historical fence only; not current permission.

## Finding 21: the `?:` flag chain splits only in sibling-specific register contexts

`amt_UpdateEntityLinks (0x1000ba30): best C 170/179, historical fence only; not current permission`.  The
match branch stores `b[0] = -1; b[4] = -1; b[3]byte = (gword > 0xb) ? 4 : 3;
b[2] = 0; result |= 1`.  The reference emits the flag chain *split* around the
first store: `seta cl; mov [eax-0x10],-1; add ecx,3; mov [eax],-1;
mov [eax-4],cl; mov [eax-8],ebx; or esi,1`.  With the identical C statement
order, `amt_ClearEntityLinks (0x1000b990)`, which is EXACT 157/157, emits
the chain *before* the first store (`mov [ecx-0x10],-1; seta dl; add edx,3;
...`), and UpdateEntityLinks under the same flags emits it fully fused
(`seta cl; add ecx,3; mov [eax-0x10],-1; ...`).

Exhausted: 5 statement orders (b0/b4/byte/b2 permutations) × {/O2, /O2 /G6};
byte/bool/int temps; `if/else`; `3+(gword>0xb)` (narrows to `add cl,3`, 80 c1
03, vs the reference's `add ecx,3` 83 c1 03); flags /G3 /G4 /G5 /G6 /GB /O1
/Og; `#pragma optimize("s"/"t")`; GA.  /G6 sinks the whole chain below all
four stores AND switches the second loop's byte compare to the memory-operand
form (`cmp dl,[ebp+0x168]`), but the reference loads it into cl
(`mov cl,[ebp+0x168]; cmp dl,cl`), i.e. the reference's second loop is
/G5-style.  No single flag or C shape reproduces both loops; the split chain
needs a scheduler behavior 8168 exhibits in neither mode.  All other 170
bytes match (arg1-based semantics: `mov ebp,[esp+0x10]` after `push esi` is
*a reload of arg1*, not arg2; the `b+4 < bound` / `b+1 < bound` loop-bound
idiom from Finding 20 applies).  Historical fence only; not current permission.

## Finding 22: amt_SwapOfficeHolders (0x1000b880): register-name residue (264/263)

The best C is 264 bytes vs 263 target: every instruction shape, order, and
slot matches; only *register names* differ.  The allocator assigns
arg1→ebp/ent2→ebx where the reference has arg1→ebx/ent2→ebp (the two
persistent callee-saved values swap ebx/ebp), names the two swap temps
eax/ecx the other way round, and schedules the ent1 reload
(`mov eax,[esp+0x14]`) between the two swap stores instead of after them.
The logic, prologue shape, search loops, and the arg1-slot spill are all
byte-identical.

Key discoveries along the way (all required for 264):
- The swap temps MUST be volatile reads.  A plain `t = *(int*)(rec2+4)` is
  value-numbered with the 3rd call's argument (same address) and kept alive
  across the call in a callee-saved register; `u = *(int*)(rec1+4)` does the
  same with the 2nd call's argument.  Either unification cascades into a
  frame (`sub esp,8`/`push ecx`) and an ent2 stack spill.  Two volatile
  temps force both loads at the swap site and collapse the function to
  264 bytes.
- The loop-bound compare must be SIGNED: pointer compares emit `jb` (72),
  the reference uses `jl` (7c): cast the pointer to `(int)`.
- The rec2-first load order (`t=rec2; rec1=t; rec2=rec1-old`) reproduces the
  reference's load order; the rec1-first form emits the loads the other way.
- Struct-typed accesses, statement-order permutations, `int`-typed arg1, and
  flags /G3–/G6 /GB /O1 /Og /Ox do not change the ebx/ebp assignment.

The remaining 8-byte residue is a pure allocator register-preference quirk
(ebp for the entry parameter vs ebx) in the spellings above.  Historical fence only; not current permission.

## Finding 23: amt_ValidateOfficeCandidate (0x1000b1c0): fail-block sinking + loop rotation

Best C is 244 bytes vs 205 target.  The reference's structure: the two
search loops are *non-rotated* do-whiles (`cmp byte [eax],dl; je found; add;
inc; cmp eax,bound; jl loop`: the bound check is the back-edge), and the
shared fail-return block (`pop esi; xor eax,eax; pop ebx; ret`) sits
mid-function as the FIRST loop's fall-through, with the found-path jumping
over it and the found-checks jumping *back* to it.  The second search's
not-found has its own inline return-0 copy.

MSVC6 12.00.8168 will not reproduce this: every C/goto/loop form
(`do-while`+goto, `while(1)`+break, explicit `loop:`/`goto` back-edges,
combined `&&` conditions, `#pragma optimize("t",off)`, /O1 /Ox /Og /G6)
either sinks the fail return block to the function end (turning every check
into a long `0f 8x` jump: the ent-null check alone is `0f 84` vs the
reference's short `74 23`) or rotates the loops with a duplicated byte
compare.  The two behaviors are coupled: sinking the fail block turns the
loop's fall-through exit into a jump, which then triggers rotation.
Additional notes: the `i >= 30` check after each found-exit is provably
dead (the loop bound 0x101de870 = base + 30*0x18) but kept; the slot base is
folded into the memory operands (`[eax + 0x101de5a4]` etc.): writing the
slot as `(char*)0x101de5a0 + i*24 + off` reproduces the `lea i*3; shl 3`
index form.  Historical fence only; not current permission.

## Finding 24: ahm_ClampFloatValue (0x1000c3c0): three FPU return blocks

Best C is 82 bytes vs 83 target (or 74 with the FPU store form).  The
reference emits the clamp as three SEPARATE return blocks: the v-store
(`fstp [mem]; mov eax,1; ret`) as the main flow's fall-through, then the
min and max blocks at the end, each `fstp st(0); fld const; mov eax,1;
fstp [mem]; ret`: the return-1 load scheduled *between* the fld and the
fstp.  MSVC6 8168 will not reproduce this:
- `*(float*)(arg2+4) = *(float*)const;` direct stores compile to integer
  moves (`mov edx,[const]; mov [ecx+4],edx`) and inline the clamp blocks
  (jump-over branches, inverted from the reference's jump-to blocks): 82B;
- routing the constant through an FPU-resident `v` (`v = const; store v;`)
  yields the fld/fstp round-trip but the compiler tail-merges the max block
  into the v-store (`fstp [mem]; mov eax,1; ret` shared): 74B;
- else-if vs separate ifs, goto-labeled blocks, and the single-store clamp
  (65B) do not change either behavior;
- /G6 fixes the min block's mov position but reorders the prologue
  (`fld` before the second arg load) and keeps the max merge.

Re-checked with fresh probes: the two requirements are mutually exclusive
under 8168. Distinct float locals per arm, volatile constant reads, volatile
store lvalues, distinct return temps, `const + 0.0f`, goto layouts, and a
folded cell pointer all land on either 22 instructions (arms tail-merged,
74B, in-tree 50/83) or 25 instructions with integer-move stores (82B,
in-tree 58/83). Only the volatile-read variant reproduces the reference's
branch polarity and block order (`jne` max at 0x42, `je` min at 0x31), and
it still stores via `mov`. In-tree best remains the original 64/83.

The three-way split with the early `mov eax,1` is a scheduler+block-layout
choice 8168 makes in neither mode.  Historical fence only; not current permission.

## Finding 25: m_pool_free (0x10006e30): block param register + fatal placement

Best C is 133 bytes vs 137 target.  The reference keeps the `block`
parameter in edx (volatile: its live range spans no call) and RELOADS it
from the stack (`mov ecx,[esp+8]`) for the list-walk part; the bounds
temps live in esi; the fatal block (`push 0x10028b94; push 0x279; push
0x10028888; call ReportFatalError`) is sunk to the end with the checks
jumping forward to it.  MSVC6 8168 instead assigns block to esi (callee-
saved) for its whole live range and places the fatal block inline after
the checks (the main flow jumps over it).  Seven formulations: separate
ifs, combined `||` with the p-load hoisted (which does sink the fatal but
speculatively loads `*(hdr)` before the hdr==0 test), assignment-in-
condition (correct load order but inline fatal), named lo/hi temps, a blk
local, /G6, all normalize to the same 133B.  The fatal-sink and the
load-order are mutually exclusive in this compiler.  Historical fence only; not current permission.

## Finding 26: sim_PriorityUpdate (0x10015400): frame vs arg-slot reuse

Best C is 76 bytes vs 83 target.  The reference allocates an 8-byte frame
(`sub esp,8`) for the `table_lookup` range output and addresses it as
`[esp+4]` (word compare against `entity[0x65]`); MSVC6 8168 slot-reuses the
dead arg2 slot instead (no frame, `[esp+0xc]` after `push esi`), producing
the same semantics 7 bytes shorter.  An `unsigned short`, two `int`, and an
8-byte struct local all pack into the arg slots; /G6 reorders the arg
prep without allocating the frame; /O1 switches to a frame pointer.  The
rest of the function (byte arg zero-extend into ecx for `table_lookup`,
unsigned word compare with `jae`, byte `>0` guard + decrement of the old
entity, `ctx->0x170` reassignment, `entity[0x65]++`) matches byte-for-byte.
Historical fence only; not current permission.

## Finding 27: sim_StartEntityQueryByType (0x10015460): callee-saved roles

Best C is 130 bytes vs 145 target.  The reference's register roles: arg1→esi,
base (from the `g_entity_type_table` global pointer) →edi, type byte→edx
(zero-extended), index→ecx, and a `xor eax,eax` hoisted before the table
computation feeding the first branch's `push eax` (arg3=0).  MSVC6 8168
assigns arg1→edx and base→esi (one push instead of two), folds the index
chain the same way but into eax, and emits `push 0` for the first branch's
arg3.  Type/base temps, /G6, and the natural forms all normalize to the
same 130B.  The type*589 index chain (lea 3t; shl 4; +t; lea *3; lea
[base+*4]) and the four `gm_ff_Objekt(v,1,0,code)` dispatch calls
match.  Historical fence only; not current permission.

## Finding 28: sim_AdvanceGameClock (0x100155c0): arg4 preserve vs reload

Best C is 215 bytes vs 197 target.  The reference keeps only esi as a
callee-saved register and RELOADS arg4 from its stack slot after the idiv
clobbers edx (`mov eax,[esp+0x10]`); MSVC6 8168 preserves arg4 in edi and
pushes ebx/esi/edi (three pushes, 18 bytes larger).  The signed /60 magic
(0x88888889 imul + sar 5), the unsigned /24 magic (0xaaaaaaab mul + shr 4),
the `h - days*24` strength-reduced modulo, and both day-rollover loops
match; /G6 reorders the prologue without changing the register count.
Historical fence only; not current permission.

## Finding 29: gm_CleanupObjectEntities (0x10015cf0): SIB base/index roles

Best C is 193 bytes vs 194 target: the only differences are addressing
encodings.  The reference uses the loop counter as the SIB *base* and the
reloaded array as the *index* (`cmp word [esi+eax],0`, `lea ecx,[esi+eax]`
on the free path); MSVC6 8168 emits the array as the base with the counter
scaled (`cmp word [eax+esi*1],0`) and `add eax,esi` instead of the lea.
Operand-order swaps in the C (`array+i` vs `i+array`), /G6, and a named
`g_query_limit` global (which DID fix the counter decrement to the `a3`
moffs form) do not change the SIB roles.  Everything else (the loop
structure, the gm_ResolveEntityById out-param chain (c→+0x5d, b→+0x14,
a→+0x178), the free path, and the final rep stosd memset) matches.
Historical fence only; not current permission.

## Finding 30: gm_CheckEntityType (0x10017ab0): lea vs folded table load

Best C is 72 bytes vs 74 target.  The reference materializes the
`base + type*589` address with a separate `lea eax,[edx+eax*4]` before the
byte load (`mov al,[eax]`); MSVC6 8168 always strength-reduces the address
into the load's SIB (`mov al,[edx+eax*4]`), 2 bytes shorter.  Pointer
variables, split `base + type + type*588` expressions, idx temps, and /G6
do not prevent the fold.  The 7-way `== 0xb/0xd/0xc/0x10/0x1c/0x1d/0x1f`
compare chain, the type*589 lea chain, and the null-arg return (which
naturally returns eax=0 without an xor) match.  Historical fence only; not current permission.

## Finding 31: ahm_ProcessEntityChain (0x1000ca00): do-while inversion

Best C is 136 bytes vs 130 target.  The reference's dispatch loop keeps the
ok test at the bottom (`test ebx,ebx; jne loop` back-edge) with the type-6
check as a forward `je` to a block after the set2 fall-through; MSVC6 8168
inverts the loop: the ok test is hoisted above the type check and the
back-edge jumps to the handler, 6 bytes larger.  Break, goto, and
post-loop-ok-test structures all trigger the inversion.  The handler
dispatch (`call [eax*4+0x1002c5a0]` with the byte index zero-extended via
`and eax,0xff`), the two walk-and-set paths (set-2 sets every node, set-1
only the final type-6 node), and the byte-compare `cmp al,6` (avoid a
`t` temp: it forces a pre-zero + full-register compare) match.  Historical fence only; not current permission.

## Finding 32: cm_GetBuildingStatCount (0x100104a0): branchless if-conversion + lea fold

Best C is 133 bytes vs 135 target.  Two residue patterns:
1. `if (x == 1) return 0xc; return 8;` (constant returns) triggers MSVC6's
   branchless if-conversion (`dec al; neg al; sbb eax,eax; and al,0xfc`);
   the reference keeps branchy `mov eax,8; cmp bl,dl; jne; mov eax,0xc`:
   writing `r = 8; if (x == 1) r = 0xc; return r;` preserves the branch.
2. The type*589 address is folded into the 0x247 load
   (`mov al,[esi+eax*4+0x247]`) where the reference materializes it
   (`lea eax,[esi+eax*4]; mov al,[eax+0x247]`): the Finding 30 fold.
   Statement order matters: the index chain must precede the obj
   (`cmd+0x65`) load to match the reference's scheduling.  Historical fence only; not current permission.

## Finding 33: cm_ChkMoveCredits (0x1000cb20): arg3-lea hoist (3 bytes)

Best C is 168 bytes vs 171 target.  The reference hoists the `&c` (arg3)
address lea above the `*(arg1+0x14)=r` store (computed at an earlier esp,
3 disp8 bytes differ); MSVC6 8168 emits all three out-param leas after the
arg4 push regardless of C structure (pc/pa/pb temps, declaration order,
statement order).  The unsigned-char `gm_QueryEntitySum` 2nd param (byte
passed raw in cl: declaring it `unsigned char` stops the zero-extension)
and the `sum - limit < 0` form (sub + jns back-edge) match.  Historical fence only; not current permission.

## Finding 34: cm_ExChangeFloat (0x1000eb70): offset-register role

Best C is 130 bytes vs 135 target.  The reference loads the float-offset
(`esi->0x14`) into edx (`mov edx,[esi+0x14]; fadd [eax+edx]; add eax,edx`);
MSVC6 8168 puts it in ecx, emitting `[eax+ecx*1]` (SIB), a
register-role difference, plus the Finding 33 arg3-lea hoist residue.
The GetFieldByType/ResolveEntityById chain, the c?a:b selection, the
`+=` float add with `fld; fadd; add; fstp`, and the result-byte store
otherwise match.  Historical fence only; not current permission.

## Finding 35: cm_ExModifyStat (0x100100a0): FPU re-compare fold

Best C is 146 bytes vs 159 target.  The reference's clamp routes the
merge point (f>=a4 → clamp to a4, versus cc<f<a4 → keep) through a second
`fcom [a4]` compare; MSVC6 8168 always folds the redundant compare away,
emitting the tighter if-converted clamp (13 bytes shorter).  The
`mov [esp+0x10],edx; fild [esp+0x10]` int→double spill, the byte stat
read/`+`/store, and the `__ftol` conversion otherwise match.  The
`if (f < a4) { if (f <= cc) f = cc; } else { f = a4; }` form is the
closest; per-branch stores over-shoot (180B).  Historical fence only; not current permission.

## Finding 36: cm_ExAllocThemaPredigt (0x1000f2f0): add-edi fold + dead-store elimination

Best C is 162 bytes vs 176 target.  The reference materializes
`add edi,0x18` once (adjusting the param base before the 7-byte entity
copy: `mov edx,[edi]; mov [ecx],edx; mov ax,[edi+4]; mov [ecx+4],ax;
mov dl,[edi+6]; mov [ecx+6],dl`) and keeps a dead byte copy
`mov dl,[edi+6]; mov [ecx+6],dl` then `mov byte [esi+0x22],0`: same
destination, overwritten).  MSVC6 8168 folds the add back into
base+offset addressing on each access (saving the 3-byte `add` + the
separate `lea ecx,[esi+0x1c]` dst pointer is also folded) and eliminates
the dead store entirely.  Both differences are optimizer strength
reductions that the `base += 0x18` formulations above did not prevent: any such formulation
flips esi/edi register roles (the two pointer temps spill), and the
dead store is only preserved by pointer-alias hiding which the GRA
resolves.  The prologue offsets 0-63, the
gm_GetFieldByType/gm_AllocObjekt calls, the interleaved
LogMessageInternal arg pushes, the `type*2507364` table store
(`lea edx,[eax+eax*8]; mov [edx*4+0x10442d08],eax2`), the `ent+0x12=0x40`
and the result-byte stores all match.  Historical fence only; not current permission
(`REBREW_ALLOW_NAKED`).

## Finding 37: cm_ExMoveObjekt (0x1000e530): node-spill fixed point + store1 address form

Best C is 340 bytes vs 346 target (10+ formulations: cmd/base stores,
`volatile`, `int*` base, inline-if calls).  Two allocator decisions are
unreproducible:

1. **store1 address form.**  The reference emits the folded
   `mov [esi+0x14],eax` (field store).  A cmd-based store
   (`*(int*)(cmd + 0x14)`) makes MSVC6 reload the address-taken param
   into a scratch (`mov ecx,[esp+0x20]`), shifting the call-1 lea
   round-robin by one register; a base-based store (`*(int*)(base+0x14)`
   or `base[5]`) makes MSVC6 hoist `lea edi,[esi+0x14]` before the
   first GetFieldByType call and store via `[edi]` (+2 bytes).  The
   reference's folded form needs neither, and no formulation produces it
   (volatile on the store target does not change the hoist).

2. **Scan-loop node spill.**  The reference spills the list node to
   `[esp+0x18]` at each loop definition, re-tests it after the unlink
  (`mov eax,[esp+0x18]; test eax,eax; jne L_attach`: a redundant
   `if (node)` that MSVC6 keeps only because the value lives in memory)
   and reloads it 3x in the attach.  The closest C keeps node in ecx
   instead (no spill, redundant check eliminated by the optimizer), and
   the attach's field2 load lands in eax instead of ecx.  Both are
   self-consistent register allocations; the spill primes the attach's
   round-robin (test-eax → field2 in ecx) and the register form primes
  eax: no C shape inverts the choice.

Everything else matches byte-for-byte: the prologue offsets, all three
GetFieldByType/ResolveEntityById call sequences (including the call-1
lea round-robin (ecx,edx,eax) and call-2 (eax,ecx,edx)), both entity
selections (src/dst via 0x5d/0x14/0x178), the `cmp [ecx+8]` scan, the
unlink, and the attach stores.  Historical fence only; not current permission (then under `REBREW_ALLOW_NAKED`).

## Finding 38: cm_ExChangeAttribute (0x1000e7d0): loop register-pairing swap

Best C is 213/242 bytes (19 formulations).  The reference's loop pairs
`{count, offset, dst2}` in ecx with the payload pointer (src) in eax;
every C formulation allocates the opposite pairing
(`{count, offset, dst2}` in eax, src in ecx): a systematic eax↔ecx
swap across ~29 register-encoding bytes.  The pairing is decided by the
src pointer's register at the loop-setup `lea` (`lea eax,[ebp+0x15]` vs
`lea ecx,[ebp+0x15]`); the count byte-load then takes the other register
(cl vs al), and the offset zero-extend (`xor ecx,ecx; mov cx,[eax]` vs
`xor eax,eax; mov ax,[ecx]`) and the `dst2 = entity + offset` sum follow
it.  Declaration order, `register` hints, statement order, and the
puVar5 pointer forms (which fix the offset-read scheduling to
`inc;xor;inc;mov cx,[eax]`) cannot flip the pairing.

What DID converge (matches byte-for-byte): the `&resolved`-local trick
  (Finding 7 workaround: a local `int* resolved` whose slot reuses the
dead `cmd` param home; the source never takes `&cmd`, so the base stays
in ebp and the field store folds to `mov [ebp+0x10],esi`); the resolve
lea round-robin (ecx,edx,eax); the dst selection into edi; the
dispatch dec-chain (switch on size {1,2,4}); the `src++;src++`-style
offset walk with the zero-extend scheduled between the increments; the
`unsigned n` + `while (n > 0)` form (emits `test; jbe`); and all three
add-to-memory inner loops (only reachable when the entity/dst2 split
keeps the entity in edi and the loop has no free scratch register).
Historical fence only; not current permission (then under `REBREW_ALLOW_NAKED`).

## Finding 39: cm_ExChangeBits (0x1000eaa0): pre-resolve field store materialization

Best C matches everything except the first 20 bytes (6+ formulations:
cmd/base stores, char-cast read/store splits, `cmd + 0`, volatile base,
`int* base` with `base[4]`, flag sweep incl. /O1, which switches to a
frame-pointer prologue).  The reference passes `&cmd` to
gm_ResolveEntityById AND folds the pre-resolve field store as
`mov [esi+0x10],eax` with the base kept in esi (pushed once).  Every C
formulation either CSE-hoists the store address
(`lea edi,[esi+0x10]` scheduled before the first GetFieldByType call):
the Finding 7 family split, stealing edi and shifting the resolve lea
round-robin) or reloads cmd from its home slot into a scratch.  The
base copy is semantically required (the post-resolve offset/size/mask/
value reads at `cmd+0x14/0x18/0x1c/0x20` use the ORIGINAL cmd while the
entity uses the modified `&cmd` slot), and its presence is what
triggers the split: the same fixed point as cm_ExFree (fenced,
177/180), cm_ExMoveObjekt (Finding 37) and cm_ExChangeAttribute
(Finding 38).

What matches byte-for-byte modulo the head: the folded resolve leas
(ecx,edx,eax), the selection (`cmd ? cmd : (pv8 ? pv8 : pv4)`), the
`puVar3 = entity + *(int*)(base+0x14)` pointer, the dec-chain dispatch
(switch on size {1,2,4}), the size1 byte-temp form
(`bVar4 = *puVar3 & ~*(char*)(base+0x20)` with byte not/and/or), the
size2 in-place `and word ptr [eax],cx` + reload, the size4 dword
pattern, and the result-byte store.  Historical fence only; not current permission
(`REBREW_ALLOW_NAKED`).

## Finding 40: cm_ExChangeDesire (0x1000e9c0): family store materialization + FPU clamp

Two blockers.  (1) The Finding 7 family store materialization: the
reference keeps the cmd base in edi (single prologue push) and folds
the field store (`mov [edi+0x10],eax`) while passing `&cmd` to
gm_ResolveEntityById(0, 0, &cmd, field); every C emits
`mov eax,[esp+4]` first, CSE-hoists `lea esi,[eax+0x10]`, and pushes
three callee-saved registers in the prologue instead of deferring ebx
and esi to L_resolved/loop-entry.  (2) The Finding 35 FPU clamp
re-compare: the reference's stat clamp routes through a second
`fcom max` after the first compare already established stat<max
(the L_clamp_chk re-check), which MSVC6 always folds away in C.

What matches: the resolve's `push 0; push 0; lea ecx,&cmd` arg pattern,
the loop's `lea ecx,[eax+eax*2+0x24]; shl ecx,2` stat-index chain
(`entity + (idx*3+0x24)*4`), the `fld [edx]; fadd [ecx+eax]; fstp`
in-place add, the entity reload from the cmd slot each iteration, the
unsigned count guard (jbe), the ebx counter with per-iteration count
reload, and the result-byte store.  Historical fence only; not current permission
(`REBREW_ALLOW_NAKED`).

## Finding 41: cm_ExRemoveLinkedObject (0x1000f0d0): prologue scheduling

Best C matches the control flow and all four gm_RemoveLinkedNodeById
call sites, but the prologue scheduling diverges (4 formulations): the
reference pushes ecx/esi/edi and then loads the original-result copy
into edi (`mov edi,[esp+0x14]`) and the cmd base into esi
(`mov esi,[esp+0x10]` at L_skip_mark, after the `*result=2` mark);
every C emits `push ecx; mov eax,[esp+0xc]` (result loaded into the
volatile eax first), interleaves the loads between the pushes, and
shifts the resolve lea round-robin by one register.  Statement order
(r-copy before/after base, mark before/after base) does not change it.

Semantics worth preserving in the fallback: the function takes
`&result` (the char* param) as a resolve out-param, so the original
result pointer must be copied (edi) for the `*result=2` / `*result=1`
marks, and the node-id reads at `cmd+0x14` / `cmd+0x18` must use a
`base` copy of the ORIGINAL cmd: the post-resolve cmd slot holds the
resolved entity (never 0 in the p1/p2 branches, so using it would fold
`*(0+0x18)` into an absolute load).  The -2 (query empty), -1 (no
entity), 0 (success) and q (remove result) return paths all match.
Historical fence only; not current permission (then under `REBREW_ALLOW_NAKED`).

## Finding 42: cm_ExClearLagerslot (0x1000e690): family store materialization (short* base)

The Finding 7 family store materialization with a `short*` base: the
reference keeps the base in esi (`push esi; mov esi,[esp+8]`) and folds
`mov [esi+0x10],eax` (the `*(int*)(psVar1+8) = field` store, +8 shorts)
while passing `&cmd` in the middle of
`gm_ResolveEntityById(0, &cmd, 0, field)`; every C emits
`mov eax,[esp+4]` first, CSE-hoists `lea esi,[eax+0x10]`, and shifts
the resolve arg pushes (the ref interleaves the store between `push
ecx` and `push 0`).  The rest of the Ghidra reference converts cleanly:
the `*cmd == 0x2a || *cmd == 0x116` word compare, the
`gm_ff_Objekt(*(int*)(cmd+10), 1, 0, (uint)(ushort)psVar1[10])`
call with the `xor edx,edx; mov dx,[esi+0x14]` zero-extend, the
`*(int*)(puVar3+7) != 1` count check, the
`gm_RemoveObjectByType((char**)(cmd+10), ...)` call, and the shared
log-return-1 tail.  Historical fence only; not current permission (then under `REBREW_ALLOW_NAKED`).

## Finding 43: cm_ExSetAttribute (0x1000e8d0): loop-head offset-read scheduling

Best C is 234/239 (the closest conversion of the family; 6 formulations).
The reference's loop head walks the payload pointer for the 16-bit
offset: `inc eax; xor ecx,ecx; inc eax; mov cx,[eax]; add eax,2`; the
offset zero-extend is scheduled BETWEEN the two pointer increments,
which prevents MSVC6 from merging them.  Every C (char* walk, puVar5
pointer forms, post-read `src++;src++` splits, int* piVar6 casts,
which regress the frame) either merges the increments into
`add $0x3,%eax` with a disp+1 read (`mov cx,[eax+1]`) or moves the xor
after the merged add: a scheduler fixed-point.  The 5-byte residue is
localized to offsets 0x87-0x8d.

What matches: the `resolved`-local trick (Finding 7 workaround: base in
ebp, `mov [ebp+0x10],eax` folded store BEFORE the resolve), the resolve
lea round-robin, the deferred ebx/edi pushes, the selection into edi,
the count guard (jbe), the dec-chain dispatch, and all three inner
STORE loops (`mov [ecx],edx`: set, not accumulate; the twin of
cm_ExChangeAttribute's add loops).  Historical fence only; not current permission
(`REBREW_ALLOW_NAKED`).

## Finding 44: gv_UpdateProductionProgress (0x10011790): arg-order + sum-register fixed points

Best C is 203/242 (13+ formulations).  The head, the shared -1
epilogue (nested ifs with a final `return -1`: the three early
`return -1` sites merge only via fall-through, not goto), the 589-
multiply type check (`dword_100a8c30 + (uchar)*v * 589`), the
CheckSlotActive call, and the ternary clamp `(val <= 0) ? 0 : val`
(branchless setle/dec/and) all match.  Two scheduler fixed-points
remain:

1. **gv_GetSlotEntry arg setup.**  The reference loads the byte arg3
   first (`mov dl,[edi+0x10]; mov eax,[edi+0xc]; push edx; push eax`)
   with NO zero/sign extension (raw byte push: the callee reads only
   the low byte); every C either zero-extends (`xor edx,edx; mov dl`
   with an unsigned char cast, +2 bytes) or sign-extends (`movsx` for
   a char cast), and the arg2 load is always hoisted ahead of arg3's
   regardless of evaluation order, temps (which break the frame), or
   char/uchar parameter declarations.
2. **Clamp sum-register role.**  The reference computes
   `val = *(uchar*)(r+0xc) + *(int*)(a+0x13)` with the byte loaded
   first into ecx, copied to edx, the dword into ecx, and the sum in
   ecx; every C lands the dword load first and the sum in edx.

Historical fence only; not current permission (then under `REBREW_ALLOW_NAKED`); the 203/242 C is preserved
in the #else fallback.

## Finding 45: gv_ActivateGraveyardSection (0x10011660): error-block placement

Best C is 275/306 (4 formulations: nested-if fall-through, error-first
ifs, if-else, block-scoped).  The head (resolve, 589-type check, the
t==3/2/1 dispatch with the shared store tails) matches byte-for-byte,
and the second resolve's `&v2` must be passed in the MIDDLE position
(`gm_ResolveEntityById(0, 0, &v2, *(a+4))`: the first resolve passes
`&v` first; the two out-params live in the arg slot and the push-ecx
local respectively).  Two layout fixed-points remain:

1. The reference INLINES the `p==0 → -3` and `v2==0 → -6` return
   blocks right after their `jne` checks; every C groups them at the
   tail with the -7/-8/-1 epilogues (je to the tail), making the
   function 9 bytes shorter and shifting the -1 target.
2. The t==2 success path pops edi BEFORE the two stores in the
   compiled (`pop edi; mov [esi+0x1a],cl; ...`) vs after in the
   reference.

The -2 (type-check) return inlines correctly in both.  Historical fence only; not current permission
(then under `REBREW_ALLOW_NAKED`). The 275/306 C is preserved in the
#else fallback.

## Finding 46: gv_GetSlotEntry (0x100105b0): shared return-0 epilogue

Best C is 35/329 positional (5 formulations).  The reference shares ONE
`xor eax,eax; pop esi; ret` epilogue for ALL fail paths (the size-range
check, every gv_CheckSlotActive fail, and every per-(b,size) c-limit
  check: all `jae/jl/jg` to 0x145), with the success
`base + (uchar)c * 20` lea-chain inline.  Every C either inlines the
  fail returns (`xor eax,eax; pop esi; ret` right after each `jb`:
shifting the whole layout) or explodes the success returns into
duplicated blocks (437B when the success is written inline with
inverted conditions).  The size must be re-read from `*(a+4)` at each
site (a `size` local forces a second callee-saved push).  The
per-path c-limits (b=0: 8/0xc/0x10, b=1: 4/6/8, b=2: size1 invalid +
2/4, b=3: size1/2 invalid + 2) and the `c*20` index chain otherwise
decode cleanly.  Historical fence only; not current permission (then under `REBREW_ALLOW_NAKED`); the C is
preserved in the #else fallback.

## Finding 47: FindSlotEntryFiltered (0x10010710): walk in the parameter, not a local

RELOC 320/320 in pure C.  The lever is that the pointer walk assigns back
into the `cursor` parameter instead of into a dedicated `cur` local:

```c
if (!cursor) { cursor = *(void**)((char*)workers + <base>); }
else         { cursor = (char*)cursor + 0x14; }
while ((unsigned char*)cursor < limit) { ... cursor = (char*)cursor + 0x14; }
```

With a separate `cur` local the function stalls at 263/320 with obj size
already 320, zero structural differences and a 27/27 CFG: msvc6 puts
type/workers/entry in edi/esi/ebx where the target uses ebx/edi/esi, and
every instruction differs by register name only.  The cause is the extra
value: `cur` and the incoming `cursor` are two live ranges over the same
pointer, so the dispatch result claims a fresh callee-saved register and
pushes the remaining three around the cycle.  Writing the walk into the
parameter merges them, the dispatch result inherits esi, and `limit`
inherits ebp from `entity`, matching the reference.

**Rule:** when a parameter is a pointer or index that the body advances,
advance the parameter itself.  Introducing a local copy adds a live range
and can rotate every callee-saved assignment in the function.

Everything reachable from the local-copy shape was ruled out first: all
24 declaration permutations, retypes, signedness, `register`, guard
splits and nestings, slot-index hoists, `switch` dispatch, `for(;;)`
rewrites, volatile pins on `type`/`entity`/`workers`/`cursor`, parameter
homing, MSVC6 SP1/SP2/SP4, and a full CFLAGS sweep (all ties at 97500,
`/G3` and peers, exact=false).  Each left 263/320 or scored worse.

## Finding 48: gv_SpawnEntities (0x10010850): prologue region-split (cold-path saves)

[2026-08-24 exhaustive follow-up: goal-mode audit.]  Best C is 292/370
positional (10+ formulations).  Additional evidence gathered:

- **Toolchain sweep** (all vendored MSVC 4.0→9.0 SP1 incl. every MSVC6
  SP1-SP6): none reproduces the reference prologue; the best toolchain
  remains the base msvc6 (the same 292 wall).
- **GA** (40 generations × 64 population, 27.5 min, stagnant after 25
  gens): best individual is the same nested-if shape: no mutation
  (pragma optimize g/s/t/y, intrinsic, check_stack, auto_inline)
  reaches the reference.
- **Flag variants**: /O1 (57), /O2+/Os (45), /O2+/Og- (66),
  /O2+/G5 (292, identical), `#pragma optimize("", off)` (72/491),
  `#pragma optimize("t", off)` (45): all strictly worse or unchanged.
- **Live-range lever confirmed**: adding `count > 0` to the guard chain
  does pull `push ebx` to entry (ebx becomes live across the guards),
  proving MSVC6 places a callee-saved save at entry iff the register's
  live range crosses the guard block.  But ebp/esi/edi have no legal
  pre-guard use: the reference's own fail epilogue returns the
  constant 0 (`xor eax,eax`), so even ebp is dead across the guards in
  the reference: its entry save has no C-expressible cause.
- **register-keyword / pointer-typed arg / do-while / goto-body /
  shared-return forms**: all ≤ 292.

Conclusion: the reference build emitted function-level saves (both
epilogues pop all four), our toolchain emits region-local saves; this
divergence is a compiler-build behavior, same class as the
gm_NextEntityQueryMatch blocker (declared unreproducible across all
available compilers).  Historical fence only; not current permission; C preserved in #else.

Best C is 291/370 positional (5+ formulations).  The entire body decodes
and matches: the `dword_100a8c30 + (uchar)*a * 589` type check (field
`tp[0x247]` in 1..3), the `FindSlotEntryFiltered(0, a, 0,
0x10010700, 0)` slot acquisition, the `*p = g_next_object_id++` counter bump,
the `slot+4/+8/+0xa/+0xc` field stores, the 5-iteration `gm_RandomMod`
byte fill (offsets +0x24..+0x28), the four `gm_RandomMod`+1 dword stores
(+0x2c/+0x30/+0x34/+0x38/+0x40), and the three discarded `gm_RandomMod`
calls.  The single blocker is the prologue: the reference saves ebx/ebp/
esi/edi all at entry (with the `mov cl,[eax]` 147-chain load interleaved
between `push ebp` and `push esi`) and its `return 0` guard epilogue pops
all four; every C formulation MSVC6 region-splits the callee-saved saves
past the three guard checks (`jne/jb/ja` to the shared ret0), so the ret0
path pops only the registers already saved.  Nested-if (guards as the
success gate) is required: the early-`return 0` form degrades to inline
`xor eax,eax; ret` per guard (56/370) and `goto fail` inlines the ret too.
The `(float)gm_RandomMod(8) & 0xffff` float-chain (`fild; fmul 21.0; fadd
42.0; __ftol`) and the `do { j++; store[j+0x23]; } while (j < 5)` rotation
both byte-match.  Historical fence only; not current permission; C preserved in #else.

**Amended (2026 campaign): deferred saves also decide the frame size.**
`CrashDumpUnhandledExceptionFilter` (0x10002770) is the same mechanism measured
at the link level: the reference defers `push ebx; push edi` to the dominator
of their first use and restores them at each exit of that region: provable
because one cold arm reaches the tail without them.  Ours has `ebx`/`edi` live
before the first branch, so the deferral window never opens and the frame stays
12 bytes larger (`sub esp,0x28c` against `0x280`), with the whole local slot map
shifted downstream.  ~30 spellings and an 18-variant flag sweep did not move it.  (That 18-variant sweep is `scripts/flagsweep.py`'s standard list applied to this function; the twelve-variant sweep recorded in the amendment below is a separate run, so the two counts are two sweeps, not a contradiction.)
The frame size is a *consequence* of which values are live at the first branch,
not of the local declarations (Finding 52).  `msvc6-c-shapes.md` §38 states the
same rule for the instruction shape.

**Amendment: the frame only tracks bytes actually spilled.** On
`CrashDumpUnhandledExceptionFilter` (0x10002770) the size moves with the
*spill count*, not with the locals: enlarging `szSep[0x20]` and `szLine[8]`
moves the frame to 0x290, while `szSep[0x1c]` (28 bytes) is *identical* to
`szSep[0x1b]` (27 bytes) and both give 0x28c. Its reference frame is 0x280,
i.e. the reference spills about three fewer 4-byte scalars. Dropping the two
locals `fail_msg`/`fail_line` does not shrink the frame at all: they get
registers; that half of the measurement is the deletion case of Finding 52, and
this is the same cascade as the deferred `push ebx; push edi` above.

**Amendment: flags and declaration order are both dead for that frame.**
Twelve flag variants (`/O1` `/Ox` `/Os` `/Ot` `/Og` `/Ob1` `/Ob2` `/Oy` `/Oa`
`/Ow` `/Op` and `/Og` combinations, all with `/Gd`) give a frame of 0x28c,
0x298 or 0x2cc: never 0x280; and eight declaration permutations (pointer group
first, byte locals last, arrays reversed, structs swapped) leave it at 0x28c.
Record these as **two levers retired for this function**, not as a general claim
(the earlier "~30 spellings and 18-variant flag sweep" line above is the
summary of this sweep); Finding 52 is the general rule for the declaration half.

## Finding 49: ls_InitNewDynastyEntity (0x100122e0): 768x768 fill induction-variable elimination

Best C is 99/341 positional (5 formulations).  The resolve/flag-select
head is byte-identical (4 real args: the 4th is the entity struct; the
`a == 0x15` selects `[d+0x1cc] |= 0x1000` + `fcn_1000b820` vs `|=
0x2000` + `fcn_1000b850`; `[d+0xa] = (short)c`), as are the tail float
stores (1000.0/1.0/12.0/330.0/1000.0), the 5-iteration `fild; fadd` byte
fill, and the `gm_AddObjekt` call.  The blocker is the nested
768x768 fill (`for p = 0x100a9820..0x10139820 step 0x300; for i < 0x300`
`p[i] = rnd(0x40)-0x20; p2[p-0x100a9820+i] = 0`): MSVC6 strength-reduces
`i` into a running pointer pair (eliminating the counter), while the
reference keeps the counter in esi and the base-offset in edi and reloads
the running slot pointer `p` from the reused arg-3 stack slot each outer
iteration.  A named `zero` variable and a `q = p - base` offset both fail
to stop the elimination.  Historical fence only; not current permission; C preserved in #else.

## Finding 50: gv_AllocGraveyardField (0x100109d0): alloc/field-init loop allocation

RESOLVED: now RELOC (832/832 byte-match, 13 relocs) as proper C under
`msvc600sp6`.  The validation/alloc head is byte-identical (the
`dword_100a8c30` 147-chain type check, the
`m_AllocTracked(0x24, "0x1002d474")` 36-byte struct + `memset 36`,
`[esi] = *(b+1)`, `[esi+4] = tp[0x247]`, the two sub-allocations
`g_field_worker_count[type]*20` and `g_field_entry_count[type]*68` with their `memset`s, and
the cleanup free chain).  The blocker was register allocation in the six
`field-init` loops (type 1: 8+4, type 2: 12, type 3: 16+12: each storing
`0`/`1`, `q`, `-1`, `0xffff` per 0x14-byte slot while stepping `q` by
0x44 or 0x88) plus the `-1` fill loop: MSVC6 merged the `-1` dword store
with the `0xffff` word store into one register (`or edx,-1` in the memset
tail, then `mov [p+4],edx` / `mov word [p+8],dx`), while the reference
keeps `edi = -1` (`or edi,0xffffffff` at the loop entry) and
`edx = 0xffff` (`mov edx,0xffff`) separate: the merge cascades into the
loop counter (`edi` vs `ebp`), index, and base-reload registers.  Two
source fixes reproduce the reference exactly: (1) write the constants as
**unsigned**: `*(unsigned*) (p+4) = 0xFFFFFFFFu` and
`*(unsigned short*) (p+8) = 0xFFFFu` (and the fill loop likewise), which
stops MSVC6 from treating them as the same value; (2) hoist `p = slot+0x1c`
and `e = slot+0x20` before the type dispatch and use them in every branch,
so the reference's single pre-dispatch `mov eax,[esi+0x1c]` /
`mov ecx,[esi+0x20]` is emitted instead of per-branch loads.

## Finding 51: m_AllocTracked (0x10006580): frame + zero-register fixed point

Byte-blocked; best config `/O2 /Gd /G6 /Oy-` (msvc600sp6) matches 184/658
instr bytes (obj 631 vs target 658, 25 relocs).  **Semantically PROVEN**
(`rebrew prove`, 2026-08-27): the C body is a faithful reconstruction (list
walk, inline strcmp/strcpy, slot fill, stat updates, all five string
literals byte-identical); the size and byte gaps are two allocator fixed
points:

1. **frame + zero register never coexist.**  The reference opens with
   `push ebp; mov ebp,esp; sub esp,0x118; mov eax,[g_array_ptr]; push ebx;
   xor ebx,ebx; push esi; cmp eax,ebx; push edi`: an ebp frame AND a
   materialized zero register in ebx (all later zero-compares/stores are
   `cmp reg,ebx` / `mov [mem],ebx` / `mov [..],bl`, and the intrinsic
   strcmp is the `cmp cl,bl` form).

   **Corrected 2026-09-05.**  This item previously read "frame + zero
   register never coexist" and concluded the idiom was unreachable from C
   under `/Oy-`.  That is wrong, and it sent later passes chasing flags
   instead of source shape.  A probe carrying m_AllocTracked's own shape
   (`.scratch/L3/pz2.c` `q1`: a 0x100-byte local array for the frame, three
   long-lived values, the same guard chain) emits the target's entry
   verbatim under `/O2 /Gd /G6 /Oy-`, frame and zero register together:

   ```
   push ebp; mov ebp,esp; sub esp,0x114; mov eax,[g]; push ebx;
   xor ebx,ebx; cmp ebx,eax; push esi; push edi
   ```

   It does not depend on spelling zeros through a named local either: the
   same probe with plain literal `0` throughout (`.scratch/L3/pz7.c`) still
   emits it, and routing all 17 zeros in the real file through a
   `const int z = 0` is inert at 212/658.

   What actually suppresses it is a value that stays live across the
   allocator call.  Bisected on the real body by truncating at successive
   statements (`.scratch/L3/{c0..c3,r1,r2,x1..x4}.c`, all `/O2 /Gd /G6
   /Oy-`): the body cut before `nodev = (int) node` and returning `ptr`
   emits `xor ebx,ebx`; the same cut returning `node` does not; adding
   `nodev = (int) node` alone kills it; adding `node->count++` alone kills
   it; adding `sz = size` and the malloc keeps it.  So the zero register and
   a node value live across `malloc` are mutually exclusive under this
   compiler, and the target has both.  Forms tried to keep both, none
   restoring the register in the full function: plain (non-volatile)
   `nodev`, a `struct GroupNode* volatile` shadow, dropping `nodev` for the
   `np` alias, moving `count++` after the null check, and hoisting the
   increment into a fresh pointer local.  The residual gap is a real
   allocator fixed point, but it is a live-range one, not a flag one.
2. **alignment-pass memset**: the `memset(ptr,0,size)` expands to the
   dest-aligning `lea ecx,[edi+edi*2]; and ecx,3; sub ebx,ecx; rep stosb;
   rep stosd; ...` form (size spilled to `[ebp-8]`, ptr to `[ebp-4]`).
   Same unreproducible expansion as m_init / m_PoolAlloc
   (Finding 19): msvc6 SP6 emits only the plain `shr ecx,2; rep stosd;
   and ecx,3; rep stosb` from any C shape.

`/O2 /Gd /G6 /Oy-` was chosen over plain `/O2 /Gd /Oy-` (167/658) because
the reference's zero-register idiom is /G6-only, and /G6 without `/Oy-`
drops the frame and 54 matched bytes (130/666).  A `rebrew test` run with
`--cflags "/O2 /Gd /G6 /Oy-"` persists the per-function metadata; the
generic `--fix-blocker` write currently crashes with an AttributeError
(`SimpleNamespace` has no `metadata_dir`) and was not used.

**Prove note (2026-08-27).**  The first `rebrew prove` runs reported a
counterexample (`EAX=2179763029 vs 0`) that turned out to be an artifact of
the prover's reloc patching, not a real semantic difference: `prove.py`
patched the original blob at the *compiled* blob's reloc offsets, and with
the layouts diverging (631 vs 658 bytes) the `_ReportFatalError` displacement
landed inside the target's `push 0x10028888` / `call ReportFatalError`
sequence, so the `g_array_ptr==0` fatal path returned the unconstrained stub
value instead of 0.  The fix (order-paired call-site stubbing in
`prove_equivalence`, with an offset-based fallback when the two blobs' call
counts differ) lets `rebrew prove` establish equivalence; STATUS is now
PROVEN.  The byte gap remains a codegen fixed point, so PROVEN, not
EXACT/RELOC, is the terminal status for this function.

## Finding 52: stack slots are coloured over live ranges, so declaration order is usually inert

MSVC6 assigns frame slots by live-range colouring: two locals whose ranges do
not overlap share a slot, so swapping their declarations usually changes
nothing, and *deleting* live locals does not necessarily shrink the frame.

- `CrashDumpUnhandledExceptionFilter` (0x10002770): declaration order,
  reversed order, char-first, and several retypings are all byte-identical, and
  deleting live locals does not shrink its 0x28c frame.
- `gm_ObjectsAvailble` (0x10015f70): 10 declaration orders byte-identical.
- `ls_LoadBuildingEntityState` (0x100128f0): the two slots the reference has at
  `[esp+0x14]`/`[esp+0x18]` cannot be swapped by declaring them in the other
  order.

The exception is **init-statement order**: on `cm_ExSellObjekt` (0x1000d930)
moving one `= 0` initialiser among the others changed which stack slot a
pointer got.  So the movable thing is the statement that creates the value, not
the declaration line.  This is the general form of the "declaration order ...
did not move it" notes in Findings 7, 8b, 22, 41 and 47, and it is the same
live-range mechanism as Finding 48's prologue split.
`msvc6-c-shapes.md` §15/§50 credit declaration order for a frame-offset steer
(round 110); on the sites above it was inert: try live ranges and initialiser
placement first.

**The exception is now a rule, not an observation (round 857, isolated).** Finding 52 recorded
that init-statement order moves a slot on one real function. Built the minimal case: three
address-taken `int`s, initialized `= 0`, all used, and swept all six permutations. **Slots are
handed out in initialization order by a fixed sequence that does not depend on declaration
order at all:**

```
init order a b c  ->  a=0x0  b=0x8  c=0x4
init order c b a  ->  c=0x4  b=0x8  a=0x0
init order b a c  ->  b=0x8  a=0x0  c=0x4
init order c a b  ->  c=0x4  a=0x0  b=0x8
init order a c b  ->  a=0x0  c=0x4  b=0x8
init order b c a  ->  b=0x8  c=0x4  a=0x0
```

Reading any row: the **1st-initialized gets `0x0`**, the **last gets `0x4`**, and the ones in
between fill downward from the top. The sequence by count:

| initialized locals | slot sequence, in init order |
|---|---|
| 2 | `0x0, 0x4` |
| 3 | `0x0, 0x8, 0x4` |
| 4 | `0x0, 0xc, 0x8, 0x4` |

So it is fully deterministic and steppable: **to move a variable to a target slot, change how
many locals are initialized before it.** Declaration position is irrelevant, which is why every
declaration-order sweep in this document came back byte-identical: the previous rounds were
permuting the wrong list.

Scope limit: measured with `= 0` initializers on address-taken `int`s. A local whose initializer
is a non-constant, or that is not address-taken, was not part of this sweep; the earlier
findings' null results for *deleting* locals still stand.

**Refined scope: the sequence is per *type pool*, not per function (round 858, isolated).**
Mixed a `char` and two `int`s, all address-taken and all assigned a runtime value:

```c
char sp; int a; int b;
a = src; sp = (char) src; b = src;
```
emits `a -> 0x8`, `sp -> 0x3`, `b -> 0x4`. The two `int`s follow the `0x8, 0x4` sequence (a
2-local run in their own pool) while the `char` is placed **independently** at `0x3`, packed
below them. So the init-order sequence applies **within each size class**, and a `char` among
`int`s does not consume an `int` position. Read the rule as: *for locals of the same size, the
j-th initialized takes the j-th slot of that pool's sequence*, not as a single function-wide
ordering.

**Tested at `CrashDumpUnhandledExceptionFilter` and it did not apply (round 858).** That function
is the one carrier whose frame differs from the reference (`sub esp,0x284` against `0x280`,
exactly one 4-byte slot), it has an address-taken `char space`, and its header records that
**8 declaration permutations** all leave the frame at `0x284`: the right control per this
finding, but the wrong list. Probed both movable things anyway: swapping `fCanContinue = 0;`
past `pCtx = ...` (byte-identical, obj 2115, `match` 643), and moving `space = ' ';` ahead of
the two `memcpy`s (`match` 643 -> **641**, frame still `0x284`). Reverted. The frame there is a
spill-count difference as its header says, not a slot-assignment one: this finding does not
reach it, and the "8 declaration permutations" note is still true, just for the wrong reason.

## Finding 53: callee-saved assignment can be an allocator tie-break that no C names

`gm_ObjectsAvailble` (0x10015f70): `slot_base` is `esi` on both sides, and the
two claimants are born at emitted indices 71 (`slot_cursor`, the query result)
and 77 (`slot = slot_base`).  The reference gives `ebx` to the 71-born and `edi`
to the 77-born; we do the reverse, and the match block's row/inner counters
follow mechanically because MSVC6 hands the free callee-saved pair out in
`ebx < esi < edi` order.  Birth order, use counts and spill timing are already
the reference's; ~600 probes across declaration order, types, scopes,
`register`, loop-guard rewrites and cursor splits never moved it.  Treat this
whole-function pair as a colourer fixed point: the Finding 12 lever (birth order
via named vs anonymous loads) does not reach it because the two birth indices
already match.

## Finding 54: strength reduction is decided by the value's uses, not by how the address is spelled

`gm_CheckInventoryCapacity` (0x10019ed0): the reference materialises a pointer
in `eax` (`mov eax,edi; add eax,ecx; ... mov al,[eax]`, no spill) while we fold
it to the SIB form and then spill a byte.  Eight address spellings (base
increment, separate pointer temp, `*(unsigned char*)`, fully inlined,
`(char*)((unsigned int)base+idx)`, `&base[idx]`) are byte-identical *to each
other*, which shows the fold is decided by that value's single use, not by the
expression.  The site is the "Ent-address shape" item in the
gm_CheckInventoryCapacity section above: this finding is the rule behind it.
`ahm_ExAllocAlchemist` (0x1000bdf0): every factorisation of a stride re-derives
the same `3,9,5,4` `lea` chain.  Same class as Finding 30 (`lea` vs folded table
load), Finding 32 item 2 and Finding 36.
`gm_AllocSpieler` (0x10018850): a round-250 inventory of "`add R,R` x4 against
`lea R,[R+R]` x4" no longer reproduces: the current diff holds exactly one
`lea`-vs-`add` pair (`lea edi,[ecx+ebx]` vs `add esi,ebx`, registers also
differing, inside the sympathy-loop register cascade) and zero self-`add`
sites.  The rule stands (a use-shape change is needed, not an address
respelling); the site count was drift, not ground truth.  Do not go looking
for four sites.

## Finding 55: the frame can be right while the slot map is not

`gm_AllocSpieler` (0x10018850) has the reference's `sub esp,0x41c` on both
sides, but our temporaries sit at `0x14/0x24/0x2c/0x30/0x38/0x40` where the
reference's stop at `0x28`, and the `work` buffer is addressed at `esp+0x34`/
`0x3c` against our `esp+0x38`/`0x40`.  An equal frame size is not evidence that
the slots are; check the slot offsets before concluding the frame is fixed
(contrast the frame-size oracle of Finding 26 / sim_PriorityUpdate, where the
size was the thing that diverged).

## Finding 56: a short object's out-of-line data is still misplaced even when the pad step fixes the following symbols

`scripts/pad_short_functions.py` appends a separate zero-filled `.text` to bring
an object up to its reference span, which keeps later symbols at their reference
VAs, but the object's *own* jump table and case map, which live after its code
inside the same object, stay at the wrong offset.  `vfs_OpenStream` (0x10009020)
was 8 bytes short of the reference's 701-byte real body; its 5-entry jump table
and 13-byte case map therefore sat 8 bytes early and every relocated entry
pointed one byte late, which was 22 of the 32 bytes of residue outside the named
functions.  Fixing the length (not the pad) was worth -36 linked.  The pad buys
the neighbours their VAs; out-of-line data inside the object needs the real
length.

**Amendment: a "length shortfall" misread when the trailing bytes are not
padding.** `CrashDumpUnhandledExceptionFilter`'s ~0x117 bytes after the final
`add esp,X; ret 4` are TWO switch jump tables (a 5-entry table with a 0x69-byte
index map for cases 0,1,0x67,0x68, and a 10-entry table with an 8-byte 0..7
index map for cases 0..7 plus 0x6e), not padding. Our two tables are emitted in
the opposite order from the reference's, which is downstream of the block
layout (`msvc6-c-shapes.md` §59); the built body is 11 bytes longer than the
reference's (`ret` at 0x10002e9e against 0x10002e99) and that 11 is absorbed by
trailing `0x09` padding, so the COMDAT span stays 2128 while the tables stay 11
bytes late. The general point: before treating a tail as padding, check whether
it is relocated table data. (`0x09` fill on this function, where others use
`0x90`, is the caveat already recorded under Finding 15.)

## Finding 57: reporting note: a per-function residue number is only comparable within one composition

Retired residue ruler. In this campaign "linked" meant the postlink
composition's per-function count. It is not current acceptance: the server
raw file matches the reference, and `scripts/gate.sh` is the whole-file check.
`split_link.sh`, `postlink_residual.py` and `linktest.sh` are retired.

Inside that composition, `postlink_residual` attributed differing bytes by
reference VA, so a symbol not exactly at its reference VA dragged its whole
window; 73 of 319 symbols were not exact. A candidate rejected in one
composition was sometimes a win in another. Only the total from a full
rebuild (`cmake --build`, then `scripts/split_link.sh`, then
`postlink_residual.py --write`) was comparable across those rounds, and
`scripts/linktest.sh` recompiled only the files it was named, so a run was
attribution only when no other source had changed since the last full build.
That sequence is the historical comparator. It is not a recovery step.

## Finding 58: inter-object size: the constraint is `have <= padded(want)`, and every real body *below* the reference span is free

The rule this campaign needed twenty rounds earlier, derived from the build's own
arithmetic rather than from argument.  It replaces an enforced rule that was
*strictly stronger than the composition requires* and that silently discarded
candidates.

**The quantities.**  `scripts/pad_short_functions.py` computes:

- `want` = the sum of the reference sizes of the functions an object defines,
  read from `src/rebrew-functions.toml`, i.e. the reference's *real* code
  lengths, **not** rounded to 16;
- `have` = the object's `.text` section size, which `cl` has already rounded
  **up to a 16-byte multiple**, so `have == 16*ceil(real_code/16)`.

It pads when `have < want`, by appending a separate zero-filled `.text` object of
`want - have` bytes; it reports `LONG` and does nothing when `have > want`.
The linker then aligns each `.text` contribution to 16.

**Consequence.**  An object's contribution to the composed image is
`max(have, 16*ceil(want/16))`.  The reference span is `16*ceil(want/16)`.  So:

> the composition is preserved **iff `have <= 16*ceil(want/16)`**, i.e. iff the
> real code length is at most the reference's *padded* span.

Everything shorter is padded up and lands on the right VA; the pad bytes are
zeros, so a short body costs residue **inside this function's own slot** and
nothing else.  Only a real body exceeding the padded span moves the symbols
after it.

**The measurement that establishes it.**  `cm_ExCopyEntityData` (0x1000ec00) has
`want`/reference size 912 (already 16-aligned), and its object's `.text` measures
912.  Its band is therefore *every* real code length `<= 912`.  The full boundary
set, measured by compiling one variant at each real-body length:

```
real 895 / 896      -> have 896 -> padded 912   neutral
real 897, 899, 900, 904, 905, 912 -> have 912 -> span 912   neutral
real 913, 917, 918  -> have 928 -> span 928     composition-breaking
```

**A lower bound does not exist.**  An earlier note in this campaign recorded the
admissible band as `[897, 912]`; 897 was merely the lowest value a probe had
tested.  Any real body at or below the padded span is composition-neutral: a
shorter body is padded, not rejected.  The reason to prefer a body *near* the
span is residue, not layout, and that is a different argument.

**The admissibility test is `have <= padded(want)`, NOT "the COMDAT is
unchanged".**  The two differ in exactly the downward direction, and the
distinction is worth a sentence because the tighter form is the one that gets
re-derived by anyone reading only the `cl` behaviour: a real body of 895 or 896
does drop the COMDAT to 896, and that *is* a bucket crossing, but the pad step
then appends 16 zero bytes and the span is 912 again.  So a bucket crossing
**downward** is recovered automatically and costs only residue inside this
function's own slot; a bucket crossing **upward** is the one thing the pipeline
cannot undo, because a longer object cannot be cut without losing code.  Compare
`have` against `16*ceil(want/16)`; do not compare it against the previous
`have`.

**The `LONG` list is mostly noise: filter it before believing it.**  Because
`have` is 16-aligned and `want` is not, the pad step labels every object whose
reference size happens to be unaligned as `LONG`.  A dry run today reports **149
of 319** objects too long, including trivial false alarms: `gm_NoopRet2.c.obj:
16 > 1 (+15)`, a one-byte function whose `have` is necessarily 16.  The signal is
**not** `have > want` but `have > 16*ceil(want/16)`.  The genuine drags are the
handful where that holds (`spiel622.c.obj: 2608 > 2496`, `spiel62.c.obj: 1408 >
1328`), and those are what move symbols off their reference VAs.

**Two rules, and confusing them is the error.**

| what moves | binding quantity | bites |
|---|---|---|
| the following symbols' VAs | **padded** span: `have <= 16*ceil(want/16)` | inter-object, the rest of the image |
| *this* object's own jump table / case map | the **real** body length | intra-object (Finding 56) |

Finding 56 is the intra-object row: `vfs_OpenStream`'s 8-byte real-body shortfall
put its own jump table and case map 8 bytes early and was worth -36 linked, and
no amount of padding could fix it, because the pad lands *after* the tables.
This finding is the inter-object row.  Applying either rule where the other binds
is as wrong as applying neither.

**How to tell which applies**, in order:

1. Does the object carry relocated data after its code: a jump table, a case
   map, anything the object's `.reloc` entries point into past the last
   instruction?  If **yes**, the real length binds (Finding 56) and the padded
   band does not apply.  `CrashDumpUnhandledExceptionFilter`'s two switch jump
   tables are the standing example.
2. If **no**, the padded band applies, and it is cheap to confirm: compile two
   variants whose real code lengths differ by a few bytes and read the object's
   `.text` size.  Unchanged ⇒ same bucket, the edit is layout-free.  Moved ⇒ you
   crossed a boundary upward and the composition changes.

**Operational rule.**  Never reject a candidate on a few bytes of real-body
drift alone.  Compare `have` against `16*ceil(want/16)`; only exceeding it is a
size rejection.

### Correction to Finding 15's amendment

Finding 15's amendment concludes: *"A candidate can therefore change the linked
section size, and move every symbol after it, while every tool reports the size
as unchanged."*  **The inference is inverted and should not be relied on.**  Its
premise is correct: every real length 3681..3696 in `gm_AllocSpieler` (0x10018850)
does report object size 3696, so the reported object size does not reveal the
real body length.  But the conclusion does not follow: `have` is a function of
the real length alone (`16*ceil(real/16)`), so *if the reported size is unchanged
then `have` is unchanged, and the span is unchanged with it.*  All of 3681..3696
give `have` 3696 against `want` 3689, `16*ceil(3689/16)` = 3696: layout-identical
in every case.  A genuine bucket crossing is *visible* in this tool: 3696 -> 3697
reports 3696 -> 3712.

What the amendment is reaching for is real but belongs to the other rule: the
aligned object size cannot tell you whether a candidate changed the **real** body
length, and that is the quantity that matters for **intra-object** table
placement (Finding 56) and for the upward bucket test.  Use it for those;
do not use it to infer that a layout moved when the number did not.

This matters beyond tidiness: the amendment's inverted reading, together with the
missing lower bound, is what produced the over-strict "real body must equal the
reference's real body" rule that rejected admissible candidates (see the
`cm_ExCopyEntityData` `do/while` case, real 900 -> 904, retracted in round 242).

## Finding 59: relocation accounting: `matched` under-counts, because msvc6 relocates memory operands but not absolute immediates

The complement of the "unreachable bytes" note, and the reason the **linked residue, not any
object metric, is the only measure**: this is the mechanism behind that rule.

Measured on `ServerMainThread` (0x100093a0). Its COMDAT carries 56 relocations: 14 `DIR32`
plus 42 `REL32`. **Every `DIR32` site is a memory operand** (`call dword ptr [0x...]`,
`mov [0x...],r`, `mov r,[0x...]`). An absolute address used as a plain immediate carries
**no** relocation at all: `push 0x101de9a0` and `mov r,0x101deb00` are pre-baked against
the preferred base.

The reference is the other way round: its `.reloc` has **128 HIGHLOW entries inside the same
2434-byte window** (mask 512 bytes against our 224). So for ~288 bytes the reference
*relocates* a slot where we emit a pre-baked constant, and the honest metric, which refuses
to match a byte the reference relocates but we do not, cannot count them, even though our
value is already byte-correct in the linked image.

Two consequences:

- **`matched` is pessimistic on such a function, and `matched-reloc` is optimistic.**  On
  `ServerMainThread` they read 1521 and 2149 of 2434, and neither is the truth; the raw
  positional residue (395 differing bytes, 250 of them non-call) is.  `matched` will never
  approach the size there, so a low `matched` is not evidence of a large codegen error.
- **Do not read "`matched-reloc − matched` = unreachable bytes" as "give up on them."**  An
  earlier note of mine called that a metric wall on `gm_AllocGebaeude`; the mechanism is
  right but the conclusion is too strong.  What the gap means is that *we reach a global by
  a route the reference does not use there*: an absolute address where the reference has a
  register already holding it, or vice versa.  That is a real codegen difference, and its
  fix (if any) is to find the addressing route, not to edit the relocation.

Also measured here and worth keeping: a `matched` ceiling computed from one side's relocation
count tells you about *our* encoding, not about the reference's, so it must be computed per
side (the reference's `.reloc` HIGHLOW count inside the window is the other half).

`src/Develop/DieGildeAddOnServer/server_c/ServerMainThread.c`

## Finding 60: reading out the frame slot map with sentinel initials (an instrument)

A slot-map question ("which of our locals got `[esp+0x14]`?") can be answered directly
instead of inferred. Replace each address-taken local's initialiser with a **distinct
constant** and compile:

```c
resolved_dynamic = (short*) 0x11;   /* ... 0x22, 0x33, ... for each local */
```

Each emits `mov dword ptr [esp+N], 0x..`, so the constants read back the per-variable slot
map in one compile. Measured on `cm_ExSellObjekt` (0x1000d930): ours is
`source_dynamic_entity`@0x14, `resolved_dynamic`@0x18, `dest_existing_entity`@0x20,
`dest_dynamic_entity`@0x1c: the reference is exactly the reverse within each pair.

That measurement then settled the diagnosis: **the swap is a pure colorer choice.**  Total
access counts per slot are identical on both sides, and every block that reads a slot reads
the *same logical value* as the reference.  So it is a same-value/different-offset
difference throughout, and **no bytes can be won from it directly**: it only moves the
downstream displacement.  Separately confirmed inert there: swapping the two declarations,
and all eleven rotations of the `= 0` initialiser block (ten byte-identical, the eleventh
moves the object but not the slot map).  Use the sentinel probe before spending probes on
declaration or statement-order spellings.

`src/Develop/DieGildeAddOn/command/command_c/cm_ExSellObjekt.c`

## Finding 61: `volatile` on a local is a per-variable fixed point, not a general register-eviction knob

On `cm_ExSellObjekt` (0x1000d930) the committed `*(volatile uint*)` cast on the log
buffer's field is a local optimum on all three of `matched`, object size and instruction
count simultaneously.  Qualifying a neighbouring local instead does not preserve it:
`source_dynamic_ref` as `short* volatile` gives `matched` 552 with `aligned` 477 but pushes
the object to **2080** (an upward bucket crossing, i.e. composition-breaking);
`source_dynamic_entity` qualified gives 413 with object 2048; removing the existing cast
gives 609 at 2048.  So `volatile` is not a dial: each qualification is its own fixed point,
and moving it between locals moves the frame.

This is the practical caution for the `volatile`-at-use-site lever generally: it works
(section 71 of the shapes doc, and the round-143 `ls_` win), but it is *per variable*, so a
sweep that qualifies "the same kind of thing" elsewhere will not transfer.

**Amendment to Finding 59 (round 248): the dominant term in `matched`'s one-sided gap is REL32 *call*
relocations, not DIR32 data addresses.**  Finding 59 above attributed the gap to msvc6
relocating memory operands but not absolute immediates.  Measured on two more functions, the
larger term is simpler: **every `call` to a local function carries a COFF `REL32` in our
object, while the linked reference has no `.reloc` entry there at all**, so those four bytes
per call can never be counted by `matched`, no matter what the source says.

Measured from the object's relocation table against the reference's `.reloc`:

| function | ours-only bytes | of which REL32 calls | reference-only bytes | `matched` ceiling |
|---|---|---|---|---|
| `ahm_ExAllocAlchemist` (0x1000bdf0) | 74 | 52 (13 calls) | 70 | 858 |
| `vfs_OpenStream` (0x10009020) | 39 | 28 (7 calls) | 31 | 597 |
| `srv_LoadBuf` (0x1000a570) | 100 | n/a | n/a | 701 |

So on `ahm_ExAllocAlchemist` the ceiling (858) equals its *current* `matched-reloc`, i.e. the
object already matches everything it can; and `vfs_OpenStream` has 207 bytes of headroom that
no code edit will move.  **Read this as headroom, not as a target**, and compute it before
deciding that a low `matched` means a large codegen error.

**Amendment (round 255): numbers for the `matched` ceiling, and two functions where the entire
shortfall is accounting.**  Computing the ceiling per window from the reference's HIGHLOW count,
against our one-sided slots:

| function | reference HIGHLOW in window | ceiling | HEAD `matched` / `matched-reloc` |
|---|---|---|---|
| `vfs_ReadCompressed` (0x10008a90) | 0 | 492 | 447 / 467 |
| `cm_ExProdObjekt` (0x1000e140) | 13 | 980 | 888 / **980** |
| `cm_ProcessCommandQueue` (0x1000aac0) | 15 | 624 | 584 / **624** |

On the last two, `matched-reloc` already **equals** the ceiling, so their entire remaining
`matched` shortfall is one-sided relocation accounting and **zero** of it is codegen work.  That
is the sharpest form of this finding: compute the ceiling first, and a function can be finished
as far as any code edit can take it while its `matched` still looks far from the size.

## Finding 62: the ebx/edi rotation is unsteerable by construction (round 307)

On `gm_ObjectsAvailble` (0x10015f70) the (row, base, inner) triple homes as
(esi, ebx, edi) where the reference has (ebx, edi, esi), with identical kernel
bytes and `base` shared in edx on both sides: only the three outer homes
rotate. Declaration order, local removal, pressure pads, and volatile-homing
each member are all inert or worse (volatile row/inner collapse the function).
The IL is isomorphic. Declaration order, local removal, pressure pads, and
volatile-homing were inert or worse on this triple. That is the measured set,
not a proof that no later spelling can move it.

## Finding 63: slot homes are canonicalized; live-set cardinality does not move them (round 361)

On `cm_ExSellObjekt` (0x1000d930) splitting a live local is coalesced to
byte-identical output, and dropping either of two pointer locals worsens
identically (609/855/442, obj 2048) without touching the [esp+0x18]/[esp+0x14]/
[esp+0x20]/[esp+0x24] permutation. Declaration reorder is likewise identical.
The permutation is driven by declaration/type mix or call-sequence pressure
outside the live set: changing which values are live in either direction
does not move it.

**Round 933 pinned the divergence down instruction-by-instruction and confirmed the
closure.** Aligning the two bodies shows **674 instructions on each side** (so nothing
is missing), with the first difference at index 14: eight consecutive `mov [esp+N],edi`
zero-stores, identical in mnemonic, order and count, differing only in the slot number:

| store | reference | ours |
|---|---|---|
| 1 | `+0x10` | `+0x10` |
| 2 | `+0x14` | `+0x24` |
| 3 | `+0x2c` | `+0x30` |
| 4 | `+0x18` | `+0x14` |
| 5 | `+0x20` | `+0x1c` |
| 6 | `+0x28` | `+0x28` |
| 7 | `+0x30` | `+0x2c` |
| 8 | `+0x1c` | `+0x18` |

This is **not** a permutation of a fixed slot set: the reference uses `0x20` where we use
`0x24`, so one local occupies 4 bytes more in our frame and the rest shift around it.

**Round 959 read the full table and corrected that last inference.** Both sides emit the **same eight
stores in the same order**; only the slot assigned to each differs:

| store # | reference | ours |
|---|---|---|
| 1 | `0x10` | `0x10` |
| 2 | `0x14` | `0x24` |
| 3 | `0x2c` | `0x30` |
| 4 | `0x18` | `0x14` |
| 5 | `0x20` | `0x1c` |
| 6 | `0x28` | `0x28` |
| 7 | `0x30` | `0x2c` |
| 8 | `0x1c` | `0x18` |

The reference's slot **set** is `{0x10, 0x14, 0x18, 0x1c, 0x20, 0x28, 0x2c, 0x30}` and ours is
`{0x10, 0x14, 0x18, 0x1c, 0x24, 0x28, 0x2c, 0x30}` -- **the same set except that we use `0x24` where
the reference uses `0x20`**, and the store *order* is the same while the slot *assigned to each store*
differs. So the correct statement of the divergence is: one local lands in a different slot and the
remaining seven are permuted around it. The earlier "one local occupies 4 bytes more" phrasing is not
supported by this table -- all eight stores are pointer-width writes to pointer-typed locals, so the
widths are uniform -- but the `0x20`/`0x24` difference itself is real and is the only slot the two sets
do not share.

**Moving the one non-pointer statement out of the run is inert**: `*(int*)(cmd + 0x1a) =
g_next_object_id;` relocated past the eight initialisers produces a **byte-identical** object: same
addresses, same slots, same order (round 959).

**But reordering the eight *initialisers* is NOT inert, and that corrects this Finding's headline**
(round 960). Two permutations were compiled and the slot assignment moved both times:

| order of the eight `= 0` initialisers | slots emitted, in store order |
|---|---|
| shipped order | `0x10, 0x24, 0x30, 0x14, 0x1c, 0x28, 0x2c, 0x18` |
| ascending-by-our-slot | `0x30, 0x28, 0x14, 0x10, 0x1c, 0x24, 0x2c, 0x18` |
| ascending-by-target-slot | `0x10, 0x30, 0x28, 0x14, 0x24, 0x1c, 0x2c, 0x18` |

| reversed | `0x28, 0x1c, 0x14, 0x30, 0x24, 0x10, 0x2c, 0x18` | **8,630** (+2) |

So **the initialiser sequence is a live lever on the slot map**, contrary to "declaration reorder is
likewise identical" above. What is closed is the claim of *inertness*; the axis itself is open. Three
permutations measured, **all three losses**, none reproducing the reference's assignment.

**Round 962 separated declaration order from initialiser order on the two variables actually rotated
(`dest_owner_entity` and `resolved_dynamic`, adjacent declarations at lines 240/241 whose slots `0x20`
and `0x24` are the only two the sets do not share):**

| probe | object | slots emitted | residue |
|---|---|---|---|
| swap the two **declarations** | **byte-identical** to shipped | unchanged (`0x24` first) | 8,628 |
| swap the two **initialisers** | changed | rotated | **8,629** (+1) |

So the distinction is sharp and worth stating: **declaration order is inert here, the initialiser
sequence is not** -- which is exactly consistent with the table above and explains why Finding 63's
declaration-reorder sweep came out flat while this axis moves. The shipped order is nonetheless kept,
because every alternative measured is a loss.

**Round 964 swept the axis, round 965 corrected the premise it ran on -- and the correction matters more
than the sweep.**

**First, the table above is incomplete: the run is NINE stores, not eight.**

```
reference  0x10, 0x14, 0x2c, 0x18, 0x20, 0x28, 0x30, 0x1c, 0x24
ours       0x10, 0x24, 0x30, 0x14, 0x1c, 0x28, 0x2c, 0x18, 0x20
```

Both sides use **the identical nine-slot set**, and in fact `{0x10, 0x14, ..., 0x30}` -- the contiguous
dwords, all nine. The two sets are **equal** (checked by sorting). So the reading given above and in round
959, "we use `0x24` where the reference uses `0x20`", was an artefact of truncating the run at eight
stores; there is no missing or extra slot, only a different **assignment order**.

**Second, the nine-slot divergence is a pure order permutation, and the reference's order is ascending.**
Our nine assignments are a shuffle of the same nine dwords.

**Third, all nine initialisers participate.** Moving `source_existing_entity` -- the one variable the
round-964 sweep held fixed -- to the front of the run changes the first emitted slot from `0x10` to
`0x2c`. So the sweep's 5,040-point negative covers only **eight** of the nine participants and therefore
does **not** close the axis; it closes the seven-variable sub-space it actually enumerated. The full space
is 9! = 362,880, about 85 hours at the measured 0.85 s per compile, which is why it was not enumerated.

**What is settled:** the divergence is an assignment-order permutation of a fixed nine-slot set; every
participant is steerable; and the sub-space swept (5,040 orders) contains no solution. **What is open:**
the remaining 357,840 orderings, which need a smarter search than brute force.

**Round 966 ran that smarter search and mapped the landscape.** A hill-climb over adjacent transpositions,
scoring by **positions matching the reference's nine slots** (read from the compiled object, 0.85 s per
candidate), starting from the shipped order:

```
start score 2
  swap(1,3) -> 3   0x10,0x14,0x30,0x24,0x1c,0x28,0x2c,0x18,0x20
  swap(2,7) -> 5   0x10,0x14,0x2c,0x24,0x1c,0x28,0x30,0x18,0x20
  local optimum at 5
```

**So the shipped order scores 2 of 9 and a 5-of-9 ordering is reachable by two transpositions** -- the
landscape is not flat, and the axis is searchable. But the climb stops at a strict local optimum, and a
multi-restart version was **abandoned on cost**: each restart is ~36 candidates per sweep with ~28
accepted moves at 0.85 s, roughly a quarter of an hour, so 25 restarts is impractical in a round.

**Round 967 sampled the map instead of searching it, and that CLOSES the ordering hypothesis on a
structural argument, not an exhaustion one.** Sixty random orders were compiled and their slot runs read
back. Two invariants hold in every sample:

```
position 7 of the nine-initialiser run -> ALWAYS 0x18
position 8                              -> ALWAYS 0x20
positions 0..6                          -> any slot EXCEPT 0x18 and 0x20
```

**So `0x18` and `0x20` are not free slots in this run: they are pinned to its last two initialisers.**
The reference's assignment is `0x10, 0x14, 0x2c, 0x18, 0x20, 0x28, 0x30, 0x1c, 0x24` -- it puts `0x18` at
**position 3** and `0x20` at **position 4**. That is unreachable by *any* permutation of this run, which is
why the 5,040-order sweep (round 964) and the hill-climb (round 966, 2/9 -> 5/9 then stuck) both failed:
**the axis was never a pure permutation.** Sixty random orders produced sixty distinct assignments with a
maximum positional score of **2 of 9**, and none matched.

**The conclusion is that the reference's `0x18`/`0x20` are claimed by something other than the 8th and 9th
initialisers of our run** -- a different variable, a different declaration, or a different statement
grouping in the original. The ordering axis is **closed**; further permutation is provably futile, and
the search should move to *what occupies those two slots* rather than *in what order the initialisers
appear*.

**Round 968 located that difference precisely, and it is not the zero-store run at all.** The first
divergence the ordering work was chasing is at **`0x1000d986`**, and reading the surrounding call shows it
is the **address of a call argument**:

```
                     reference        ours
0x1000d986  lea ecx, [esp + 0x2c]   [esp + 0x28]
0x1000d98e  lea edx, [esp + 0x20]   [esp + 0x20]   <- IDENTICAL
0x1000d993  lea eax, [esp + 0x40]   [esp + 0x3c]
0x1000d999  call 0x10015e90                        <- gm_ResolveEntityById
```

The **middle argument's address is identical on both sides**; the 1st and 3rd differ by exactly **4 bytes**.
The call's arguments are `&source_existing_entity`, `&resolved_dynamic`, `&source_static_entity` -- three
**address-taken** locals, and the middle one is the only one whose slot matches.

**So the divergence is an address-taken-slot layout difference, and it is a different mechanism from the
zero-store run.** Round 967's pinned `0x18`/`0x20` are downstream of it, not the cause: our extra dword
sits between `0x20` and `0x28`, which is exactly the `0x24` slot the run showed pinned to
`source_container_ptr`.

**And the initialiser axis does not reach these slots.** Moving `source_static_entity`'s initialiser to the
front of the run (round 968 probe) leaves all three `lea` addresses **unchanged** (`0x28`, `0x20`, `0x3c`).
That is consistent and worth stating: the zero-store run's order steers *those* stores, while
**address-taken locals are allocated by a different rule**. Chasing the run's order cannot fix an argument
address.

**Round 969 counted slot use across the whole frame to find the extra dword, and the answer is a
measurement trap rather than a finding.** A per-slot frequency table over the 674 instructions shows
`0x34` and `0x3c` used **only by us** and `0x40` only by the reference -- which looks like a missing or
extra stack slot. It is not:

- **`[esp+N]` displacements are not comparable across the two images**, because `esp` moves. The file's
  own round-182 note already records this for exactly these two sites: *"tracking esp depth through the
  pushes, the reference's `[esp+0x44]` and our `[esp+0x3c]` are both frame+0x468"* -- **the same physical
  slot written two ways.** The `0x34`/`0x40` pair is the same story.
- So the two `lea` sites at `0x1000d986`/`0x1000d993` are argument addresses whose *displacements* differ
  partly because the pushes between them differ, not because the frame has a different number of locals.

**Corollary for this file and generally: compare frame slots after normalising esp depth, or compare
against the frame base -- never by the raw `[esp+N]` literal.** A raw displacement table will show phantom
differences at every site that sits on a different push depth, which is most of them.

**Method that made this affordable, and worth reusing:** the full link cycle costs minutes per candidate,
but an initialiser permutation only needs the **single translation unit compiled to an object** -- 0.85 s,
read back with a small `.text` scanner that extracts the consecutive `mov [esp+N],edi` stores. A 5,040-point
sweep took ~70 minutes in the background instead of days. **Before declaring a permutation axis
infeasible, check whether the metric can be read from the object rather than the link.**

**And the divergence is smaller than "a permutation" suggests.** Counting uses of the two slots the sets
do not share, over the whole 674-instruction body:

| | `[esp+0x20]` | `[esp+0x24]` |
|---|---|---|
| reference | 7 | 3 |
| ours | 5 | 4 |

Both slots are live on both sides, so no variable is missing: it is a **three-reference rotation**
between two adjacent dwords. That is the precise target if this row is revisited, and it is much
narrower than the eight-store table implies.

**Method note:** this is why a score read from one ruler is not a result. The residue went **up** by one
byte and the hex `0x21b4 -> 0x21b5` was briefly read as a gain; `gate.sh`'s baseline comparison, not the
transcription, is authoritative.

**And the one structural candidate is now measured rather than argued.** The file models
`log_buffer` as a synthetic `struct SLogBuffer { uint weight_fraction; char text[512]; }`
whose leading dword is never read as a member but reserves the reference's 4-byte hole.
That construct was invented to reproduce `sub esp,0x228`, so it deserved a probe:
replacing it with a plain `char log_buffer[512]` plus a separate `uint weight_fraction`
local (semantically identical) drops the frame to `sub esp,0x224`: proving the leading
dword is what allocates the hole, and measures **residue 8,633 -> 8,642 (+9)**. Reverted.
The synthetic aggregate is load-bearing, exactly as the file claimed; the `0x20`/`0x24`
difference is not reachable by un-modelling it.

## Finding 64: the callee-saved home order is a fixed invariant of *value count*, not of anything in the source (round 846, isolated)

Finding 63 says declaration reorder is inert on a real body. Rebuilt the shape in isolation
(`.scratch/epi/`, the round-844 testbed: a three-accumulator loop around one call) and swept
every variable that could plausibly steer it. **All of them are inert, and the homes are
identical every time.**

| varied | result |
|---|---|
| declaration order, 6 permutations of `row`/`base`/`inner` | `xor ebp,ebp` / `xor ebx,ebx` / `xor edi,edi`: identical |
| first-use order in the loop, 3 permutations | identical |
| use multipliers in the tail (`1,2,3` / `3,2,1` / `2,3,1`) | identical |
| a call placed before the initialisers instead of only inside the loop | identical |

In this SP6 testbed, declaration order, first use, use weight, and initialiser
position did not move the homes. For three call-crossing accumulators in the
listed shape, every permutation homed them `ebp`, `ebx`, `edi` in that order.
That is the testbed result, not a rule to quote for every function.

**Cardinality is the variable that does move it.** With four accumulators the zeroing
becomes `xor edi,edi` / `xor ebp,ebp` / `xor ebx,ebx`: a different order, and `esi` takes a
role. Consistent with Findings 62/63: the rotation seen *between two functions* is the same
rule evaluated at a different live-set size, not noise and not a colourer whim.

**Consequence for the walled rows, and why this does not close them.** If the reference
homes a triple `(ebx, edi, esi)` where we home `(esi, ebx, edi)` at the *same* cardinality,
the difference is upstream of the homes: cardinality, call pressure, or the kernel.
The sweep above says the listed namings did not reach it. Recorded so that
testbed is not re-swept as if it were unmeasured.

Probe recipe: `.scratch/epi/b2.sh` (one `cl` call through the msvc6 image) plus
`objdump -d | grep 'xor +%e'`. Three accumulators around a `sink(i)` call reproduce the
whole family in under a minute.

## Finding 65: the accumulator homes are decided by *role competition for `esi` and `edi`*, not by cardinality (round 847, isolated)

Finding 64 said cardinality moves the homes. It does, but cardinality is a proxy: the
immediate cause is **which loop role claims `esi`/`edi` first**. Disassembled the family end
to end; the roles are accumulator(s), the induction counter, and the array walker (MSVC6
strength-reduces `t[i]` into a walking pointer).

| shape | homes | spill |
|---|---|---|
| 2 accumulators + `int i` counter | `a->ebx`, `b->ebp`, `i->esi`, walker `edi` | **none**: all four callee-saved, one per role |
| 3 accumulators + `int i` counter | `b->ebx`, `c->ebp`, walker `esi`; `a` in a stack slot | **one**: `mov 0x14(%esp),%ecx` in, `mov %ecx,0x10(%esp)` out, every iteration |
| 3 accumulators, pointer-driven (`while (p < end)`) | `a->ebx`, `b->ebp`, `c->edi`, walker `esi` | none |

So the homes do not rotate because the live-set got bigger; they rotate because the walker
takes `esi`, **and with only `ebx`/`ebp`/`edi` left for three accumulators one must go to
memory**. Which one spills is what changes the visible assignment.

**This is checkable and it explains the walled rows.** Read the reference: if it keeps its
accumulators all register-resident and the candidate spills one, the divergence is the
**role that owns `esi`**, not the accumulator names, and per Finding 64 no renaming reaches
it. The reachable question is only whether the *walker* or the *counter* is the value that
holds `esi`, which is a loop-shape decision (shapes §8), not a naming one.

**Round 972 checked the zero-branch-difference carriers from the round-971 census and they are all this
class.** `gm_ObjectsAvailble` (25 residue, 0 branch-target differences) diverges at index 73 and the
divergence is a **consistent `ebx`/`edi` role exchange**:

| index | reference | ours |
|---|---|---|
| 73 | `test ebx, ebx` | `test edi, edi` |
| 77 | `mov edi, esi` | `mov ebx, esi` |
| 80 | `mov ax, word ptr [edi]` | `mov ax, word ptr [ebx]` |

Both sides are 235 instructions; the roles are simply exchanged. The carrier's header already records it
as residue and lists what was tried -- *"declaration order, hoist positions, extra-copy and cursor splits
all inert"*, and *"up/down/indexed/derived-def and decl-order variants all keep our roles"* -- which is
this Finding's mechanism, and it is why the file's residue has resisted. **So a carrier with zero
branch-target differences and a register-only divergence is a Finding 62/63 case, not a placement case.**

**Scope limit: this does NOT explain Finding 62's rotation (checked, round 847).**
`gm_ObjectsAvailble` (0x10015f70) is the case Finding 62 records as `(esi, ebx, edi)` against
the reference's `(ebx, edi, esi)`. Disassembled its prologue: `esi` there holds the **address
of a local array** (`mov dword ptr [esp+0x18],0x92` … `call gm_StartFilteredEntitySearch`),
not a walking pointer and not a loop counter. So the competition this finding describes is
not the one operating in that function. Do not cite this finding as the cause of the
`gm_ObjectsAvailble` rotation. That mechanism was still unidentified in round 847.
Finding 62 records the probes that were inert there, not a permanent stop.

**Negative result worth keeping:** the number of `push` instructions is **5 for every n from
1 to 6**: the compiler always saves the same set and never grows it. Counting pushes is
therefore not a cardinality signal, and an early attempt in this round read the `pop` mirrors
as extra pushes and got a flat 5 for the wrong reason. Count the *body*, not the file.

Probe recipe as Finding 64, plus: to see a spill, grep the loop body for the same
`0xNN(%esp)` slot appearing as both a load and a store.

## Finding 66: `CrashDump`'s 2-register frame difference is FOUR deferred restores, not a prologue shape (round 992)

> **Superseded (round 1145):** the deferred save is reproducible from C: early exits that `return` instead of jumping to shared exit code (see `msvc6-c-shapes.md` section 200).

Round 927 recorded the sharpest prior statement of this carrier's first divergence: *"the frame difference is
2 extra callee-saved registers, not merely 4 stack bytes"*: the reference is
`sub esp,0x280; push ebp; push esi`, ours is `sub esp,0x284; push ebx; push ebp; push esi; push edi`.
Round 992 located **where the reference's `ebx`/`edi` actually live**, and it is not the prologue.

**The reference saves `ebx`/`edi` at `0x1000282c` (~190 bytes into the function) and restores them at four
separate sites:**

```
0x1000282c  push ebx
0x1000282d  push edi          <- deferred save, once
...
0x10002dac  pop edi
0x10002dad  pop ebx
0x10002dae  jmp 0x10002e66    <- restore site 1

0x10002de5  pop edi
0x10002de6  pop ebx
0x10002de7  jmp 0x10002e66    <- restore site 2

0x10002e17  pop edi
0x10002e18  pop ebx
0x10002e19  jmp 0x10002e66    <- restore site 3

0x10002e49  pop edi
0x10002e4a  pop ebx
0x10002e4b  jmp 0x10002e66    <- restore site 4
```

**All four restores are immediately preceded by `call dword ptr [0x10024010]` (`CloseHandle`)** and all jump
to the common exit `0x10002e66`. Our build instead saves both registers in the prologue and emits a single
interleaved epilogue (`pop edi; pop esi; pop ebp; pop ebx` straddling `test eax,eax` at `0x10002e68-0x10002e6d`).

**Why this matters and what it changes.** It converts "2 extra callee-saved registers" from a *frame
observation* into a **liveness fact**: in the reference, `ebx` and `edi` are live only across the region
between `0x1000282c` and the four `CloseHandle` cleanups, i.e. across the mini-dump walk and its error
paths. Our C keeps whatever holds `ebx`/`edi` live across the whole function, so msvc6 allocates them at
entry. §81's two named levers are exactly this; the new information is that the **restore count is four and
they all sit on `CloseHandle` sites**, so the liveness window is bounded by the cleanup paths, not by the
frame.

**Not yet reachable from source.** The carrier is at its span (2128 = reference span exactly, verified this
round), and shapes §81 records 8 declaration permutations and 11 flag combinations already exhausted, with
the round-174 attempt that hit `0x280` exactly losing **+66**. Recorded so the next attempt starts from the
liveness window rather than from the frame number.

**Measured this round:** no source edit; residue 8,628 unchanged.

## Finding 67: `CrashDump`'s deferred save is a REGISTER-ROLE assignment, and the header's −2 is stale (round 993)

> **Superseded (round 1145):** the deferred save is reproducible from C: early exits that `return` instead of jumping to shared exit code (see `msvc6-c-shapes.md` section 200).

Finding 66 established that the reference saves `ebx`/`edi` at `0x1000282c` rather than in the prologue.
Round 993 located the cause, and it is not a save placement.

**The two builds give the same value to different registers:**

| | reference | ours |
|---|---|---|
| `hDbgFile` = `CreateFileA(...)` result | **`mov ebp, eax`** @ `0x1000281d` | **`mov edi, eax`** @ `0x1000281f` |
| the save pair | `push ebx; push edi` @ `0x1000282c`, *after* the CreateFile result is in ebp | `push ebx; ...; push edi` in the prologue |

The reference parks `hDbgFile` in **ebp** and frees **edi** for its later, separate use (`mov edi,
[0x10024034]` at `0x1000282e`, then `call edi` at `0x10002843`/`0x10002880`). We occupy `edi` with
`hDbgFile` from byte ~0xAF onward, so msvc6 must save it at entry.

**Probed, and the role is not steerable.** Giving `hDbgFile` a tighter C scope (a block-local alias so its
live range ends before the walk) measures **+0: byte-identical**. msvc6 folds the alias and keeps the same
allocation, which is §1's standing result for this class.

So Finding 66's "liveness window" reading is correct but not actionable: the window is real, and the choice
of *which* register holds `hDbgFile` is the compiler's.

**Header correction.** `CrashDumpUnhandledExceptionFilter.c:139-142` records a round-129 lane:

```
 * Round-129 lane: moving `nFrames = 0x800;` from
 * above `/* Stack walk */` to just before `for (;;) {` (semantically
 * neutral single pre-loop store): object +2/+2 both rulers, linked
 * 1597 -> 1595 (-2, confirmed after full rebuild).  Kept for the bytes.
```

**Re-measured this round: +30, not −2.** Applied exactly as described (store moved from its position in the
`hCrashLog != -1` block to immediately before the walk loop): residue **8,628 → 8,658**. Reverted. The note's
`1597 -> 1595` describes a tree state from before the round-110 span fix and the round-180 corrections; the
tree has since moved to 1,583 for this carrier and the same edit now costs 30 bytes.

This is the **fourth** stale-header delta found in four rounds (982: −53 → +505; 985: "bankable" → span
overflow; 986: 11 → +343; 993: −2 → +30). See workflow-traps §14: the rule stands, and this carrier's
header is not exempt from it despite being the most carefully maintained in the tree.

### Finding 67 addendum: the swapped pair is `ebp`/`edi`, and three probes confirm no C lever (round 994)

Finding 67 named the mechanism but not the full pair. Round 994 pinned both registers and tested every
plausible C lever.

**The two builds have exchanged the roles of `ebp` and `edi`:**

| value | reference | ours |
|---|---|---|
| `hDbgFile` (CreateFileA result) | **`ebp`**: `mov ebp,eax` @ `0x1000281d`, tested at `0x1000281f` | `edi` @ `0x1000281f` |
| `[0x10024034]` (function pointer, `call`ed at `0x10002843`/`0x10002880`) | **`edi`**: `mov edi,[0x10024034]` @ `0x1000282e` | `ebp` @ `0x1000282e` |

Non-push/pop uses: reference `ebp` 6 sites (`0x1000281d`..`0x10002f18`), ours 8; the first use of each
register is exactly the other's variable.

**Three probes, all measured at the link:**

| probe | delta |
|---|---|
| swap `hProcess`/`hDbgFile` declaration order (header says 8 permutations were tried; this is the pair that matches the reference's *first-use* order) | **+0**, byte-identical |
| block-local alias giving `hDbgFile` a shorter live range (Finding 67) | **+0**, byte-identical |
| hoist `hProcess = GetCurrentProcess()` above `CreateFileA` so `hProcess` is assigned first | **+109** (8,628 → 8,737) |

The third is worse for a semantic reason, not a codegen one: `GetCurrentProcess` would then execute on paths
the reference does not call it on. The first two are byte-identical because msvc6 folds the aliases.

**Conclusion, and it is the same as §1's.** Which of two same-typed pointers receives `ebp` versus `edi` is
decided by the allocator's own heuristics over the whole function's live ranges. Declaration order does not
reach it, scope does not reach it, and the one construct that changes the order (`GetCurrentProcess` earlier)
also changes the program. This row is closed as an allocator wall, with three measured attempts recorded so
it is not re-probed.

**Measured:** all three reverted; residue 8,628 unchanged; `src/` unmodified.

## Finding 68: register PRESSURE matches on all 19 carriers; the residue is pure register CHOICE (round 1004)

Section 16 of `codegen-walls.md` measures the residue as 67.5% register-role. That classification rests on an
assumption worth testing directly: is the difference in *which register* a value gets, or in *how many*
registers the function needs? Only the second is addressable from C, because it is live-range pressure.

**Measured: the callee-saved save sequence, per carrier, reference vs ours:**

| carrier | reference | ours | |
|---|---|---|---|
| `gm_AllocSpieler` | `ebx ebp esi edi` | `ebx ebp esi edi` | |
| `cm_ExSellObjekt` | `ebx ebp esi edi` | `ebx ebp esi edi` | |
| `ls_LoadBuildingEntityState` | `ebx ebp esi edi` | `ebx ebp esi edi` | |
| `cm_ExCopyEntityData` | `ebx ebp esi edi` | `ebx ebp esi edi` | |
| `gv_ExAllocGraveyardWorker` | `ebx ebp esi edi` | `ebx ebp esi edi` | |
| `ServerMainThread` | `ebx ebp esi edi` | `ebx ebp esi edi` | |
| `gm_AllocGebaeude` | `ebp ebx esi edi` | `ebp ebx esi edi` | |
| `vfs_OpenStream` | `ebx ebp esi edi` | `ebx ebp esi edi` | |
| `gm_FindNextFilteredEntity` | `esi ebx ebp edi` | `esi ebx ebp edi` | |
| `gm_CheckInventoryCapacity` | `ebx ebp esi edi` | `ebx ebp esi edi` | |
| `m_AllocTracked` | `ebp ebx esi edi` | `ebp ebx esi edi` | |
| `srv_LoadBuf` | `ebx ebp esi edi` | `ebx ebp esi edi` | |
| `gm_ObjectsAvailble` | `esi ebx edi ebp` | `esi ebx edi ebp` | |
| `vfs_ReadCompressed` | `ebx ebp esi edi` | `ebx ebp esi edi` | |
| `cm_ExProdObjekt` | `ebx ebp esi edi` | `ebx ebp esi edi` | |
| `cm_ProcessCommandQueue` | `ebx ebp esi edi` | `ebx ebp esi edi` | |
| `gm_CalculateProductionValue` | `ebx esi ebp edi` | `ebx esi ebp edi` | |
| `CrashDumpUnhandledExceptionFilter` | `ebp esi` + deferred `ebx edi` | `ebx ebp esi edi` | **differs** |

**18 of 19 are identical, including save ORDER.** The single exception is `CrashDump`, and its cause is already
isolated (Finding 67: `hDbgFile` in `ebp` vs `edi`, so the reference can defer the `ebx`/`edi` pair to
`0x1000282c`).

**What this establishes.** Register *pressure*: how many callee-saved registers the function needs, and in
which order msvc6 saves them, is **already correct on 18 of 19 carriers**. So the 5,825 register-class bytes
are not "our function needs a different number of registers"; they are the allocator choosing differently among
registers it already has. That is §1's class, and §1's evidence is that no C spelling reaches it: now
confirmed with the pressure dimension ruled out as the cause.

**Method note.** A naive "first four `push` of a callee-saved register" reading is wrong: it catches argument
pushes (`push ebx` as a call argument) as if they were saves. `ahm_ExAllocAlchemist` reported `ebx ebp ebx ebx`
under that reading; its actual prologue is `push ebx; push ebp`, and the extra `push ebx` operands are call
arguments. Read the prologue region explicitly, or filter to pushes that precede the first `call`.

## Finding 69: `gm_ObjectsAvailble`'s `ebx`/`edi` roles: three new spellings, none lands; "inert" in the header is not always exactly 0 (round 1029)

`gm_ObjectsAvailble` (`0x10015f70`, 720 B, 25 residue) is the cleanest register-role carrier in the tree:
**220 of 235 instructions are identical**, the instruction count matches exactly (235 both sides), and the
15 differences are a pure `ebx`↔`edi` exchange plus an `edx`/`edi` rotation. The reference tests
`slot_cursor` in **ebx** and holds `slot_base` in **edi**; we have the two reversed.

```
idx 73  ref test ebx, ebx                  | bld test edi, edi
idx 77  ref mov  edi, esi                  | bld mov  ebx, esi
idx 85  ref mov  eax, [ebx + 0x14]         | bld mov  eax, [edi + 0x14]
```

The header lists declaration reorder, hoist positions, extra-copy and cursor splits as inert. Three
spellings were re-measured **at the link** this round, all reverted:

| spelling | header's label | measured |
|---|---|---|
| `slot_base = ...;` before `slot_cursor = 0;` (init order swapped) | inert | **+4** |
| `slot_cursor` declared second (after `slot_base`) | inert ("inert") | **+0**: confirmed |
| `slot_base` given an early `slot = slot_base;` use above the branch | not listed | **+4** |

**Two things worth keeping.**

1. **The header's "inert" labels are accurate in kind but not always zero.** The declaration-order spelling
   is exactly 0; the initialiser-order spelling labelled inert is actually **+4**. Inert and mildly negative
   are different categories, and only one of them is safe to compose with other edits. Verify, do not
   inherit, an "inert" claim when building a multi-part candidate.
2. **Two different spellings landing on the identical +4 is the signature of a collapse, not a measurement.**
   Swapping the initialiser order and hoisting a first use both produce the same schedule, which means the
   allocator's choice here is a fixed point of the entry block rather than a function of either statement.
   Consistent with Findings 62/63: the roles are chosen from the whole-frame assignment.

**Judgement:** with 220/235 instructions identical, exact instruction-count parity, and all six known
spellings landing at 0 or worse, this row's remaining 25 bytes are the allocator's register *choice* under a
frame layout that already matches. No C lever named. Not re-probed without a new allocator finding.

## Finding 70: 18 of 19 carriers have the reference's exact frame; only CrashDump differs (round 1041)

Frame size is the coarsest allocator decision and the one most likely to explain a register-role divergence:
if a carrier's stack frame differs, slot assignment differs, and the register colouring follows. Surveyed
every carrier's prologue `sub esp,<imm>` in the reference against the shipped file:

| carrier | reference | shipped | |
|---|---|---|---|
| `gm_AllocSpieler` | `esp,0x41c` | `esp,0x41c` | ok |
| `cm_ExSellObjekt` | `esp,0x228` | `esp,0x228` | ok |
| `ServerMainThread` | `esp,0x1e4` | `esp,0x1e4` | ok |
| `srv_LoadBuf` | `esp,0x2a0` | `esp,0x2a0` | ok |
| `m_AllocTracked` | `esp,0x118` | `esp,0x118` | ok |
| `gm_AllocGebaeude` | `esp,0x410` | `esp,0x410` | ok |
| `gm_CheckInventoryCapacity`, `gm_ObjectsAvailble` | `esp,0x20`, `esp,0x28` | same | ok |
| `ls_LoadBuildingEntityState`, `cm_ExCopyEntityData`, `vfs_OpenStream` | `esp,0xc` | `esp,0xc` | ok |
| `gv_ExAllocGraveyardWorker` | `esp,0x10` | `esp,0x10` | ok |
| `ahm_ExAllocAlchemist`, `vfs_ReadCompressed`, `cm_ExProdObjekt`, `cm_ProcessCommandQueue`, `gm_CalculateProductionValue` | `esp,8`/`0x10` | same | ok |
| `gm_FindNextFilteredEntity` | (no `sub esp`) | same | ok |
| **`CrashDumpUnhandledExceptionFilter`** | **`esp,0x280`** | **`esp,0x284`** | **DIFF** |

**Eighteen of nineteen frames match exactly.** So the residue is *not* a frame-layout cascade on any carrier
but one, which sharpens Findings 62/63: the register-role rotations on the eight zero-branch carriers happen
under a frame that is already correct, so they are a pure colouring choice among equally-valid allocations
rather than a consequence of slot assignment. That is consistent with Finding 67's observation that 18 of 19
carriers have identical save order and register pressure.

**The one exception is already a documented wall.** `CrashDump`'s 4-byte surplus is shapes §81, which
records four independent routes to `sub esp,0x280` (space-drop, hProcess reload, pDbgBuf kill, nested-loop
shape) plus the round-174 mechanism: reading the walk loop's guard through the parameter instead of the
local ends `pCtx`'s live range and produces `sub esp,0x280` exactly with aligned instructions *rising*
392 → 407. It was link-tested under the rule's own proviso: **+66 linked, the row +58.** Sixth confirmation
that closing the frame alone still costs bytes.

**A stale note found by the survey.** `vfs_OpenStream`'s header states *"the target's frame is 0xc and ours
is 8, so every [esp+...] displacement is off by 4 from index 0"*. **Ours is `esp,0xc`: it matches.** The
note predates the `int mode14` fix recorded later in the same header ("gives the target's `sub esp,0xc`
frame with the same 0x13/0x14/0x18 slots"), so the header contradicts itself and the newer entry is correct.
A future round reading the older paragraph would chase a frame mismatch that no longer exists.

## Finding 71: CrashDump's register roles hinge on one priority comparison; stack slots follow references per byte (round 1145, traced in c2)

Traced under `winedbg --gdb` with a private wineprefix (a compile takes about 2 s instead of 28 s on
the shared toolchain lock; tracer scripts kept under `.scratch/c2trace-crashdump/`, gitignored).

- **Register roles.** In the current source the `WriteFile` import node has priority 102 and `nInstr`
  148. Once `WriteFile` ranks higher, c2 reproduces 10 of the 11 tracked reference roles (CreateFileA
  esi, ReadFile edi, hDbgFile ebp, pDbgBuf ebx, WriteFile esi, nInstr edi, pInstr ebx,
  pExceptionPointers edi, and no cached constant 0 in edi, so `push 0` appears). The odd one is
  CloseHandle, called from memory in the reference. Each newline `WriteFile` written inside a switch
  case adds about 10 to its priority (14 in the access-violation case). Loop weight follows the
  control flow: a `goto`-built loop traces identically to a `while`.
- **Stack layout** (c2 `0x107405b6`): locals go into bins sorted by size, then by reference count;
  final offsets run in order of references per byte, highest nearest the frame bottom, and single
  chars fill alignment holes. The reference's bytes 8-9 are alignment padding. Our 0x284 frame (0x280
  in the reference) is one extra bin shared by the `volatile` `fail_line`, `excCode` and `szDateLen`.
- **Switch tails.** The reference's two tails are cross-jumped per-case `WriteFile(msg);
  WriteFile(nl); break;` arms, grouped by the scratch register each arm starts on. Our compile groups
  the same cases, but group A's arms start on two registers (the access-violation arm uses a different
  number of temporaries, counted modulo 3), so only group B merges and the per-case source is 2272
  bytes against a 2128 span.
- **Best candidate** (per-case newlines in three cases plus four non-volatile locals) measured +28
  linked: it still pushes all four callee-saved registers at entry and keeps `fCanContinue`/`szLine`
  in the wrong order. Next step: make group A's arms start on one scratch register.
- **Measurement trap:** a candidate that overflowed the 2128 span collapsed that round's
  composition and left a bad `build/split_poc.map`, so later `linktest` runs collapsed too.
  `split_link.sh` and `linktest.sh` are retired. Do not run them to recover. Rebuild the
  current target from tracked inputs and compare the raw image.

**Round 1145 end state: 4 bytes, the frame-fill tie.** At 0x10002c5c `frameInfo[0]` and
`frameInfo[1]` issue in reverse order. Both stores are ready in cycle 1 at priority 2, so the lower
IL sequence wins, and `fi[1] = hCrashLog` is the group-A join (the only statement identical at both
join sites that needs no scratch register), so it is always first in the block. Priority terms, from
the weight table: height x 8192, +65536 for a memory read, +65536 for a float-class (0x4xxx) store
to memory, + (successor count >> 5); only height can move, and `fi[0]` has no successor `fi[1]`
lacks. Every other join candidate fails: loads and zeros need a scratch register (the picker gives
eax on side A, edx on side B, by layout order, so copies never merge); a named local folds and
empties the join (object 1149); `espVal -= 4` writes flags and is ordered ahead of the `xor`. An
exact result needs a join that survives the first cross-jump but emits nothing, or a switch shape
that merges the group-A arms without one. Traces: `.scratch/c2trace-crashdump5/` (gitignored).

## Finding 72: a multi-use constant is a colouring candidate; its register follows range overlap (round 1145)

The constant `1` in the ahm/graveyard counter blocks is a colouring candidate (graveyard id 18). The
select cost routine (`0x1071f7b3`) counts only preference lists and pins, so with every cost 0 it takes
the first register no coloured neighbour holds over its range: `dl` only while another candidate (the
volatile `cmd_payload` reload, `_slot_ptr`) holds `ecx` across it. Its dl/cl role therefore follows
which ecx candidates overlap its source range, not its position. In the graveyard worker under /Ow,
stores through `grave` form one chain in source order; `g_citizen_count`/`g_next_object_id` symbol
stores are outside it, so the citizen store sinks to the end of the block where the reference has it
inside the chain. Both are closed: the graveyard worker under plain `/O2`, where no chain forms and
a named local holds ecx over the 1 (shapes 201); ahm as below.
Traces and variant generators: `.scratch/c2trace-counters/` (gitignored).

ahm closed (RELOC) by giving the 1 an ecx neighbour that is not a barrier: a `kind` local kept as a
candidate by a dead may-alias store (shapes section 200). Traced at select entry (`0x1071f7b3`,
allowed set at `[cand+0x20]`): with the load folded the 1's allowed set is {ecx, edx} and it takes
ecx; with `kind` coloured first it is {edx}. The range walk from `[cand+0x28]` to `[cand+0x30]` is
per basic block (sets at block `+0x40/+0x44/+0x48`), so the 1 and the counter locals share a block
without interfering: interference inside a block is tuple-level.

## Finding 73: CrashDump's frame-fill tie (0x10002c5c) against the cross-jump, picker and DAG rules (traced in c2)

Closed (`0x10002770`). Spelling: group_a_done is `espVal += 4` then the same `espVal -= 4` on both arms of `if (nFrames)`, then `break`. The frame fill writes `frameInfo[0]` before `frameInfo[1]`. Frame immediate `sub esp,0x280`. Measured `rebrew test`: RELOC, 2115/2115, delta 0 (was NEAR_MATCHING 2111/2115, the four bytes `6c 40 54 3c` at `0x10002c5d`). A single subtract, or one `goto` to a shared subtract, leaves `add ebx,4` / `sub ebx,4` (2127 bytes). Identical arms fold away after the group-A tails have cross-jumped, so the tails stay shared and the join emits nothing. The scheduler then issues `89 54 24 3c` before `89 6c 24 40`.

The decision, for the joins that do not fold, is the ready-list order at `0x107278ae`: priority (`+0x2c`)
descending, then sequence (`+0x36`) ascending. Sequence is the block-local creation order
(`0x10726361`, counter `0x1079f16c` reset at `0x1072631f`), so the group-A join `fi[1]`, the first
item of the merged frame-fill block, always issues before `fi[0]` at equal height. The rules that
close every other join, each traced on this function:

- **Pass order** (driver `0x107601e5`): scratch picks (`0x10720798`), frame-slot weights
  (`0x10722246`) and packing (`0x107400e7`), cross-jump, scheduler (`0x107258b7`). A join's operands
  therefore count once more in the slot weights, and its scratch registers are fixed before merging.
- **Cross-jump** is `fcn.107295a5`, called per jump item from the flow cleanup `fcn.10723474` at
  `0x10723701`, in the second cleanup pass only (driver `0x107606cc`). It walks back from the jump and
  from the target label, skipping labels (kind 0x1a) and op-444 items on both sides, compares items
  with `fcn.107291dc` (op, type, operands, registers included), moves the jumper to the first matched
  item and hands labels it crossed to `fcn.1073bf54`. Among marker items only op 444 compares equal
  (table `0x10786ef0`). A join block holding only labels and a `jmp` is threaded by the earlier jump
  passes (label merge `fcn.1070f864`), so the group-A arms then stop merging into 0xc000008e.
- **Scratch picks follow layout, not source.** The join is laid out after the 0xc000008e arm whatever
  its textual position (moved after the 0xc000001d arm: still after 0xc000008e), so its cursor is eax;
  the frame fill follows 0xc00000fd, cursor edx.
- **DAG edges.** Memory refs are matched through list `0x1079f144` with `fcn.1070438b` (same symbol:
  offset ranges); `fi[0]` and `fi[1]` are symmetric in every memory and register rule, and nothing in
  the reference block writes edx, the only register `fi[0]` alone reads. Barrier nodes
  (`fcn.10726d9b`): item kinds 0xf, 0x13, 0x14, 0x16 other than op 444, 0x19 and real labels
  (0x1a), ops 0x166/0x9c/0xb2 and volatile operands. A barrier links every current sink to itself
  and itself to every later node at latency 0, and flushes the memory and register lists, so a
  consumer of a volatile load gets a latency-0 edge and can issue in the same cycle.

| Join or frame-fill change | Object (now 2111/2115) | Fails on |
|---------------------------|------------------------|----------|
| `fi[0] = pDbgBuf` | 1525 | pick eax vs edx; `pDbgBuf` weight +1 moves its slot |
| `pStack = espVal - 4` | 2083 | `add ebx` ahead of `xor` (flags); `pStack` store early; slot swap |
| `hLog = hCrashLog`, `ctx = pCtx` (also `register`, `+ 0` casts), `espVal += 0`, a second `fi[1]` store | 1149 | copy propagation or dead-store removal empties the join |
| `default:` label as the join | 1149 | threaded before the cross-jump |
| group-A arms write only the message, join writes the newline | 1328 | arm picks rotate eax, ecx, edx |
| `ctx = *(CONTEXT* volatile*) &pCtx` | 1821 | merges exactly (arms and 0xc000008e tail as the reference), but `pCtx` weight 4 to 5 reorders the 4-byte slots and the latency-0 barrier edge issues the Eip load in cycle 0 into eax |
| `CONTEXT* volatile pCtx` | 1780 | same, plus slot changes at every `pCtx` use |
| `frameInfo` at function scope, 192 join/order permutations (inner and outer scope) | best 2111 | tie or worse |
| `memset` for the zero stores | 1706-1829 | zero in edx, stores chained |
| no join: group-A arms `break` like the B arms, frame fill in source order | 1149 | frame fill exact; A arms unmerged (pairwise merge sees 20 bytes, below) |
| join body: unreferenced label, `(void) 0`, `do { } while (0)`, a `goto` chain, `if (v) goto frame_fill;` | 1149 | threaded |
| 730 one-statement joins over every local: `v = v`, `v = (T) w`, temporary round trips, `if (v) { }`, `(void) v` | 1149 or at most 1548 | folded before the third jump pass, or emits |
| `hLogW = hCrashLog = CreateFileA(...)` with join `hCrashLog = hLogW` (and reversed) | 1149 | copy folded |
| `hLog = hCrashLog` in the join, every B arm and `default`, `fi[1] = hLog` | 1149 | copy propagation (same source on every path) |
| `espVal -= 4` as the join | 2098 | `sub ebx, 4`, height 3, issues in cycle 1 |
| the four zero stores as the join | 621 | the 0 candidate spans join and fill, colours to ebx |
| `memcpy(&frameInfo[0], &pDbgBuf, 4)` | 2111 | folds to the plain store |
| `fi[0]` as a separate function-scope `int` (stack-layout dependent, not a fix) | 2089 | `fi[0]` issues first (memory edge to the Eip load), but the packer puts the int at `[esp+0x54]`, above the array |

**The tie has no priority input.** Priority is written at `0x1072700d`/`0x10727042` from the weight
words at `[0x10799204]` (this target: -1, 13, -5, -1, -2, 16, 16), each applied as a shift
(`0x10727781`): `height << 13` + `(successor count, +0x22) >> 5` + `(memory source operand, +0x3a
bit 0) << 16` + `(x87-class store: item type & 0xf000 == 0x4000, +0x3a bit 1) << 16`. The
critical-path flag (+0x39 bit 6) and +0x39 bit 7 are 0/1 values shifted right by 1, so they add 0.
The memory-source bit is set when the item's source operand list holds a kind 2 or 6 operand
(`0x10726408`); the store bit from the destination list (`0x1072642b`). Traced at the frame fill:
`fi[1]` (seq 1) and `fi[0]` (seq 4) are both exactly 0x4000 (height 2, one successor, the loop-head
label node op 430, lat 0; no memory source; type 0x1004). Raising `fi[0]` needs a successor, i.e. a
later access overlapping frameInfo bytes 0..3 or a later writer of edx; the reference block has
neither. The per-cycle issue loop (`0x10727977`) does not separate them either: both pass the slot
check `[0x10799214]` in slot 0 and slot 1, and the dead-label marker (op 444, seq 2) is slot-0 only.
Inputs traced and ruled out:

| Input | Object | c2 result |
|-------|--------|-----------|
| `*(float*) &frameInfo[0] = *(float*) &pDbgBuf` | 2111 | float copies lower to type 0x1004 `mov`; type 0x4004 appears only on x87 items (`fild`/`fstp`) |
| unreferenced user label in the join (`group_a_done: dead_a: goto frame_fill;`, or `break`), fill in source order | 2231 (size) | op 444 is the marker `0x107028f1` leaves for a deleted user label (symbol +0x30 == 0); the arms are still threaded past it and stop merging |
| join `espVal -= 4`, `pStack = espVal` | 2098 | merges, but emits `sub ebx, 4` (reference `add ebx, -4`), and as IL item 1 its flags edge puts it ahead of the `xor` |

With the fill in source order and no `fi[1]` join (the dead-label row), the frame fill schedules as
the reference: `fi[0]` gets seq 2 and `fi[1]` seq 3, both issue in cycle 1 in that order. A join that
leaves `fi[1]` out of the merged block's head therefore needs no frame-fill change.

**Pairwise tail merge, traced (cleanup 2 only).** Per label, `fcn.10729090` (called at `0x1072351f`
when `[0x107ac348]` is 0) zeroes each unconditional jumper's `+0x12` and passes every pair to
`fcn.1073f41d`, which walks back like the cross-jump (labels and op 444 skipped, `fcn.107291dc`
compares). It merges only if the encoded sizes of the matched items (`fcn.1072afd4`, encoder
`fcn.10729e5b`; a stack `lea` counts 6), summed front to back until the sum reaches 20, plus the
larger `+0x12` exceed 20 (`jg` at `0x1073f646`), or if the match contains an unconditional jump.
The size test runs only while `[0x107ac0b4]` is set; clear, `0x1073f5ba` merges any match of one
item or more. The survivor's `+0x12` becomes at least 20,
so after one merge every other jumper follows. The group-A arms share `push ebp`, `call esi` (message)
and `push 0`, `lea`, `push`, `push 2`, `lea` (newline): 1+2+2+6+1+2+6 = 20, for any argument order,
since the last push before `hCrashLog` is always a 1-byte `push reg`. The A arms therefore merge only
by falling into a join block after 0xc000008e.

**`[0x107ac0b4]` is `/Ot` (favour speed), traced and ruled out.** c2 decodes the per-function option
word from c1's IL function record (reader `0x1072ff79` stores it at function `+0x18`, then calls the
decoder `0x107308df`, `ecx` = word): bit 23 to `[0x107ac0b4]` (`0x1073090b`), also bit 8 `0x107ac0b8`,
25 `0x107ac098`, 18 `0x107ac0a4`, 31 `0x107ac0bc`, 11 `0x107ac054`, 24 `0x107ac0d8`, 21 `0x107ac058`
(copied to `0x107ac34c`), 9 `0x107ac11c`, 10 `0x107ac118`. Words read at `0x107308df` under gdb for
this file: `/O2` and `/Ot`, `/Ox`, `/G5`, `/Gy`, `/Gf`, `/GF`, `/Gs`, `/Zi` 0x00a00800; `/Os` 0x00200800;
`/Og-` 0x00800800; `/Op` 0x00a40800; `/Ge` 0x80a00800; `/Od` 0x00800000. Per function,
`#pragma optimize("s", on)` and `("t", off)` give 0x00200800 (`"y", off` clears bit 11, `"w", on`
sets 24 and 25, `"a", on` 25, `"p", on` 18). Only `/Os` or the size pragma clears bit 23, and c2
reads the flag at 120 sites. Measured: clearing it under gdb right after the decoder gives 334/2115,
the same as `/Os` and `#pragma optimize("s", on)` (334), so it is the whole favour-size code
generator, not a merge switch. Clearing it only inside `fcn.1073f41d` (no-join source, fill in
source order) gives 1941/2115 at 2091 bytes: the size test is skipped, so the B arms merge into
the A tail too. The `+0x12` reset at `0x107290e7` leaves no carried credit, and the only jumpers to
the A label are the seven A arms, so with the flag set nothing else can merge first.

One more matched item cannot reach 21 either (traced on every A pair). Counting starts at the item
after the first mismatch (`push msg`) and stops at the first sum of 20 or more; the reference bytes
fix the counted items (1, 2, 2, 6, 1, 2, 6, then the 1-byte `push edx` last in any argument order),
so the sum lands on 20 exactly. Overshoot needs the message push itself to match, and no two A arms
share one: lengths 0xb, 0xa, 0x15, 0x14, 0x13, 0x18, 0x12, distinct strings, and the jump tables at
`0x10002e9c`/`0x10002f1c` hold no second entry into 0xc000008e's arm. The size-free path
(`0x1073f57c` records an unconditional jump, kind 0x11, or a kind 0x13 item met after the first
match; `0x1073f648` merges there) needs such an item in the common tail, and the A tail holds only
pushes (kind 0xc op 0xd), `call esi` (kind 0xe) and `lea` (kind 0xc op 0x12).

**Join lifetime, traced.** An empty join is threaded by the third jump pass `fcn.107050de` (driver
`0x10760574`), otherwise by cleanup 1 at `0x10723553` (`fcn.10703052` skips items without flag
bit 0, which includes labels and op 444). Between cleanup 1 and 2 only the peephole `fcn.10723779`
deletes items: register self-moves (`0x10723d07`, deleted at `0x10723d1d`; the `szDateLen` and
`szTimeLen` call-result copies are `mov eax, eax` self-moves, not stack stores) and op-0x19e uses
(here from switch dispatch at `0x10711276`, the return value at `0x1071774d` and compare-with-0
elimination at `0x1071b184`; all eight creation sites and the other deletions are listed at the end
of this finding). After cleanup 2 only jumps and labels are deleted. A join body that
vanishes needs a copy that global copy propagation keeps (seen only for call results and
loop-carried variables) or one of those uses; no statement tried qualifies. Otherwise the join is
the fill's IL prefix and must be pick-free (join cursor eax after 0xc000008e, fill cursor edx after
0xc00000fd), which leaves `fi[1]` (seq tie), `add ebx` and the `pStack` store, all measured above.
The alias asymmetry is ruled out (below); the remaining input is a vanishing join body.

**Alias asymmetry, traced and ruled out.** Each `frameInfo[i]` operand is a field symbol (kind 4,
`+0x8` parent `frameInfo`, `+0x20` size 4, `+0x24` offset). The DAG query (`0x10726c99`,
`fcn.1070438b`) decides a store against a later indirect load (kind 6, points-to tag at operand
`+0x1c`) at `0x10704a6d`: `fcn.10704bac` tests the *parent* symbol against the tag's set
(`[0x1079d6b0][tag]`, abstract objects whose `+0x30` list holds the member symbols), and after
layout (`0x10704b70`) also every symbol sharing the parent's frame region (`fcn.1073abb5`, regions
at `[0x107ae23c]`). Two stores to one parent compare field offset ranges (`0x107047f9`); different
parents compare frame offsets (`0x1070481b`). `fi[0]` and `fi[1]` share their parent, so every
query answers alike for both; only a different object or a later same-block access overlapping
bytes 0..3 (the reference has none) separates them. Traced at the fill: `pCtx`'s tag 4 holds the
function-scope address-taken locals (`szModulePath`, `szDateBuf`, `mbi`, three 4-byte locals) and
the literal initialisers; the inner-block `frameInfo`, `szLine` and `space` are not members, so
both queries return 0. Pointer spellings of the `fi[0]` store all fold to the plain store (2111):
an index local (initialised or assigned), `*(int*)((char*) frameInfo + k0)`, `frameInfo[fCanContinue]`,
`frameInfo[nFrames - 0x800]`, a pointer local initialised or assigned from `frameInfo`.

**A vanishing join closes the function (measured under gdb).** Deleting the join item at the
peephole entry (`0x10723779`, calling c2's unlink `fcn.107026f1` on it) with the fill in source
order and the join ending in `break;`: a register copy join (`hCrashLog = (void*) espVal;`, item
`r4 <- r6`) gives 2115/2115; `nFrames = 0x800;` gives 2103 (fill exact, but its operand counted in
the slot weights and swapped four 4-byte slots). The A arms cross-jump into the empty join in the
two cleanup calls after the peephole (`fcn.10723474` runs four times, cross-jumps only in the last
two), and the fill then schedules as the reference; an unreferenced label in the join is not
needed, because the `break` target stays referenced by the default dispatch. A `goto frame_fill`
join instead leaves the dead `frame_fill` label's op-444 node at the head of the fill, where it
takes cycle 1 and pushes both stores behind the `xor` and `add`. The missing piece is therefore a
join statement that is a copy between two variables coloured to one register (ebx or ebp), which
the IL keeps and the register allocator turns into a self-move.

**Why no such copy has been found.** In the reference build the peephole deletes four self-moves
and four op-0x19e uses (`0x10723d22`, `0x1072459e`; no other delete site fires): the `key` update
in the decrypt loop (loop-carried) and the `szDateLen`/`szTimeLen` call results. Each self-move is a
copy from an expression or call-result temporary, not a variable-to-variable copy. The IL removes
a variable copy `v = w` when `v` already holds `w`'s value number on that path, or when every use of
`v` can take `w`. A behaviour-preserving join copy needs `v == w` at run time on every path into the
fill, so the IL keeps it only if that equality is hidden from value numbering. The hiding sources
are a memory load, a call, or a loop phi. The first two emit code, and no loop encloses the switch.
Tracer kits (item dump, priority dump, pairwise-merge and peephole traces, the 1 s compile
harness and sweeps): `.scratch/crashdump-kits/` in the main checkout (gitignored).

- **The IL optimizer (passes 0x107603e8 to 0x10760434) empties every no-op join tried:**
  self-assignments, `+ 0`, `* 1`, `| 0`, `& 0xffffffff`, `~~x`, casts, `__assume`, struct self-copy,
  block-local copies, a copy variable defined in every arm or before the switch (`void*`, `int`,
  `char*`, `register`). It also removes a repeated condition by value number, including `x & x`,
  alias spellings (`*(unsigned*)(char*)&x`, `((unsigned*)&mbi)[4]`) and globals. `if (c) break;`
  before the join's jump dies in the first cleanup call: `fcn.10728ba7` drops a jcc aimed where
  the following jump goes and the compare goes with it (`fcn.1074f5ba`, `fcn.1072d0f5`).
- **`fcn.10728ecb` (second call only) drops a repeated compare after a jcc**, and the second jcc
  only when the condition codes match. `if (x > 0) ...; if (x != 0) ...` (unsigned) survives the
  IL and shares `test ebx, ebx`, but compiles to `ja` and `jne`, so the second jcc stays (1548).
  No IL-distinct pair with one compare and one condition code was found (263 conditional joins,
  best 1620).
- **Case bodies are laid out in source order**, each dispatch block inserted before the first case
  of its range; the frame fill follows the last case.

| Join or frame-fill change | Object | Fails on |
|---------------------------|--------|----------|
| `nFrames = 0x800;` or `fCanContinue = 0;` as the join | 1527, 1547 | arms merge, the store stays |
| newline written once after the switch, default skips it | 914 | one tail; WriteFile priority drops, roles change |
| `/O1`, `/Os`, `/O2 /Os` | 325-337 | whole function changes |
| 360 one-statement joins (`x = x;`, `if (x) { }`, `(void) x;`, `x = (T) y;` over 18 locals), each before and after an unreferenced label, fill in source order | 1149 or at most 1548 | none reaches the peephole as a self-move: folded by the IL (346) or emits code |
| nested `switch` join (`switch (excCode) { }`, `{ default: break; }`, `{ case 0: break; }`, on `espVal`, `hCrashLog`, `nFrames`, `pStack`) | 1149 | folded before code generation; no dispatch op-0x19e is created (`0x10711276` fires only for the main switch) |
| second name for the fill's register value (`void* hL` for `hCrashLog`, `unsigned e2` for `espVal`): copied after the definition or taking the call/load directly with the old name copied from it; join `new = old;` or `old = new;`; fill reads either name; join ends in `break;` or `goto frame_fill;` (32 variants) | 1149 | copy folded, join threaded |
| `static __inline` identity function in the join (`hCrashLog = crash_id(hCrashLog);`, `espVal`, `hProcess`, `pCtx`, bare call) | 1142, 1145 | inlined and folded, join threaded |
| scan-loop `nInstr`/`pInstr` moved to function scope, join copies `espVal`/`hCrashLog`/0 into them | 1149 | dead (reinitialised before the scan loop), removed |

**An op-0x19e use cannot stand alone in the join (traced).** c2 creates op 0x19e (`fcn.1070ceb9`,
ecx 0x19e) at eight sites, and every one attaches the use to an anchor item in the same block:

| Site | Routine | Anchor and placement | C shape |
|------|---------|----------------------|---------|
| `0x10711276` | `fcn.10710c3f` | before the table jump (op 397), after the range `ja`; only when the index operand is a register | jump-table switch |
| `0x1071774d` | `fcn.10716f3a` | after the new `mov eax, value` of a `return`, before the exit jump | `return v;` |
| `0x10767b45` | `fcn.107676d9` | same, for an `edx:eax` return | `__int64` return |
| `0x1071b184` | `fcn.1071ae05` | after the flag-setting def whose `cmp x, 0` it removes; the walk back stops at a label, so def, use and jcc share a block; no use when the flags reach the jcc through a `mov` | `x = a - k; if (x)` |
| `0x1071d000` | `fcn.1071cdfa` | after the `dec` of a compare-chain switch | small switch lowered to `dec`/`jcc` |
| `0x107146d9` | `fcn.1071455e` | after each fixed-register setup `mov` of a string intrinsic (ecx count, eax value, esi, edi) | `memset`, `memcpy` |
| `0x1074f598` | `fcn.1074f49d` | after an item whose other result is dead | multi-result ops |
| `0x107664db` | `fcn.107663fc` | before a widened byte/word store | adjacent small stores |

The peephole (`fcn.10723779`) deletes every use it reaches (`0x10724590`/`0x10724599`) but none of
the anchors except a register self-move (`0x10723d1d`). A use therefore vanishes with its block only
when its anchor is a self-move: the `return` copy of a value already in eax (a function exit, not a
join) and an intrinsic setup whose operand is already in the fixed register. Every other item the
peephole deletes: `add r, k` followed by `sub r, k` (or the reverse) on one register, flags unread
(`0x10723ff1`, `0x10723ffa`; the IL folds such a pair in C, `espVal += 4; espVal -= 4;` gives 1149);
op 0x166 intrinsic items, replaced by their expansion (`0x10724569`, `fcn.10766d4d`); ops 395, 402,
405, 407, 410 and 421 (`0x10724597`), which only `__try` creates here (pseudo edges and markers of
the SEH frame, which the reference lacks).

| Join (fill in source order, join ends in `break;`) | Object | c2 result |
|----------------------------------------------------|--------|-----------|
| `memset(szDateBuf, 0, 0);`, `memset(&mbi, 0, 0);` | 1545, 1530 | the join survives cleanup 1 and the A arms merge; `xor ecx, ecx`, `xor eax, eax`, `lea edi` stay |
| `memset(pExceptionPointers, 0, 0);` | 1544 | `mov edi, edi` and its use deleted (the pointer is edi); `xor ecx, ecx`, `xor eax, eax` stay |
| every A arm and 0xc000008e: `nV = WriteFile(<newline>);`, join `memset(pExceptionPointers, nV, 0);` | 1547 (2123 bytes) | at peephole entry the join is `mov ecx, 0`, `mov eax, eax`, `mov edi, edi`, three uses, `jmp`; the peephole leaves only `xor ecx, ecx` |
| `memcpy` with count 0 (buffers, `hCrashLog`, `espVal`, `pExceptionPointers` as both pointers) | 916-938 | also loads esi, which holds `WriteFile` |
| `memmove(..., 0)`; `(void) memcmp(..., 0)`, `(void) strlen(...)` | 1331; 1149 | library call; folded as dead |
| `if (--espVal) espVal++; else espVal++;`, `if ((espVal & 3) != 0)`, `if ((int) (espVal >> 2) > 0)` with `nFrames = 0x800` | 1518-1548 | the def stays with its use |
| `switch (espVal & 7)` with six equal cases; an empty `switch (excCode)` | 1011; 1149 | the table jump stays; folded |

A zero-count string op always keeps `mov ecx, 0`: ecx is not live across the preceding `WriteFile`,
so no count operand can already be in it. Option A is closed: no op-0x19e use leaves the join empty.

**Allocator transfers cannot be the vanishing join (traced).** The global allocator `fcn.1071beb0`
(driver `0x107605d5`) moves a split value only through memory or an immediate, never register to
register. After a split (`0x1071c086`), `fcn.1073d0c5` runs the rewrite `fcn.1073dda7`, which adds
block-entry reloads (op 0x163, maker `fcn.10711ae3`, placed by `fcn.107105d9`) and operand loads
`mov t, [sym]` (`fcn.1073e222`, op 1); `fcn.1073da19` adds spill stores (op 0x164, maker at
`0x1070fbbc`). A reload's source is an immediate for a constant candidate (symbol kind 0xd,
`0x10711aef`) and a memory operand (0x14a/0x14b) for every other kind. `fcn.10720d7c` then deletes
the 0x164 stores `fcn.10769fea` accepts (`0x10720e12`) and turns the rest into op 1 (`0x10721ab2`). The peephole's
self-move test (`0x10723ad5`) needs a register source, so no transfer can colour to a deletable
self-move; and the pass runs after the third jump pass and before cleanup 1, so it can only add code
to a join or empty it too early. Measured on ten variants (the current join, `break` join,
register-copy join, seven conditional joins): 165 to 196 allocator-made moves each, 15 reaching the
peephole, none register to register.

**Peephole deletes, complete list** (`fcn.10723779`; op table `0x107280c0`/`0x107280d4` for ops
0x18c to 0x1a5): register self-moves (`0x10723d1d`); a register copy `mov D, S` whose list
predecessor is `mov S, D`, rewritten to a self-move at `0x10723c43` (the join's predecessor is the
0xc000008e arm's call); op 0x19e with no destination (`0x10724599`); ops 395, 402, 405, 407, 410
and 421 unconditionally (`0x10724597`); two-item folds that keep one item (`0x10723ff1`,
`0x10724395`, `0x10724677`). Traced on small probes, ops 395, 402, 405 and 407 come only from
`__try` (`__finally`, `__except`, `__leave`, also an empty `__try { } __finally { }`), which always
adds the `fs:[0]` frame the reference lacks; `_alloca`, `__assume`, `__noop`, `_enable`,
`_disable`, `_inp`, `_outp`, `_rotl`, intrinsic `abs`, `fabs`, `memset` and `strlen`, and a
`volatile` local create none of them. A fifth op-0x19e creator, `0x107146ce` in `fcn.1071455e`
(driver `0x10760541`), stores register parameters to their homes only when the convention bits
(`[0x107ac378]+0x14 & 0x1c`) are 4; this function has 0x10.

**Flags do not break the tie** (measured on the 2111/2115 source, `rebrew test --cflags`, object
bytes): `/O2 /Gd` 2111; `/G5`, `/GB`, `/Op` 2111 (same default weight row); `/Ow` 2074; `/G6` (the
other weight row) 652; `/Oa` 1136; `/G6 /Ow` 649. A sampled `rebrew match flags
--tier full` (95,280 of 6,193,152 combinations) found no exact result.

## Finding 74: Processor Pack c2 (client targets): routine map, rules and open cases

The two clients build with the `rebrew/msvc:6.0-sp5-pp-win32` image, whose `c2.dll` (loaded at
0x10700000, like SP6's) is a different build: none of Findings 71-73's addresses carry over, but the
IL node layout and the scheduler weights do. Addresses found by code shape from the SP6 routines and
confirmed under `winedbg --gdb` with a private wineprefix (about 20 s per compile; catch `c2\.dll`
and continue until the code is mapped before setting breakpoints). Tracer kit (`dbgrun.sh`,
`run.sh`, gdb scripts): gitignored `.scratch/pp/` of the worktree that ran it.

| Routine | SP6 | PP | Notes |
|---|---|---|---|
| Scheduler node creation | | `0x1070f234` | sequence `+0x36` from counter `0x107ad5fc`; flag byte `+0x3c`: bit 2 memory source (kind 2/6 operand, set at `0x1070f273`), bit 3 memory destination (`0x1070f289`) |
| DAG edge add | | `0x1070f6b1` | `ecx` from, `edx` to, `[esp+4]` kind: 0x20 memory read-after-write (`0x1070f91d`), 0x40 memory write-after-read (`0x1070f96f`), 0x80000 to the block terminator |
| Scheduler priority | | `fcn.10714f6a` | height word `+0x34`, successors `+0x22`; writes `+0x28` at `0x10715094`, final priority `+0x2c` at `0x107150b4` (`ecx`); x87-store bonus at `0x10715107` |
| Weight table | | `[0x107b1a00]` | rows at `0x107b6978 + cpu*16`; default (and `/G3`-`/G5`) row `0x107b6998`, `/G6` row `0x107b69a8`; SP6's weights (-1, 13, -5, -1, -2, 16, 16) |
| Weight helper | | `fcn.1071585c` | `term << w` (negative `w` shifts right) |
| Ready-list insert | `0x107278ae` | `0x107159a9` | priority `+0x2c` descending, then sequence `+0x36` ascending |
| Cycle loop | | `fcn.10715a7c` | `ecx` = cycle; ready list `[0x107b1b8c]`, next at `+0x10` |
| Issue point | | `0x10715bc0` | `esi` = node (`+0x1c` tuple with op at `+4`, `+0x2c` priority, `+0x30` earliest cycle, `+0x36` sequence), `ebx` = cycle |
| Memory alias query | | `0x107044e9` | symbol (kind 2) against indirect (kind 6) goes to `0x10704511` |
| Escape mark | | `0x1073a2c4` | parent `+5 \|= 4` when an address operand (op 0x24c) sits under a call-argument tuple (op 0x25c/0x26b); walker `0x1073cf92` |
| Frame weight insert | `fcn.1073a9c4` | `0x10713312` | list head `0x107b15fc`, symbol size `+0x20`, weight `+0x34`; called from the operand walk at `0x1070de4c` ("Frame slots" above) |
| Priority walk | `0x1071d925` | `0x10707a0b` | loop weight `1 << depth` at `0x10707b6e` |
| Priority accumulation | | `0x10708374`..`0x107083c0` | per block: add at `0x10708374`/`0x10708393`, subtract at `0x107083bd` |
| Candidate list | | `[0x107ac5b4]` | sorted insert `0x10708a6e`; next at `+0x14`; complete at `0x10731413` |
| Colouring select | `0x1071f7b3` | `fcn.10709937` | `ecx` = candidate, `edx` = class; register in `edi` from `0x10709a8e`, stored to candidate `+0x10` at `0x10709a99`; caller `fcn.1073122d`, call at `0x10731552` |
| Scratch picker / assign | `0x10721c0f` | `0x1070c32b` / `0x1070c669` | `ecx` = register at assign; cursor `[0x107b1418]` (read `0x1070c645`, write `0x1070c662`) into the list `0x107c49d4` (eax, ecx, edx, esi, edi, ebx, ebp), reset per function at `0x1070a2e4` |

Records:

- **Colouring candidate:** `+0` symbol, `+0xc` priority, `+0x10` assigned register, `+0x14` next,
  `+0x1c` id, `+0x20` allowed-register bitset (first chunk word `+8`, bit n = register n), `+0x24`
  uses, `+0x38` preference list, `+0x40` weight, `+0x44` node id. Symbol: `+4` kind (0x20804
  local, 0xa0805/0x20805 parameter, 3 temporary, 0x4000003 address or constant), `+0x1c` symbol
  index.
- **Register numbers:** 1 eax, 2 ecx, 3 edx, 4 ebx, 6 ebp, 7 esi, 8 edi. The class-0 try order
  (`[0x107b690c]` -> `0x107b6888`) is eax, ecx, edx, esi, edi, ebx, ebp. Costs (`0x107ac480`) are 0
  unless a preference or a one-register neighbour applies, so the first allowed register in that
  order wins.

Rules:

- **Scheduler priority terms (default row):** height `<< 13`, a memory source `<< 16` (bit 2), a
  float-class tuple (type `& 0xf000 == 0x4000`) with a memory destination `<< 16` (bit 3; both bits
  set at `0x1070f273..0x1070f297`), successor count `>> 5`. Ties go to the lower sequence number.
- **Colouring order:** priority descending; on equal priority the higher node id (`+0x44`) goes
  first (the insert at `0x10708a6e` compares `+0xc`, then `+0x44`).
- **Candidate ids (`+0x1c`) follow first appearance in the IL, not declaration order** (0x4fc3a0:
  `int i = 0x11;` as the first statement gave `i` id 1, the same `i` initialised at the loop id 4).
  They do not decide ties: 0x4fc3a0 with `k` lists id 6 before id 5, as the `+0x44` order gives.
- **Colouring priority** accumulates per block: a candidate referenced in the block gains `pending *
  N`, one live through the block unreferenced loses `N`, with `N` = candidates referenced in the
  block times `1 << loop depth`.
- **Few temporaries reach the scratch picker:** `fcn_005c80f0` makes 16 picks; the district, index
  and handle values are colouring candidates (kind 3).
- **Block-scoped locals drop may-alias edges.** A message struct declared in the branch that sends
  it gets no edge from its stores to a later load through a pointer (0x5d63e0: store height 8
  against 11 at function scope; shapes 202). Block scope also lets locals share frame slots (0x402090,
  0x4af800; shapes 202).
- **Symbol against indirect access (`0x10704511`).** Tag 1 aliases everything. For a local (parent
  class 4/5) the parent needs flag `+5` bit 0x02 (set on the address-taken `dlg` of 0x58ee70); with
  bit 0x04 (set by the escape mark) the tag's set `[0x107ae3cc][tag]` is walked (abstract objects,
  class 0xc, members at `+0x30`); without bit 0x04 a tag below `[0x107ae398]` (5) never aliases.
  Observed tags: 3 on an access through a parameter (set: globals only), 4 on an access through a
  call's returned pointer (set: globals and every escaped local). The set is flow-insensitive: a
  local whose address is passed to a call anywhere in the function aliases every tag-4 access,
  before the call too. Used on 0x5c8400 (shapes 202, closed).

Open cases, each traced to one decision:

- **0x414830 (289/296):** the loop's last `fstp` is a float-class store (type 0x4004), whose
  +65536 term issues it ahead of the pointer and counter updates; the reference issues it after
  them.
- **0x414960 (325/332):** the last `mx->z` store's `fstp` is in the latch block with `add
  ecx,0x50; dec edx`; its float-store bonus gives it 81920 against 32768 and 24576, so it issues
  first. The reference issues it last, which this formula gives only without the bonus.
- **0x4c6090 (174/188):** the `m.kind` store issues before the `r + 0x170` load, which the reference
  loads first. Loading it into a local first gives that order, but the local tells c2 that ecx is 0
  in the else arm, and the `xor ecx, ecx` before `mov cx, [eax]` is dropped (-2 bytes).
- **0x4ce210 (68/74):** the rotation picks `g_9badd0` eax, `arg` ecx and the `&m` push temp edx.
  The reference's `&m` in eax is what one more rotation pick before it would give; no source shape
  producing that pick has been found (phantom stores, named copies, literal-address reads).
- **0x50be50 (83/102):** the table walker (kind 0x4000003, id 0x2d) and the parameter `s` (id
  0x11) tie at priority 21, so the walker is coloured first and takes esi; the reference has `s` in
  esi. Per-block terms: the call block gives `s` +28 and the walker -14, the head and increment
  blocks give the walker +12 and +16 against -6 and -8. Loop form, `return` in the loop,
  `continue`, no `w` local and dead constant stores all keep the tie.
- **0x58ee70:** the reference issues both `*slot` loads ahead of the `dlg` field stores; with `dlg`
  escaped and `slot` a tag-4 call result, c2 orders a `*slot` load after any earlier `dlg` store,
  so the source must read `*slot` before the store.
- **0x5ce800 (497/513, after a `bit` local for the flag bits put `d` in ebx):** `out` (priority 184
  = 8x14 + 6x12) is coloured before `flags` (172 = 2x14 + 12x12) and takes esi. A tie would go to
  `flags` (higher id).
- **0x5db8e0 (630/637):** the `-1` candidate (kind 0x4000003, priority 190) interferes with the
  first-loop values, among them `x0` (esi, priority 202), so it gets edi and `result` (priority 33)
  gets esi. With a 0-based first loop (no `n - 1`) the interference is gone, but the table walker is
  no longer strength-reduced.

## Unused shared function declarations can alter spill-slot assignment

At TL 0x482f20, adding six unused sound API prototypes to client_types.h
exchanges two local stack slots (0x10 and 0x18) at five instructions. Body715
and all 39 relocations stay fixed; native 715/715 becomes 710/715. Scratch
isolation preserves the match with the shared record/global declarations
alone and reproduces the loss with prototypes alone. Moving the header first,
reversing/reordering prototypes, omitting parameter names, meaningful local
renames, and local declaration order probes are inert. This observation does
not establish a general optimizer mechanism or identify one offending prototype.

The shared sound API now has its own inferred client_sound.h, included by
nine sound users, with original declaration order preserved. client_types.h
returns exactly to baseline and canonical 0x482f20 is RELOC715/715 again;
constructor150/allocator63/request132 retain their complete matches. The full
all-target repeat remains required to accept this header repair. Evidence:
.scratch/goal-shared-sound/stack-slot-probes/{results,naming-results,header-results,
declaration-results}.json and repaired-482f20-test.json. The first descriptive
rename probe accidentally changed the include extension and failed; corrected
probe is in header-results.json, not evidence of a compiler error.

## VFS client copy provenance (2026-10-09)

The existing `vfs_AddFile` and `vfs_fwrite` ports in the shared
`Develop/Units/vfs/vfs.c` now have managed GOLDTL identities at `0x42e740`
(inventory extent 1472) and `0x430910` (368). The names are inferred from the
VFS allocation labels and file API. These functions have no server raw-map
entry; client identity does not establish a server address or a byte match.

The original TL bytes contain the same hand-written aligned-copy prelude at
`0x42e8f7`, `0x42e949` and `0x4309e9`:

```text
8d0c7f 83e103 2bd9 7e0c f3a4 8bcb 83e303 c1e902 f3a5 03cb f3a4
```

This complete sequence is 26 bytes; older descriptions calling it 24 bytes
are imprecise. It uses the invariant EBX scratch, destination alignment
idiom and C-operand homing analyzed under “The prelude is hand-written asm”.
The source uses this sequence at the corresponding two array moves and
memory-stream write. Stock LIBCMT whole-body probes miss both functions;
their VFS calls and allocation labels independently identify game code.
Managed per-function BLOCKER notes record this assembly provenance. They do
not assert that the surrounding client code matches: register allocation
and server-only inferred logging still need client verification.

Receipts: `.scratch/goal20/vfs-client-evidence.json`, `vfs-client-binding.json`
and `vfs-{addfile,fwrite}-{asm,library}.json`. The evidence script checks both
inventory extents, every prelude, unique source definitions and unchanged
source bytes. No server identity or STATUS was fabricated to clear lint.

Initial client comparisons (`--no-promote`) confirm unfinished bodies:
`vfs_AddFile` compiles to 1526 bytes against 1472; `vfs_fwrite` to 496 against
368. Both report SIZE_MISMATCH, and neither receives a stored byte verdict.
These results supersede older trial sizes for this exact source/configuration.

## AddFile operand lifetime controls (2026-10-12)

The canonical client body still emits1477 bytes for TL 0x42e740's complete 1472
native bytes. Eighteen bounded full-unit probes retain the existing attested
copy instructions and vary C operand homes/scopes, assignment and declaration
order, local spelling, initializer spelling and reuse of the dead loop counter.
Several reach1472 bytes, but the best masked comparison still differs by 243;
none is adopted. Three declaration-order, four name and one initializer control
produce identical function bytes and typed operands. Do not repeat those probes
as a new hypothesis. The production C and compiler flags are unchanged.

The two original 26-byte copy sequences at 0x42e8f7/0x42e949 are now recorded
through document-assembly in target-scoped SOURCE evidence. Their provenance
comes from the compiler controls and stock-library exclusions above, independently
of a complete function match. The blocker retains the actual unresolved result.
The full server gate still passes 316/316 functions,652/652 data comparisons and
all 286720 raw bytes. Receipts: .scratch/goal21/shared-vfs-addfile/negative-controls.json.

Upstream055127e8 corrects diff's candidate_size from the clipped comparison
buffer to the actual emitted length. The real project JSON changes only 1472
to 1477, preserving all instruction comparisons and blocker classifications.
Two regressions fail before;41 focused and 11725 full tests pass after(52 skips,
88% coverage), with committed-head packaging/reproducibility/provenance checks.
Its upstream push/CI integration is pending. A size-equal or clean-prefix diff
alone cannot establish the complete native body or its operand bindings.

## Narrow factory inputs and a reused count slot (Goal68, 2026-10-16)

The native building factory's DWORD stores to its incoming argument slot do not
establish a full-width semantic input. SERVER `gm_AllocGebaeude` consumes the
low byte of building type and low ushort of owner. The later slot holds a
full-width fill/loop count after the type has been saved elsewhere.

Its canonical definition now agrees with command.c's existing unsigned-char /
unsigned-short declaration and uses a separate ordinary `int count`. VC6 reuses
the dead type argument slot for that count without casts, volatile additions or
new flags. Narrowing the old body while continuing to reuse its parameter failed
C2443; that failure was not evidence against narrow inputs. Original formal and
counter spelling remain inferred.

The existing SERVER-only aligned-fill assembly is retained, with only its named
count operand changed. The complete prelude at 10017611 is 26bytes; older24-byte
descriptions are imprecise. Positive original-macro evidence is the cross-site
compiler/control analysis above and codegen-walls6b, independently of this match.
A new target-scoped source evidence record documents that retained macro; no
client assembly or factory provider is asserted.

All 1078 factory bytes,49operand destinations,6literal uses,44-byte jump table and
74-byte index map agree. All 127 old spiel.c contexts preserve complete code,
fixup destinations and literals, including 11weak bodies; all 43private field
declarations are unchanged. Generated local-label names change but their actual
function-relative destinations do not. Receipts: .scratch/goal68/factory-production
and factory-review. A compatible contract is not a new client factory provider.
