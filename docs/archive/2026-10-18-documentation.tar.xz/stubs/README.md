# Client comparison builds

Gold and GoldTL now link as raw PE32 executables, with MSVC maps, at:

- `build/Europa1400Gold.exe` and `build/Europa1400Gold.map`
- `build/Europa1400Gold_TL.exe` and `build/Europa1400Gold_TL.map`

These builds contain recovered sources plus explicit placeholder functions and
storage. They are for comparison, not gameplay. Placeholder sizes and types
do not establish native allocations, layouts, or ownership. No reference bytes
are copied into the output and no forced unresolved or duplicate link is used.

## Build

From the project root, using the pinned toolchain images with native unshare:

`compiler.execution_backend = "unshare"` also applies to CMake's CL/LINK/LIB
commands. The generated filenames still end in `-docker.cmake`; they invoke
the backend-aware driver and need no regeneration for this runtime change.

```sh
uv run --frozen cmake -S . -B build/clients \
  -DCMAKE_TOOLCHAIN_FILE="$PWD/cmake/toolchain-msvc-6.0-sp5-docker.cmake" \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_RUNTIME_OUTPUT_DIRECTORY="$PWD/build" \
  -DREBREW_BUILD_SERVER=OFF \
  -DREBREW_BUILD_GOLD=ON -DREBREW_BUILD_GOLDTL=ON \
  -DREBREW_DEBUG_INFO=OFF
uv run --frozen cmake --build build/clients --parallel 2
```

Gold uses Processor Pack `/ML` and `LIBC`; GoldTL uses Processor Pack `/MT`
and `LIBCMT`. The server configuration remains separate. Client `/OPT:NOREF`
retains code and data while the entrypoints are stubs. Remove that temporary
retention setting when the real entrypoint references are recovered.

The builds use the existing isolated client object trees under
`.scratch/goal83-gold-build-baseline/build` and
`.scratch/goal83-tl-build-baseline/build`. Both full client builds completed under Goal110 using unshare. Gold also
relinked after the vertex-buffer getter C replacement. Build logs are under
`.scratch/goal110-full-runs/`. Further warning repairs require another rebuild
before the images represent those edits. The command above is the ordinary
clean rebuild recipe.

## Compare

The original commands now find the executables:

```sh
uv run --frozen rebrew verify --data
uv run --frozen rebrew verify --data --target Europa1400Gold.exe
```

`verify --data` checks the existing image without a function compile batch.
Add `--functions` for combined source verification, or pass a particular source
file to verify that file alongside the data. Image-only comparisons:

```sh
uv run --frozen rebrew verify \
  --target Europa1400Gold.exe --data --whole-binary --raw-link --dry-run --json
uv run --frozen rebrew verify \
  --target Europa1400Gold_TL.exe --data --whole-binary --raw-link --dry-run --json
```

Exit 1 is expected: these artifacts differ from their references. The first
reports are `.scratch/goal84-client-build/gold-compare.json` and
`goldtl-compare.json`. Both parse the sibling map and report no missing build
or image-reading error. Neither has data symbols placed at their native VAs.
The entrypoints remain five-byte stubs rather than the native 1856-byte bodies.
Data-only verification preserves the function result cache and comparison
baseline. The compiler backend is now explicitly `unshare`, using the pinned
image filesystem; image-only checks do not initialize that runner.

## Regenerate placeholders

Each target has its own `unresolved.txt` input and generated `symbol_stubs.c`.
The last completed maps contain 2893 Gold and 2960 GoldTL scaffold symbols.
The current Gold scaffold removes three video-list functions, adds
comparison-only capacity for six color writes, and includes a generated
vertex-buffer pointer slot. Those changes have linked; refresh the manifests
from the current maps before using their counts. These
symbols are linked only into their client and remain outside recovered `src/`
and its metadata accounting.

```sh
uv run --frozen rebrew build symbol-stubs --source-dir src \
  --log stubs/gold/unresolved.txt --footer stubs/SCAFFOLD.txt \
  --specials stubs/gold/specials.toml \
  --output stubs/gold/symbol_stubs.c
uv run --frozen rebrew build symbol-stubs --source-dir src \
  --log stubs/goldtl/unresolved.txt --footer stubs/SCAFFOLD.txt \
  --specials stubs/goldtl/specials.toml \
  --output stubs/goldtl/symbol_stubs.c
```

The generator uses declarations where available and fallback types otherwise.
For example, `g_slot_table` is a two-byte placeholder, not a recovered client
slot allocation. Named configured library/import providers are excluded;
unbound numeric aliases of library functions can still be placeholders.

When a real provider becomes available, remove its placeholder and regenerate.
Do not link the server's BSS ownership files into these client scaffolds.

Gold also has five generated source-closure placeholders listed in
`gold/source-closure.json`. Four came from the selected MSX fade function; the
vertex-buffer pointer slot came from the recovered getter. These are actual
COFF references absent from the saved unresolved-link log. They do not claim
native storage ownership. After regenerating the base file above, refresh
only that addition through the existing public generator:

```sh
uv run --frozen python - <<'PY'
import json
from pathlib import Path
from rebrew.gen_stubs import collect_extern_info, generate_stubs
stub = Path('stubs/gold/symbol_stubs.c')
symbols = json.loads(Path('stubs/gold/source-closure.json').read_text())['symbols']
generated = generate_stubs(symbols, collect_extern_info(Path('src')))
fragment = generated.split('#include <time.h>\n\n', 1)[1].split('/* Function stubs */', 1)[0].strip()
marker = '/* Generated source-closure placeholders; see source-closure.json. */'
base = stub.read_text().split(marker, 1)[0].rstrip()
stub.write_text(base + '\n\n' + marker + '\n' + fragment + '\n')
PY
```

`gold/symbols.json` describes the last completed map, rather than unlinked
additions. Refresh it with `linked_manifest.py` after a successful new link.
Both `specials.toml` files omit an obsolete sound-control function placeholder.
Gold's also omits the three shared video-list functions and preserves the
comparison-only color-array capacity. Empty implementations emit no replacement
function. The historical unresolved logs remain intact;
the next linked manifests must record the reduced placeholder sets.

`omitted-sources.cmake` separately lists single-function TUs with colliding C
names: 26 Gold and 5 TL choices. These comparison choices do not prove that
the independent native bodies are equivalent. Their permanent name/provider
repairs remain open. The zlib sample program `minigzip` is also omitted.

The server rebuilt after the shared guards and remains byte-identical:
SHA-256 `3cc2ce9049e41ab6d0eea042df4966fbf57e5e27c67fb923e81709d2683609d1`.
Its fresh verification passes 316 functions, 652 data comparisons, and the
whole file. Client scaffold builds add no recovered-byte or ownership credit.
