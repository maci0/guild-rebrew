# Assembly audit — 2026-10-18

The initial source scan found 133 files with 266 real assembly blocks. This is an
inventory, not a count of original assembly functions or recovered C.

Goals86–88 replaced eleven of the original 57 Gold naked bodies with complete C:
`0x42c200`, `0x42c240`, `0x42c280`, `0x42c2c0`, `0x42c300`, `0x42c340`,
`0x4fe1e0`, `0x4c0210`, `0x4ce130`, `0x44f680`, and `0x44f860`.
The six table searches and 56-byte record search are RELOC with every operand
VALIDATED and complete applied native equality; the 41-byte record update and
29-byte list-tail walk are EXACT without relocations. The 66-byte count reader
and 70-byte stream-header reader are RELOC with all six call operands VALIDATED;
their complete applied native bytes and non-CodeView sections/relocations match.
Rejecting address/site/window controls pass, and focused all-target lint is clean.
That left 46 bodies from the original list. Goal90 identifies one of them as
an already-available zlib provider, leaving 45 unsupported bodies. These are source measurements;
fresh raw-link validation for all replacements remains pending.

Goal105's fresh all-target lint reports 41 E023 errors on each target, plus one
TL W020 and three Gold W020 warnings. The warnings identify the two `SaveBMP24`
fill helpers and the Gold bindings of `fcn_00402370` and `fcn_0040fea0`.
No new assembly exception was granted. `0x5a89a0` was an
additional whole-body inline-assembly wrapper outside the initial 57 naked
declarations. Goal89 recovered it in C: putting the existing lookup before
the wrapper in the shared translation unit preserves EDX. Standalone and
callee-last controls fail. Fresh tests match the lookup, wrapper and following
function (27/31/111 bytes) on both clients, with every operand VALIDATED.
The remaining Gold caller also matches its 28-byte body. The wrapper's current
assembly work-item flag is cleared; its former file is retained as inactive
history. No assembly exception was needed. Evidence: `.scratch/goal89-tu-wrapper/`.

Gold `0x465c80` is `inflate_trees_fixed`: the existing vendored zlib C provider
matches its 46-byte body, all four operands and 4,360 bytes of private static
data on both clients (TL `0x462390`). Native callers push five arguments,
agreeing with the original zlib header rather than the old four-argument
assembly declaration. The row is now LIBRARY with that compiled provider;
the old source remains inactive history. No wrapper, copied tables or extra
storage was added. Eleven original entries are recovered game C, one is a
library correction, and 45 remain unsupported. This does not earn game
reversing credit or establish original archive selection/native placement.
Evidence: `.scratch/goal90-fixed-trees/`.

Goal91 replaces Gold `0x4c24c0` with its complete 23-byte C body. Native
callers and the existing shared fade implementation establish `void(float, int)`;
the old single-integer contract was incorrect. Both wrapper operands validate.
The shared callee at Gold `0x4241a0` / TL `0x420530` matches all 175 bytes
and all 20 applied operands on both images. Gold now selects that existing C
provider instead of a return-zero placeholder. The one trailing Gold NOP is
excluded by native extent repair, not emitted as source assembly. Correcting
the declaration in `0x4c2480` preserves all 63 bytes, but does not recover that
caller's assembly. The initial 57 now comprise twelve recovered game C bodies,
one library correction and 44 unsupported bodies. No assembly exception or
native storage owner was invented. Fresh raw-link placement remains pending.
Evidence: `.scratch/goal91-sound-wrapper/`.

Goal93 recovers the 63-byte Gold caller at `0x4c2480` by selecting the existing
TL control provider. TL `0x4c2d90` also selects the complete shared 23-byte
wrapper instead of its return-zero placeholder. All thirteen affected contexts
freshly pass RELOC; both controls validate seven operands and both wrappers
validate two. Old files remain inactive history, outside all target source
lists. The initial 57 now comprise thirteen game C recoveries, one library
correction and 43 unsupported bodies. This adds no assembly exception or native
storage. Follow-up raw links and placement checks are pending.
Evidence: `.scratch/goal93-shared-sound-control/`.

Goal98 replaces Gold `0x46c250` with its complete 45-byte C width setter,
using the existing `GuiEnt.w` field and canonical global declaration. Both
operands validate and the full applied native body matches; five rejecting
controls and a bounded 32-bit behavior check pass. The source marker and
assembly blocker are cleared without granting an assembly exception. The
initial 57 now comprise fourteen game C recoveries, one library correction
and 42 unsupported bodies. Goal99 subsequently implemented the called helper
in C, but its129-byte object still differs from137 native bytes. New raw-link
placement is pending. Evidence: `.scratch/goal98-gui-width/`.

Goal105 replaces Gold `0x45dad0` with53 bytes of ordinary C. All six operands
validate, the applied native body is identical, and14 rejecting controls pass.
The assembly marker and blocker are cleared without granting an exception.
The initial57 now comprise15 game C recoveries, one library correction and41
unsupported bodies. No accounted text or native storage owner was added.
A comparison-only array capacity was staged for the next link. Goal106 applied
that scaffold stage;
the fresh source/provider links are unfinished. Evidence:
`.scratch/goal105-color-init/` and `.scratch/goal106-client-cutover/`.

| Class | Files | Finding |
| --- | ---: | --- |
| Initial Gold whole-function naked bodies | 57 | No positive original-assembly receipt; all 57 retained in the snapshot's Gold map |
| Retired Gold CRT assembly files | 5 | No active source binding and no contribution in either client map |
| Empty guarded TL naked templates | 14 | No assembly instructions; these are unfinished placeholders, not original assembly |
| Other files containing inline assembly | 71 | Includes repeated fill/copy cores and native INT3; review origin per definition and target |

The initial 57 reconstructions were explicitly tagged `source = "naked"`
with blockers through the locked metadata writer. That snapshot had 19 EXACT
and 36 RELOC byte verdicts; two had no verdict. Those measurements do not
mean the original C has been recovered. E023 remains a failing gate. No assembly
was replaced by guessed C or zero-return stubs in this audit.

## What qualifies

Padding must be evidenced alignment bytes at the actual site, separate from
reachable function code. Scheduling NOPs inserted to influence C code generation
do not qualify. None of the 57 naked bodies is padding-only.

Native INT3 branches are strong evidence for an original assembly statement
on VC6. The repeated 26-byte fill/copy family is a likelihood judgment based
on register invariance across diverse native contexts and operand homing,
including spills/reloads of literal counts. These positive structural observations
are stronger than an unsuccessful C search. Stock-library exclusions and matching
bytes only corroborate them; they do not independently establish authorship or
an original macro name. See [allocator evidence](msvc6-allocator.md#the-prelude-is-hand-written-asm-not-a-compiler-expansion-2026-09-04).

The initial scan found52 current definition/target receipts. The separate TL
registry receipt brought that to53. Goal108 rechecks every one of those definition
hashes and209 distinct native target/core sites, including all60 registry cores
in each client. A one-byte site slide rejects at every core. The literal0x3f0
spill/reload in both client building-table functions is also rechecked directly.
This updates50 older receipts that overstated compiler/library exclusions as
proof; the two registry inference receipts and Gold INT3 receipt are preserved.
Original inline assembly remains a likelihood inference from positive structural
evidence. No finite failed C search proves impossibility, and no macro name or
author is recovered.

The same shared debug-check definition has native conditional INT3 at TL
`0x405197`, `0x4051a4` and `0x4051bb`, within its68-byte body. Its three existing
`__asm { int 3 }` statements are independently scoped to TL as well as Gold,
bringing the count to54 receipts:52 fill/copy inferences and two INT3 target
receipts. No C, assembly, byte verdict or build artifact changes. Two descriptive
function fields (the VFS blocker and SaveBMP8 note) are aligned with this wording;
all identities, STATUS values and verification records are preserved. Receipts
and descriptions use their locked metadata writers. Evidence:
`.scratch/goal108-assembly-provenance/`.

The four previously unscoped W020 sites were then reviewed against their own
native parents: the Gold and TL SaveBMP24 helpers each have two complete fill
cores, and Gold's `fcn_00402370` and `fcn_0040fea0` each have one. All six reject
a one-byte site slide. Four new, target-specific inference receipts cover only
those existing blocks; they recover no helper name or whole function. The final
audit has58 current receipts (56 fill/copy, two INT3) and215 distinct native
core sites. No whole-function naked body receives an exception.

Fresh final all-target lint reports41 E023 errors and zero warnings for each
target. The previous four W020 sites are now supported by their own native
evidence. The41 unsupported whole-function bodies remain failures, and this
review adds no recovered C or accounted text. All completed PE/map hashes are
unchanged; the server image still equals its reference.

A current receipt is not independent reproof of every statement in its prose.
A receipt for Gold does not exempt a TL definition, and an arbitrary blocker or
global compile define grants no assembly permission. The independent review
raised these wording and target-scope caveats; Goal108's scoped native checks do
not replace fresh full-function or raw-link verification.

## Compilation and retention

Current comparison clients use `/OPT:NOREF` because WinMain is still a stub.
That retains contributions of selected objects; it does not compile omitted TUs
or extract every member of an archive. Gold originally used `/OPT:REF`; compiled
COMDATs can therefore be absent from a target image. A public-symbol gap alone
does not identify a discarded function, storage owner, or padding object.

The `.scratch/goal83-*-build-baseline/build` directories were reused and
reconfigured for Goal84; their present link recipes are not frozen historical
evidence. Earlier failed-link maps are empty. Distinguish an existing object,
a selected link input, an archive extraction, and a retained contribution.

Originally compiled code can be discarded while still influencing library
selection, IAT/hint order or relocation reservation. Native source strings,
Rich/linker fingerprints and controlled links can support that history; absence
from the surviving function inventory cannot refute compilation by itself.

The five retired CRT files and the comparison omit lists are build selection
decisions. They must not be described as native linker discards. The initial57
Gold reconstructions were present in that snapshot's built map, so linker
discard could not excuse their assembly. Subsequent C recoveries are described
above; their current-source raw links still require verification.

## Goal88 remaining-list snapshot

This46-row table preserves the byte claims after the first eleven C recoveries.
Five entries subsequently became C or library corrections, leaving41 current
work items. Query `rebrew todo --category naked-reconstruction --json` for the
live list; these historical byte verdicts are not current C-recovery claims.

| Source | Native identity | Stored byte verdict |
| --- | --- | --- |
| [GOLD.fcn_004011a0.c](../src/GOLD.fcn_004011a0.c) | GOLD.0x4011a0 | RELOC |
| [GOLD.fcn_0040cfd0.c](../src/GOLD.fcn_0040cfd0.c) | GOLD.0x40cfd0 | RELOC |
| [GOLD.fcn_0040d1e0.c](../src/GOLD.fcn_0040d1e0.c) | GOLD.0x40d1e0 | RELOC |
| [GOLD.fcn_00418030.c](../src/GOLD.fcn_00418030.c) | GOLD.0x418030 | unmeasured |
| [GOLD.fcn_00423a50.c](../src/GOLD.fcn_00423a50.c) | GOLD.0x423a50 | RELOC |
| [GOLD.fcn_0042ebc0.c](../src/GOLD.fcn_0042ebc0.c) | GOLD.0x42ebc0 | RELOC |
| [GOLD.fcn_004364f0.c](../src/GOLD.fcn_004364f0.c) | GOLD.0x4364f0 | EXACT |
| [GOLD.fcn_0044c5d0.c](../src/GOLD.fcn_0044c5d0.c) | GOLD.0x44c5d0 | RELOC |
| [GOLD.fcn_0044f5f0.c](../src/GOLD.fcn_0044f5f0.c) | GOLD.0x44f5f0 | EXACT |
| [GOLD.fcn_00454500.c](../src/GOLD.fcn_00454500.c) | GOLD.0x454500 | EXACT |
| [GOLD.fcn_0045ca10.c](../src/GOLD.fcn_0045ca10.c) | GOLD.0x45ca10 | RELOC |
| [GOLD.fcn_0045dad0.c](../src/GOLD.fcn_0045dad0.c) | GOLD.0x45dad0 | EXACT |
| [GOLD.fcn_0045f600.c](../src/GOLD.fcn_0045f600.c) | GOLD.0x45f600 | RELOC |
| [GOLD.fcn_00461690.c](../src/GOLD.fcn_00461690.c) | GOLD.0x461690 | RELOC |
| [GOLD.fcn_00465c80.c](../src/GOLD.fcn_00465c80.c) | GOLD.0x465c80 | EXACT |
| [GOLD.fcn_0046c250.c](../src/GOLD.fcn_0046c250.c) | GOLD.0x46c250 | RELOC |
| [GOLD.fcn_00475fe0.c](../src/GOLD.fcn_00475fe0.c) | GOLD.0x475fe0 | EXACT |
| [GOLD.fcn_004788e0.c](../src/GOLD.fcn_004788e0.c) | GOLD.0x4788e0 | EXACT |
| [GOLD.fcn_004790d0.c](../src/GOLD.fcn_004790d0.c) | GOLD.0x4790d0 | RELOC |
| [GOLD.fcn_0047ce20.c](../src/GOLD.fcn_0047ce20.c) | GOLD.0x47ce20 | EXACT |
| [GOLD.fcn_004a8650.c](../src/GOLD.fcn_004a8650.c) | GOLD.0x4a8650 | RELOC |
| [GOLD.fcn_004ac1a0.c](../src/GOLD.fcn_004ac1a0.c) | GOLD.0x4ac1a0 | RELOC |
| [GOLD.fcn_004aca90.c](../src/GOLD.fcn_004aca90.c) | GOLD.0x4aca90 | RELOC |
| [GOLD.fcn_004b3ca0.c](../src/GOLD.fcn_004b3ca0.c) | GOLD.0x4b3ca0 | RELOC |
| [GOLD.fcn_004c2480.c](../src/GOLD.fcn_004c2480.c) | GOLD.0x4c2480 | RELOC |
| [GOLD.fcn_004c24c0.c](../src/GOLD.fcn_004c24c0.c) | GOLD.0x4c24c0 | RELOC |
| [GOLD.fcn_004c60b0.c](../src/GOLD.fcn_004c60b0.c) | GOLD.0x4c60b0 | RELOC |
| [GOLD.fcn_004cd650.c](../src/GOLD.fcn_004cd650.c) | GOLD.0x4cd650 | unmeasured |
| [GOLD.fcn_004ce1b0.c](../src/GOLD.fcn_004ce1b0.c) | GOLD.0x4ce1b0 | EXACT |
| [GOLD.fcn_004d0ca0.c](../src/GOLD.fcn_004d0ca0.c) | GOLD.0x4d0ca0 | RELOC |
| [GOLD.fcn_004d8c70.c](../src/GOLD.fcn_004d8c70.c) | GOLD.0x4d8c70 | RELOC |
| [GOLD.fcn_004ebf60.c](../src/GOLD.fcn_004ebf60.c) | GOLD.0x4ebf60 | RELOC |
| [GOLD.fcn_005115e0.c](../src/GOLD.fcn_005115e0.c) | GOLD.0x5115e0 | RELOC |
| [GOLD.fcn_005116e0.c](../src/GOLD.fcn_005116e0.c) | GOLD.0x5116e0 | RELOC |
| [GOLD.fcn_00511870.c](../src/GOLD.fcn_00511870.c) | GOLD.0x511870 | RELOC |
| [GOLD.fcn_005127b0.c](../src/GOLD.fcn_005127b0.c) | GOLD.0x5127b0 | RELOC |
| [GOLD.fcn_0051ad60.c](../src/GOLD.fcn_0051ad60.c) | GOLD.0x51ad60 | EXACT |
| [GOLD.fcn_005286a0.c](../src/GOLD.fcn_005286a0.c) | GOLD.0x5286a0 | RELOC |
| [GOLD.fcn_0053d6d0.c](../src/GOLD.fcn_0053d6d0.c) | GOLD.0x53d6d0 | RELOC |
| [GOLD.fcn_00552290.c](../src/GOLD.fcn_00552290.c) | GOLD.0x552290 | RELOC |
| [GOLD.fcn_00555410.c](../src/GOLD.fcn_00555410.c) | GOLD.0x555410 | RELOC |
| [GOLD.fcn_00557d80.c](../src/GOLD.fcn_00557d80.c) | GOLD.0x557d80 | RELOC |
| [GOLD.fcn_0056b9f0.c](../src/GOLD.fcn_0056b9f0.c) | GOLD.0x56b9f0 | EXACT |
| [GOLD.fcn_00575900.c](../src/GOLD.fcn_00575900.c) | GOLD.0x575900 | SIZE_MISMATCH |
| [GOLD.fcn_005a9ae0.c](../src/GOLD.fcn_005a9ae0.c) | GOLD.0x5a9ae0 | RELOC |
| [GOLD.fcn_005a9b30.c](../src/GOLD.fcn_005a9b30.c) | GOLD.0x5a9b30 | RELOC |

## Replays and limits

The original all-target lint reported57 E023 files. Goal105 reports41 E023;
the converted C providers and library correction are recorded above. Remaining
bodies still require C reconstruction.
The upstream guard-bypass repair is covered by three regressions;
`REBREW_ALLOW_NAKED` no longer suppresses the diagnostic. Minor padding remains
allowed. Genuinely original naked routines require a separately reviewed exception;
none of these 57 has one.

The switch at `0x575900` exposed a separate extent error: its old EXACT compared
only a 48-byte prefix. Native cases and the internal nine-entry jump table occupy
196 bytes, followed by 12 alignment NOPs. The unchanged existing object now
measures SIZE_MISMATCH48/196; this was an object comparison without a fresh
compile. Its unsupported assembly remains a work item. The unrelated
`lua_version` label at `0x575930` was retired with binding history: that address
is an internal return-one case block. No library provider was established.
Evidence and the previous measurement are preserved in
`.scratch/goal87-switch-review/`.

Detailed machine inventory and independent review notes are in ignored scratch:
.scratch/goal85-asm-audit/{inventory.json,inline-review.md,link-review.md}.
The full C conversion of these bodies, all original link discards, and gameplay
remain unchecked. The client outputs are still comparison builds.
