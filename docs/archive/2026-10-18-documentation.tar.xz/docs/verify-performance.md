# Verification performance — 2026-10-17

`rebrew verify --data` now checks the existing image without scanning or
compiling function sources. The plain command measured **1.598 seconds** here;
exit 1 still correctly reports the client reconstruction's differences.

| Check | Seconds | Result |
| --- | ---: | --- |
| Gold data, dry run | 0.674 | Expected differences, zero function checks |
| TL data, dry run | 0.667 | Expected differences, zero function checks |
| Gold data, normal metadata writes | 1.764 | Expected differences |
| TL data, normal metadata writes | 2.011 | Expected differences |
| Server data, normal metadata writes | 2.066 | 652/652 matched |

These are local measurements, not a benchmark of the full cold source build.
The function cache and comparison baseline were unchanged by the image-only
checks; the dry-run check also preserved all 5,121 existing local cache files.

## Causes and fixes

The old `--data` path unconditionally called the whole function verification
pipeline. It scanned thousands of sources, checked per-function fingerprints,
and compiled or re-extracted/recompared objects after the requested data check.
Changing runners could not eliminate that unrelated work.

The upstream CLI now makes `--data` and `--whole-binary` image-only by default.
Use `rebrew verify --data --functions` for the combined check. Bare `verify`,
`--text`, and explicit source scopes keep their function verification. Image-only
checks do not initialize a compiler runner, clear the function cache, or replace
the whole-function comparison baseline. JSON records `functions_checked`.

Separately, `check_known_bindings = true` previously disabled the verification
result cache completely. It now permits a cached verdict only when the usual
binary and compile-input identities match and every recorded operand still
resolves to its recorded address. Missing evidence, changed addresses, newly
resolved names and disappeared bindings force a fresh comparison. Unchanged
conflicts stay failures. This preserves operand checking rather than switching
it off to obtain cache hits.

The final test run also exposed an in-process path-cache bug: a metadata root
spelled `.` could keep resolving to a previous project after changing working
directory. Cache keys are now made absolute before memoized symlink resolution.
Two regressions cover both `.` and a relative subdirectory, preserving caching
while preventing reads from the wrong project.

Cold MSVC batches also had a command-line overflow: a 4,002-file test produced
36,030 characters, beyond Wine's 32,767-character limit. The failed group could
then fall back to thousands of individual compiler launches. Oversized batches
now use response files, retaining a readable first source for the image wrapper
and preserving argument order. Small MSVC and POSIX batches keep their existing
behavior. A pinned Processor Pack probe produced identical objects through
ordinary arguments and the response-file path. A full cold client build was
not repeated for this fix.

## Runner and caches

The project had no explicit execution backend and therefore used Docker.
`compiler.execution_backend = "unshare"` is now configured after admission
probes passed for SP5 and Processor Pack. This uses the pinned image filesystem
and Wine, with no host compiler fallback. Actual client checks passed: Gold
55/55 EXACT and TL 30/30 RELOC with both operands validated. The CMake build
driver's container-runtime selection is separate from this verification setting.
A server SP5 check also remained EXACT at 33/33 bytes.

The compile cache contains **69,890 entries**, about 200 MiB within its 500 MiB
limit. A repeated Gold check recorded one object-cache hit and zero misses.
Counting filesystem blobs understates its entries because small objects live
in SQLite. A warm object hit still incurs symbol extraction/comparison; a warm
verification-result hit avoids those. CMake build objects are separate and are
not trusted without matching compile-input fingerprints. Backend-specific keys
keep Docker and unshare objects separate, so the first compile under a new
backend can miss without deleting the older cache entries.

## Imported slots

`__imp__EnterCriticalSection@4` and `__imp__LeaveCriticalSection@4` already have
`storage_kind = "import"` metadata and are present in both client PEs. Their
storage belongs to the linker/loader; the functions are provided by KERNEL32.
They need no C bodies or replacement storage. The map's DLL records were
excluded from the data-placement view as well as from ownership attribution.
Placement now includes those slots while static-storage ownership still excludes
them. The CLI shows their native and built addresses as DISPLACED, without
claiming that import-name agreement establishes matching bytes or placement.

Receipts are in `.scratch/goal85-asm-audit/`: live/dry timing JSON, the exact
terminal command output, namespace test results, cache counters and regression
logs. All three raw image hashes remained unchanged. The assembly audit is
tracked separately in [assembly-audit.md](assembly-audit.md).
