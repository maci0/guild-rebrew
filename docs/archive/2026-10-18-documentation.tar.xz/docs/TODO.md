# Current work

Current work: **Goal109 native unshare build runtime, 2026-10-18**. The
[three-binary goal](../goal.md) remains incomplete.

The project already selected `unshare` for compiler verification. The upstream
CMake driver now honors that same project-level setting for CL/LINK/LIB too.
It retains same-path project mounts, nested build cwd, immutable image admission,
clock pinning and response-file rewriting. A native regression exposed and fixed
the `/tmp` project mount-order problem. Both clients' real source objects are
byte-identical across Docker and unshare with the same flags and pinned time.
The existing generated CMake recipes each rebuild one object successfully through
the editable upstream executable, with both jobs concurrent. No full client link
was run; all existing PEs/maps are unchanged. This adds no recovered C or STATUS.
Evidence: `.scratch/goal109-unshare-runtime/REPORT.md`.

The final unrestricted upstream suite now passes **12579 tests, 36 skipped**,
including the earlier text-placement repair. Ruff/format and mypy392 pass.
Access is restored. CMake uses the project-wide runtime; per-target backend
identity and cross-context object-cache reuse remain open capabilities.

Previous checkpoint: **Goal108 assembly provenance review**.

Goal108 rechecks all53 pre-existing assembly receipt hashes and209 distinct
native fill/copy core sites. All60 registry cores in each client are present;
every core rejects a one-byte site slide. The native stored/reloaded literal
count in both client building-table functions supplies a separate structural
observation. Fifty older receipts now state the likelihood inference explicitly,
instead of treating compiler controls or library exclusions as proof. The two
already-qualified registry receipts remain unchanged. TL's three native INT3
assertion branches now have their own target receipt, alongside Gold's, for54
receipts at that stage. The four remaining W020 sites then receive scoped
inference receipts after independent native-parent checks: two fill cores in
each client's SaveBMP24 and one each in Gold's `fcn_00402370` and `fcn_0040fea0`.
All six new sites reject a one-byte slide. The final count is58 current receipts
and215 distinct native fill/copy sites. No source assembly, C bytes or STATUS
changed. Only two descriptive
function fields are aligned with that evidence; identities, verification records
and data metadata are unchanged. The old C-search waiver is historical and grants
no new exception.
Evidence: `.scratch/goal108-assembly-provenance/REPORT.md` and
[assembly audit](assembly-audit.md#what-qualifies).

Final all-target lint reports41 E023 errors and **zero warnings** on each target.
The remaining41 whole-function assembly reconstructions receive no exception.
This review adds no recovered C or accounted text. Completed client PEs/maps are
unchanged; the existing server still equals its reference byte-for-byte.

The latest interruption terminated both resumed builds (Gold near4%, T&L near3%)
and the final upstream suite near98%. Their old handles are missing and no build
process remained at that checkpoint. Access was restricted then: Docker was
denied and upstream was read-only. Goal109 restores access and completes the
upstream suite, as recorded above. The completed PEs/maps below remain unchanged. Gold log:
`.scratch/goal107-text-placement/gold-build.log`; T&L log:
`.scratch/goal106-client-cutover/tl-build-resume.log`. The read-only full-suite
rerun finished with12533 passed,43 skipped and15 failures:11 socket-permission
failures and4 UV read-only-cache failures. It is not a green suite.

The upstream text-placement repair is implemented. The standalone command now
prefers the supplied PE's sibling map; it and `verify --text` fail on missing
expected functions. Shared name conversion preserves decorated identities and
excludes data rows. Seven original regression assertions and an additional corrupt
image case failed before their fixes; all53 focused tests pass again in the
current read-only session. All eight recorded upstream inputs are unchanged.
The initial full
suite passed12554 with36 skipped before that final image-validation correction;
the interrupted final suite is not a pass. Ruff, formatting and configured
mypy392 checks pass. Real client replays find
Gold4557 displaced/1missing and TL4988 displaced/0missing, both exit1.
No game source, metadata verdict or binary bytes changed in this repair. Final
unrestricted full-suite validation subsequently passes in Goal109; fresh client
links remain outstanding.
Evidence: `.scratch/goal107-text-placement/REPORT.md`.

Both client executables and sibling maps exist under `build/` and have preserved,
hash-checked copies in `.scratch/goal106-client-cutover/completed-before-configure/`.
Gold's completed PE is 819200 bytes (SHA-256 `47175181eaf0762c9cad69fe17704f37f82aeddb33521e7ce53c723139836b7d`);
T&L's is 1372160 bytes (`47da69474ecd91472e806bed263271b592e018c09ffb3b954b0b6540116628bb`).
Data-only and whole-image comparisons run without compiling functions. Neither
client is byte-identical or playable: data, sections, imports and resources differ.
The critical-section import slots are present and displaced in both images.

Goal100's three obsolete Gold comparison functions are now removed, and Goal105's
comparison-only color array capacity is applied. Both existing client trees are
reconfigured for the current shared providers. The following Gold rebuild was
interrupted at about 7%; its first resume exited 2 because the Wine lock path was
read-only, and Docker access was denied. Goal107 restored access and resumed
both builds. No dependency checks or object timestamps were bypassed. Compare
the fresh raw links after those builds finish.
The immediate T&L before/after command comparison has 4848 retained rules, exactly
one changed command (the obsolete inverse-helper include path), and no additions
or removals. This does not establish historical source/header inputs.

The standalone `build check-text-placement` command ignored these sibling maps,
reported every function missing and exited 0. A read-only diagnostic using the
same map APIs as `verify --text` finds Gold4557/4558 and TL4988/4988 functions,
all displaced. Goal107 repairs this upstream and records the replay and regression
in its tests and `docs/IDEAS-GUILD.md`. The historical all-missing CLI output is
not a placement pass.
Evidence and exact next commands: `.scratch/goal106-client-cutover/REPORT.md`.

**Goal88 source checkpoint:** eleven of the original 57 Gold whole-function
assembly reconstructions are now C. All six table searches at `0x42c200`,
`0x42c240`, `0x42c280`, `0x42c2c0`, `0x42c300` and `0x42c340` are RELOC with
every operand validated and complete applied native equality. The record search
at `0x4ce130` is RELOC56 with all three operands validated. The record update
at `0x4fe1e0` and list-tail walk at `0x4c0210` are EXACT41 and EXACT29 without
relocations. The stream/count readers at `0x44f680` and `0x44f860` are now
RELOC66 and RELOC70, with all six call operands validated. The latter's C
signature includes the second incoming argument read by native code but absent
from the old assembly declaration. Rejecting controls and focused all-target lint pass. Pointer returns
follow the native callers; no storage or TU reorganization was added. These
replace already-accounted assembly and add no accounted text. Evidence is in
`.scratch/goal86-{table-group,packed-store}/` and
`.scratch/goal87-{review,record-review}/` and
`.scratch/goal88-{save-counter,stream-header,stream-apply}/`.

**Goal89 shared-TU checkpoint:** the additional Gold wrapper at `0x5a89a0`
is now C in the existing TL lookup/wrapper unit. Lookup-before-wrapper order
matches the native register allocation; standalone and callee-last controls
fail. Fresh tests on both clients pass all three bodies (27/31/111 bytes),
with all 14 operands VALIDATED. The remaining Gold caller passes at 28 bytes
with its canonical pointer return. Two list-head identities add no storage.
Both stock `__ftol` helpers have strict native receipts, separately from game
C progress and original archive selection. Retired files remain historical,
outside the generated Gold source list. Focused all-target lint is clean.
Evidence: `.scratch/goal89-tu-wrapper/`.

**Goal90 library correction:** Gold `0x465c80` is zlib's
`inflate_trees_fixed`, not a game getter. The existing vendored C provider
matches all 46 bytes and all four operands on both clients; TL's native address
is `0x462390`. All 4,360 bytes of its private static tables also match each
original and the displaced data in the comparison builds. The old Gold
assembly claim is retired in place; no C wrapper, tables or storage were added.
This leaves eleven C recoveries, one library correction and 45 unsupported
bodies from the initial 57. Library credit stays separate from game progress.
Both native receipts and eight data identities are recorded. Static data
placement in the general verifier remains unresolved; its comparison at the
native addresses still reports drift. Evidence: `.scratch/goal90-fixed-trees/`.

**Goal91 shared sound checkpoint:** Gold `0x4c24c0` is now correctly typed
`void(float, int)` C, RELOC23 with both operands VALIDATED. Its callee at
`0x4241a0` selects the existing TL `fcn_00420530` provider; both complete
175-byte bodies pass with 17 VALIDATED and three explicit IAT_POLICY operands.
Independent full comparison covers all 20 slots on both images. The native
Gold extent repair removes one following alignment NOP. The only other C
declaration was corrected without changing its 63-byte caller object; that
caller remains unsupported assembly. Six unsized identities and audited float
pools per client add no native storage owner. Four real new Gold COFF references
have generated comparison-only placeholders outside recovered sources.
Fresh all-target lint now has 44 E023 errors per target and unchanged warnings
(server 0, TL 1, Gold 3). Twelve original entries are recovered game C, one is
a library correction, and 44 remain unsupported. The 175-byte Gold callee is
an additional real C provider; the 23-byte wrapper was already accounted as
assembly. Evidence: `.scratch/goal91-sound-wrapper/`.

**Goal93 shared sound control:** both clients now select the existing 63-byte
control and 23-byte wrapper C providers. All thirteen affected definition/caller
contexts freshly pass RELOC; the control's seven operands and wrapper's two
operands are VALIDATED on each image. Four unsized identity rows per client
add no storage. The retired assembly and stub files remain inactive history.
Two obsolete comparison functions were removed from the scaffolds. The initial
57 Gold entries now comprise thirteen recovered game C bodies, one library
correction and 43 unsupported bodies. All-target lint confirms 43 E023 errors
per target, with unchanged warnings (server 0, TL 1, Gold 3).
Evidence: `.scratch/goal93-shared-sound-control/`.

**Goal98 GUI width setter:** Gold `0x46c250` is now C using the canonical
`GuiEnt` declaration, with compile-time checks for stride `0x2ec` and width
offset `0x14`. Fresh official verification is RELOC45/45 with both operands
VALIDATED; independent full native equality and five rejecting controls pass.
A bounded 32-bit C89 check verifies truncation, unchanged neighboring bytes
and helper call order. The second full-width argument carrier is inferred;
only its low word is used. Its called helper remains a stub. No storage,
extent, header or scaffold changed. The original 57 entries now comprise
fourteen game C recoveries, one library correction and 42 unsupported bodies.
All-target lint reports 42 errors per target and unchanged warnings
(server 0, TL 1, Gold 3). The running Gold pass predates this source replacement;
the later incremental build and raw placement checks remain pending.
Evidence: `.scratch/goal98-gui-width/`.

**Goal99 GUI centering helper:** `0x46c1c0` now implements the flag-gated
parent/screen centering behavior in C. Native callers establish one cdecl
index and discard EAX; its one C caller now agrees on `void(int)` without
changing any non-CodeView section or relocation. The caller freshly remains
RELOC45 with both operands VALIDATED. The helper itself is 129 bytes against
137 native code bytes and honestly records SIZE_MISMATCH, with a remaining
register/scheduling gap. Bounded 32-bit C89 branch/halving checks and focused
all-target lint pass. No new storage, header, scaffold or assembly was added.
Guarded native inventory repairs exclude seven trailing NOPs and separate
the independently called 557-byte position helper at `0x46cd90` from the
preceding 21-byte wrapper; the position helper still has no source provider.
The initial named audit rejected concurrent input changes. Its stable rerun
has no selected signature finding; unknown SDK/include contexts remain
explicit. New incremental client links and raw placement are pending.
Evidence: `.scratch/goal99-gui-center/`.

The named contract audit exposed repeated shared-header extraction per
including unit and repeated AST walks per global. That upstream performance
bug is repaired without combining semantic contexts. The new regression
fails before the fix and preserves contexts/findings/calls afterward. All
12,549 upstream tests pass (36 skipped), as do Ruff, formatting and mypy 392.
The warmed 12-unit fixture is about 21x faster with complete reports equal.
The complete real all-target report is also equivalent to the pre-fix result,
including input hashes and all unknown contexts. It took 133.44 seconds; no
controlled pre-fix whole-project timing is available. Evidence is in the same
Goal99 directory. This does not change the CMake Docker/backend limitation.

The previous build-resume checkpoint is superseded by Goal106 above. Both
completed comparison artifacts remain available; current-provider client links
are still pending. The server retains raw identity, 316/316 EXACT
functions and 652/652 data comparisons; unsupported assembly still fails lint.
The upstream rename repair passed 12,546 tests with 36 skipped, Ruff and mypy.

The earlier FastRouter Build workers stopped on exhausted usage balance.
The native Paseo `grok-4.7` workers delivered partial TL implementations and
are now archived, with their sources and receipts preserved for review. Their
runtime reported high thinking despite accepting low; that discrepancy remains
unresolved. The replacement free pool also exhausted its usage quota and is now closed, detailed below. Earlier getter, color,
slot-clear and callback investigations remain scratch-only.

**Goal94 TL slot cleanup:** `0x4be530` now contains the complete eight-slot C
walk using the existing slot access view and helper. The native loop compares
32-bit addresses as signed integers; preserving that condition removes the
unsigned-branch mismatch. Official verification is RELOC33/33 with all three
operands VALIDATED. Independent complete native equality and six rejecting
controls pass. The 32-bit C89 behavior check covers empty, mixed, full and
helper-mutated slot lists. Focused all-target lint passes. The contract audit
finds no selected disagreement but retains unknown SDK/include contexts.
No storage, header or native extent was changed. This new TL body is separate
from the original Gold assembly recovery count. Evidence:
`.scratch/goal94-slot-cleanup/`.

**Goal95 shared cleanup and release:** Gold `0x4bdca0` now selects the same
33-byte cleanup C as TL `0x4be530`. Both freshly pass RELOC33 with all three
operands VALIDATED, full native equality and six rejecting controls per image.
The Gold inventory had coalesced its15-byte tail-call helper with this separate
called entry; a guarded native repair now separates them. No new storage or
placeholder was added. Current source selection is Gold4470, TL4841 and
server43. The running Gold Make tree predates that new provider; a later
batched configure is required. Evidence: `.scratch/goal95-slot-sharing/`.

The first worker's TL `0x41f5f0` release body also passes fresh RELOC46 with
all three calls VALIDATED and seven rejecting controls. Root repaired its
native extent64 to46; the excluded tail includes an unattributed `ret`, which
was not disguised as padding. The 32-bit C89 null/hit and helper-order checks
pass. The subsequent root review integrates the lookup contracts under Goal100.
The previous worker pool is now closed. None of these results
establishes complete raw-link placement. Evidence:
`.scratch/goal95-ui-release-review/`.

**Goal97 registration review:** the worker's TL `0x4bcab0` body now has fresh
RELOC42 verification with all five operands VALIDATED. The two existing data
rows have their C names without any storage/extent/owner claim. Correcting its
direct caller's pointer-return declaration preserves the complete 88-byte
object contribution and all relocations. Registration, cleanup and initialization
all freshly pass RELOC; the initialization's seven string operands remain
unresolved. Focused lint passes on all targets. The deeper resource-provider
pointer/input contracts remain explicitly open. Evidence:
`.scratch/goal97-registration-review/`.

The radius-search implementation at TL `0x4cec00` has a reviewed native extent
of225 code bytes, excluding15 NOPs; its old function size41 truncated an
instruction. Inventory and function extents are corrected independently of
matching. The current C object is223 bytes and records SIZE_MISMATCH. Eight
native internal branches and both returns were checked; bounded grid behavior
checks pass. No assembly, padding or full byte match is claimed. Evidence:
`.scratch/goal94-4cec00/root-CURRENT.json`.

An inline width-accessor experiment still emits 223 bytes and was not integrated.
It supplies no original-assembly evidence. Evidence:
`.scratch/goal98-width-accessor/`.

All three OpenCode Space Bunny Free workers exhausted the provider's free quota
without delivering an implementation and are closed. The runtime audit did
confirm the requested free model and low thinking. Root reclaimed the assignments;
no paid replacement was launched. Evidence: `.scratch/goal100-worker-handoff/`
and `.scratch/goal96-workers/CURRENT.json`.

**Goal100 shared video-list review:** both clients now select the same 31-byte
ID lookup, 34-byte handle lookup and 46-byte release C definitions. Fresh official
verification passes Gold8/8 and TL16/16 contexts; the six core bodies match every
applied native byte with rejecting controls. Caller/allocator/unlinker object
preservation, a bounded32-bit C89 fixture and focused all-target lint pass.
Selected-name contract audits find no contradictions, with SDK/include unknowns
still explicit. The inferred declaration header and unsized head identities add
no storage or owner claim. Historical Gold files remain inactive. The completed
Gold build predates these provider bindings. Goal106 applied the three guarded
comparison-function removals after its terminal result and reconfigured both
client trees. Fresh raw-link placement and organization remain unverified.
Evidence: `.scratch/goal100-video-lookups/REPORT.md`.

**Goal101 TL name lookup:** `0x432410` now has complete C and fresh EXACT111
verification without relocations. The inferred two-pointer contract has no
known direct callers. The signed-count, case-sensitive first-match lookup passes
32-bit C89 boundary cases and focused all-target lint. Shifted-window, changed-byte
and alternate-schedule controls reject. No native extent, data owner, header or
scaffold changed; fresh raw-link verification remains pending. Evidence:
`.scratch/goal101-name-index/REPORT.md`.

**Goal102 TL action index:** `0x51fd00` now implements null-to-minus-one and the
unsigned queue-address difference divided by0x194. The two native callers
consume indexes; no C caller required a prototype edit. Both native and compiled
bodies are39bytes, but only17 applied bytes agree, so the official verdict is
STUB despite the complete behavior implementation. Its single global operand
is VALIDATED. Nine32-bit C89 cases and focused all-target lint pass. The separate
native extent repair excludes nine following NOPs. An existing unnamed data row
gains its existing C name without storage, size or owner. No assembly or new
comparison stub was added. Evidence: `.scratch/goal102-action-index/REPORT.md`.

**Goal103/104 queue controls:** six small action-index flag controls did not
improve the17/39 match, so production flags are unchanged. The inverse helper
now shares one pointer-typed C definition on Gold0x51ad90 and TL0x51fd30,
reusing the existing404-byte queue view. Both freshly pass RELOC30 with their
single operand VALIDATED, full applied native equality and three rejecting
controls per image. The32-bit valid-index fixture and focused all-target lint
pass. No header/type/storage/extent changes or new accounted text result.
The obsolete TL absolute include flag is removed. The existing live Gold Make
tree must switch from its unchanged historical source at the same later batched
configure as the Goal95/100 providers. Raw links, data, imports, placement and
organization remain pending. Evidence: `.scratch/goal104-queue-pointer/REPORT.md`.

The reviewed stream cutover is applied across 65 source paths. TL's byte/dword
readers now have separate providers calling native `vfs_ReadData` at `0x4306b0`;
Gold retains its `0x430bd0` provider. Fresh scoped verification covers 98
definitions in 84 translation-unit/target contexts: server 11/11, Gold 28/37,
TL 45/50. Remaining failures are incomplete bodies, size mismatches or typed
stubs; these signature edits do not implement them. Both new TL wrappers are
RELOC23 with their call operands VALIDATED. The VFS definitions' `char*` stream,
the unsigned return view in `fcn_004acc00`, and the unbound TL string reader
remain explicit contract/provider debt. Five placeholder blockers are documented.

The `0x575900` audit corrected a false full-body EXACT: its unchanged object
contains 48 bytes of a 196-byte switch/table extent and now records
SIZE_MISMATCH. The interior `lua_version` claim at `0x575930` is retired with
history. Its assembly remains unfinished; no guessed C or padding was landed.
**Goal105 Gold initializer:** `0x45dad0` is now ordinary C with fresh RELOC53,
all six operands VALIDATED and complete applied native equality. Fourteen
rejecting controls pass. The assembly marker/blocker are cleared; the original57
now comprise15 game C recoveries, one library correction and41 unsupported
bodies. Full all-target lint confirms41 E023 each (warnings server0/TL1/Gold3).
No new accounted text, native extent or recovered storage results. A comparison-only
24-byte array was staged with Goal100's three stub omissions; Goal106 applied
the compiled stage after Gold's terminal build result. The Gold name-only
identity has no native owner or complete extent. Current C linking and fresh
raw-link placement remain pending. Evidence:
`.scratch/goal105-color-init/REPORT.md`.
See `.scratch/goal87-switch-review/REPORT.md` and
`.scratch/goal87-field-updates/REVIEW.md`.

**Goal85 tooling checkpoint:** plain `rebrew verify --data` now completes in
1.60 seconds here without a function compile pass. Known-binding result caches
are reused safely, oversized MSVC batches use response files, and relative
metadata roots stay independent across project changes. Verification now uses
the configured namespace runner. Upstream validation: 12544 passed, 36 skipped;
Ruff and mypy 392 pass. [Details and timings](verify-performance.md).
The [assembly audit](assembly-audit.md) records the initial 57 Gold
whole-function reconstructions and the remaining 41; byte verdicts do not mean
recovered C.

**Goal84 comparison-build checkpoint:** both raw client executables and linker
maps now exist under `build/`. Gold is 819200 bytes; GoldTL is 1372160 bytes.
Data and whole-image comparisons run on both and report expected differences.
The latest completed maps contain 2893 Gold and 2960 GoldTL build-only symbols;
Goal106 subsequently changes the Gold scaffold before its next link. Neither
client is a playable or byte-identical reconstruction. These placeholders do
not establish native allocations or ownership. [Build and comparison recipes](../stubs/README.md).
Receipts are in `.scratch/goal84-client-build/`.

The shared duplicate-provider guards preserve eight complete server objects.
The server rebuilt and passes 316 functions, 652 data comparisons and whole-file
verification, retaining SHA-256
`3cc2ce9049e41ab6d0eea042df4966fbf57e5e27c67fb923e81709d2683609d1`.
Upstream stub generation now handles decorated calls, source typedefs and
parameter-name collisions: 68 focused tests and 12524 full-suite tests pass,
with 36 skipped; Ruff and the configured 392-file mypy check pass.

## Next actions

1. Continue VFS/loadsave and scene-loader contracts beyond the verified stream boundary.
   Constructors, filename opener callers, receiver and selected loadsave readers
   now carry opaque pointers. Complete sections and relocation targets are
   preserved in 87 compiler contexts / 140 bound definitions. The private
   24-byte `VFS_FILE` remains a directory entry; stream allocation is 320 bytes.
   `ahm_AllocAhmInfo` now also carries an opaque stream. All 87 final object
   contexts pass preservation. The refreshed server gate passes every non-lint
   check; its overall result still fails project lint. Named contract audits
   report no selected contradictions; SDK/include/parser unknowns remain.
   The download-buffer integer field/layout span is a separate storage review.
   TL building reader `0x522510`: all 1,455 body bytes and 63
   operands pass independent proof; one following NOP was removed from its native
   function extent through the reviewed CLI. Root integrated the canonical
   loadsave header; CLI records RELOC1455 with 62 validated operands and only
   `_realloc` unresolved. Five native data identities add no C storage or owner.
   Town reader `0x524040` now records RELOC1478 after the success-path copy
   materializes its destination first; all 1,478 bytes and 58 native operand
   slots independently agree. Final catalog evidence is 56 validated slots and
   only `_sprintf` / `__strlwr` unresolved. Two additional unsized base identities
   and the complete 24-byte format literal allocate no storage. Native extent repairs separately
   exclude ten alignment NOPs after each town/dialog body.
   TL `0x448360` now has a complete C body, currently SIZE_MISMATCH1353/1406.
   Its native38-call set and literal contents agree; shifted84 operands are not
   native-site validation. The native extent separately excludes2 alignment NOPs.
   Gold `0x44be60` is complete C1428/native1417 after correcting its clone helper to one pointer. Gold resource finalizer `0x461080` is RELOC166 with all166 applied bytes and6 native operands equal; its worker remains549/native563.
   Canonical callbacks/context and Gold resource types preserve21 compiler
   contexts. Pointer-global and primitive-reader closure remains open; the old
   Gold vector-reader bug claim is stale.
2. Replace remaining unsupported client assembly. Latest all-target lint has
   43 errors, with 0/1/3 warnings in SERVER/TL/Gold. The upstream E023 repair
   exposes bare-block assembly previously missed; it does not represent new
   assembly. Gold resource replacement/release thunks now have61/55-byte C
   bodies with complete native operand proofs. Their coupled callers verify.
   The upstream lint, address-comparison and archive-inspection fixes pass12,497 tests with36 skips. Gold dialog callback `0x41c830` now has complete C,
   NEAR_MATCHING1830 with 17 stack-slot bytes and one SIB byte still different.
   Its independent proof validates 108 operand slots; catalog policy/unknowns
   remain separate. Repair inline-assembly warnings and missing STUB blockers. The stale
   `event.validator_view` evidence is refreshed on both clients with current
   compiler-checked20-byte stride and RELOC630 verification. Preserve the strict private `_holdrand`
   rejection; do not invent its storage or raw-link provider.
3. Adopt shared838-byte `cm_ExCreateGeb` after closing its remaining VFS,
   model-load and rendering providers. Placement declarations/factory formal
   repair are integrated; numeric `0x442d50` remains explicit. The current TL data scan reports seven declaration conflicts, including the new
   scene pointer views; the last Gold scan reported one. Sized identity metadata
   does not reconcile C declarations. Continue the Goal72
   large-function, credit and terrain maps; Gold `0x422dc0` has no recovered C.
4. Keep separate iterator/GUI/scene-command providers until complete client
   organization baselines exist. The reviewed scene-command merge is unsafe
   without those raw baselines; no move/merge was applied. Native alias and
   complete Docker SDK-context audit gaps remain recorded upstream.
5. Complete client raw images, providers, data, placement and ownership checks.
   Both clients select the hash-pinned Miles6.1c archive. Preserve the server, including
   discarded source affecting linking; do not substitute compatible archives.

## Goal83: active integration

Root receipts are `.scratch/goal83-scene-contracts/`,
`.scratch/goal83-resource-thunk/`, `.scratch/goal83-sprite-release/` and
`.scratch/goal83-upstream-lint/`, `.scratch/goal83-upstream-xrefs/`,
`.scratch/goal83-finalizer-globals/` and `.scratch/goal83-scene-data-integration/`. The live ownership registry is
`.scratch/goal83-scene-contracts/coordination.json`. Ten Grok workers are delegated: client link/CMake repair, Gold exact-C integration,
TL worker matching, plus entrypoints, duplicate command providers, global owners,
CRT providers, stream contracts, resource lookup and terrain integration packages.
Production write scopes stay exclusive; seven supporting tracks are scratch-only.
Root coordinates and reviews cross-target results.

The cdecl callback keeps three full integers, and Gold selectors remain full
integers even where native code separately tests the low byte. The TL20-byte
context and Gold0x80 resource stride/offsets are compiler-checked. These records
are inferred declaration views, without storage-owner claims. All21 first-stage
complete objects preserve their code/data/relocation destinations. Later Gold
resource integration preserves9 complete objects and the61-byte thunk body;
the unimplemented destructor's void signature removes its fabricated EAX=0.
Both resource creator/destructor bodies remain placeholders with blockers.

Gold node release becomes55-byte C. Three affected bodies total147 native bytes
and10 validated operands, with wrong-symbol/site controls; two other complete
objects are unchanged. Five production functions reverify RELOC. The table stays
unsized and declaration-only. These116 newly reconstructed C bytes were already
accounted as assembly; they are not additional accounted text or raw-link proof.

The event validator view is re-reviewed and compiler-checked on both clients;
its shared630-byte definition remains RELOC on both. No source or storage changed.
Current warning counts are8/9/12 for SERVER/TL/Gold.

The upstream lint fix reuses the MSVC token scanner for bare assembly blocks,
labels, comments and surrounding C. Sixteen new regressions and369 targeted
parser/lint tests pass; the final complete suite is12,492 passed/36 skipped.
The first full run's onboarding failure passed alone and in the final full run.
The fresh server gate completed:316/316 functions,652/652 data and all286720 raw bytes remain identical (SHA-256 `3cc2ce9049e41ab6d0eea042df4966fbf57e5e27c67fb923e81709d2683609d1`). Every non-lint check passes; overall gate remains failed by65 E023 errors.
The166-byte Gold finalizer now has complete native code and six operand-slot
proofs, with rejecting controls. Three named scalar declarations add no storage
or owners, and eleven other complete objects stay unchanged. The corrected
worker call is `(name,resource)`; fifteen legal variants did not improve its
549-byte body. Its native563-byte body remains unmatched.

TL scene metadata adds four sized scalar views, three unsized bases and three
complete literals; the existing vector row only gains its section. No storage
or allocation owner was assigned. Known-binding checks now reject82 shifted
operand sites, leaving two CRT operands unresolved. The1353-byte body remains
unmatched against1406 native bytes. Gold's one-argument clone call is corrected;
its complete1428-byte loader still mismatches1417 native bytes, excluding seven
alignment NOPs. The Gold clone-list helper is integrated as136 code bytes, excluding eight
alignment NOPs. All136 image bytes and9 catalog-validated operands agree. The list head is a
4-byte alias at the unsized sentinel+0x1f4; no storage owner or full static
extent is claimed. Across54 compiler contexts,53 other complete non-CodeView
objects preserve their sections and operands. The fresh server gate retains
316 function matches,652 data matches and full286720-byte raw identity; its
known65 lint errors and8 warnings remain. TL terrain and client read-body
recovery continue in scratch.

TL default action callback `0x4079d0` now has a30-byte C body and complete
native operand proof. Its registry/constructor declarations share the existing
queue header;44 other complete objects preserve all sections and relocations
across45 compiler contexts. Coupled verification completes with54 matches and6 existing weak results across60 definitions. The named contract audit has no selected findings; include/parser unknowns remain.

The shared xref scanner now reports image-valued comparison immediates separately
from memory accesses. Three new regressions failed before repair;60 focused
tests and the full12,495-test upstream suite pass. Indexed/register-relative
references and complete allocation extents remain unresolved.

Stock CRT review finds complete code candidates for TL realloc815 and
sprintf82, but45/two strict operands remain unresolved. Full111-byte swprintf
is rejected despite its prefix candidate. No native identity, provider or extent
was promoted. Archive inspection now distinguishes absolute COFF symbols from
storage; the final upstream suite passes12,497 tests with36 skips.

Native primitive review identifies forwarded integer read results and a returned
NUL pointer; loader void declarations do not establish those return contracts.
TL4011f0 reads a dword; Gold4011f0 writes a by-value byte. TL string-reader
claim naming a source with no definition was retired through the guarded
binding workflow; its native extent/history remain, with replacement pending.
The shared byte/dword wrappers reference a Gold-only callee name in TL. Read-body recovery and a
reviewed primitive cutover remain open; no provider merge was applied. The shared four-dword reader now uses the inferred
name `ReadVfsFourDwords`, separating TL4012b0/Gold401270 from Gold4012b0
(three-dword write); both53-byte bodies and all four operands per body remain
identical. Provider-aware
rename/binding previews refuse the independent same-name VFS definitions; the
capability gap is recorded upstream. TL terrain scratch C is complete but
unmatched (1189 or1166 versus1319 native bytes); its constructor/resource
contracts are under review before integration.

The client build preparation found a Miles6.1c SDK archive whose bundled DLL
exactly hashes to the Guild runtime backup. All351 SDK hint/name pairs and
all51 TL/31 Gold reference imports agree, including real isolated LINK probes.
Both clients now select the pinned pristine archive, checked during configuration
and immediately before linking; independent archive review confirms the pin and
interface, without establishing the original linker's archive selection. Gold's
generated object uses PP /ML and agrees with pinned verification on code and
default-library directives. TL configuration succeeds; complete client builds
and raw comparisons remain open. The upstream CMake
source-list scoping bug is repaired: two before-failing regressions,16 focused
tests and12,499 full-suite passes/36 skips. A one-file request now emits just
that source and the selected target macros. Gold RNG legacy include-path flags
were removed after whole-object preservation; all six bound Gold definitions
reverify RELOC, resolving that TU flag conflict.

A subsequent upstream fix makes contract/organization scans use the compiler's
implicit shared source root. The nested-header regression fails before and
passes after; final focused checks pass215 tests/1 skip and the complete suite
passes12,501/36 skips. The selected organization replay now fingerprints
ch_script.h with no missing local include; client raw baselines remain absent.
The fresh server rebuild remains fully raw-identical (316 functions,652 data,
Wine exports/imports/layout pass). The gate still has65 lint errors/8 warnings.
Its false-positive client PP pin was corrected to inspect generated server rules;
12 project tests and the actual server pin block replay pass.

Both actual client builds compiled every selected C source:4,482 Gold and4,840
TL objects, with zero compiler errors. Their raw links failed: Gold reports47
duplicate definitions and2,944 unresolved symbols; TL reports46 and3,006. Both
include unresolved WinMain. Neither emitted the target executable. The build
supervisors errored after those terminal logs; no compiler/build processes remain.
The production-input freeze is lifted. Preserve the logs/objects in the original
baseline directories and `.scratch/goal83-client-link-baselines/`; these failures
provide no complete-image placement/import/organization baseline.

Entrypoint review identifies the existing Gold0x53cf50/TL0x544c50 game entries
as stdcall WinMain4args: both native startups push four arguments and every
native user-entry return pops16. Existing cdecl main(void) stubs emit `_main`,
causing `_WinMain@16` to remain unresolved. The entrypoint worker is assigned
an upstream rename-reference bug (comments, script string and local `main`
misclassified as references), full regression/suite, then the managed ABI/name
cutover. This repairs the existing placeholder's interface; its1856-byte body
is still unreconstructed. Gold's separate entry0 CRT-startup claim needs strict
operand proof and guarded retirement; no new startup provider is accepted.

Gold0x41c420 is integrated as55-byte C, fresh officialEXACT with0relocations.
Native inventory64→55 excludes nine alignment NOPs. Old/new complete non-CodeView
object sections and GoldLIBC directives are identical; focused lint changes one
E023 to0errors/0warnings. The old assembly was alreadyEXACT, so this improves
source fidelity without adding accounted text. The staged47-byte cursor writer
Gold0x461e60 is assigned for the next measured C integration. Receipts are
`.scratch/goal83-gold-depth-mask/REPORT.md` and `triage/REPORT.md`.

The combined-target CMake fixture exposed another upstream bug: including a
second flag table overwrites a shared source's first target flags and macros.
`--cmake-target` now scopes generated source properties to the consuming build
target. Both actual CMake inclusion orders and rejecting controls pass24 focused
tests; the full upstream suite passes12,509 tests with36 skips. The client-link worker applied the scoped helper and all three call sites,
removed an obsolete source-wide zlib `/O2`, and verified all three generated
compile contexts in one combined tree (configure0; unchanged source lists).
A fresh complete server gate is assigned after the CMake repair; stock WS2_32
ordinal-import provider proof is pending before client library selection changes.
Detailed link scope is `.scratch/goal83-client-link-repair/SCOPE.md`:93 duplicate
rows comprise49 cross-target shared-TU definitions,33 same-target symbol
collisions,9 storage duplicates and2 unbound Gold providers. Both original
isolated client baseline attempts are now terminal; their single-target contexts were unaffected
by this combined-target bug. The terrain-constructor subtask hit repeated
service errors. Root completed its scratch C89 body:1,567 versus1,695 native
bytes,42 COFF slots and the same21 intended direct-call targets in order. Four
native aligned-copy preludes are absent from standard C output. No production
body or verdict changed; receipts are `.scratch/goal83-tl-terrain-constructor/`.

A scratch return-only repair for the bitmap-name helper fcn_0045be40 preserves
complete non-CodeView objects in both clients. Native/caller evidence shows its
current void return is wrong; its output buffer pointer is consumed. The worker's
fcn_0045f9e0 reference-binding preview selects this existing Gold identity. The
return/input carrier closure and production drop remain pending while raw builds
run; receipts are `.scratch/goal83-resource-name-contracts/`.

A full TL resource-worker C candidate is264 bytes with235 same-offset bytes
equal. The private0x70 record view is compiler-checked;29 scheduling/register
bytes remain. Keeping the mip value in a local preserves the native word read
with the existing byte parameter, so push width does not justify widening it.
Production is still the stub pending caller/header closure and matching. Evidence:
`.scratch/goal83-tl-resource-worker/REPORT.md`.

Neither client has a verified complete raw image. Source contracts and matching
for the scene loader, primitives and universe/resource providers remain open.

## Goal82: stream contracts and savegame readers

Root changed the shared stream API and coupled callers while retaining full
compiled code/data/rdata/bss bytes, external relocation names and internal
section/offset targets. Compiler-local label renumbering is checked by its actual
target, with rejecting controls. Receipts: `.scratch/goal82-vfs/`.

TL building reader `0x522510` now has a full C body. Root integration preserves
all 1,455 bytes and 63 relocation records from the reviewed baseline object.
Resolving image operands makes the entire body equal; shifted version data and
wrong reader callees reject. This proof does not establish storage ownership,
library providers or a linked client image. The inventory repair separates the
following NOP from the function. Managed comparison records RELOC1455 with62
validated slots and one unresolved `_realloc`; the separate proof validates all
operands. Identity-only records for three TL dwords and two compiler literals
leave storage owners unresolved.

The town reader measures RELOC1478 after a bounded copy-loop search, using
inherited flags. Its full body and 58 native operand slots agree. The Gold dialog
remains NEAR_MATCHING1830 with 18 real code bytes different; its native operand
proof validates 108 slots. Its bounded follow-up found no closer candidate.
Thirteen Gold declaration identities and two compiler-checked
record strides add no storage or complete array extent. The logger's definition
and other caller now use its existing three-argument header, preserving both
complete objects; its native body remains a zero STUB with an explicit blocker.

Upstream `replace_function_prototype` failed after valid MSVC inline assembly;
it now uses the existing MSVC syntax masker. Four regression cases pass.
The disassembly hex/CFG modes also now honor
`--output` and preview behavior, with 18 regression cases. The final repaired
upstream suite has12,476 passes and36 skips. Prior upstream changes are preserved.
No commit or publication was made.

A fresh server raw relink has zero build errors and all 286,720 bytes equal the
reference. The final full gate completed:316/316 functions,652/652 data, complete
raw-file/section/import/export/relocation/resource/header/layout checks, Wine,
D3DX8 attribution and compiler checks pass. Overall GATE FAIL comes from lint.
Current lint is31 errors and8/10/13 warnings across SERVER/TL/Gold. Data conflicts
remain0/3/1; the newly exposed town byte-array/record-array conflict is fixed by
the canonical declaration, preserving three complete contexts/five definitions.
All 69 scoped matches have current source/header/compiler inputs and native hashes.
All three delegated runs and their follow-ups are terminal. The final three
TL definitions remeasure RELOC with no conflicts after the last data bindings.
Root owns every production source and metadata edit. Current handles
and outcomes live in `.scratch/goal82-vfs/live-verification.json` and
`parallel-agents.json`; the three-binary goal remains incomplete.

| Evidence frame | Goal82 checkpoint |
| --- | --- |
| File agreement | Server: all 286,720 raw bytes identical; clients unverified. |
| Accounted `.text` | SERVER 141,382/141,382; TL 1,128,130/2,491,370; Gold 467,936/2,006,532. Includes library and padding bytes. |
| Game source | New TL building/town bodies add 2,933 matched C bytes (RELOC). Gold dialog has 18 body bytes still different. |
| Data verification | Server 66,664/66,664 bytes; clients 0 (totals 335,380 TL/280,072 Gold). Twenty-one new identity rows create no storage or owner. |

Named contracts have no selected contradictions, with 305/4,102/2,646
SERVER/TL/Gold SDK/include/parser unknowns across the full unpreprocessed reports.
Those partial audits do not establish complete source contracts. All scoped jobs
are terminal; no search, watch or verification process remains running.

## Goal81: VFS closer and reviewed entity-reader call

- TL `CloseVfsStream` (`0x430580`) now verifies RELOC296. Its old body used the
  server pool address. The repair uses the existing TL pool/counter declarations,
  reproducing native EDI allocation without assembly, padding or extra flags.
  Full 296 bytes, all 11 operands and 21 rejecting controls pass independently.
  CLI comparison still reports ten unresolved operand records; native proof is
  separate from canonical bindings, selected providers and raw-link agreement.
- Receiver `0x525b40` remains RELOC824 after two source references are bound to
  `ls_LoadEntities` / `GOLDTL.0x00522e30`. Complete code/data sections and fixup
  sites are preserved; only one callee relocation name changes. Its native call
  and two rejecting controls pass. The callee's weak verdict is unchanged.
- Rebrew wrongly counted a disabled `#if 0` copy as a second provider, and accepted
  a selected provider present only in disabled code. Fixed upstream with seven
  regression cases; unknown/live branches still reject. Full upstream suite:
  12,454 passed, 36 skipped; touched Python passes Ruff/format and source mypy.
  Stale cache-argument test fixtures and API-breaking-change documentation were
  repaired after the first full run exposed nine failures.
- No named storage, data/type rows or data verdicts added. Data type conflicts
  remain 0/3/1 across SERVER/TL/Gold. Constructors/readers
  and real scene-loader bodies remain open. Inherited flags are `/O2 /Gd`;
  obsolete naked permission and redundant override removed through managed tools.

| Evidence frame | Current result |
| --- | --- |
| File agreement | Server: all 286,720 raw bytes identical; clients unverified. |
| Accounted `.text` | SERVER 141,382/141,382; TL 1,125,186/2,491,370; Gold 467,926/2,006,532. Includes library/padding, not source-fidelity proof. |
| Game source | TL closer adds 296 freshly matched C bytes. Receiver 824 preserves its existing match; no pointer cutover claimed. |
| Data verification | Server 66,664/66,664 stored verified bytes; clients 0. Client totals TL 335,380 / Gold 280,072. Declarations/operand content do not establish storage owners. |

Server raw hash remains `3cc2ce9049e41ab6d0eea042df4966fbf57e5e27c67fb923e81709d2683609d1`,
`.text` VirtualSize `0x22846`, 100 imports. No SERVER-bound C/header changed; full
server gate was not rerun. The existing complete gate passes 316/316 function,
652/652 data and all other non-lint checks, including Wine. **GATE FAIL** remains
from lint. Current all-target lint remains 31 errors and 8/10/13 warnings. Native
pool/count operands do not supply a client raw link or source storage owner.

Baseline named contracts expose real constructor/closer contradictions and
122/921/639 SERVER/TL/Gold SDK/include/parser unknowns. They are unpreprocessed,
not passing full contract audits. Both current published comparison input sets
and native reference hashes are checked afresh.

All scoped jobs are terminal; no watch or verification jobs remain live.

Receipts/replay: `.scratch/goal81-vfs/{REPORT.md,close-proof.py,
receiver-preserve.py,inputs-current.py,entity-name-apply.json,status-final.json,
lint-current.json,server-final.json,live-verification.json}`.
Technical evidence: [C shape](msvc6-c-shapes.md#vfs-closer-needs-the-named-counter-object-goal81-2026-10-17),
[object distinction](data-ownership.md#vfs-stream-and-directory-entry-are-distinct-goal81-2026-10-17),
[names](naming_conventions.md#vfs-closer-declarations-and-entity-call-binding-goal81-2026-10-17).
Goals75–80 and their receipts are in [history](goal-history.md).

## Goal73: placement callback adopted

- Both transform providers now take `char*` and recover their private node view
  locally. TL `0x455350` and Gold `0x458a10` remain EXACT 254. No caller
  translation unit was edited.
- The placement-search callback is `src/GOLDTL.fcn_00598550.c`. TL `0x598550`
  and Gold `0x58fc80` are RELOC 148/148. Gold calls the real `fcn_00458a10`;
  both call the shared bounds helper. Known bindings validate those two callees.
  Compiler-literal and CRT operands stay unresolved names. Stock `LIBCMT`/`LIBC`
  whole-body probes miss.
- Each client's 224-byte inventory span was the existing 62-byte RELOC
  `fcn_00598510`, two NOPs, this 148-byte callback and twelve NOPs. The shrink
  matches the existing function metadata and does not change that verdict. The
  callback adds **148 matched bytes per client**. Accounted text is now TL
  1,123,923 / 2,491,370 and Gold 419,026 / 2,006,532. Server remains 141,382 /
  141,382, file-identical.
- Fresh Gold bounds verification: 27 passes and two pre-existing weak results,
  with status writes. The current-tree server gate passes, including raw-file
  identity and Wine `Init`/`Exit`. All-target lint: zero errors/warnings.
- The removed `cflags_presets` and empty server `crt_sources` entry are still
  the reviewed configuration delta. This tree also renames target `marker` to
  `module`. The passing gate is the current link evidence; it does not prove
  client raw files.

Receipts: `.scratch/goal73/`. The 838-byte building candidate remains in
`.scratch/goal67/create-building/`.

## Goal72: parallel native mapping

- Three large TL functions now have inferred roles and strong Gold counterparts:
  combat results `0x4d6170` / `0x4d4d70`, combat task progression `0x4d8d00` /
  `0x4d76a0`, and round/day refresh `0x540020` / `0x538740`. These map 13,915
  TL code bytes, or 13,948 complete comparison bytes including the task table.
  Original identifiers, source paths and selected providers remain unknown.
- A merged TL inventory entry is separated into the 111-byte name lookup
  `0x432410` and independent 4,850-byte callback `0x432480`, plus 15 verified
  NOPs. No existing source or status claim was truncated.
- Native diagnostics attest `rd_object` at TL `0x447110` / Gold `0x44abb0`.
  Complete comparison extents are 3,348 / 3,432 bytes, including both switch
  tables. Terrain readers `0x447e30` / `0x44b920` remain address-named. Borrowed
  stream ownership, result uses, allocation/cleanup order and real Gold
  differences are pinned; missing contracts prevent source adoption.
- Credit recovery TL `0x5c4ec0` / Gold `0x5b9430` is mapped at 1,095 bytes each.
  Gold `0x501190` is the native counterpart of TL `0x503fe0`, canonically named
  `gm_StartFilteredEntitySearch` without claiming an original identifier or
  source provider. Its complete 284-byte extent includes its local table.
- Both formatter rows retain `fcn_0051af00`: three sibling bodies share the
  `io_Text` diagnostic, so it attests a family rather than a unique overload.
  Their 6,455-byte extents include code, alignment and both local tables. The
  caller matrix includes 933 existing source calls; no broad contract repair
  or library attribution was inferred from masked signatures.
- Fifteen new native-only rows and two existing native-only updates are saved.
  TL lookup's reference SIZE changes 288 to 284, retaining SIZE_MISMATCH and
  historical verification at reference_size 288. Every prior verdict, binding
  and history remains unchanged, including all 6,067 EXACT/RELOC rows. All
  31 pending bounds-repair source hashes still match their compilation receipt.
- Inventory repairs separate 71 TL / 65 Gold trailing NOP bytes without losing
  reference bytes. Embedded tables remain in complete function extents. TL now
  has 1,217 no-source functions / 1,206,761 bytes; the count rises by one because
  the callback is separately inventoried. Mapping adds **zero matched bytes**.
  Accounted TL text is 1,123,775 / 2,491,370 bytes (45.1%), including libraries
  and padding; this batch's increase is verified padding, not recovered C.
- Final all-target lint: zero errors/warnings. All three data scans: zero
  conflicts, duplicate definitions and type conflicts. No production C, data,
  types, config or server inventory changed in this batch. No fresh build,
  commit or push: Docker and `.git` remain denied in this session.

Receipts: `.scratch/goal72/{plan.json,admission.json,preservation.json,
{tl,gold}-extents-{preview,apply}.json,lint-final.json,status-final.json,
data-{0,1,2}.json}`; detailed reports under `large/`, `credit-deps/` and
`scene-deps/`. Native proof scripts pin full spans, tables, branches, literal
references and old claims. Goal71's UI splits, scene-loader ABI, sale controls
and uncompiled credit draft remain in `.scratch/goal71/`; its milestone is in
[goal history](goal-history.md).

## Goal69: adopted and checked

- `client_scene_transform.h` owns `int(float*, float*, float)` for bounds helpers
  TL `0x451840` / Gold `0x453e70`. Removed 23 local declarations; corrected the
  pointer/float arguments of TL `0x402c00`, Gold `0x402720` and TL `0x405d70`.
  No arithmetic, control flow, flags, storage or layout changed.
- Complete paired compilation preserves 64 contexts across 31 files, including
  five weak bodies: code, external operands, local destinations and literals.
  Ten generated `$L` names differ; their destinations agree. Receipt hashes
  still matched at handoff. This recovers access contracts, not original spelling.
- TL verification finished with 32 passes and three old weak results. Gold's
  resumed verifier failed before status writes. All 6,067 prior strong statuses
  and all prior weak statuses were preserved; fresh Gold/server checks remain open.
- Native-only names: attested `init_LoadObjektScene`, TL `0x510c90` / Gold
  `0x50d7f0` (940/938 code bytes), and inferred `SaveBMP24`, TL `0x401ed0` /
  Gold `0x401b90` (439 code + nine NOPs each). These four mappings add **zero
  matched game bytes** and no source/provider/extent claim. Initializer callers
  `0x4e4230` / `0x4e2910` remain separate from preceding 165-byte functions.

## Pending evidence and cautions

- The freshly rebuilt 286,720-byte server image equals the reference. The
  completed Goal75 gate failed lint; its function, data, whole-file and Wine
  load/exports checks passed. Earlier clean-lint/data scans predate the
  unsupported client assembly. No current client data-placement or complete
  source-contract proof follows from those older results.
- An independently written config delta removes MSVCRT/ZLIB `cflags_presets`,
  an empty SERVER `crt_sources` entry and other keys. Public config comparison
  confirms preset changes. A Goal70 public-resolver audit found no effective
  toolchain/flag change in 857 SERVER, 3,908 TL and 2,745 Gold source bindings
  (`.scratch/goal70/config-impact.json`). Preserve and review the edit separately;
  archive selection and fresh raw links remain unverified.
- Placement needs one 84-byte result view, a 132-byte callback context and correct
  Gold iterator/transform providers. The 288-byte iterator candidate matches but
  is unadopted. A transform signature-only typed-node view preserves 254 bytes;
  the 262-byte field rewrite was rejected. The 60-file transform family is open.
- Universe transport spans 129 direct files, expanding to 151 C files plus one
  header and 241 bindings (154 TL / 87 Gold). Native `%s` use supports a `char*`
  record/name view, distinct from the integer index. Prepare resource, iterator
  and owner-field transports for one coordinated cutover. The nine-binding
  CharacterCount control is prepared in scratch only: one uncompiled C89 candidate,
  exact native registrations and 42-byte bodies, plus 14 native-only execution
  cases and six rejecting controls. No global cutover or source verdict is earned.
  Receipts: `.scratch/goal70/count-control/` and `count-review/`.
- Preserve OWN-before-OTHER query order, discarded server inputs and the native
  cutscene allocator-zero read at address 8. Reopen exhausted court, queue,
  office, camera, timer and runner probes only with new evidence.
- Upstream SDK-context replay is committed locally as `7b17d76b`; `make check`
  and commit hooks passed. Push/full pre-push checks and remote state are
  unverified. The native-alias contract gap patch is prepared but unsubmitted.
  Last recorded guild push is `0fce67f5`; neither is a current remote check.

## CURRENT STATE

Historical generated gate snapshot; refreshed by `scripts/gate.sh` when run with
`GATE_LOG`. It does not replace the pending current-tree checks above.

<!-- CURRENT-STATE:BEGIN -->
<!-- generated by scripts/update_state_table.py -- do not hand-edit -->

| Quantity | Value | Source |
|---|---|---|
| verify `passed` | **316/316** | gate's `BASELINE` |
| `.text` residue | **0** | raw-link file identity |
| raw-link `.data` divergence | **0** | raw-link file identity |
| relocation records missing / extra | **0 / 0** | `rebrew verify --whole-binary` |
| raw-link import table | **matches** | gate, round 210 |
| OBJECTIVE GAP (raw link vs reference) | **0** | raw-link file identity |
| ...of which | **0 differing bytes in the common prefix, 0 bytes of size shortfall** | gate's decomposition |
| annotations shorter than the binary | **?** | `rebrew verify --json` |
| `cmake --build` exit | **0** | gate's build step |

<!-- CURRENT-STATE:END -->

## Receipts

Start at `.scratch/goal69/`: `bounds-preservation.json`, `bounds-review.md`,
`bounds-contracts.json`, `preservation.json`, `scope-promote.json`,
`verify-gold.log`, `lint-final.json`, `data.json`, `status.json`,
`external-config.patch` and `external-config-comparison.json`.
Further reports: `transform-contract/REPORT.md`, `iterator-contract/REPORT.md`,
`universe-pointer/REPORT.md`, `native-names/` and `upstream-docs/HANDOFF.md`.
Initializer evidence is in `.scratch/goal68/init-scene/`.

Recorded TL accounting: 1,216 source-less functions / 1,206,828 bytes;
1,123,704 / 2,491,370 accounted `.text` bytes (45.1%). Query current metadata
with `uv run --frozen rebrew status --all-targets --json` before reporting progress.

[Milestones and full historical logs](goal-history.md). Keep this file to current
work: replace completed items, put technical findings in their owning reference,
and link receipts instead of copying session transcripts.
